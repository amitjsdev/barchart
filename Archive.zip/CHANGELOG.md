# Changelog

## [Unreleased]

- User profile page
- Settings page

# [2.1.3] - 2021-01-13

### Changed

- Refactored Survey dashboard to fetch locations using the Locations API

# [2.1.2] - 2021-01-13

### Fixed

- Place Order button in BGI Inventory

# [2.1.1] - 2021-01-12

### Fixed

- Blood Bank Insights module access

# [2.1.0] - 2021-01-12

### Added

- [[LAB-99](https://ormae.atlassian.net/browse/LAB-99)] - Blood Bank Insights module
- [[LAB-80](https://ormae.atlassian.net/browse/LAB-80)] - Days filter to "Average Stock Days" chart in CBB, BBB, & PBB dashboard
- [[LAB-88](https://ormae.atlassian.net/browse/LAB-88)] - Region filter in CBB, BBB, & PBB dashboard
- [[LAB-120](https://ormae.atlassian.net/browse/LAB-120)] - Filters for inventory management
- [[LAB-122](https://ormae.atlassian.net/browse/LAB-122)] - Transfer inventory
- [[LAB-121](https://ormae.atlassian.net/browse/LAB-121)] - Local search bar
- [[LAB-119](https://ormae.atlassian.net/browse/LAB-119)] - Last PPM and next PPM date to be calculated
- [[LAB-118](https://ormae.atlassian.net/browse/LAB-118)] - Alert on PPM Date
- [[LAB-135](https://ormae.atlassian.net/browse/LAB-135)] - Update logo
- [[LAB-134](https://ormae.atlassian.net/browse/LAB-134)] - Add status and Planned/not planned filter
- [[LAB-133](https://ormae.atlassian.net/browse/LAB-133)] - Add Planned /not-planned to Status modal
- [[LAB-131](https://ormae.atlassian.net/browse/LAB-131)] - Bl  oodbank Insights Dashboard


### Changed

- [[LAB-94](https://ormae.atlassian.net/browse/LAB-94)] - Days to OOS chart filter labels

### Removed

- [[LAB-95](https://ormae.atlassian.net/browse/LAB-95)] - Inventory composition chart from all 3 BB dashboards

# [2.0.19] - 2021-01-11

### Added

- [[LAB-114](https://ormae.atlassian.net/browse/LAB-114)] - Download current inventory as Excel in BGI
- [[LAB-98](https://ormae.atlassian.net/browse/LAB-98)] - _Last Updated By_ column in CBB, BBB, & PBB Inventory

# [2.0.17] - 2021-01-07

### Changed

- [[LAB-92](https://ormae.atlassian.net/browse/LAB-92), [LAB-96](https://ormae.atlassian.net/browse/LAB-96)] - Daily Consumption chart X axis with date series and separated Daily Consumption measure into Extraction & PCR

# [2.0.15] - 2021-01-07

### Added

- [[LAB-108](https://ormae.atlassian.net/browse/LAB-108)] - Add KPI card based on Total Samples Received

### Changed

- [[LAB-112](https://ormae.atlassian.net/browse/LAB-112)] - Non-MoH Lab capacity KPI into 2 sections Extraction & PCR capacity

# [2.0.13] - 2021-01-05

### Added

- [[LAB-83](https://ormae.atlassian.net/browse/LAB-83)] - Brand code & NUPCO item code columns in Non-MoH Inventory
- [[LAB-85](https://ormae.atlassian.net/browse/LAB-85)] - Remaining inventory column in NUPCO inventory
- [[LAB-87](https://ormae.atlassian.net/browse/LAB-87)] - Brand filter in Non-MoH Purchase page
- [[LAB-81](https://ormae.atlassian.net/browse/LAB-81)] - Button to download PO as PDF file in Purchase page
- [[LAB-107](https://ormae.atlassian.net/browse/LAB-107)] - New question to Tests section in MoH survey

### Changed

# [2.0.8] - 2020-12-31

### Fixed

- [LAB-93](https://ormae.atlassian.net/browse/LAB-93) - Samples per day & No. of Attendees KPI statistics in BGI dashboard

# [2.0.7] - 2020-12-29

### Added

- [LAB-77](https://ormae.atlassian.net/browse/LAB-77) - Blood bank - Add days filter to Days to OOS chart
- [LAB-79](https://ormae.atlassian.net/browse/LAB-79) - Tooltip to Non-MoH location tabs

### Changed

- [LAB-75](https://ormae.atlassian.net/browse/LAB-75) - Added _Target SLA_ & _TAT_ to TMS ticket PDF
- [LAB-89](https://ormae.atlassian.net/browse/LAB-89) - Update TMS Ticket status chart priorities & color scheme

### Fixed

- [LAB-78](https://ormae.atlassian.net/browse/LAB-78) - Non-MoH Lab capacity chart

### Removed

- [LAB-76](https://ormae.atlassian.net/browse/LAB-76) - TMS Tickets table page limit select input

# [2.0.1] - 2020-12-26

### Changed

- BGI survey access to allow Store in-charge role to Read & Update

# [2.0.0] - 2020-12-25

### Added

- User modules to support access to multiple modules by single user with module specific roles
- Super User role for all modules
- Shared API service for common APIs consumed by multiple modules
- Core services for HTTP & Auth

### Changed

- Access Control Layer
- Modularized Pages
- Separated BGI & MoH into separate modules
- User profile state is now maintained using _UmiJS plugin-initial-state_

### Deprecated

- Apis object is replaced by HttpService, ApiService, and module services (eg. BgiService, MohService, etc...)
- userProfile util is replaced by _UmiJS plugin-initial-state_

# [1.4.12] - 2020-12-23

### Added

- Category and Service Provider dropdown in TMS dashboard

# [1.4.11] - 2020-12-20

### Fixed

- The location filter drop down in BGI

# [1.4.10] - 2020-12-19

### Added

- Close Ticket in TMS

### Fixed

- Download ticket in global search

# [1.4.9] - 2020-12-18

### Added

- BBB and PBB Dashboards
- TMS Ticket Status Chart

# [1.4.8] - 2020-12-18

### Added

- Pending orders flow in Purchase view

### Changed

- Blood-bank subtract daily consumption from quantity in hand

# [1.4.7] - 2020-12-16

### Fixed

- _Total filter tips per type_ question _Other_ option removed in MoH survey
- Logo changed
- Splash screen logo changed

# [1.4.6] - 2020-12-15

### Fixed

- Blood-bank Days to OOS bar chart (NAT) color changed
- Daily test date query changed to _condumptiondate_

# [1.4.5] - 2020-12-14

### Added

- _Total filter tips per type_ question in MoH survey
- Total filter tips measure to _Total reagent stock count_ chart

###

# [1.4.4] - 2020-12-11

### Added

- MoH Dashboard location restriction for Surveyor role

# [1.4.3] - 2020-12-11

### Fixed

- Lab capacity calculation missmatch between KPI card & Chart in Non-MoH dashboard

# [1.4.2] - 2020-12-11

### Added

All the below additions are in Blood bank dashboard

- Total serology tests & Total NAT tests KPIs
- Stock chart with drill down
- Daily tests chart with drill down
- Inventory update response chart
- Days to OOS chart (Serology & NAT)
- Date filter

### Changed

- Removed Dashboard menu item for PBB & BBB users

# [1.4.0] - 2020-11-28

### Added

- Blood bank module

# [1.3.0]

### Added

- Non-MoH module

# [1.2.0]

### Added

- TMS module

# [1.1.0]

### Added

- MoH module

# [1.0.0]

### Added

- Initial release with BGI module
