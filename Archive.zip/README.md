# Lab Pro X

This project is initialized with [Ant Design Pro](https://pro.ant.design).

## Environment Prepare

Install `node_modules`:

```bash
npm install
```

or

```bash
yarn
```

### Start project

```bash
npm start
```

### Build project

```bash
npm run build
```
