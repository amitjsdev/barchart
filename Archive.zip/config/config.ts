// https://umijs.org/config/
import { defineConfig } from 'umi';
import defaultSettings from './defaultSettings';
import proxy from './proxy';
const { REACT_APP_ENV } = process.env;
export default defineConfig({
  hash: true,
  antd: {
    dark: true,
  },
  dva: {
    hmr: true,
  },
  layout: {
    name: 'LabProX',
    locale: true,
  },
  locale: {
    // default zh-CN
    default: 'en-US',
    antd: true,
    // default true, when it is true, will use `navigator.language` overwrite default
    baseNavigator: false,
  },
  dynamicImport: {
    loading: '@/components/PageLoading/index',
  },
  targets: {
    ie: 11,
  },
  // umi routes: https://umijs.org/docs/routing

  /* path: '/',
  component: '../layouts/BasicLayout', */
  routes: [
    {
      name: 'centralBloodBank',
      path: '/cbb',
      access: 'canReadCbbModule',
      routes: [
        {
          name: 'inventory',
          icon: 'home',
          path: '/cbb/inventory',
          component: './BloodBank/BloodBankInventory',
          wrappers: ['@/wrappers/auth'],
          exact: true,
        },
        /* {
          name: 'purchase',
          icon: 'shopping-cart',
          path: '/cbb/purchase',
          component: './BloodBank/BloodBankPurchase',
          wrappers: ['@/wrappers/auth'],
          exact: true,
        }, */
        {
          name: 'dashboard',
          icon: 'dashboard',
          path: '/cbb/dashboard',
          component: './BloodBank/BloodBankDashboard/CbbDashboard',
          wrappers: ['@/wrappers/auth'],
          exact: true,
          // access: 'isCbbUser'
        },
        {
          name: 'instrumentInventory',
          icon: 'exception',
          path: '/cbb/instrument-inventory',
          component: './BloodBank/BloodBankInstrumentDashboard',
          wrappers: ['@/wrappers/auth'],
          exact: true,
        },
        {
          name: 'ticket',
          icon: 'exception',
          path: '/cbb/tickets',
          component: './BloodBank/BloodBankTickets',
          wrappers: ['@/wrappers/auth'],
          exact: true,
        },
        {
          name: 'transfer',
          icon: 'exception',
          path: '/cbb/transfer',
          component: './BloodBank/BloodBankTransfer',
          wrappers: ['@/wrappers/auth'],
          exact: true,
        },
      ],
    },
    {
      name: 'peripheralBloodBank',
      path: '/pbb',
      access: 'canReadPbbModule',
      routes: [
        {
          name: 'inventory',
          icon: 'home',
          path: '/pbb/inventory',
          component: './BloodBank/BloodBankInventory',
          wrappers: ['@/wrappers/auth'],
          exact: true,
        },
        /* {
          name: 'purchase',
          icon: 'shopping-cart',
          path: '/pbb/purchase',
          component: './BloodBank/BloodBankPurchase',
          wrappers: ['@/wrappers/auth'],
          exact: true,
        }, */
        {
          name: 'dashboard',
          icon: 'dashboard',
          path: '/pbb/dashboard',
          component: './BloodBank/BloodBankDashboard/PbbDashboard',
          wrappers: ['@/wrappers/auth'],
          exact: true,
          // access: 'isCbbUser'
        },
        {
          name: 'instrumentInventory',
          icon: 'exception',
          path: '/pbb/instrument-inventory',
          component: './BloodBank/BloodBankInstrumentDashboard',
          wrappers: ['@/wrappers/auth'],
          exact: true,
        },
        {
          name: 'ticket',
          icon: 'exception',
          path: '/pbb/tickets',
          component: './BloodBank/BloodBankTickets',
          wrappers: ['@/wrappers/auth'],
          exact: true,
        },
        {
          name: 'transfer',
          icon: 'exception',
          path: '/pbb/transfer',
          component: './BloodBank/BloodBankTransfer',
          wrappers: ['@/wrappers/auth'],
          exact: true,
        },
      ],
    },
    {
      name: 'branchBloodBank',
      path: '/bbb',
      access: 'canReadBbbModule',
      routes: [
        {
          name: 'inventory',
          icon: 'home',
          path: '/bbb/inventory',
          component: './BloodBank/BloodBankInventory',
          wrappers: ['@/wrappers/auth'],
          exact: true,
        },
        /* {
          name: 'purchase',
          icon: 'shopping-cart',
          path: '/bbb/purchase',
          component: './BloodBank/BloodBankPurchase',
          wrappers: ['@/wrappers/auth'],
          exact: true,
        }, */
        {
          name: 'dashboard',
          icon: 'dashboard',
          path: '/bbb/dashboard',
          component: './BloodBank/BloodBankDashboard/BbbDashboard',
          wrappers: ['@/wrappers/auth'],
          exact: true,
          // access: 'isCbbUser'
        },
        {
          name: 'instrumentInventory',
          icon: 'exception',
          path: '/bbb/instrument-inventory',
          component: './BloodBank/BloodBankInstrumentDashboard',
          wrappers: ['@/wrappers/auth'],
          exact: true,
        },
        {
          name: 'ticket',
          icon: 'exception',
          path: '/bbb/tickets',
          component: './BloodBank/BloodBankTickets',
          wrappers: ['@/wrappers/auth'],
          exact: true,
        },
        {
          name: 'transfer',
          icon: 'exception',
          path: '/bbb/transfer',
          component: './BloodBank/BloodBankTransfer',
          wrappers: ['@/wrappers/auth'],
          exact: true,
        },
      ],
    },
    {
      name: 'bloodBankInsights',
      path: '/bbi',
      access: 'canReadBbiModule',
      routes: [
        {
          name: 'dashboard',
          icon: 'dashboard',
          path: '/bbi/dashboard',
          component: './BloodBankInsights/BloodBankInsightsDashboard',
          wrappers: ['@/wrappers/auth'],
          exact: true,
          // access: 'isCbbUser'
        },
      ],
    },
    {
      path: '/user',
      layout: false,
      // Routes: ['src/pages/Authorized'],
      // authority: ['admin', 'guest'],
      routes: [
        {
          exact: true,
          name: 'login',
          path: '/user/login',
          component: './user/login',
        },
        {
          exact: true,
          name: 'setPassword',
          path: '/user/set-password',
          component: './user/set-password',
        },
      ],
    },
    {
      path: '/',
      component: './Welcome',
      exact: true,
      layout: false,
      // wrappers: ['@/wrappers/auth'],
    },
    {
      name: 'userMangement',
      icon: 'user',
      path: '/user-management',
      component: './UserManagement',
      access: 'canReadUserManagementModule',
      wrappers: ['@/wrappers/auth'], // authority: ['']
    },
    {
      path: 'bgi',
      name: 'bgi',
      access: 'canReadBgiModule',
      routes: [
        {
          name: 'inventory',
          icon: 'home',
          path: '/bgi/inventory',
          component: './BGI/InventoryV2',
          wrappers: ['@/wrappers/auth'],
        },
        {
          name: 'purchase',
          icon: 'shopping-cart',
          path: '/bgi/purchase',
          component: './BGI/Purchase',
          wrappers: ['@/wrappers/auth'],
        },
        {
          name: 'dashboard',
          icon: 'dashboard',
          path: '/bgi/metrics',
          component: './BGI/Metrics',
          wrappers: ['@/wrappers/auth'],
        },
        {
          name: 'survey',
          icon: 'form',
          path: '/bgi/survey',
          component: './BGI/BgiSurvey/BgiSurvey',
          access: 'canReadBgiSurvey',
          wrappers: ['@/wrappers/auth'],
        },
        {
          name: 'imsTickets',
          icon: 'exception',
          path: '/bgi/tickets',
          component: './BGI/IMSTickets',
          access: 'canReadBgiModule',
          wrappers: ['@/wrappers/auth'],
        },
      ],
    },
    {
      name: 'moh',
      path: 'moh',
      access: 'canReadMohModule',
      routes: [
        {
          name: 'survey',
          icon: 'form',
          path: '/moh/survey',
          component: './MoH/Survey',
          access: 'canReadMohSurvey',
          wrappers: ['@/wrappers/auth'],
        },
        {
          name: 'surveyDashboard',
          icon: 'bar-chart',
          path: '/moh/survey-dashboard',
          component: './MoH/SurveyMetrics',
          wrappers: ['@/wrappers/auth'],
        },
      ]
    },
    {
      path: '/tms',
      name: 'tms',
      // icon: 'car',
      access: 'canReadTmsModule',
      // layout: false,
      routes: [
        {
          name: 'tmsDashboard',
          icon: 'bar-chart',
          path: '/tms/dashboard',
          component: './TMS/TMSDashboard',
          exact: true,
          wrappers: ['@/wrappers/auth'],
        },
        {
          name: 'tmsTickets',
          icon: 'form',
          path: '/tms/tickets',
          component: './TMS/Ticket',
          exact: true,
          wrappers: ['@/wrappers/auth'],
        },
        {
          name: 'tmsSettings',
          icon: 'setting',
          path: '/tms/settings',
          component: './TMS/Settings',
          exact: true,
          wrappers: ['@/wrappers/auth'],
        },
        {
          name: 'globalSearch',
          icon: 'search',
          path: '/tms/search',
          component: './TMS/GlobalSearch',
          exact: true,
          // access: 'canStaffAdminSurveyor',
          wrappers: ['@/wrappers/auth'],
        },
      ],
    },
    {
      path: 'redcrescent',
      name: 'redcrescent',
      access: 'canReadRedCrescentModule',
      routes: [
        {
          name: 'inventory',
          icon: 'home',
          path: '/redcrescent/inventory',
          component: './RedCrescent/InventoryV2',
          wrappers: ['@/wrappers/auth'],
        },
        {
          name: 'purchase',
          icon: 'shopping-cart',
          path: '/redcrescent/purchase',
          component: './RedCrescent/Purchase',
          wrappers: ['@/wrappers/auth'],
        },
        {
          name: 'dashboard',
          icon: 'dashboard',
          path: '/redcrescent/metrics',
          component: './RedCrescent/Metrics',
          wrappers: ['@/wrappers/auth'],
        },
        {
          name: 'imsTickets',
          icon: 'exception',
          path: '/redcrescent/tickets',
          component: './RedCrescent/IMSTickets',
          access: 'canReadRedCrescentModule',
          wrappers: ['@/wrappers/auth'],
        },
      ],
    },
    {
      name: 'nonMoh',
      access: 'canReadNonMohModule',
      routes: [
        {
          name: 'survey',
          icon: 'form',
          path: '/non-moh/survey',
          component: './NonMoH/SurveyNonMoh',
          exact: true,
          // access: 'canNonMohUser',
          wrappers: ['@/wrappers/auth'],
        },
        {
          name: 'inventory',
          icon: 'home',
          path: '/non-moh/inventory',
          component: './NonMoH/InventoryNonMoh',
          exact: true,
          // access: 'canNonMohUser',
          wrappers: ['@/wrappers/auth'],
        },
        {
          name: 'purchase',
          icon: 'shopping-cart',
          path: '/non-moh/purchase',
          component: './NonMoH/PurchaseNonMoh',
          exact: true,
          // access: 'canNonMohUser',
          wrappers: ['@/wrappers/auth'],
        },
        {
          name: 'imsTickets',
          icon: 'exception',
          path: '/non-moh/tickets',
          component: './NonMoH/NonMohTickets',
          // access: 'canStaffAdmin',
        },
        {
          name: 'nupco_inventory',
          icon: 'home',
          path: '/non-moh/nupco-inventory',
          component: './NonMoH/NupcoInventory',
          exact: true,
          access: 'canReadNupcoInventory',
        },

        {
          name: 'dashboard',
          icon: 'shopping-cart',
          path: '/non-moh/dashboard',
          component: './NonMoH/Dashboard',
          exact: true,
          // access: 'canNonMohUser',
          wrappers: ['@/wrappers/auth'],
        },
      ],
    },
    {
      layout: false,
      component: '@/pages/404',
      wrappers: ['@/wrappers/auth'],
    },
  ],
  // Theme for antd: https://ant.design/docs/react/customize-theme-cn
  theme: {
    // ...darkTheme,
    darkTheme: 'true',
    'primary-color': defaultSettings.primaryColor,
  },
  // @ts-ignore
  title: false,
  ignoreMomentLocale: true,
  proxy: proxy[REACT_APP_ENV || 'dev'],
  manifest: {
    basePath: '/',
  },
}); 