/* eslint-disable consistent-return */
import {
  ModuleTypes,
  BgiRoles,
  MohRoles,
  UserManagementRoles,
  NonMohRoles,
  BloodBankRoles,
} from '@/services/Constants';

const hasAccessToModule = (moduleName: App.ModuleType, modules: App.Module[]): boolean => {
  if(!window.location.href.includes("redcrescent")){
    const currentModule = modules.find((module) => module.name === moduleName);
    return !!currentModule;
  }
};

export default function access(initialState: App.InitialStateType) {
  const { currentUser } = initialState;

  const userModuleMap: { [x: string]: App.Module } = currentUser?.modules.reduce((acc, cur) => {
    return {
      ...acc,
      [cur.name]: cur,
    };
  }, {});

  /**
   * Name all access controls in the format "can{ CRUD operation | Action }{ Module | Page | Component }[{ Module | Page | Component }]"
   * eg. canReadUserManagement, canCreateUser,
   *
   * You can also chain Module, Component, etc..
   * eg. canReadBgiInventory, canUpdateNonMohInventory
   */
  return {
    canReadBgiMohModule: () =>
      currentUser &&
      (hasAccessToModule(ModuleTypes.BGI, currentUser.modules) ||
        hasAccessToModule(ModuleTypes.MOH, currentUser.modules)),
    // BGI
    canReadBgiModule: () => currentUser && hasAccessToModule(ModuleTypes.BGI, currentUser.modules),

    canUpdateBgiInventory: (inventoryLocationId: number) => {
      if (currentUser) {
        if (userModuleMap[ModuleTypes.BGI]?.role === BgiRoles.SUPER_USER) return true;

        if (userModuleMap[ModuleTypes.BGI]?.role === BgiRoles.STORE_INCHARGE) {
          return inventoryLocationId == userModuleMap[ModuleTypes.BGI]?.locationId;
        }

        return userModuleMap[ModuleTypes.BGI]?.role === BgiRoles.SUPER_MANAGER;
      }
      return false;
    },

    canPlaceBgiPurchaseOrder: (inventoryLocationId: number) => {
      if (currentUser) {
        if (userModuleMap[ModuleTypes.BGI]?.role === BgiRoles.SUPER_USER) return true;

        if ([BgiRoles.MANAGER, BgiRoles.PLANNER].includes(userModuleMap[ModuleTypes.BGI]?.role)) {
          return inventoryLocationId == userModuleMap[ModuleTypes.BGI]?.locationId;
        }

        return userModuleMap[ModuleTypes.BGI]?.role === BgiRoles.SUPER_MANAGER;
      }
      return false;
    },
    canPlaceTransferRequest: (inventoryLocationId: number) => {
      if (currentUser) {
        if (userModuleMap[ModuleTypes.BGI]?.role === BgiRoles.SUPER_USER) return true;

        if ([BgiRoles.MANAGER, BgiRoles.PLANNER].includes(userModuleMap[ModuleTypes.BGI]?.role)) {
          return inventoryLocationId == userModuleMap[ModuleTypes.BGI]?.locationId;
        }

        return userModuleMap[ModuleTypes.BGI]?.role === BgiRoles.SUPER_MANAGER;
      }
      return false;
    },
    canApproveBgiPurchaseOrder: () =>
      currentUser &&
      (userModuleMap[ModuleTypes.BGI]?.role === BgiRoles.SUPER_USER ||
        userModuleMap[ModuleTypes.BGI]?.role === BgiRoles.SUPER_APPROVER),

    canCompleteBgiPurchaseOrder: (inventoryLocationId: number) => {
      if (currentUser) {
        if (userModuleMap[ModuleTypes.BGI]?.role === BgiRoles.SUPER_USER) return true;

        if (userModuleMap[ModuleTypes.BGI]?.role === BgiRoles.STORE_INCHARGE) {
          return inventoryLocationId == userModuleMap[ModuleTypes.BGI]?.locationId;
        }

        return userModuleMap[ModuleTypes.BGI]?.role === BgiRoles.SUPER_MANAGER;
      }

      return false;
    },

    canReadBgiSurvey: () => {
      const allowedRoles: string[] = [
        BgiRoles.SUPER_USER,
        BgiRoles.MANAGER,
        BgiRoles.STORE_INCHARGE,
      ];
      return currentUser && allowedRoles.includes(userModuleMap[ModuleTypes.BGI]?.role);
    },

    canUpdateBgiSurvey: () => {
      const allowedRoles: string[] = [
        BgiRoles.SUPER_USER,
        BgiRoles.MANAGER,
        BgiRoles.STORE_INCHARGE,
      ];
      return currentUser && allowedRoles.includes(userModuleMap[ModuleTypes.BGI]?.role);
    },

    canCloseBgiTickets: () => {
      if (currentUser) {
        const allowedRoles: string[] = [
          BgiRoles.SUPER_USER,
          BgiRoles.SUPER_MANAGER,
          BgiRoles.SUPER_APPROVER,
        ];
        return allowedRoles.includes(userModuleMap[ModuleTypes.BGI]?.role);
      }

      return false;
    },

    // MoH
    canReadMohModule: () => currentUser && hasAccessToModule(ModuleTypes.MOH, currentUser.modules),

    canReadMohSurvey: () => {
      if (currentUser) {
        const allowedRoles: string[] = [
          MohRoles.SUPER_USER,
          MohRoles.SURVEYOR,
          MohRoles.READ_SURVEYOR,
        ];
        return allowedRoles.includes(userModuleMap[ModuleTypes.MOH]?.role);
      }

      return false;
    },

    canUpdateMohSurvey: () => {
      return (
        currentUser &&
        (userModuleMap[ModuleTypes.MOH]?.role === MohRoles.SUPER_USER ||
          userModuleMap[ModuleTypes.MOH]?.role === MohRoles.SURVEYOR)
      );
    },

    canReadAllMohDashboard: () =>
      currentUser &&
      (userModuleMap[ModuleTypes.MOH]?.role === MohRoles.SUPER_USER ||
        userModuleMap[ModuleTypes.MOH]?.role === MohRoles.READ_SURVEYOR),

    // Non-MoH
    canReadNonMohModule: () =>
      currentUser && hasAccessToModule(ModuleTypes.NON_MOH, currentUser.modules),

    canReadAllNonMohInventory: () =>
      currentUser &&
      (userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_USER ||
        userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_APPROVER),

    canUpdateNonMohInventory: (inventoryLocationId: number) => {
      if (currentUser) {
        if (userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_USER) return true;

        if (userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.MANAGER) {
          return inventoryLocationId == userModuleMap[ModuleTypes.NON_MOH]?.locationId;
        }
      }
      return false;
    },

    canReadNupcoInventory: () => {
      return (
        currentUser &&
        (userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_USER ||
          userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_APPROVER)
      );
    },

    canReadAllNonMohPurchaseOrder: () =>
      currentUser &&
      (userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_USER ||
        userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_APPROVER),

    canPlaceNonMohPurchaseOrder: (inventoryLocationId: number) => {
      if (currentUser) {
        if (userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_USER) return true;

        return (
          userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.MANAGER &&
          inventoryLocationId == userModuleMap[ModuleTypes.NON_MOH]?.locationId
        );
      }
      return false;
    },

    canApproveNonMohPurchaseOrder: () => {
      return (
        currentUser &&
        (userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_USER ||
          userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_APPROVER)
      );
    },

    canCompleteNonMohPurchaseOrder: (inventoryLocationId: number) => {
      if (currentUser) {
        if (userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_USER) return true;

        return (
          userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.MANAGER &&
          inventoryLocationId == userModuleMap[ModuleTypes.NON_MOH]?.locationId
        );
      }
      return false;
    },

    canCloseNonMohTickets: () =>
      currentUser &&
      (userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_USER ||
        userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_APPROVER),

    canReadAllNonMohDashboard: () =>
      currentUser &&
      (userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_USER ||
        userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_APPROVER),

    canUploadInflowOutflowData: () =>
      currentUser &&
      (userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_USER ||
        userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_APPROVER),

    canReadNupcoInventoryChart: () =>
      currentUser &&
      (userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_USER ||
        userModuleMap[ModuleTypes.NON_MOH]?.role === NonMohRoles.SUPER_APPROVER),

    // Blood bank

    canReadCbbModule: () => currentUser && hasAccessToModule(ModuleTypes.CBB, currentUser.modules),

    canReadPbbModule: () => currentUser && hasAccessToModule(ModuleTypes.PBB, currentUser.modules),

    canReadBbbModule: () => currentUser && hasAccessToModule(ModuleTypes.BBB, currentUser.modules),

    canReadAllBloodBankInventories: (moduleType: App.ModuleType) =>
      currentUser &&
      (userModuleMap[moduleType]?.role === BloodBankRoles.SUPER_USER ||
        userModuleMap[moduleType]?.role === BloodBankRoles.SUPER_APPROVER),

    canReadAllBloodBankTransfer: (moduleType: App.ModuleType) =>
    currentUser &&
    (userModuleMap[moduleType]?.role === BloodBankRoles.SUPER_USER ||
      userModuleMap[moduleType]?.role === BloodBankRoles.SUPER_APPROVER),

    canPlaceBloodBankPurchaseOrder: (moduleType: App.ModuleType) =>
      currentUser &&
      (userModuleMap[moduleType]?.role === BloodBankRoles.SUPER_USER ||
        userModuleMap[moduleType]?.role === BloodBankRoles.REGION_MANAGER),

    canUpdateBloodBankInventory: (moduleType: App.ModuleType) =>
      currentUser &&
      (userModuleMap[moduleType]?.role === BloodBankRoles.SUPER_USER ||
        userModuleMap[moduleType]?.role === BloodBankRoles.REGION_MANAGER),

    canCloseBloodBankTicket: (moduleType: App.ModuleType) =>
      currentUser &&
      (userModuleMap[moduleType]?.role === BloodBankRoles.SUPER_USER ||
        userModuleMap[moduleType]?.role === BloodBankRoles.SUPER_APPROVER),

    // TMS
    canReadTmsModule: () => currentUser && hasAccessToModule(ModuleTypes.TMS, currentUser.modules),

    // User Management
    canReadUserManagementModule: () =>
      currentUser && hasAccessToModule(ModuleTypes.USER_MANAGEMENT, currentUser.modules),

    canSuperAdmin:
      currentUser &&
      userModuleMap[ModuleTypes.USER_MANAGEMENT]?.role === UserManagementRoles.SUPER_ADMIN,
    canTmsUser: currentUser && false,
    isNonMohUser: currentUser && false,
    isBloodBankUser: currentUser && false,
    isCbbUser: currentUser && false,
    isPbbUser: currentUser && false,
    isBbbUser: currentUser && false,
    canUpdateSurvey: () => currentUser && false,

    // Blood Bank Insights
    canReadBbiModule: () => currentUser && hasAccessToModule(ModuleTypes.BBI, currentUser.modules),
    canReadRedCrescentModule:()=>window.location.href.includes("redcrescent")
  };
}
