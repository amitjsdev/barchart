import { history } from 'umi';
import { notification, Modal } from 'antd';
import SecureLS from 'secure-ls';

const secureLS = new SecureLS();

export const storageService = {
  setItem: (key: string, value: any) => secureLS.set(key, value),
  getItem: (key: string) => {
    try {
      return secureLS.get(key);
    } catch (err) {
      Modal.error({
        title: 'Something went wrong!',
        content: 'User details is unavailable or corrupt in local storage. Login again.',
        onOk: () => {
          Modal.destroyAll();
          storageService.clear();
          history.push('/user/login');
        },
      });
      return null;
    }
  },
  removeItem: (key: string) => secureLS.remove(key),
  clear: () => secureLS.removeAll(),
};
