import { storageService } from '@/services/storage';
import httpService from './http.service';
import { getToken } from './cubejs';
import { ApiUrlFragments } from './Constants';

export default {
  login: (credential: API.LoginRequest) => {
    return httpService.post<API.LoginRequest, API.LoginResponse>(
      `${ApiUrlFragments.AUTH}/login`,
      credential,
    );
  },
  logout: () => httpService.post(`${ApiUrlFragments.AUTH}/logut`),
  getUserProfile: () => httpService.get<API.Profile>(`${ApiUrlFragments.USER}/profile`),
  getCubeJsToken: () => getToken().then((data) => data.token),
  getAuthToken: () => {
    try {
      return storageService.getItem('auth-token');
    } catch (error) {
      return null;
    }
  },
  getCubeJsTokenFromLocal: () => {
    try {
      return storageService.getItem('cubejs-token');
    } catch (error) {
      return null;
    }
  },
};
