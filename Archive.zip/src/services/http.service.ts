import axios, { AxiosInstance } from 'axios';
import { history } from 'umi';
import { Modal } from 'antd';

import authService from '@/services/auth.service';
import { storageService } from '@/services/storage';
import errorHandler from '@/api/errorHandler';
class HttpService {
  axiosInstance: AxiosInstance;

  constructor() {
    this.axiosInstance = axios.create({
      // baseURL: hostname.BASE_URL,
    });

    // Request interceptors
    this.axiosInstance.interceptors.request.use(
      (config) => {
        try {
          if (config?.url && !config.url.endsWith('/auth/login')) {
            const authToken = authService.getAuthToken();
            if (!authToken) {
              Modal.error({
                title: 'Something went wrong!',
                content: 'Authorization token is unavailable or corrupt. Login again.',
                onOk: () => {
                  Modal.destroyAll();
                  storageService.clear();
                  history.push('/user/login');
                },
              });
              return null;
            }
            config.headers.token = authToken;
          }
          return config;
        } catch (error) {
          console.error(error);
        }
      },
      (error) => {
        // Do something with request error

        return Promise.reject(error.response);
      },
    );

    // Response
    this.axiosInstance.interceptors.response.use(
      (response) => {
        return response.data;
      },
      (error) => {
        const { response } = error;
        if (!response || response.status === 401 || response.status === 403) {
          errorHandler(error, null, 'popup');
        }
        return Promise.reject(error.response);
      },
    );
  }

  get<T>(url: string, config?: any) {
    return this.axiosInstance.get<any, T>(url, config);
  }

  post<T, R>(url: string, data?: any, config?: any) {
    return this.axiosInstance.post<T, R>(url, data, config);
  }

  put<T, R>(url: string, data?: any, config?: any) {
    return this.axiosInstance.put<T, R>(url, data, config);
  }

  patch<T, R>(url: string, data?: any, config?: any) {
    return this.axiosInstance.patch<T, R>(url, data, config);
  }

  delete<T, R>(url: string, config?: any) {
    return this.axiosInstance.delete<T, R>(url, config);
  }
}

const httpService = new HttpService();
Object.freeze(httpService);

export default httpService;
