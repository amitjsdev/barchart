import httpService from '@/services/http.service';
import hostname from '@/hostname';
import authService from './auth.service';
import { ApiUrlFragments } from './Constants';
import errorHandler from './errorHandler';

export const getToken = async () => {
  return httpService.get(`${ApiUrlFragments.CUBEJS}/auth/token`).catch((err) => errorHandler(err));
};

export const getCubejsApiParams = (url?: string) => {
  return {
    token: authService.getCubeJsTokenFromLocal(),
    options: {
      apiUrl: `${hostname.CUBEJS_URL}/api/1.0/dashboard/v1`, //   /api/1.0/dashboard/v1
      headers: { token: authService.getAuthToken() },
    },
  };
};
