enum LabTypes {
  BGI = 'bgi',
  RC = 'redcrescent',
  MOH = 'moh',
  NON_MOH = 'nonmoh',
  TMS = 'tms',
  CBB = 'centralbloodbank',
  PBB = 'peripheralbloodbank',
  BBB = 'branchbloodbank',
}

enum ModuleTypes {
  BGI = 'bgi',
  RC = 'redcrescent',
  MOH = 'moh',
  NON_MOH = 'nonmoh',
  TMS = 'tms',
  CBB = 'centralbloodbank',
  PBB = 'peripheralbloodbank',
  BBB = 'branchbloodbank',
  BBI = 'bloodBankInsights',
  USER_MANAGEMENT = 'userManagement',
}
enum UserManagementRoles {
  SUPER_ADMIN = 'superAdmin',
}

enum BgiRoles {
  PLANNER = 'planner',
  STORE_INCHARGE = 'inCharge',
  MANAGER = 'manager',
  SUPER_MANAGER = 'superManager',
  SUPER_APPROVER = 'superApprover',
  SUPER_USER = 'superUser',
}

enum MohRoles {
  SURVEYOR = 'surveyor',
  READ_SURVEYOR = 'readSurveyor',
  SUPER_USER = 'superUser',
}

enum NonMohRoles {
  MANAGER = 'manager',
  SUPER_APPROVER = 'superApprover',
  SUPER_USER = 'superUser',
}

enum BloodBankRoles {
  REGION_MANAGER = 'regionManager',
  SUPER_APPROVER = 'superApprover',
  SUPER_USER = 'superUser',
}

enum ApiUrlFragments {
  AUTH = '/api/1.0/auth',
  USER = '/api/1.0/user',
  CUBEJS = '/api/1.0/dashboard',
  INVENTORY = '/api/1.0/inventory',
  TRANSPORT = '/api/1.0/transport',
  DOWNLOAD = '/api/1.0/download',
}

enum IMSTicketStatues {
  CREATED = 'created',
  COMPLETED = 'completed',
}
// 'created' | 'pending' | 'completed' | 'cancelled'
enum POStatues {
  CREATED = 'created',
  PENDING = 'pending',
  COMPLETED = 'completed',
  CANCELLED = 'cancelled',
}

enum BbiRoles {
  ANALYST = 'analyst',
  SUPER_USER = 'superUser',
}

export {
  LabTypes,
  ModuleTypes,
  ApiUrlFragments,
  IMSTicketStatues,
  BgiRoles,
  MohRoles,
  UserManagementRoles,
  NonMohRoles,
  BloodBankRoles,
  POStatues,
  BbiRoles
};
