import { storageService } from '@/services/storage';
import { history } from 'umi';
import { notification, Modal } from 'antd';
import { AxiosResponse } from 'axios';

type MessageType = 'notification' | 'popup';

const codeMessage = {
  200: 'The server successfully returned the requested data. ',
  201: 'Create or modify data successfully. ',
  202: 'A request has entered the background queue (asynchronous task). ',
  204: 'Delete data successfully. ',
  400: 'There was an error in the request sent, and the server did not create or modify data. ',
  401: 'The user does not have permission (the token, username, password are wrong). ',
  403: 'The user is authorized, but access is forbidden. ',
  404: 'The request sent is for a record that does not exist, and the server is not operating. ',
  406: 'The requested format is not available. ',
  410: 'The requested resource has been permanently deleted and will no longer be available. ',
  422: 'When creating an object, a validation error occurred. ',
  500: 'Please contact LabProX team ',
  502: 'Gateway error. ',
  503: 'The service is unavailable, the server is temporarily overloaded or maintained. ',
  504: 'The gateway has timed out. ',
};

const errorHandler = (
  errorResponse: AxiosResponse,
  customMessage: string | null = null,
  messageType: MessageType = 'notification',
) => {
  // const { response = {} as AxiosResponse } = error;

  if (Object.keys(errorResponse).length && errorResponse.status) {
    const errortext = codeMessage[errorResponse.status] || errorResponse.statusText;
    const { message } = errorResponse.data;

    if (errorResponse.status === 401 || errorResponse.status === 403) {
      Modal.error({
        title: 'Something went wrong!',
        content: customMessage || message || errortext,
        onOk: () => {
          Modal.destroyAll();
          storageService.clear();
          history.push('/user/login');
        },
      });
    } else {
      if (errorResponse.status === 500) customMessage = codeMessage[errorResponse.status];

      if (messageType === 'notification') {
        notification.error({
          message: 'Something went wrong!',
          description: customMessage || message || errortext,
        });
      } else if (messageType === 'popup') {
        Modal.error({
          title: 'Something went wrong!',
          content: customMessage || message || errortext,
        });
      }
    }
  } else {
    Modal.error({
      title: 'Something went wrong!',
      content: 'Unable to connect to the network. Please check your connectivity.',
    });
  }
};

export default errorHandler;
