import { message, Modal } from 'antd';
import moment from 'moment';
import { storageService } from '@/services/storage';
import { setUserProfileInLocal, getUserProfileFromLocal, getAuthToken } from '@/utils/userProfile';
import { history } from 'umi';
import errorHandler from './errorHandler';
import hostname from '../hostname';

const axios = require('axios');

const api_host = hostname.BASE_URL;

const api_url_fragment = {
  auth: `${api_host}/api/1.0/auth`,
  user: `${api_host}/api/1.0/user`,
  inventory: `${api_host}/api/1.0/inventory`,
  cubeJs: `${api_host}/api/1.0/dashboard`,
  transport: `${api_host}/api/1.0/transport`,
};

/* HTTP Interceptors */

// Request
axios.interceptors.request.use(
  (config) => {
    try {
      if (config?.url && !config.url.endsWith('/auth/login')) {
        const authToken = getAuthToken();
        if (!authToken) {
          Modal.error({
            title: 'Something went wrong!',
            content: 'Authorization token is unavailable or corrupt. Login again.',
            onOk: () => {
              Modal.destroyAll();
              storageService.clear();
              history.push('/user/login');
            },
          });
        }
        config.headers.token = authToken;
      }
      return config;
    } catch (error) {}
  },
  (error) => {
    // Do something with request error

    return Promise.reject(error.response);
  },
);

// Response
axios.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    const { response } = error;
    if (response.status === 401 || response.status === 403) {
      errorHandler(error, null, 'popup');
    }
    return Promise.reject(error.response);
  },
);

/**
 * @deprecated This object shouldn't be used.
 * Instead use HttpService, ApiService and module services
 */

const Apis = {};
const headers = {};
const getHeaders = () => {
  return { headers: { token: storageService.getItem('auth-token') } };
};

Apis.getCubeJsToken = async () => {
  return axios.get(`${api_url_fragment.cubeJs}/auth/token`);
};

Apis.login = (params) => {
  return axios
    .post(`${api_url_fragment.auth}/login`, {
      email: params.username,
      password: params.password,
    })
    .then((res) => {
      message.success('Login Successful');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.logout = () => {
  return axios
    .post(`${api_url_fragment.auth}/logout`)
    .then((res) => res.data)
    .catch((err) => errorHandler(err, null));
};

Apis.getProfile = () => {
  return axios
    .get(`${api_url_fragment.user}/profile`)
    .then((res) => res.data)
    .catch((err) => errorHandler(err, null, 'popup'));
};

Apis.getUserLocations = () => {
  return axios
    .get(`${api_url_fragment.user}/locations`)
    .then((res) => res.data)
    .catch((err) => errorHandler(err, null));
};

Apis.getUserRegions = () => {
  return axios
    .get(`${api_url_fragment.user}/regions`)
    .then((res) => res.data)
    .catch((err) => errorHandler(err, null));
};

Apis.getRegionsByLabType = () => {
  const userType = storageService.getItem('type');
  return axios
    .get(`${api_url_fragment.user}/regions?labType=${userType}`)
    .then((res) => res.data)
    .catch((err) => errorHandler(err, null));
};

Apis.getAllUsers = () => {
  return axios
    .get(`${api_url_fragment.user}/users`)
    .then((res) => res.data)
    .catch((err) => errorHandler(err, null));
};

Apis.createUser = (user) => {
  return axios
    .post(`${api_url_fragment.user}/users`, user)
    .then((res) => res.data)
    .catch((err) => errorHandler(err, null));
};

// INVENTORY

Apis.getLocations = () => {
  try {
    const userType = storageService.getItem('type') || null;
    return axios
      .get(`${api_url_fragment.user}/locations/${userType}`)
      .then((res) => res.data)
      .catch((err) => errorHandler(err, null));
  } catch (err) {
    return null;
  }
};

Apis.getInventory = (locationId, page) => {
  return axios
    .get(
      `${api_url_fragment.inventory}/inventories/${locationId}?limit=150&page=${page}`,
      getHeaders(),
    )
    .then((res) => res.data.results)
    .catch((err) => errorHandler(err, null));
};
Apis.getTranfer = (locationId, page) => {
  return axios
    .get(
      `${api_url_fragment.inventory}/inventories/${locationId}?limit=150&page=${page}`,
      getHeaders(),
    )
    .then((res) => res.data.results)
    .catch((err) => errorHandler(err, null));
};

Apis.getNonMohInventory = (locationId, page) => {
  return axios
    .get(
      `${api_url_fragment.inventory}/nonmoh-inventories/${locationId}?limit=60&page=${page}`,
      getHeaders(),
    )
    .then((res) => res.data.results)
    .catch((err) => errorHandler(err, null));
};

Apis.getNupcoInventory = () => {
  return axios
    .get(`${api_url_fragment.inventory}/nupco-inventories`, getHeaders())
    .then((res) => {
      return res.data.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.filterInventory = (locationId, page, filters) => {
  const { status, type, category = '' } = filters;
  const statusFragment = '';
  let typeFragment = '';
  let categoryFragment = '';

  if (type !== 'clear') {
    typeFragment = type;
  }
  if (category && category !== 'clear') categoryFragment = category;

  const config = {
    headers: getHeaders(),
    params: {
      limit: 150,
      page,
      classification: typeFragment,
      category: categoryFragment,
    },
  };
  if (status !== 'clear') {
    config.params[status] = true;
  }
  return axios
    .get(`${api_url_fragment.inventory}/cbb-inventories/${locationId}`, config)
    .then((res) => res.data.results)
    .catch((err) => errorHandler(err, null));
};

Apis.nonMohfilterInventory = (locationId, page, filter) => {
  return axios
    .get(
      `${api_url_fragment.inventory}/nonmoh-inventories/${locationId}?limit=50&page=${page}&${filter.status}=true`,
      getHeaders(),
    )
    .then((res) => res.data.results)
    .catch((err) => errorHandler(err, null));
};

Apis.getBatches = (skuId) => {
  return axios
    .get(`${api_url_fragment.inventory}/batches/inventory/${skuId}`)
    .then((res) => res.data.message)
    .catch((err) => errorHandler(err, null));
};

Apis.updateCBBBatches = (payload, id) => {
  return axios
    .post(`${api_url_fragment.inventory}/cbb-inventories/inventory/${id}`, payload)
    .then((res) => {
      message.success('Batches updated successfully');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.updateBatches = (data) => {
  return axios
    .post(`${api_url_fragment.inventory}/batches/update`, data)
    .then((res) => {
      message.success('Batches updated successfully');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.updateNupcoInventory = (data, id) => {
  return axios
    .post(`${api_url_fragment.inventory}/nupco-inventories` + `/${id}`, data)
    .then((res) => {
      message.success('SKU updated successfully');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.updateDailyConsumption = (data) => {
  return axios
    .post(`${api_url_fragment.inventory}/inventories/update-daily`, data)
    .then((res) => {
      message.success('Daily consumption updated successfully');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.createOrder = (data) => {
  return axios
    .post(`${api_url_fragment.inventory}/purchase-order/create/`, data)
    .then((res) => {
      message.success('Order Creation Success');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.confirmLabStatus = () => {
  return axios
    .post(`${api_url_fragment.inventory}/surveys/lab-status`, {
      locationId: storageService.getItem('locationId'),
      status: true,
    })
    .then((res) => {
      message.success('Lab Status Updated Successfully');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.getOrder = (location, status, approved = null) => {
  let _url = '';
  let locationFragment = '';
  if (+location) locationFragment = `location=${location}&`;
  const labType = storageService.getItem('type');

  if (status === 'created')
    _url = `${api_url_fragment.inventory}/purchase-order/?${locationFragment}status=created&isApproved=false&labType=${labType}`;
  else if (status === 'approved')
    _url = `${api_url_fragment.inventory}/purchase-order/?${locationFragment}status=created&isApproved=true&labType=${labType}`;
  else if (status === 'pending')
    _url = `${api_url_fragment.inventory}/purchase-order/?${locationFragment}status=pending&isApproved=true&labType=${labType}`;
  else if (status === 'completed')
    _url = `${api_url_fragment.inventory}/purchase-order/?${locationFragment}&status=completed&labType=${labType}`;
  else if (status === 'cancelled')
    _url = `${api_url_fragment.inventory}/purchase-order/?${locationFragment}&status=cancelled&labType=${labType}`;

  return axios
    .get(_url)
    .then((res) => res.data.data)
    .catch((err) => errorHandler(err, null));
};

Apis.updateOrder = (id, data) => {
  return axios
    .put(`${api_url_fragment.inventory}/purchase-order/${id}/update-status`, data)
    .then((res) => {
      message.success('Orders Updated!');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.appoveOrder = (id) => {
  return axios
    .patch(
      `${api_url_fragment.inventory}/purchase-order/${id}/approve-order`,
      { isApproved: true },
      getHeaders(),
    )
    .then((res) => {
      message.success('Orders Approved!');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.deleteOrder = (id) => {
  return axios
    .delete(`${api_url_fragment.inventory}/purchase-order/${id}/delete-order`)
    .then((res) => {
      message.success('Orders Deleted!');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.saveSurveyFormAsDraft = (data, date, id) => {
  return axios
    .post(`${api_url_fragment.inventory}/surveys/draft/${date}/${id}`, data)
    .then((res) => {
      message.success('Survey Form Saved Successfully!');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.saveSurveyForm = (data, date, id) => {
  return axios
    .post(`${api_url_fragment.inventory}/surveys/draft/${date}/${id}`, data)
    .then((res) => {
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.getYesterdaySurveyDraft = () => {
  const _date = moment().subtract(1, 'days').format('YYYY-MM-DD');
  const locId = parseInt(storageService.getItem('locationId'));
  return (
    axios
      // .get(api_url_fragment.inventory + `/surveys/draft/` + _date + '/' + locId, getHeaders())
      .get(`${api_url_fragment.inventory}/surveys/draft/latest/${locId}`, getHeaders())
      .then((res) => res.data)
      .catch((err) => errorHandler(err, null))
  );
};

Apis.getSurveyDraftForm = () => {
  const today = new Date();
  const dd = String(today.getDate()).padStart(2, '0');
  const mm = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
  const yyyy = today.getFullYear();
  const _date = `${yyyy}-${mm}-${dd}`;
  const locId = parseInt(storageService.getItem('locationId'));
  return axios
    .get(`${api_url_fragment.inventory}/surveys/draft/${_date}/${locId}`, getHeaders())
    .then((res) => res.data)
    .catch((err) => errorHandler(err, null));
};

Apis.uploadSurveyForm = (data) => {
  return axios
    .post(`${api_url_fragment.inventory}/surveys/create`, data)
    .then((res) => {
      message.success('Survey Form Uploaded Successfully!');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.uploadNonMohSurveyForm = (data) => {
  return axios
    .post(`${api_url_fragment.inventory}/surveys/nonmoh-create`, data)
    .then((res) => {
      message.success('Survey Form Uploaded Successfully!');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.uploadBgiForm = (data) => {
  return axios
    .post(
      `${api_url_fragment.inventory}/surveys/bgi-create`,
      {
        ...data,
        locationId: storageService.getItem('locationId'),
      },
      getHeaders(),
    )
    .then((res) => {
      message.success('Survey Form Uploaded Successfully!');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.getSurveyFormStatus = () => {
  const today = new Date();
  const dd = String(today.getDate()).padStart(2, '0');
  const mm = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
  const yyyy = today.getFullYear();
  const _date = `${yyyy}-${mm}-${dd}`;
  const locId = parseInt(storageService.getItem('locationId'));
  return axios
    .get(
      `${api_url_fragment.inventory}/surveys/exists?locationId=${locId}&date=${_date}`,
      getHeaders(),
    )
    .then((res) => res.data)
    .catch((err) => errorHandler(err, null));
};

Apis.getInventoryBatches = (id) => {
  return axios
    .get(`${api_url_fragment.inventory}/batches/inventory/${id}`)
    .then((res) => res.data)
    .catch((err) => errorHandler(err, null));
};

Apis.deleteInventoryBatches = (id) => {
  return axios
    .delete(`${api_url_fragment.inventory}/batches/remove/${id}`)
    .then((res) => {
      message.success('Batch Deleted!');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.getImsTickets = (locationId) => {
  let locationFragment = '';
  if (locationId) locationFragment = `locationId=${locationId}`;
  const labType = storageService.getItem('type');
  return (
    axios
      .get(`${api_url_fragment.inventory}/tickets?${locationFragment}&labType=${labType}`)
      // .get(api_url_fragment.inventory + `/tickets?locationId=5&labType=`+type)
      .then((res) => res.data)
      .catch((err) => errorHandler(err, null))
  );
};

Apis.getImsTransfer = (locationId) => {
  let locationFragment = '';
  if (locationId) locationFragment = `locationId=${locationId}`;
  const labType = storageService.getItem('type');
  return (
    axios
      .get(
        `${api_url_fragment.inventory}/instruments/transactions?${locationFragment}&labType=${labType}`,
      )
      // .get(api_url_fragment.inventory + `/tickets?locationId=5&labType=`+type)
      .then((res) => res.data)
      .catch((err) => errorHandler(err, null))
  );
};

Apis.closeImsTicket = (ticketId) => {
  return axios
    .post(`${api_url_fragment.inventory}/tickets/${ticketId}`, { status: 'completed' })
    .then((res) => {
      message.success(`Ticket no. ${ticketId} was closed Successfully!`);
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

// TMS-----------------

Apis.closeTMSTicket = (ticketId) => {
  return axios
    .post(`${api_url_fragment.transport}/tickets/${ticketId}`, { status: 'completed' })
    .then((res) => {
      message.success(`Ticket no. ${ticketId} was closed Successfully!`);
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.getTokenData = (page, limit) => {
  return axios
    .get(`${api_url_fragment.transport}/tickets?limit=` + `${limit}` + `&offset=` + `${page}`)
    .then((res) => res.data)
    .catch((err) => errorHandler(err, null));
};

Apis.getSettingsData = async () => {
  return axios
    .get(`${api_url_fragment.transport}/settings`)
    .then((res) => res.data)
    .catch((err) => errorHandler(err, null));
};

Apis.uploadXLX = (data) => {
  const formData = new FormData();
  formData.append('file', data.originFileObj, data.name);
  return axios
    .post(`${api_url_fragment.transport}/upload`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
    .then((res) => {
      message.success('File Uploaded Successfully!');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.sendMissingSamplesReportAsEmail = async (payload) => {
  return axios
    .get(`${api_url_fragment.transport}/pod-data/report`, { params: payload })
    .then((res) => {
      const { success } = res.data;
      if (success) message.success('Report sent successfully!');
    })
    .catch((err) => errorHandler(err, null));
};

Apis.getAutocompleteResults = (searchText, searchCategory) => {
  return axios
    .get(`${api_url_fragment.transport}/auto-complete/${searchCategory}/${searchText}`)
    .then((res) => res.data.data)
    .catch((err) => errorHandler(err, null));
};

Apis.searchTMSTickets = (regionId, searchTerm) => {
  const params = { search: searchTerm };
  if (regionId) params.regionId = regionId;
  return axios
    .get(`${api_url_fragment.transport}/tickets/`, { params })
    .then((res) => res.data.data)
    .catch((err) => errorHandler(err, null));
};

Apis.searchTMSPodData = (searchTerm) => {
  const params = { patientCode: searchTerm };
  return axios
    .get(`${api_url_fragment.transport}/pod-data/`, { params })
    .then((res) => res.data.data)
    .catch((err) => errorHandler(err, null));
};

// Non-MoH
Apis.confirmInventory = (status) => {
  return axios
    .post(
      `${api_url_fragment.inventory}/surveys/lab-status`,
      {
        status,
        locationId: storageService.getItem('locationId'),
      },
      getHeaders(),
    )
    .then((res) => {
      message.success('Inventory status updated successfully!');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

Apis.getNonMohInventoryStatus = () => {
  const today = new Date();
  const dd = String(today.getDate()).padStart(2, '0');
  const mm = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
  const yyyy = today.getFullYear();
  const _date = `${yyyy}-${mm}-${dd}`;
  const locId = parseInt(storageService.getItem('locationId'));
  return axios
    .get(`${api_url_fragment.inventory}/surveys/lab-status?locationId=${locId}&date=${_date}`)
    .then((res) => res.data?.message)
    .catch((err) => errorHandler(err, null));
};

Apis.uploadInflowOutflowData = (data) => {
  return axios
    .post(`${api_url_fragment.inventory}/flows`, data)
    .then((res) => {
      message.success('File uploaded successfully');
      return res.data;
    })
    .catch((err) => errorHandler(err, null));
};

// Blood bank
Apis.getProducts = () => {
  const labType = storageService.getItem('type');
  return axios
    .get(`${api_url_fragment.inventory}/products/classifications?labType=${labType}`)
    .then((res) => res.data)
    .catch((err) => errorHandler(err, null));
};

export const API_URL = api_url_fragment;

export default Apis;
