import { ItemType } from "./pages/BloodBank/BloodBankTransfer/Types";

declare namespace App {
  interface InitialStateType {
    settings?: any;
    currentUser?: App.CurrentUser;
  }

  export interface CurrentUser {
    name: string;
    email: string;
    organisationId: string;
    modules: Module[];
    defaultModule: ModuleType;
    currentModule: ModuleType;
  }

  export interface Module {
    name: ModuleType;
    locationId: number | null;
    locationName: string | null;
    regionId: number | null;
    regionName: string | null;
    role: string;
    default: boolean;
  }

  export type LabType =
    | 'bgi'
    | 'moh'
    | 'nonmoh'
    | 'tms'
    | 'centralbloodbank'
    | 'peripheralbloodbank'
    | 'branchbloodbank';

  export type ModuleType =
    | 'bgi'
    | 'moh'
    | 'nonmoh'
    | 'tms'
    | 'centralbloodbank'
    | 'peripheralbloodbank'
    | 'branchbloodbank'
    | 'userManagement'
    | 'bloodBankInsights';

  export type PurchaseOrderStatus = 'created' | 'pending' | 'completed' | 'cancelled';
  export type ImsTicketStatus = 'created' | 'completed';
}

declare namespace API {
  export interface LoginStateType {
    status?: 'ok' | 'error';
    type?: string;
  }

  export interface LoginRequest {
    username: string;
    password: string;
  }

  export interface LoginResponse {
    token: string;
  }

  export interface Profile {
    name: string;
    email: string;
    organisationId: string;
    modules: App.Module[];
  }

  export interface RegionResponse {
    createdAt: string;
    id: number;
    name: string;
    nhccRegionName: string;
    updatedAt: string;
  }

  export interface InventoryResponse {
    success: boolean;
    results: {
      data: Sku[];
      limit: number;
      page: number;
      totalCount: number;
      totalPages: number;
    };
  }
  export interface TransferResponse {
    success: boolean;
    results: {
      data: Transfer[];
    };
  }
  export interface BatchesResponse {
    success: boolean;
    message: SkuWithBatches;
  }

  export interface UpdateBatchRequest {
    id: number;
    quantity: number;
    productId: number;
    locationId: number;
    inventoryId: number;
    hasExpiry: boolean;
    batchNumber?: string;
    expiryDate?: string;
    manufactureDate?: string;
  }

  export interface UpdateDailyConsumptionRequest {
    dailyConsumption: number | undefined;
    inventoryId: number | undefined;
    locationId: number | undefined;
    productId: number | undefined;
  }

  export interface Location {
    code: string;
    createdAt: string;
    email: string;
    id: number;
    labCapacity: number;
    labType: App.LabType;
    leadTime: number;
    locationType: string;
    maxNearOutOfStockCriteria: number;
    maxSafeStockCriteria: number;
    maxStockLevelDays: number;
    minNearExpiryDays: number;
    minNearFullCapacityCriteria: number;
    minNotCompletePODays: number;
    minOverStockCriteria: number;
    minSafeStockCriteria: number;
    minStockLevelDays: number;
    name: string;
    numberOfAttendees: number;
    optimizationStockLevel: number;
    primaryContact: string;
    primaryMobile: string;
    purchaseOrderEmail: any;
    region: string;
    regionId: number;
    reorderStockLevel: number;
    samplesPerDay: number;
    updatedAt: string;
  }

  export interface Sku {
    availableQuantities: number;
    binNumber: number | null;
    consumableDays: number;
    consumption: number | null;
    createdAt: string;
    dailyConsumption: number;
    dailyDemand: number;
    expiryDate: string;
    id: number;
    labType: App.LabType;
    locationId: number;
    monthlyConsumption: number;
    product: Product;
    productId: number;
    quantitiesInTransit: number;
    quantity: number;
    reOrderLevel: number;
    reOrderQuantity: number;
    updatedAt: string;
  }

  export interface Transfer {
    id: number; 
    status: string;
    toLabType: App.LabType;
    toLocationId: number;
    toRegionId: number;
    items:ItemType[]
    updatedAt: string;
    createdAt: string;
  }
  interface Product {
    category: string;
    classification: BgiProductClassification | BloodBankProductClassification;
    code: string;
    createdAt: string;
    description: string;
    id: number;
    labType: App.LabType;
    unitOfMeasures: string;
    updatedAt: string;
  }

  export interface SkuWithBatches {
    availableQuantities: number;
    batches: Batch[];
    binNumber: null;
    consumableDays: number;
    createdAt: string;
    dailyConsumption: number;
    dailyDemand: number;
    expiryDate: string;
    id: number;
    labType: App.LabType;
    locationId: number;
    monthlyConsumption: number;
    productId: number;
    quantitiesInTransit: number;
    reOrderLevel: number;
    reOrderQuantity: number;
    updatedAt: string;
  }

  interface Batch {
    id: number;
    productId: number;
    inventoryId: number;
    locationId: number;
    batchNumber: string;
    expiryDate: string;
    manufactureDate: string;
    quantity: number;
    hasExpiry: true;
    createdAt: string;
    updatedAt: string;
  }


export interface InstrumentalMachineResponse {
  success: boolean;
  data: InstrumentalSku[];
}

 interface InstrumentalSku {
  id: number,
  locationId: number,
  labType: string,
  regionId: number,
  equipmentName: string,
  serialNumber: string,
  model: string,
  manufacturer: string,
  state: string,
  utilization: string,
  warranty: string,
  ppm: number,
  anualPpm: string,
  lastPpmDate: string,
  nextPpmDate: string,
  maintenance: string,
  createdAt: string,
  updatedAt: string
}

export interface TransactionHistory {
  id: number,
  locationId: number,
  labType: string,
  regionId: number,
  instrumentId: number,
  state: string,
  fixDate: string,
  comment: string,
  supportFile: string,
  turnAroundTime: number,
  createdAt: String,
  updatedAt: String
}


  type BgiProductClassification = 'PPE' | 'Consumables' | 'Reagents';
  type BloodBankProductClassification = 'Phenotyping' | 'serology';
}
