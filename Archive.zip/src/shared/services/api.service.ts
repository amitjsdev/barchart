/* eslint-disable @typescript-eslint/dot-notation */
import httpService from '@/services/http.service';
import { ApiUrlFragments, IMSTicketStatues, POStatues } from '@/services/Constants';
import errorHandler from '@/services/errorHandler';
import moment from 'moment';

export default {
  // Get
  getLocationsByLabType: (labType: App.LabType) => {
    return httpService
      .get<API.Location[]>(`${ApiUrlFragments.USER}/locations/${labType}`)
      .catch((err) => errorHandler(err));
  },
  
  getInstrumentSpanEndCount: (labType: App.LabType) => {
    return httpService
      .get<API.Location[]>(`${ApiUrlFragments.INVENTORY}/locations/${labType}`)
      .catch((err) => errorHandler(err));
  },
  
  getRegionsByLabType: (labType: App.LabType) => {
    return httpService
      .get<API.RegionResponse[]>(`${ApiUrlFragments.USER}/regions`, {
        params: { labType },
      })
      .catch((err) => errorHandler(err));
  },

  getBatches: (skuId: number) => {
    return httpService
      .get<API.BatchesResponse>(`${ApiUrlFragments.INVENTORY}/batches/inventory/${skuId}`)
      .then((data) => data.message)
      .catch((err) => errorHandler(err));
  },

  getOrders: (
    labType: App.LabType,
    locationId: number,
    status: App.PurchaseOrderStatus,
    isApproved = null,
  ) => {
    const params = { labType, status };
    if (isApproved !== null) params['isApproved'] = isApproved;
    if (locationId) params['location'] = locationId;

    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/purchase-order`, { params })
      .catch((err) => errorHandler(err));
  },

  getProductsByLabType: (labType: App.LabType) => {
    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/products/classifications`, {
        params: { labType },
      })
      .catch((err) => errorHandler(err));
  },

  getImsTickets: (labType: App.LabType, locationId: number) => {
    const params = { labType, locationId };

    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/tickets`, { params })
      .catch((err) => errorHandler(err));
  },
  getInstrumentalTransferRequest: ( locationId: number,status:string,outGoing:boolean,paramsData:any) => {
    const params = { locationId, status,outGoing,...paramsData};
    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/instruments/transactions`, { params })
      .catch((err) => errorHandler(err));
  },
  
  // Update, delete
  createPurchaseOrder: (order: any) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/purchase-order/create/`, order)
      .catch((err) => errorHandler(err));
  },

  updateBatches: (update: API.UpdateBatchRequest) => {
    return httpService
      .post<API.UpdateBatchRequest, { success: boolean }>(
        `${ApiUrlFragments.INVENTORY}/batches/update`,
        update,
      )
      .catch((err) => errorHandler(err));
  },

  deleteBatch: (batchId: number) => {
    return httpService
      .delete(`${ApiUrlFragments.INVENTORY}/batches/remove/${batchId}`)
      .catch((err) => errorHandler(err));
  },

  updateDailyConsumption: (update: API.UpdateDailyConsumptionRequest) => {
    return httpService
      .post<API.UpdateDailyConsumptionRequest, { success: boolean }>(
        `${ApiUrlFragments.INVENTORY}/inventories/update-daily`,
        update,
      )
      .catch((err) => errorHandler(err));
  },

  updateOrder: (orderId: number, data: any) => {
    return httpService
      .put(`${ApiUrlFragments.INVENTORY}/purchase-order/${orderId}/update-status`, data)
      .catch((err) => errorHandler(err));
  },

  approveOrder: (orderId: number) => {
    return httpService
      .patch(`${ApiUrlFragments.INVENTORY}/purchase-order/${orderId}/approve-order`, {
        isApproved: true,
      })
      .catch((err) => errorHandler(err));
  },

  deleteOrder: (orderId: number) => {
    return httpService
      .delete(`${ApiUrlFragments.INVENTORY}/purchase-order/${orderId}/delete-order`)
      .catch((err) => errorHandler(err));
  },

  closeImsTicket: (ticketId: number) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/tickets/${ticketId}`, {
        status: IMSTicketStatues.COMPLETED,
      })
      .catch((err) => errorHandler(err));
  },

  getSurveyFormStatus: (locationId: number) => {
    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/surveys/exists`, {
        params: {
          locationId,
          date: moment().format('YYYY-MM-DD'),
        },
      })
      .catch((err) => errorHandler(err));
  },
  
  
};
