const hostname = {
  BASE_URL: process.env.REACT_APP_BASE_URL || '', // http://139.59.56.155
  CUBEJS_URL: process.env.REACT_APP_BASE_URL || '',
  TMS_BASE_URL: process.env.REACT_APP_BASE_URL || '',
};

export default hostname;
