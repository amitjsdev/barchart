// @ts-nocheck

import HomeOutlined from '@ant-design/icons/HomeOutlined';
import DashboardOutlined from '@ant-design/icons/DashboardOutlined';
import ExceptionOutlined from '@ant-design/icons/ExceptionOutlined';
import UserOutlined from '@ant-design/icons/UserOutlined';
import ShoppingCartOutlined from '@ant-design/icons/ShoppingCartOutlined';
import FormOutlined from '@ant-design/icons/FormOutlined';
import BarChartOutlined from '@ant-design/icons/BarChartOutlined';
import SettingOutlined from '@ant-design/icons/SettingOutlined';
import SearchOutlined from '@ant-design/icons/SearchOutlined'

export default {
  HomeOutlined,
DashboardOutlined,
ExceptionOutlined,
UserOutlined,
ShoppingCartOutlined,
FormOutlined,
BarChartOutlined,
SettingOutlined,
SearchOutlined
}
    