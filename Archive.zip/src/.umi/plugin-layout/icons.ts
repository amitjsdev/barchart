// @ts-nocheck

  import HomeOutlined from '@ant-design/icons/es/icons/HomeOutlined';
import DashboardOutlined from '@ant-design/icons/es/icons/DashboardOutlined';
import ExceptionOutlined from '@ant-design/icons/es/icons/ExceptionOutlined';
import UserOutlined from '@ant-design/icons/es/icons/UserOutlined';
import ShoppingCartOutlined from '@ant-design/icons/es/icons/ShoppingCartOutlined';
import FormOutlined from '@ant-design/icons/es/icons/FormOutlined';
import BarChartOutlined from '@ant-design/icons/es/icons/BarChartOutlined';
import SettingOutlined from '@ant-design/icons/es/icons/SettingOutlined';
import SearchOutlined from '@ant-design/icons/es/icons/SearchOutlined'
  export default {
    HomeOutlined,
DashboardOutlined,
ExceptionOutlined,
UserOutlined,
ShoppingCartOutlined,
FormOutlined,
BarChartOutlined,
SettingOutlined,
SearchOutlined
  }
      