export default {
  'layout.global.error.title': '出错了，可点击右下角进行反馈',
  'layout.global.error.stack': '错误堆栈',
};
