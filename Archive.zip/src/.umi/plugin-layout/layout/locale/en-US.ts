export default {
  'layout.global.error.title':
    'Something wrong, click on the bottom right corner to give us feedback',
  'layout.global.error.stack': 'Error stack',
};
