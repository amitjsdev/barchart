// @ts-nocheck
import React from 'react';
import { ApplyPluginsType, dynamic } from '/Users/catlina/Documents/ormae/frontend/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';
import LoadingComponent from '@/components/PageLoading/index';

export function getRoutes() {
  const routes = [
  {
    "path": "/",
    "component": dynamic({ loader: () => import(/* webpackChunkName: '.umi__plugin-layout__Layout' */'/Users/catlina/Documents/ormae/frontend/src/.umi/plugin-layout/Layout.tsx'), loading: LoadingComponent}),
    "routes": [
      {
        "name": "centralBloodBank",
        "path": "/cbb",
        "access": "canReadCbbModule",
        "routes": [
          {
            "name": "inventory",
            "icon": "home",
            "path": "/cbb/inventory",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BloodBank__BloodBankInventory' */'/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankInventory'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "dashboard",
            "icon": "dashboard",
            "path": "/cbb/dashboard",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BloodBank__BloodBankDashboard__CbbDashboard' */'/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankDashboard/CbbDashboard'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "instrumentInventory",
            "icon": "exception",
            "path": "/cbb/instrument-inventory",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BloodBank__BloodBankInstrumentDashboard' */'/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankInstrumentDashboard'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "ticket",
            "icon": "exception",
            "path": "/cbb/tickets",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BloodBank__BloodBankTickets' */'/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankTickets'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "transfer",
            "icon": "exception",
            "path": "/cbb/transfer",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BloodBank__BloodBankTransfer' */'/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankTransfer'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          }
        ]
      },
      {
        "name": "peripheralBloodBank",
        "path": "/pbb",
        "access": "canReadPbbModule",
        "routes": [
          {
            "name": "inventory",
            "icon": "home",
            "path": "/pbb/inventory",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BloodBank__BloodBankInventory' */'/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankInventory'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "dashboard",
            "icon": "dashboard",
            "path": "/pbb/dashboard",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BloodBank__BloodBankDashboard__PbbDashboard' */'/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankDashboard/PbbDashboard'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "instrumentInventory",
            "icon": "exception",
            "path": "/pbb/instrument-inventory",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BloodBank__BloodBankInstrumentDashboard' */'/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankInstrumentDashboard'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "ticket",
            "icon": "exception",
            "path": "/pbb/tickets",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BloodBank__BloodBankTickets' */'/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankTickets'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "transfer",
            "icon": "exception",
            "path": "/pbb/transfer",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BloodBank__BloodBankTransfer' */'/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankTransfer'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          }
        ]
      },
      {
        "name": "branchBloodBank",
        "path": "/bbb",
        "access": "canReadBbbModule",
        "routes": [
          {
            "name": "inventory",
            "icon": "home",
            "path": "/bbb/inventory",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BloodBank__BloodBankInventory' */'/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankInventory'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "dashboard",
            "icon": "dashboard",
            "path": "/bbb/dashboard",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BloodBank__BloodBankDashboard__BbbDashboard' */'/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankDashboard/BbbDashboard'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "instrumentInventory",
            "icon": "exception",
            "path": "/bbb/instrument-inventory",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BloodBank__BloodBankInstrumentDashboard' */'/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankInstrumentDashboard'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "ticket",
            "icon": "exception",
            "path": "/bbb/tickets",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BloodBank__BloodBankTickets' */'/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankTickets'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "transfer",
            "icon": "exception",
            "path": "/bbb/transfer",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BloodBank__BloodBankTransfer' */'/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankTransfer'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          }
        ]
      },
      {
        "name": "bloodBankInsights",
        "path": "/bbi",
        "access": "canReadBbiModule",
        "routes": [
          {
            "name": "dashboard",
            "icon": "dashboard",
            "path": "/bbi/dashboard",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BloodBankInsights__BloodBankInsightsDashboard' */'/Users/catlina/Documents/ormae/frontend/src/pages/BloodBankInsights/BloodBankInsightsDashboard'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          }
        ]
      },
      {
        "path": "/user",
        "layout": false,
        "routes": [
          {
            "exact": true,
            "name": "login",
            "path": "/user/login",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__user__login' */'/Users/catlina/Documents/ormae/frontend/src/pages/user/login'), loading: LoadingComponent})
          },
          {
            "exact": true,
            "name": "setPassword",
            "path": "/user/set-password",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__user__set-password' */'/Users/catlina/Documents/ormae/frontend/src/pages/user/set-password'), loading: LoadingComponent})
          }
        ]
      },
      {
        "path": "/",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Welcome' */'/Users/catlina/Documents/ormae/frontend/src/pages/Welcome'), loading: LoadingComponent}),
        "exact": true,
        "layout": false
      },
      {
        "name": "userMangement",
        "icon": "user",
        "path": "/user-management",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__UserManagement' */'/Users/catlina/Documents/ormae/frontend/src/pages/UserManagement'), loading: LoadingComponent}),
        "access": "canReadUserManagementModule",
        "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
        "exact": true
      },
      {
        "path": "/bgi",
        "name": "bgi",
        "access": "canReadBgiModule",
        "routes": [
          {
            "name": "inventory",
            "icon": "home",
            "path": "/bgi/inventory",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BGI__InventoryV2' */'/Users/catlina/Documents/ormae/frontend/src/pages/BGI/InventoryV2'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "purchase",
            "icon": "shopping-cart",
            "path": "/bgi/purchase",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BGI__Purchase' */'/Users/catlina/Documents/ormae/frontend/src/pages/BGI/Purchase'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "dashboard",
            "icon": "dashboard",
            "path": "/bgi/metrics",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BGI__Metrics' */'/Users/catlina/Documents/ormae/frontend/src/pages/BGI/Metrics'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "survey",
            "icon": "form",
            "path": "/bgi/survey",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BGI__BgiSurvey__BgiSurvey' */'/Users/catlina/Documents/ormae/frontend/src/pages/BGI/BgiSurvey/BgiSurvey'), loading: LoadingComponent}),
            "access": "canReadBgiSurvey",
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "imsTickets",
            "icon": "exception",
            "path": "/bgi/tickets",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__BGI__IMSTickets' */'/Users/catlina/Documents/ormae/frontend/src/pages/BGI/IMSTickets'), loading: LoadingComponent}),
            "access": "canReadBgiModule",
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          }
        ]
      },
      {
        "name": "moh",
        "path": "/moh",
        "access": "canReadMohModule",
        "routes": [
          {
            "name": "survey",
            "icon": "form",
            "path": "/moh/survey",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__MoH__Survey' */'/Users/catlina/Documents/ormae/frontend/src/pages/MoH/Survey'), loading: LoadingComponent}),
            "access": "canReadMohSurvey",
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "surveyDashboard",
            "icon": "bar-chart",
            "path": "/moh/survey-dashboard",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__MoH__SurveyMetrics' */'/Users/catlina/Documents/ormae/frontend/src/pages/MoH/SurveyMetrics'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          }
        ]
      },
      {
        "path": "/tms",
        "name": "tms",
        "access": "canReadTmsModule",
        "routes": [
          {
            "name": "tmsDashboard",
            "icon": "bar-chart",
            "path": "/tms/dashboard",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__TMS__TMSDashboard' */'/Users/catlina/Documents/ormae/frontend/src/pages/TMS/TMSDashboard'), loading: LoadingComponent}),
            "exact": true,
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})]
          },
          {
            "name": "tmsTickets",
            "icon": "form",
            "path": "/tms/tickets",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__TMS__Ticket' */'/Users/catlina/Documents/ormae/frontend/src/pages/TMS/Ticket'), loading: LoadingComponent}),
            "exact": true,
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})]
          },
          {
            "name": "tmsSettings",
            "icon": "setting",
            "path": "/tms/settings",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__TMS__Settings' */'/Users/catlina/Documents/ormae/frontend/src/pages/TMS/Settings'), loading: LoadingComponent}),
            "exact": true,
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})]
          },
          {
            "name": "globalSearch",
            "icon": "search",
            "path": "/tms/search",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__TMS__GlobalSearch' */'/Users/catlina/Documents/ormae/frontend/src/pages/TMS/GlobalSearch'), loading: LoadingComponent}),
            "exact": true,
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})]
          }
        ]
      },
      {
        "path": "/redcrescent",
        "name": "redcrescent",
        "access": "canReadRedCrescentModule",
        "routes": [
          {
            "name": "inventory",
            "icon": "home",
            "path": "/redcrescent/inventory",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__RedCrescent__InventoryV2' */'/Users/catlina/Documents/ormae/frontend/src/pages/RedCrescent/InventoryV2'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "purchase",
            "icon": "shopping-cart",
            "path": "/redcrescent/purchase",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__RedCrescent__Purchase' */'/Users/catlina/Documents/ormae/frontend/src/pages/RedCrescent/Purchase'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "dashboard",
            "icon": "dashboard",
            "path": "/redcrescent/metrics",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__RedCrescent__Metrics' */'/Users/catlina/Documents/ormae/frontend/src/pages/RedCrescent/Metrics'), loading: LoadingComponent}),
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          },
          {
            "name": "imsTickets",
            "icon": "exception",
            "path": "/redcrescent/tickets",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__RedCrescent__IMSTickets' */'/Users/catlina/Documents/ormae/frontend/src/pages/RedCrescent/IMSTickets'), loading: LoadingComponent}),
            "access": "canReadRedCrescentModule",
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
            "exact": true
          }
        ]
      },
      {
        "name": "nonMoh",
        "access": "canReadNonMohModule",
        "routes": [
          {
            "name": "survey",
            "icon": "form",
            "path": "/non-moh/survey",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__NonMoH__SurveyNonMoh' */'/Users/catlina/Documents/ormae/frontend/src/pages/NonMoH/SurveyNonMoh'), loading: LoadingComponent}),
            "exact": true,
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})]
          },
          {
            "name": "inventory",
            "icon": "home",
            "path": "/non-moh/inventory",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__NonMoH__InventoryNonMoh' */'/Users/catlina/Documents/ormae/frontend/src/pages/NonMoH/InventoryNonMoh'), loading: LoadingComponent}),
            "exact": true,
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})]
          },
          {
            "name": "purchase",
            "icon": "shopping-cart",
            "path": "/non-moh/purchase",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__NonMoH__PurchaseNonMoh' */'/Users/catlina/Documents/ormae/frontend/src/pages/NonMoH/PurchaseNonMoh'), loading: LoadingComponent}),
            "exact": true,
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})]
          },
          {
            "name": "imsTickets",
            "icon": "exception",
            "path": "/non-moh/tickets",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__NonMoH__NonMohTickets' */'/Users/catlina/Documents/ormae/frontend/src/pages/NonMoH/NonMohTickets'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "name": "nupco_inventory",
            "icon": "home",
            "path": "/non-moh/nupco-inventory",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__NonMoH__NupcoInventory' */'/Users/catlina/Documents/ormae/frontend/src/pages/NonMoH/NupcoInventory'), loading: LoadingComponent}),
            "exact": true,
            "access": "canReadNupcoInventory"
          },
          {
            "name": "dashboard",
            "icon": "shopping-cart",
            "path": "/non-moh/dashboard",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__NonMoH__Dashboard' */'/Users/catlina/Documents/ormae/frontend/src/pages/NonMoH/Dashboard'), loading: LoadingComponent}),
            "exact": true,
            "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})]
          }
        ]
      },
      {
        "layout": false,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'@/pages/404'), loading: LoadingComponent}),
        "wrappers": [dynamic({ loader: () => import(/* webpackChunkName: 'wrappers' */'@/wrappers/auth'), loading: LoadingComponent})],
        "exact": true
      }
    ]
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
