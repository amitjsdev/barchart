// @ts-nocheck
import { plugin } from './plugin';
import * as Plugin_0 from '/Users/catlina/Documents/ormae/frontend/src/app.tsx';
import * as Plugin_1 from '/Users/catlina/Documents/ormae/frontend/node_modules/umi-plugin-antd-icon-config/lib/app.js';
import * as Plugin_2 from '/Users/catlina/Documents/ormae/frontend/src/.umi/plugin-access/rootContainer.ts';
import * as Plugin_3 from '/Users/catlina/Documents/ormae/frontend/src/.umi/plugin-dva/runtime.tsx';
import * as Plugin_4 from '../plugin-initial-state/runtime';
import * as Plugin_5 from '/Users/catlina/Documents/ormae/frontend/src/.umi/plugin-locale/runtime.tsx';
import * as Plugin_6 from '@@/plugin-layout/runtime.tsx';
import * as Plugin_7 from '../plugin-model/runtime';

  plugin.register({
    apply: Plugin_0,
    path: '/Users/catlina/Documents/ormae/frontend/src/app.tsx',
  });
  plugin.register({
    apply: Plugin_1,
    path: '/Users/catlina/Documents/ormae/frontend/node_modules/umi-plugin-antd-icon-config/lib/app.js',
  });
  plugin.register({
    apply: Plugin_2,
    path: '/Users/catlina/Documents/ormae/frontend/src/.umi/plugin-access/rootContainer.ts',
  });
  plugin.register({
    apply: Plugin_3,
    path: '/Users/catlina/Documents/ormae/frontend/src/.umi/plugin-dva/runtime.tsx',
  });
  plugin.register({
    apply: Plugin_4,
    path: '../plugin-initial-state/runtime',
  });
  plugin.register({
    apply: Plugin_5,
    path: '/Users/catlina/Documents/ormae/frontend/src/.umi/plugin-locale/runtime.tsx',
  });
  plugin.register({
    apply: Plugin_6,
    path: '@@/plugin-layout/runtime.tsx',
  });
  plugin.register({
    apply: Plugin_7,
    path: '../plugin-model/runtime',
  });
