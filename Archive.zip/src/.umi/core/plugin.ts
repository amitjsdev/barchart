// @ts-nocheck
import { Plugin } from '/Users/catlina/Documents/ormae/frontend/node_modules/@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['modifyClientRenderOpts','patchRoutes','rootContainer','render','onRouteChange','dva','getInitialState','initialStateConfig','locale','locale','layout','request',],
});

export { plugin };
