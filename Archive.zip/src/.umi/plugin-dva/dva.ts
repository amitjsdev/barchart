// @ts-nocheck
import { Component } from 'react';
import { ApplyPluginsType } from 'umi';
import dva from 'dva';
// @ts-ignore
import createLoading from '/Users/catlina/Documents/ormae/frontend/node_modules/dva-loading/dist/index.esm.js';
import { plugin, history } from '../core/umiExports';
import ModelGlobal0 from '/Users/catlina/Documents/ormae/frontend/src/models/global.ts';
import ModelLogin1 from '/Users/catlina/Documents/ormae/frontend/src/models/login.ts';
import ModelSetting2 from '/Users/catlina/Documents/ormae/frontend/src/models/setting.ts';
import ModelUser3 from '/Users/catlina/Documents/ormae/frontend/src/models/user.ts';
import ModelModel4 from '/Users/catlina/Documents/ormae/frontend/src/pages/BGI/BgiSurvey/model.ts';
import ModelModel5 from '/Users/catlina/Documents/ormae/frontend/src/pages/BGI/IMSTickets/model.ts';
import ModelModel6 from '/Users/catlina/Documents/ormae/frontend/src/pages/BGI/InventoryV2/model.ts';
import ModelModel7 from '/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankInstrumentDashboard/model.ts';
import ModelModel8 from '/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankInventory/model.ts';
import ModelModel9 from '/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankTickets/model.ts';
import ModelModel10 from '/Users/catlina/Documents/ormae/frontend/src/pages/BloodBank/BloodBankTransfer/model.ts';
import ModelModel11 from '/Users/catlina/Documents/ormae/frontend/src/pages/MoH/Survey/model.ts';
import ModelModel12 from '/Users/catlina/Documents/ormae/frontend/src/pages/NonMoH/InventoryNonMoh/model.ts';
import ModelModel13 from '/Users/catlina/Documents/ormae/frontend/src/pages/NonMoH/NonMohTickets/model.ts';
import ModelModel14 from '/Users/catlina/Documents/ormae/frontend/src/pages/NonMoH/SurveyNonMoh/model.ts';
import ModelModel15 from '/Users/catlina/Documents/ormae/frontend/src/pages/RedCrescent/IMSTickets/model.ts';
import ModelModel16 from '/Users/catlina/Documents/ormae/frontend/src/pages/RedCrescent/InventoryV2/model.ts';

let app:any = null;

export function _onCreate(options = {}) {
  const runtimeDva = plugin.applyPlugins({
    key: 'dva',
    type: ApplyPluginsType.modify,
    initialValue: {},
  });
  app = dva({
    history,
    
    ...(runtimeDva.config || {}),
    // @ts-ignore
    ...(typeof window !== 'undefined' && window.g_useSSR ? { initialState: window.g_initialProps } : {}),
    ...(options || {}),
  });
  
  app.use(createLoading());
  
  (runtimeDva.plugins || []).forEach((plugin:any) => {
    app.use(plugin);
  });
  app.model({ namespace: 'global', ...ModelGlobal0 });
app.model({ namespace: 'login', ...ModelLogin1 });
app.model({ namespace: 'setting', ...ModelSetting2 });
app.model({ namespace: 'user', ...ModelUser3 });
app.model({ namespace: 'model', ...ModelModel4 });
app.model({ namespace: 'model', ...ModelModel5 });
app.model({ namespace: 'model', ...ModelModel6 });
app.model({ namespace: 'model', ...ModelModel7 });
app.model({ namespace: 'model', ...ModelModel8 });
app.model({ namespace: 'model', ...ModelModel9 });
app.model({ namespace: 'model', ...ModelModel10 });
app.model({ namespace: 'model', ...ModelModel11 });
app.model({ namespace: 'model', ...ModelModel12 });
app.model({ namespace: 'model', ...ModelModel13 });
app.model({ namespace: 'model', ...ModelModel14 });
app.model({ namespace: 'model', ...ModelModel15 });
app.model({ namespace: 'model', ...ModelModel16 });
  return app;
}

export function getApp() {
  return app;
}

export class _DvaContainer extends Component {
  constructor(props: any) {
    super(props);
    // run only in client, avoid override server _onCreate()
    if (typeof window !== 'undefined') {
      _onCreate();
    }
  }

  componentWillUnmount() {
    let app = getApp();
    app._models.forEach((model:any) => {
      app.unmodel(model.namespace);
    });
    app._models = [];
    try {
      // 释放 app，for gc
      // immer 场景 app 是 read-only 的，这里 try catch 一下
      app = null;
    } catch(e) {
      console.error(e);
    }
  }

  render() {
    const app = getApp();
    app.router(() => this.props.children);
    return app.start()();
  }
}
