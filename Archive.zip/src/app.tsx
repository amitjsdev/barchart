import React from 'react';
import { BasicLayoutProps, Settings as LayoutSettings } from '@ant-design/pro-layout';
import { message, notification } from 'antd';
import { history, RequestConfig } from 'umi';
import RightContent from '@/components/RightContent';
import Footer from '@/components/Footer';
import { ResponseError } from 'umi-request';
import { getUserProfileFromLocal } from '@/utils/userProfile';
import { storageService } from '@/services/storage';
import authService from '@/services/auth.service';
import { queryCurrent } from './services/user';
import defaultSettings from '../config/defaultSettings';
import logo from './assets/logo.png';

interface InitialStateType {
  settings?: LayoutSettings;
  currentUser?: App.CurrentUser;
}

console.log(
  '%cLabProX\n%cVersion: 2.1.19',
  'color: #753BBD; font-weight: bold; font-size: 24px; padding-bottom: 8px;',
  'color: #e0e0e0; font-size: 12px; padding-bottom: 6px;',
);

export async function getInitialState(): Promise<InitialStateType> {
  const fetchUserInfo = async () => {
    try {
      // return getUserProfileFromLocal();
      return authService.getUserProfile();
    } catch (err) {
      console.error(err);
      // throw Error('User details not found or incomplete!');
      /* message.error('Unauthorized access! Try logging in again.');
      storageService.clear();
       */
      history.push('/user/login');
      return {};
    }
  };

  if (history.location.pathname !== '/user/login') {
    try {
      const currentUserLocal = await fetchUserInfo();
      return {
        currentUser: currentUserLocal,
        settings: defaultSettings
      };
    } catch (err) {
      console.error(err);
      history.push('/user/login');
    }
  }
  return {
    // fetchUserInfo,
    settings: defaultSettings,
  };
}

const Logo: React.FC<any> = (props) => {
  return <img src={logo} alt="MoH | LabProX" style={{ height: '25px' }} />;
};

export const layout = ({
  initialState,
}: {
  initialState: { settings?: LayoutSettings; currentUser?: App.CurrentUser };
}): BasicLayoutProps => {
  return {
    rightContentRender: () => <RightContent />,
    disableContentMargin: false,
    logo: <Logo />,
    // footerRender: () => <Footer />,
    onPageChange: () => {
      const { location } = history;
      if (location.pathname === '/user/login') {
        storageService.clear();
      }
    },
    ...initialState?.settings,
  };
};

const codeMessage = {
  200: 'The server successfully returned the requested data. ',
  201: 'Create or modify data successfully. ',
  202: 'A request has entered the background queue (asynchronous task). ',
  204: 'Delete data successfully. ',
  400: 'There was an error in the request sent, and the server did not create or modify data. ',
  401: 'The user does not have permission (the token, username, password are wrong). ',
  403: 'The user is authorized, but access is forbidden. ',
  404: 'The request sent is for a record that does not exist, and the server is not operating. ',
  406: 'The requested format is not available. ',
  410: 'The requested resource has been permanently deleted and will no longer be available. ',
  422: 'When creating an object, a validation error occurred. ',
  500: 'Please contact LabProX team ',
  502: 'Gateway error. ',
  503: 'The service is unavailable, the server is temporarily overloaded or maintained. ',
  504: 'The gateway has timed out. ',
};

/**
 * 异常处理程序
 */
const errorHandler = (error: ResponseError) => {
  const { response } = error;
  if (response && response.status) {
    const errorText = codeMessage[response.status] || response.statusText;
    const { status, url } = response;

    // notification.error({
    //   message: `请求错误 ${status}: ${url}`,
    //   description: errorText,
    // });
  }

  if (response && error.response.status === 401) {
    history.push('/user/login');
  }
  if (!response) {
    notification.error({
      description: '您的网络发生异常，无法连接服务器',
      message: '网络异常',
    });
  }
  throw error;
};

export const request: RequestConfig = {
  errorHandler,
};
