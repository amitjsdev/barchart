import { message } from 'antd';
import moment from 'moment';

import httpService from '@/services/http.service';
import errorHandler from '@/services/errorHandler';
import apiService from '@/shared/services/api.service';
import { LabTypes, ApiUrlFragments } from '@/services/Constants';

export default {
  getSurveyFormStatus: (locationId: number) => {
    return apiService
      .getSurveyFormStatus(locationId)
      .then((data: any) => data.message)
      .catch((err) => errorHandler(err));
  },

  getSurveyDraftForm: (locationId: number) => {
    const todaysData = moment().format('YYYY-MM-DD');
    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/surveys/draft/${todaysData}/${locationId}`)
      .catch((err) => errorHandler(err));
  },

  submitSurvey: (surveyData: any) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/surveys/create`, surveyData)
      .then(() => message.success('Survey submitted successfully'))
      .catch((err) => errorHandler(err));
  },

  saveSurveyFormAsDraft: (formData: any, date: string, locationId: number) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/surveys/draft/${date}/${locationId}`, formData)
      .then(() => message.success('Survey form saved successfully'))
      .catch((err) => errorHandler(err));
  },

  getLocations: () => apiService.getLocationsByLabType(LabTypes.MOH),
};
