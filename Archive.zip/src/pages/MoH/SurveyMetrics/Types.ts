export type FilterType = 'granularity' | 'dateRange';
export type GranularityType = 'day' | 'week' | 'month' | 'year';

export type DateRangeType = string[];

export interface DateFilterType {
  granularity: GranularityType;
  dateRange: DateRangeType;
}
