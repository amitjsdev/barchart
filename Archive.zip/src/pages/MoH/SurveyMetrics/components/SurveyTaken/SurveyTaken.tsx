import React, { useState } from 'react';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { Spin, Empty, Modal, Typography, Row, Col } from 'antd';
import { Chart, Axis, Tooltip, Geom, Coord, Legend, Interval } from 'bizcharts';
import moment from 'moment';

import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';
import LabDetailsTable from './LabDetailsTable';
import styles from './index.less';

const { Title, Paragraph, Text } = Typography;

const SurveyTaken = (props) => {
  const { dateRangeFilter } = props;

  const [drillDownQuery, setDrillDownQuery] = useState();
  const [allLocationsQuery, setAllLocationsQuery] = useState();

  const [isModalVisible, setIsModalVisible] = useState(false);
  const [tableDescription, setTableDescription] = useState();

  const formatResultSet = (resultSet) => {
    const lastUptime = 0;

    resultSet.loadResponses[0].data = resultSet.loadResponses[0].data.map((item) => {
      const formattedItem = { ...item };
      formattedItem['Answers.count'] = +item['Answers.count'];
      formattedItem['Answers.firstTimeProcessingRate'] = +(20 - formattedItem['Answers.count']);

      return formattedItem;
    });

    return resultSet;
  };

  const formatData = (data) => {
    return data.map((item) => {
      const formattedItem = { ...item };
      formattedItem.x = moment(formattedItem.x).format('DD-MM-YYYY');
      if (formattedItem.color === 'Answers.firstTimeProcessingRate') {
        formattedItem.color = 'Labs not taken survey';
        // formattedItem.measure = 26;
        return formattedItem;
      }

      formattedItem.color = 'Labs taken survey';
      return formattedItem;
    });
    /* .map((item) => {
        
        if (item.x === startDate || item.x === endDate) item.measure = 0;
        return item;
      }); */
  };

  const stackedChartData = (resultSet) => {
    const data = resultSet
      .pivot()
      .map(({ xValues, yValuesArray }) =>
        yValuesArray.map(([yValues, m]) => ({
          x: resultSet.axisValuesString(xValues, ', '),
          color: resultSet.axisValuesString(yValues, ', '),
          measure: m && Number.parseFloat(m),
        })),
      )
      .reduce((a, b) => a.concat(b), []);

    return formatData(data);
    // return data
  };

  const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

  const cubejsParams = getCubejsApiParams(API_URL);

  const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

  const filters = [
    {
      member: 'Answers.date',
      operator: 'inDateRange',
      values: [dateRangeFilter.dateRange[0], dateRangeFilter.dateRange[1]],
    },
  ];

  /* const timeDimensions = [
    {
      dimension: 'Answers.date',
      granularity: dateRangeFilter.granularity,
      dateRange: dateRangeFilter.dateRange,
    },
  ]; */

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['Answers.count', 'Answers.firstTimeProcessingRate'],
      timeDimensions: [],
      dimensions: ['Answers.date'],
      filters,
      segments: [],
      order: { 'Answers.date': 'asc' },
    },
    {
      cubejsApi,
    },
  );

  const allLocationsResponse = useCubeQuery(allLocationsQuery, {
    skip: !allLocationsQuery,
    cubejsApi,
  });

  const drillDownResponse = useCubeQuery(drillDownQuery, {
    skip: !drillDownQuery,
    cubejsApi,
  });

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  //   Drill down
  const baseItemDetailsQuery = {
    measures: ['Answers.count'],
    timeDimensions: [],
    dimensions: ['Locations.name'],
    filters: [],
  };

  const getItemDetailQuery = (key, date) => {
    const filters = [
      {
        dimension: 'Locations.labType',
        operator: 'equals',
        values: ['moh'],
      },
      {
        dimension: 'Answers.date',
        operator: 'equals',
        values: [moment(date, 'DD-MM-YYYY').format('YYYY-MM-DD')],
      },
    ];

    return { ...baseItemDetailsQuery, filters };
  };

  const handleClickOnChart = (data) => {
    // const query = getXAndYValues(geomId);

    const query = {
      key: data.color,
      date: data.x,
    };

    setAllLocationsQuery({
      dimensions: ['Locations.name'],
      filters: [
        {
          dimension: 'Locations.labType',
          operator: 'equals',
          values: ['moh'],
        },
      ],
    });

    if (allLocationsResponse.resultSet) {
      const dataSource = allLocationsResponse.resultSet.tablePivot();
      const columns = allLocationsResponse.resultSet.tableColumns();

      // setIsModalVisible(true);
    }

    setDrillDownQuery(getItemDetailQuery(query.key, query.date));

    if (drillDownResponse) {
      setTableDescription({
        date: query.date,
        key: query.key,
      });
      setIsModalVisible(true);
    }
  };

  const parseResultSet = (allLocationsResultSet) => {
    return allLocationsResultSet ? allLocationsResultSet.loadResponses[0].data : null;
  };

  const colors = ['color', ['#753BBD', '#291940']];
  const BarRender = ({ resultSet }) => (
    <Chart
      scale={{ x: { tickCount: 8 } }}
      // height={280}
      data={stackedChartData(formatResultSet(resultSet))}
      autoFit
      padding="auto"
      onIntervalClick={(e, chart) => {
        handleClickOnChart(e.data.data);
      }}
    >
      <Axis name="x" label={false} tickLine={false} />
      <Axis name="measure" />
      <Tooltip />
      {/* <Geom type="interval" position={`x*measure`} color={colors} /> */}
      <Interval
        adjust={[{ type: 'stack', reverseOrder: false }]}
        position="x*measure"
        color={colors}
      />
    </Chart>
  );

  const ModalHeader = () => (
    <Row>
      <Col>
        <Title level={4}>{tableDescription.key}</Title>
        <Text type="secondary" level={5}>
          {tableDescription.date}
        </Text>
      </Col>
    </Row>
  );

  const handleModalOk = () => setIsModalVisible(false);
  const handleModalCancel = () => setIsModalVisible(false);
  const allLabs = parseResultSet(allLocationsResponse.resultSet);
  const labsTakenSurvey = parseResultSet(drillDownResponse.resultSet);

  const data = resultSet?.loadResponses[0].data || null;

  return data && data.length ? (
    <>
      <BarRender resultSet={resultSet} />
      <Modal
        title="Survey taken"
        centered
        visible={isModalVisible}
        width={720}
        onOk={handleModalOk}
        onCancel={handleModalCancel}
        destroyOnClose
        footer={false}
      >
        {allLabs && labsTakenSurvey ? (
          <LabDetailsTable allLabs={allLabs} labsTakenSurvey={labsTakenSurvey} />
        ) : null}
      </Modal>
    </>
  ) : (
    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
  );
};
export default SurveyTaken;
