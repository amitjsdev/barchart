import React from 'react';
import { List, Tabs, Empty, Badge } from 'antd';

import styles from './index.less';

const { TabPane } = Tabs;

const LabDetailsTable = ({ allLabs, labsTakenSurvey }) => {
  const labsTakenSurveyNames = labsTakenSurvey.map((lab) => lab['Locations.name']);
  const labsNotTakenSurveyNames = allLabs
    ?.filter((lab) => !labsTakenSurveyNames?.includes(lab['Locations.name']))
    .map((lab) => lab['Locations.name']);

  return labsNotTakenSurveyNames && labsTakenSurvey ? (
    <Tabs defaultActiveKey="1" centered>
      <TabPane
        className={styles.tableContainer}
        tab={<span>Labs taken survey ({labsTakenSurveyNames.length})</span>}
        key="1"
      >
        <List
          itemLayout="horizontal"
          dataSource={labsTakenSurveyNames}
          renderItem={(item) => <List.Item>{item}</List.Item>}
          bordered
        />
      </TabPane>
      <TabPane
        className={styles.tableContainer}
        tab={<span>Labs not taken survey ({labsNotTakenSurveyNames.length})</span>}
        key="2"
      >
        <List
          itemLayout="horizontal"
          dataSource={labsNotTakenSurveyNames}
          renderItem={(item) => <List.Item>{item}</List.Item>}
          bordered
        />
      </TabPane>
    </Tabs>
  ) : (
    <Empty />
  );
};

export default LabDetailsTable;
