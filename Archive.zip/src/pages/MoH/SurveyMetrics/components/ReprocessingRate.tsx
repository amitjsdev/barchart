import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Row, Col, Statistic, Table, Spin, Empty, Space, Typography } from 'antd';
import { InboxOutlined } from '@ant-design/icons';

import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';

const { Text } = Typography;

const numberRender = ({ resultSet, pivotConfig }) => (
  <Row type="flex" justify="center" align="middle" style={{ height: '100%' }}>
    <Col>
      {resultSet.seriesNames().map((s) => (
        <Statistic value={resultSet.totalRow()[s.key]} suffix="%" />
      ))}
    </Col>
  </Row>
);

const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) => {
  const data = resultSet?.loadResponses[0]?.data;
  const result = (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
    (error && error.toString()) || <Spin />;

  return data && data.length && data[0]['Answers.reprocessingRate'] ? (
    result
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

const ChartRenderer = (props) => {
  const { dateRangeFilter, location } = props;

  /* const timeDimensions = [
    {
      dimension: 'Answers.createdat',
      granularity: dateRangeFilter.granularity,
      dateRange: dateRangeFilter.dateRange,
    },
  ]; */

  const filters = [
    { member: 'Answers.date', operator: 'inDateRange', values: dateRangeFilter.dateRange },
  ];
  if (location && location !== 'All locations') {
    filters.push({ member: 'Locations.name', operator: 'equals', values: [location] });
  }

  return (
    <QueryRenderer
      query={{
        measures: ['Answers.reprocessingRate'],
        timeDimensions: [],
        order: {},
        filters,
      }}
      cubejsApi={cubejsApi}
      render={renderChart(numberRender, {
        x: [],
        y: ['measures'],
        fillMissingDates: true,
        joinDateRange: false,
      })}
    />
  );
};

export default ChartRenderer;
