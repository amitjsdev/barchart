import React, { useState } from 'react';
import { Pie } from '@ant-design/charts';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';

import { Empty, Spin } from 'antd';
import styles from './index.less';

// CubeJS
const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint
const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

// CubeJS
const cubeQueryRender = (props) => {
  const { dateRangeFilter, location } = props;

  /* const timeDimensions = [
    {
      dimension: 'Answers.date',
      granularity: dateRangeFilter.granularity,
      dateRange: dateRangeFilter.dateRange,
    },
  ]; */

  const filters = [
    { member: 'Answers.date', operator: 'inDateRange', values: dateRangeFilter.dateRange },
  ];

  if (location && location !== 'All locations') {
    filters.push({ member: 'Locations.name', operator: 'equals', values: [location] });
  }

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['Answers.totalSamplesTested'],
      timeDimensions: [],
      dimensions: ['Locations.name'],
      filters,
      order: {},
    },
    {
      cubejsApi,
    },
  );

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const dataSource = resultSet.tablePivot();

  const chartData = dataSource.map((item) => {
    return {
      type: item['Locations.name'],
      value: item['Answers.totalSamplesTested'],
    };
  });

  return chartData.length ? (
    <SamplesCollectedPie data={chartData} />
  ) : (
    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
  );
};

const SamplesCollectedPie: React.FC = (props) => {
  // ANT Chart
  const config = {
    // renderer: 'svg',
    // theme : 'dark' ,
    autoFit: true,
    appendPadding: 10,
    data: props.data,
    angleField: 'value',
    colorField: 'type',
    radius: 1,
    innerRadius: 0.7,
    pieStyle: {
      stroke: 0,
    },
    label: {
      type: 'inner',
      offset: '-0.5',
      content: '{percentage}',
      style: {
        fill: '#fff',
        fontSize: 0,
        textAlign: 'center',
      },
    },
    legend: false,
    statistic: {
      title: false,
      content: {
        style: {
          fill: '#fff',
          textAlign: 'center',
          fontSize: 32,
        },
      },
    },
  };
  return <Pie className={styles.fixValue} {...config} />;
};

export default cubeQueryRender;
