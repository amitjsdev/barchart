import React from 'react';
import cubejs from '@cubejs-client/core';
import { Row, Col, Statistic, Table, Spin } from 'antd';
import itemNameMap from '../StockShortage/itemNameMap';

const getFormattedColumns = (defaultColumns) => {
  return [
    {
      dataIndex: defaultColumns[1].dataIndex,
      key: defaultColumns[1].key,
      shortTitle: 'Count of Tests',
      title: 'Count of Tests',
      type: 'number',
    },
    {
      dataIndex: defaultColumns[2].dataIndex,
      key: defaultColumns[2].key,
      shortTitle: 'Machines Count',
      title: 'Machines Count',
      type: 'number',
    },
  ];
};

const getLocationName = (columns) => {
  return columns[0].title;
};

const getStockType = (columns) => {
  return columns[1].title;
};

const getFormattedData = (dataSource) => {
  return dataSource;
};

const ItemDetailTable = ({ resultSet, pivotConfig }) => {
  return resultSet ? (
    // <div className={styles.tableContainer}>
    <Table
      pagination={false}
      columns={getFormattedColumns(resultSet.tableColumns(pivotConfig))}
      dataSource={getFormattedData(resultSet.tablePivot(pivotConfig))}
    />
  ) : (
    // </div>
    <Spin />
  );
};

export default ItemDetailTable;
