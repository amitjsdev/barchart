import React from 'react';
import { Statistic, Space, Typography } from 'antd';
import { InboxOutlined } from '@ant-design/icons';

const { Text } = Typography;

enum LabCapacity {
  'The regional laboratory in Riyadh' = 3000,
  'Regional laboratory in Jeddah' = 2500,
  'Regional laboratory in Makkah' = 2500,
  'The regional laboratory in Medina' = 2000,
  'Assir Regional Laboratory' = 2250,
  'Prince Muhammad bin Abdulaziz Hospital in Riyadh' = 2500,
  'Qassim Regional Laboratory' = 1000,
  'The regional laboratory in Hail' = 800,
  'Al-Ahsa Regional Laboratory' = 2000,
  'King Fahd Specialist Hospital in Tabuk' = 500,
  'The regional laboratory in Taif' = 500,
  'Al-Baha Regional Laboratory' = 400,
  'Regional laboratory in Najran' = 1000,
  'The Regional Laboratory in Qurayyat' = 500,
  'The regional laboratory in Jazan' = 1000,
  'Northern Border Regional Laboratory' = 500,
  'Prince Muteb Hospital Lab' = 500,
  'Deba Lab' = 800,
  'Bisha Regional Lab' = 600,
  'Dammam Regional Lab' = 2500,
}

const locations = [
  'The regional laboratory in Riyadh',
  'Regional laboratory in Jeddah',
  'Regional laboratory in Makkah',
  'The regional laboratory in Medina',
  'Assir Regional Laboratory',
  'Prince Muhammad bin Abdulaziz Hospital in Riyadh',
  'Qassim Regional Laboratory',
  'The regional laboratory in Hail',
  'Al-Ahsa Regional Laboratory',
  'King Fahd Specialist Hospital in Tabuk',
  'The regional laboratory in Taif',
  'Al-Baha Regional Laboratory',
  'Regional laboratory in Najran',
  'The Regional Laboratory in Qurayyat',
  'The regional laboratory in Jazan',
  'Northern Border Regional Laboratory',
  'Prince Muteb Hospital Lab',
  'Deba Lab',
  'Bisha Regional Lab',
  'Dammam Regional Lab',
];

export default (props) => {
  const { location } = props;

  let capacity = 0;

  if (location === 'All locations') {
    capacity = locations
      .map((loc) => LabCapacity[loc])
      .reduce((total, current) => total + current, 0);
  } else {
    capacity = parseInt(LabCapacity[location], 10);
  }

  return capacity ? (
    <Statistic value={capacity} />
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};
