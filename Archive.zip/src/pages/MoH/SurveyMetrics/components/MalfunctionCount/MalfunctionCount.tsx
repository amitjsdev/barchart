import React, { useState } from 'react';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { Spin, Empty, Modal, Typography, Row, Col } from 'antd';
import { Chart, Axis, Tooltip, Geom, Interval } from 'bizcharts';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';
import ItemDetailsTable from './ItemDetailsTable';

const { Title, Text } = Typography;

const MalfunctionCount = (props) => {
  const { dateRangeFilter, location } = props;

  const [drillDownQuery, setDrillDownQuery] = useState();
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [tableDescription, setTableDescription] = useState();

  const formatData = (data) => {
    return data.map((item) => {
      const formattedItem = { ...item };

      if (formattedItem.color.endsWith('Answers.totalExtractionMalfunctionCount')) {
        formattedItem.color = 'Extraction, PCR & Automated malfunction count';
        return formattedItem;
      }

      formattedItem.color = 'Serology malfunction count';
      return formattedItem;
    });
  };

  const stackedChartData = (resultSet) => {
    const data = resultSet
      .pivot()
      .map(({ xValues, yValuesArray }) =>
        yValuesArray.map(([yValues, m]) => ({
          x: resultSet.axisValuesString(xValues, ', '),
          color: resultSet.axisValuesString(yValues, ', '),
          measure: m && Number.parseFloat(m),
        })),
      )
      .reduce((a, b) => a.concat(b), []);

    return formatData(data);
    // return data;
  };

  const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

  const cubejsParams = getCubejsApiParams(API_URL);

  const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

  const filters = [
    { member: 'Answers.date', operator: 'inDateRange', values: dateRangeFilter.dateRange },
  ];
  if (location && location !== 'All locations') {
    filters.push({ member: 'Locations.name', operator: 'equals', values: [location] });
  }

  const getItemLocationFilter = (locationName) => ({
    dimension: 'Locations.name',
    operator: 'equals',
    values: [locationName],
  });

  const baseItemDetailsQuery = {
    dimensions: ['SurveyOptions.name', 'SurveyOptions.value'],
    filters: [],
  };

  enum SurveyOptionsKey {
    'Extraction, PCR & Automated malfunction count' = 'machine_malfunctioning',
    'Serology malfunction count' = 'serology_malfunctioning_machines',
  }

  const getItemDetailQuery = (machineType, locationName) => {
    const drillDownQueryfilters = [
      {
        dimension: 'SurveyOptions.key',
        operator: 'equals',
        values: [SurveyOptionsKey[machineType]],
      },
      { member: 'Answers.date', operator: 'inDateRange', values: dateRangeFilter.dateRange },
    ];
    if (locationName.length) drillDownQueryfilters.push(getItemLocationFilter(locationName));

    return { ...baseItemDetailsQuery, filters: drillDownQueryfilters };
  };

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: [
        'Answers.totalExtractionMalfunctionCount',
        'Answers.totalSerologyMalfunctionCount',
      ],
      timeDimensions: [],
      dimensions: ['Locations.name'],
      filters,
    },
    {
      cubejsApi,
    },
  );

  const drillDownResponse = useCubeQuery(drillDownQuery, {
    skip: !drillDownQuery,
    cubejsApi,
  });

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const handleClickOnChart = (data) => {
    const query = {
      machineType: data.color,
      locationName: data.x,
    };

    setDrillDownQuery(getItemDetailQuery(query.machineType, query.locationName));

    if (drillDownResponse) {
      setTableDescription({
        locationName: query.locationName,
        stockTypeName: query.machineType,
      });
      setIsModalVisible(true);
    }
  };

  const handleModalOk = () => setIsModalVisible(false);
  const handleModalCancel = () => setIsModalVisible(false);

  const colors = ['color', ['#27a29e', '#753BBD']];
  const BarRender = ({ resultSet }) => (
    <Chart
      scale={{ x: { tickCount: 8 } }}
      // height={280}
      data={stackedChartData(resultSet)}
      autoFit
      padding="auto"
      onIntervalClick={(e, chart) => {
        handleClickOnChart(e.data.data);
      }}
    >
      <Axis name="x" label={false} tickLine={false} />
      <Axis name="measure" />
      <Tooltip />
      {/* <Geom type="interval" position={`x*measure`} color={colors} /> */}
      <Interval adjust={[{ type: 'stack' }]} position="x*measure" color={colors} />
    </Chart>
  );

  const ModalHeader = () => (
    <Row>
      <Col>
        <Title level={4}>{tableDescription.stockTypeName}</Title>
        <Text type="secondary" level={5}>
          {tableDescription.locationName}
        </Text>
      </Col>
    </Row>
  );

  const data = resultSet?.loadResponses[0].data || null;

  return data && data.length ? (
    <>
      <BarRender resultSet={resultSet} />
      <Modal
        title={<ModalHeader />}
        centered
        visible={isModalVisible}
        width={720}
        onOk={handleModalOk}
        onCancel={handleModalCancel}
        destroyOnClose
        footer={false}
      >
        <ItemDetailsTable
          resultSet={drillDownResponse.resultSet}
          pivotConfig={drillDownResponse.pivotConfig || null}
        />
      </Modal>
    </>
  ) : (
    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
  );
};

export default MalfunctionCount;
