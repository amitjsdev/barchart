import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Spin, Empty } from 'antd';
import DataSet from '@antv/data-set';
import { Chart, Axis, Tooltip, Geom, Coord, Legend, Interval } from 'bizcharts';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';

const formatResultSet = (resultSet) => {
  const lastUptime = 0;
  resultSet.loadResponses[0].data = resultSet.loadResponses[0].data.map((item) => {
    const formattedItem = { ...item };
    formattedItem['Answers.machineUptimeRatio'] = +item['Answers.machineUptimeRatio'].toFixed(2);
    formattedItem['Answers.firstTimeProcessingRate'] = +(
      1 - formattedItem['Answers.machineUptimeRatio']
    ).toFixed(2);

    return formattedItem;
  });

  return resultSet;
};

const convertToPercentage = (value) => (value * 100).toFixed(2);

const formatData = (data) => {
  return data.map((item) => {
    // color: "Answers.firstTimeProcessingRate"
    // measure: 0.08
    // x: "Regional laboratory in Najran"
    const formattedItem = { ...item };
    if (formattedItem.color === 'Answers.firstTimeProcessingRate') {
      formattedItem.color = 'Machine downtime';
      formattedItem.measure = +convertToPercentage(formattedItem.measure);
      return formattedItem;
    }

    formattedItem.color = 'Machine Uptime';
    formattedItem.measure = +convertToPercentage(formattedItem.measure);
    return formattedItem;
  });
};

const stackedChartData = (resultSet) => {
  const data = resultSet
    .pivot()
    .map(({ xValues, yValuesArray }) =>
      yValuesArray.map(([yValues, m]) => ({
        x: resultSet.axisValuesString(xValues, ', '),
        color: resultSet.axisValuesString(yValues, ', '),
        measure: m && Number.parseFloat(m),
      })),
    )
    .reduce((a, b) => a.concat(b), []);

  return formatData(data);
};

// const colors = ['color', ['#E38F3C', '#1DAD28']];
const colors = ['color', ['#27a29e', '#753BBD']];

const itemVal =
  '<li data-index={index}>' +
  '<span style="background-color:{color};width:8px;height:8px;border-radius:50%;display:inline-block;margin-right:8px;"></span>' +
  '{name}: {value}%' +
  '</li>';

const axisLabel = {
  formatter(text, item, index) {
    return `${text}%`;
  },
};

const barRender = ({ resultSet }) => (
  <Chart
    // renderer="svg"
    padding={[20, 20, 40, 20]}
    scale={{ x: { tickCount: 8 } }}
    // height={300}
    data={stackedChartData(formatResultSet(resultSet))}
    autoFit
  >
    <Axis name="x" label={false} tickLine={false} />
    <Axis name="measure" label={axisLabel} />
    <Tooltip itemTpl={itemVal} />
    <Geom type="interval" position="x*measure" color={colors} />
  </Chart>
);

function Grouped({ resultSet }) {
  const ds = new DataSet();
  const dv = ds
    .createView()
    .source(stackedChartData(formatResultSet(resultSet)))
    .transform({
      type: 'percent',
      field: 'measure', // 统计销量
      dimension: 'color', // 每年的占比
      groupBy: ['x'], // 以不同产品类别为分组
      as: 'percent',
    });

  return (
    <Chart
      // height={400}
      padding="auto"
      scale={{
        percent: {
          min: 0,
          formatter(val) {
            return `${(val * 100).toFixed(2)}%`;
          },
        },
      }}
      data={dv.rows}
      autoFit
    >
      <Interval adjust="stack" color={colors} position="x*measure" />
      <Tooltip shared />
      <Axis name="x" label={false} tickLine={false} />
      <Axis name="measure" label={axisLabel} />
    </Chart>
  );
}

const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) => {
  const data = resultSet?.loadResponses[0]?.data;
  const result = (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
    (error && error.toString()) || <Spin />;

  return data && data.length ? result : <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
};

const ChartRenderer = (props) => {
  const { dateRangeFilter } = props;

  /* const timeDimensions = [
    {
      dimension: 'Answers.date',
      granularity: dateRangeFilter.granularity,
      dateRange: dateRangeFilter.dateRange,
    },
  ]; */

  const filters = [
    { member: 'Answers.date', operator: 'inDateRange', values: dateRangeFilter.dateRange },
  ];

  return (
    <QueryRenderer
      query={{
        measures: ['Answers.firstTimeProcessingRate', 'Answers.machineUptimeRatio'],
        timeDimensions: [],
        filters,
        dimensions: ['Locations.name'],
        order: {},
      }}
      cubejsApi={cubejsApi}
      render={renderChart(Grouped, {
        x: ['Locations.name'],
        y: ['measures'],
        fillMissingDates: true,
        joinDateRange: false,
      })}
    />
  );
};

export default ChartRenderer;
