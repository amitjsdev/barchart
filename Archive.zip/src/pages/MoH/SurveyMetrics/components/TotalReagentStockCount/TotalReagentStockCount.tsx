/* eslint-disable no-else-return */
import React, { useState } from 'react';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { Spin, Empty, Modal, Typography, Row, Col } from 'antd';
import { Chart, Axis, Tooltip, Interval } from 'bizcharts';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';
import ItemDetailsTable from './ItemDetailsTable';

const { Title, Text } = Typography;

const TotalReagentStockCount = (props) => {
  const { dateRangeFilter, location } = props;

  const [drillDownQuery, setDrillDownQuery] = useState();
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [tableDescription, setTableDescription] = useState();

  const formatData = (data) => {
    return data.map((item) => {
      const formattedItem = { ...item, label: '' };

      if (formattedItem.color.endsWith('SurveyOptions.serologyFilterTipsStock')) {
        formattedItem.color = 'Serology tips stock in hand';
        formattedItem.label = 'SurveyOptions.serologyFilterTipsStock';
        return formattedItem;
      } else if (formattedItem.color.endsWith('SurveyOptions.pcrStockReagent')) {
        formattedItem.color = 'PCR reagent stock in hand';
        formattedItem.label = 'SurveyOptions.pcrStockReagent';
        return formattedItem;
      } else if (formattedItem.color.endsWith('SurveyOptions.extractionStockReagent')) {
        formattedItem.color = 'Extraction reagent stock in hand';
        formattedItem.label = 'SurveyOptions.extractionStockReagent';
        return formattedItem;
      } else if (formattedItem.color.endsWith('SurveyOptions.allStockFilterTips')) {
        formattedItem.color = 'Total Filter tips';
        formattedItem.label = 'SurveyOptions.allStockFilterTips';
        return formattedItem;
      }
    });
  };

  const stackedChartData = (resultSet) => {
    // setResultSetData(resultSet)
    const data = resultSet
      .pivot()
      .map(({ xValues, yValuesArray }) =>
        yValuesArray.map(([yValues, m]) => ({
          x: resultSet.axisValuesString(xValues, ', '),
          color: resultSet.axisValuesString(yValues, ', '),
          measure: m && Number.parseFloat(m),
        })),
      )
      .reduce((a, b) => a.concat(b), []);

    return formatData(data);
  };

  const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

  const cubejsParams = getCubejsApiParams(API_URL);

  const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

  const filters = [
    { member: 'Answers.date', operator: 'inDateRange', values: dateRangeFilter.dateRange },
  ];
  if (location && location !== 'All locations') {
    filters.push({ member: 'Locations.name', operator: 'equals', values: [location] });
  }
  const getItemLocationFilter = (locationName) => ({
    dimension: 'Locations.name',
    operator: 'equals',
    values: [locationName],
  });

  const baseItemDetailsQuery = {
    measures: ['SurveyOptions.pcrStockReagent'],
    timeDimensions: [],
    dimensions: ['SurveyOptions.name'],
    order: {
      'SurveyOptions.pcrStockReagent': 'desc',
    },
    filters: [],
  };

  const getItemDetailQuery = (stockType, locationName) => {
    const filters = [];
    if (locationName.length) filters.push(getItemLocationFilter(locationName));
    filters.push(
      { member: 'Answers.date', operator: 'inDateRange', values: dateRangeFilter.dateRange },
      {
        dimension: 'SurveyOptions.type',
        operator: 'equals',
        values: ['quantity'],
      },
      {
        dimension: stockType,
        operator: 'gt',
        values: ['0'],
      },
    );
    const order = {};
    order[stockType] = 'desc';

    return { ...baseItemDetailsQuery, filters, measures: [stockType] };
  };

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: [
        'SurveyOptions.pcrStockReagent',
        'SurveyOptions.serologyFilterTipsStock',
        'SurveyOptions.extractionStockReagent',
        'SurveyOptions.allStockFilterTips',
      ],
      timeDimensions: [],
      dimensions: ['Locations.name'],
      order: {},
      filters,
    },
    {
      cubejsApi,
    },
  );

  const drillDownResponse = useCubeQuery(drillDownQuery, {
    skip: !drillDownQuery,
    cubejsApi,
  });

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const getXAndYValues = (geomId) => {
    const chartIdPrefix = 'chart-geom0-';
    const pcrStockReagentKey = 'SurveyOptions.pcrStockReagent';
    const serologyFilterTipsStockKey = 'SurveyOptions.serologyFilterTipsStock';
    const extractionStockReagentKey = 'SurveyOptions.extractionStockReagent';
    const locationNameAndMeasure = geomId.replace(chartIdPrefix, '');

    if (locationNameAndMeasure.endsWith(pcrStockReagentKey)) {
      const locationName = locationNameAndMeasure.replace(`-${pcrStockReagentKey}`, '');
      return {
        locationName,
        stockTypeKey: pcrStockReagentKey,
      };
    }

    if (locationNameAndMeasure.endsWith(serologyFilterTipsStockKey)) {
      const locationName = locationNameAndMeasure.replace(`-${serologyFilterTipsStockKey}`, '');
      return {
        locationName,
        stockTypeKey: serologyFilterTipsStockKey,
      };
    }

    if (locationNameAndMeasure.endsWith(extractionStockReagentKey)) {
      const locationName = locationNameAndMeasure.replace(`-${extractionStockReagentKey}`, '');
      return {
        locationName,
        stockTypeKey: extractionStockReagentKey,
      };
    }
  };

  enum StockTypeName {
    'SurveyOptions.pcrStockReagent' = 'PCR Reagent stock',
    'SurveyOptions.serologyFilterTipsStock' = 'Serology filter tips stock',
    'SurveyOptions.extractionStockReagent' = 'Extraction Reagent stock',
    'SurveyOptions.allStockFilterTips' = 'Total Filter tips',
  }

  const handleClickOnChart = (data) => {
    // const query = getXAndYValues(geomId);
    const query = {
      stockTypeKey: data.label,
      locationName: data.x,
    };

    setDrillDownQuery(getItemDetailQuery(query.stockTypeKey, query.locationName));

    if (drillDownResponse) {
      setTableDescription({
        locationName: query.locationName,
        stockTypeName: StockTypeName[query.stockTypeKey],
      });
      setIsModalVisible(true);
    }
  };

  const handleModalOk = () => setIsModalVisible(false);
  const handleModalCancel = () => setIsModalVisible(false);

  const colors = ['color', ['#27a29e', '#753BBD', '#A72566', '#E38F3C']];
  const BarRender = ({ resultSet }) => (
    <Chart
      scale={{ x: { tickCount: 8 } }}
      // height={280}
      data={stackedChartData(resultSet)}
      autoFit
      padding="auto"
      onIntervalClick={(e, chart) => {
        handleClickOnChart(e.data.data);
      }}
    >
      <Axis name="x" label={false} tickLine={false} />
      <Axis name="measure" />
      <Tooltip offset={100} />
      {/* <Geom type="interval" position={`x*measure`} color={colors} /> */}
      <Interval adjust={[{ type: 'stack' }]} position="x*measure" color={colors} />
    </Chart>
  );

  const ModalHeader = () => (
    <Row>
      <Col>
        <Title level={4}>{tableDescription.stockTypeName}</Title>
        <Text type="secondary" level={5}>
          {tableDescription.locationName}
        </Text>
      </Col>
    </Row>
  );

  const data = resultSet?.loadResponses[0].data || null;

  return data && data.length ? (
    <>
      <BarRender resultSet={resultSet} />
      <Modal
        title={<ModalHeader />}
        centered
        visible={isModalVisible}
        width={720}
        onOk={handleModalOk}
        onCancel={handleModalCancel}
        destroyOnClose
      >
        <ItemDetailsTable
          resultSet={drillDownResponse.resultSet}
          pivotConfig={drillDownResponse.pivotConfig || null}
        />
      </Modal>
    </>
  ) : (
    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
  );
};

export default TotalReagentStockCount;
