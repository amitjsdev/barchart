export default [
  {
    key: 'me1',
    value: 'Bioneer',
  },
  {
    key: 'me2',
    value: 'Thermo Fisher',
  },
  {
    key: 'me3',
    value: 'Perkin Elmer',
  },
  {
    key: 'me4',
    value: 'Abbott m24sp',
  },
  {
    key: 'me5',
    value: 'Abbott m2000sp',
  },
  {
    key: 'me6',
    value: 'Extraction MBGI',
  },
  {
    key: 'me7',
    value: 'Mag NA Pure',
  },
  {
    key: 'me8',
    value: 'C 6800',
  },
  {
    key: 'me9',
    value: 'EZ1',
  },
  {
    key: 'me0',
    value: 'Others',
  },

  {
    key: 'mpcr1',
    value: 'ABI RT PCR',
  },
  {
    key: 'mpcr2',
    value: 'ROCH -LIGHTCYCLER',
  },
  {
    key: 'mpcr3',
    value: 'BGI PCR',
  },
  {
    key: 'mpcr4',
    value: 'Abbott m2000rt RealTime PCR',
  },
  {
    key: 'mpcr5',
    value: 'Real-Time PCR Rotor GENE',
  },
  {
    key: 'mpcr6',
    value: 'Real-Time PCR Applied Biosystem 7500',
  },

  {
    key: 'me1',
    value: 'Bioneer',
  },
  {
    key: 'me2',
    value: 'Thermo Fisher',
  },
  {
    key: 'me3',
    value: 'Perkin Elmer',
  },
  {
    key: 'me4',
    value: 'Abbott m24sp',
  },
  {
    key: 'me5',
    value: 'Abbott m2000sp',
  },
  {
    key: 'me6',
    value: 'Extraction MBGI',
  },
  {
    key: 'me7',
    value: 'Mag NA Pure',
  },
  {
    key: 'me8',
    value: 'C 6800',
  },
  {
    key: 'me9',
    value: 'EZ1',
  },
  {
    key: 'me0',
    value: 'Others',
  },
  {
    key: 'mpcr1',
    value: 'ABI RT PCR',
  },
  {
    key: 'mpcr2',
    value: 'ROCH -LIGHTCYCLER',
  },
  {
    key: 'mpcr3',
    value: 'BGI PCR',
  },
  {
    key: 'mpcr4',
    value: 'Abbott m2000rt RealTime PCR',
  },
  {
    key: 'mpcr5',
    value: 'Real-Time PCR Rotor GENE',
  },
  {
    key: 'mpcr6',
    value: 'Real-Time PCR Applied Biosystem 7500',
  },

  {
    key: 're1',
    value: 'MagNA Pure 96 DNA and Viral NA SV Kit from Roche',
  },
  {
    key: 're2',
    value: 'EXTRACTION  (Thermo Fisher)',
  },
  {
    key: 're3',
    value: 'cobas® SARS-CoV-2 fro, Roche',
  },
  {
    key: 're4',
    value: 'DNA/RNA Extraction  Abbott',
  },
  {
    key: 're5',
    value: 'EXTRACTION (Boineer)',
  },
  {
    key: 're6',
    value: 'EXTRACTION (Perkin Elmer)',
  },
  {
    key: 're7',
    value: 'Qiagen EZ1 Extraction',
  },

  {
    key: 'rpcr1',
    value: 'KOGENE',
  },
  {
    key: 'rpcr2',
    value: 'QUIDEL',
  },
  {
    key: 'rpcr3',
    value: 'Solgent - nCoV PCR Test',
  },
  {
    key: 'rpcr4',
    value: 'Abbott SARS-CoV-2 Amplification Reagent (PCR)',
  },
  {
    key: 'rpcr5',
    value: 'CO-DIAGNOSTICS',
  },
  {
    key: 'rpcr6',
    value: 'ALTONA SARS CoV-2 PCR KIT 1.0',
  },
  {
    key: 'rpcr7',
    value: 'RdRb',
  },
  {
    key: 'rpcr0',
    value: 'Others',
  },

  {
    key: 're1',
    value: 'MagNA Pure 96 DNA and Viral NA SV Kit from Roche',
  },
  {
    key: 're2',
    value: 'EXTRACTION  (Thermo Fisher)',
  },
  {
    key: 're3',
    value: 'cobas® SARS-CoV-2 fro, Roche',
  },
  {
    key: 're4',
    value: 'DNA/RNA Extraction  Abbott',
  },
  {
    key: 're5',
    value: 'EXTRACTION (Boineer)',
  },
  {
    key: 're6',
    value: 'EXTRACTION (Perkin Elmer)',
  },
  {
    key: 're7',
    value: 'Qiagen EZ1 Extraction',
  },
  {
    key: 'rpcr1',
    value: 'KOGENE',
  },
  {
    key: 'rpcr2',
    value: 'QUIDEL',
  },
  {
    key: 'rpcr3',
    value: 'Solgent - nCoV PCR Test',
  },
  {
    key: 'rpcr4',
    value: 'Abbott SARS-CoV-2 Amplification Reagent (PCR)',
  },
  {
    key: 'rpcr5',
    value: 'CO-DIAGNOSTICS',
  },
  {
    key: 'rpcr6',
    value: 'ALTONA SARS CoV-2 PCR KIT 1.0',
  },
  {
    key: 'rpcr7',
    value: 'RdRb',
  },
  {
    key: 'rpcr0',
    value: 'Others',
  },

  {
    key: 'consumable_pcr0',
    value: 'Others',
  },
  {
    key: 'consumable_pcr1',
    value: 'Processing Cartridges',
  },
  {
    key: 'consumable_pcr2',
    value: '1000ul tips',
  },
  {
    key: 'consumable_pcr3',
    value: '300ul tips',
  },

  {
    key: 'consumable_pcr4',
    value: '200ul tips',
  },
  {
    key: 'consumable_pcr5',
    value: '100ul tips',
  },
  {
    key: 'consumable_pcr6',
    value: '10ul tips',
  },
  {
    key: 'consumable_pcr7',
    value: 'Tips-comb plate',
  },

  {
    key: 'ms1',
    value: 'PEBIII',
  },
  {
    key: 'ms2',
    value: 'TECAN',
  },
  {
    key: 'ms3',
    value: 'BGI',
  },
  {
    key: 'ms4',
    value: 'Evolis',
  },
  {
    key: 'ms5',
    value: 'ET-Max',
  },
  {
    key: 'ms6',
    value: 'DEMO',
  },
  {
    key: 'ms7',
    value: 'DYNIX',
  },
  {
    key: 'ms8',
    value: 'ARCHITECT i2000',
  },
  {
    key: 'ms9',
    value: 'IMMAGE 800',
  },
  {
    key: 'ms0',
    value: 'Others',
  },
  {
    key: 'ms1',
    value: 'PEBIII',
  },
  {
    key: 'ms2',
    value: 'TECAN',
  },
  {
    key: 'ms3',
    value: 'BGI',
  },
  {
    key: 'ms4',
    value: 'Evolis',
  },
  {
    key: 'ms5',
    value: 'ET-Max',
  },
  {
    key: 'ms6',
    value: 'DEMO',
  },
  {
    key: 'ms7',
    value: 'DYNIX',
  },
  {
    key: 'ms8',
    value: 'ARCHITECT i2000',
  },
  {
    key: 'ms9',
    value: 'IMMAGE 800',
  },
  {
    key: 'ms0',
    value: 'Others',
  },

  {
    key: 'serology_consumable0',
    value: 'Others',
  },
  {
    key: 'serology_consumable1',
    value: 'Antibodies',
  },
  {
    key: 'serology_consumable2',
    value: '1000ul',
  },
  {
    key: 'serology_consumable3',
    value: '300ul',
  },

  {
    key: 'serology_consumable4',
    value: '200ul',
  },
  {
    key: 'serology_consumable5',
    value: '1000ul',
  },
  {
    key: 'serology_consumable6',
    value: '10ul',
  },

  // Change my keys
  {
    key: 'serology_consumable7',
    value: 'IgG',
  },

  // Change my keys
  {
    key: 'serology_consumable8',
    value: 'IgM',
  },
  {
    key: 'filter_tiptype0',
    value: 'Others',
  },
  {
    key: 'filter_tiptype1',
    value: '1000ul',
  },
  {
    key: 'filter_tiptype2',
    value: '300ul',
  },
  {
    key: 'filter_tiptype3',
    value: '200ul',
  },
  {
    key: 'filter_tiptype4',
    value: '100ul',
  },
  {
    key: 'filter_tiptype5',
    value: '10ul',
  },
  {
    key: 're0',
    value: 'Others',
  },
  {
    key: 'stock_filter_tiptype0',
    value: 'Others',
  },
  {
    key: 'stock_filter_tiptype1',
    value: '10ul',
  },
  {
    key: 'stock_filter_tiptype2',
    value: '20ul',
  },
  {
    key: 'stock_filter_tiptype3',
    value: '100ul',
  },
  {
    key: 'stock_filter_tiptype4',
    value: '200ul',
  },
  {
    key: 'stock_filter_tiptype5',
    value: '300ul',
  },
  {
    key: 'stock_filter_tiptype6',
    value: '1000ul',
  },
];
