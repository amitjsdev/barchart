import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Row, Col, Statistic, Spin, Space, Typography } from 'antd';
import { InboxOutlined } from '@ant-design/icons';

import { getCubejsApiParams } from '@/services/cubejs';

const { Text } = Typography;

enum QueryKeys {
  TOTAL_RECEIVED_SAMPLES = 'Answers.totalReceivedSamples',
}

const numberRender = ({ resultSet }) => (
  <Row justify="center" align="middle" style={{ height: '100%' }}>
    <Col>
      {resultSet.seriesNames().map((s) => (
        <Statistic value={resultSet.totalRow()[s.key]} />
      ))}
    </Col>
  </Row>
);

const cubejsParams = getCubejsApiParams();

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) => {
  const data = resultSet?.loadResponses[0]?.data;
  const result = (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
    (error && error.toString()) || <Spin />;

  return data && data.length && data[0][QueryKeys.TOTAL_RECEIVED_SAMPLES] !== null ? (
    result
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

const ChartRenderer = (props) => {
  const { dateRangeFilter, location } = props;

  const filters = [
    { member: 'Answers.date', operator: 'inDateRange', values: dateRangeFilter.dateRange },
  ];
  if (location && location !== 'All locations') {
    filters.push({ member: 'Locations.name', operator: 'equals', values: [location] });
  }
  return (
    <QueryRenderer
      query={{
        measures: [QueryKeys.TOTAL_RECEIVED_SAMPLES],
        filters,
      }}
      cubejsApi={cubejsApi}
      render={renderChart(numberRender, {
        x: [],
        y: ['measures'],
        fillMissingDates: true,
        joinDateRange: false,
      })}
    />
  );
};

export default ChartRenderer;
