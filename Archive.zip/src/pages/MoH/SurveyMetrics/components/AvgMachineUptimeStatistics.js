import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Row, Col, Statistic, Table, Spin, Empty, Space, Typography } from 'antd';
import { InboxOutlined } from '@ant-design/icons';

import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';

const { Text } = Typography;

const formatValue = (value) => Math.round(value) * 8;

const numberRender = ({ resultSet, pivotConfig }) => (
  <Row type="flex" justify="center" align="middle" style={{ height: '100%' }}>
    {resultSet.seriesNames().map((s) => {
      if (s.key === 'Answers.averageMachineUptimeHours') {
        return (
          <Col key={s.key}>
            <Statistic value={formatValue(resultSet.totalRow()[s.key])} />
          </Col>
        );
      }

      return (
        <Col key={s.key}>
          <Statistic
            value={`/ ${formatValue(resultSet.totalRow()[s.key])}`}
            valueStyle={{ fontSize: '1em', paddingLeft: '12px' }}
          />
        </Col>
      );
    })}
  </Row>
);

const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint
const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) => {
  const data = resultSet?.loadResponses?.data;
  const result = (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
    (error && error.toString()) || <Spin />;

  return result;

  /* return data && data.length ? (
    result
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  ); */
};

const ChartRenderer = (props) => {
  const { dateRangeFilter } = props;

  /* const timeDimensions = [
    {
      dimension: 'Answers.createdat',
      granularity: dateRangeFilter.granularity,
      dateRange: dateRangeFilter.dateRange,
    },
  ]; */
  const filters = [
    { member: 'Answers.date', operator: 'inDateRange', values: dateRangeFilter.dateRange },
  ];
  return (
    <QueryRenderer
      query={{
        measures: ['Answers.averageMachineUptimeHours', 'Answers.averageMachineTotalHours'],
        timeDimensions: [],
        order: {},
        filters,
      }}
      cubejsApi={cubejsApi}
      render={renderChart(numberRender, {
        x: [],
        y: ['measures'],
        fillMissingDates: true,
        joinDateRange: false,
      })}
    />
  );
};

export default ChartRenderer;
