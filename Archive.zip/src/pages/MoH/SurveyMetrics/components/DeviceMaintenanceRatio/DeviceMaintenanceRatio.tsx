import React, { useState } from 'react';
import { Empty, Spin } from 'antd';
import { Pie } from '@ant-design/charts';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '../../../../hostname';

import styles from './index.less';

const colors = {
  yes: '#1DAD28',
  no: '#E33C3C',
};
/* const data = [
  {
    type: 'Yes',
    value: 77,
  },
  {
    type: 'No',
    value: 23,
  },
]; */

const convertToPercentage = (value, totalCount) => {
  if (totalCount) return ((value / totalCount) * 100).toFixed(2);
  return 1;
};

// CubeJS
const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint
const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

// CubeJS
const cubeQueryRender = (props) => {
  const { dateRangeFilter } = props;

  /* const timeDimensions = [
    {
      dimension: 'Answers.date',
      granularity: dateRangeFilter.granularity,
      dateRange: dateRangeFilter.dateRange,
    },
  ]; */

  const filters = [
    { member: 'Answers.date', operator: 'inDateRange', values: dateRangeFilter.dateRange },
  ];

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['Answers.machineRegularMaintainence', 'Answers.machineNoRegularMaintainence'],
      timeDimensions: [],
      filters,
      order: {},
    },
    {
      cubejsApi,
    },
  );

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const dataSource = resultSet.tablePivot();

  //   Answers.machineNoRegularMaintainence: 7
  // Answers.machineRegularMaintainence: 5
  const data = {
    yesCount: dataSource[0]['Answers.machineRegularMaintainence'],
    noCount: dataSource[0]['Answers.machineNoRegularMaintainence'],
  };

  const totalCount = data.yesCount + data.noCount;

  const chartData = [
    {
      type: 'Yes',
      value: +convertToPercentage(data.yesCount, totalCount),
    },
    {
      type: 'No',
      value: +convertToPercentage(data.noCount, totalCount),
    },
  ];

  return totalCount ? (
    <SamplesCollectedPie data={chartData} />
  ) : (
    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
  );
};

const SamplesCollectedPie: React.FC = (props) => {
  // ANT Chart
  const config = {
    // renderer: 'svg',
    autoFit: true,
    appendPadding: 10,
    data: props.data,
    angleField: 'value',
    colorField: 'type',
    color: [colors.yes, colors.no],
    /* color: (type: string) => {
      if (type === 'Safe stock') return colors.safeStock;
      if (type === 'Near OOS') return colors.nearOos;
      if (type === 'OOS') return colors.oos;
    }, */
    radius: 1,
    innerRadius: 0,
    pieStyle: {
      stroke: 0,
    },
    label: {
      type: 'inner',
      offset: '-0.5',
      content: '{name} - {percentage}',
      style: {
        fill: '#fff',
        fontSize: 0,
        textAlign: 'center',
      },
    },
    legend: {
      layout: 'horizontal',
      position: 'bottom',
    },
    /* statistic: {
      title: false,
      content: { formatter: () => `${data.reduce((acc, cur) => acc + cur.value, 0)}` },
    }, */
    // statistic : { title : { formatter : ( ) => 'Total' } } ,
  };
  return <Pie className={styles.fixValue} {...config} />;
};

/* const InventoryComposition = () => {
  const chartData = cubeQueryRender();
  

  return <SamplesCollectedPie data={chartData} />
} */

export default cubeQueryRender;
