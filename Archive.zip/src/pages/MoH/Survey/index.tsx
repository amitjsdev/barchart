import React, { useState, useEffect } from 'react';
import {
  Spin,
  Card,
  Row,
  Col,
  Select,
  DatePicker,
  Affix,
  Anchor,
  Divider,
  Typography,
  message,
  Form,
  Input,
  Button,
  Radio,
  Result,
  InputNumber,
} from 'antd';
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import { connect, Access, useAccess, useModel } from 'umi';

// import { ISurveySection } from './surveyInterface';
import moment from 'moment';
import { PageContainer } from '@ant-design/pro-layout';
import { ModuleTypes } from '@/services/Constants';
import mohService from '../services/moh.service';
import { StateType } from './model';
import styles from './index.less';

const { Link } = Anchor;
const { Text, Paragraph } = Typography;

let tableData = {};
let surveyData = {};

const Success: React.FC<any> = (props) => {
  return (
    <div style={{ padding: '10%' }}>
      <Result
        status="success"
        title="Form Successfully Submitted"
        subTitle="Please come tomorrow to take the survey."
        extra={[]}
      />
    </div>
  );
};

const SurveyForm = (props: any) => {
  const { mohProfile } = props;
  const [loading, setLoading] = useState<boolean>(true);
  const [inputFieldValues, setInputFieldValues] = useState({});
  const [inputFieldValuesSurvey, setInputFieldValuesSurvey] = useState({});
  const [nonReagentConsumable, setNonReagentConsumable] = useState<boolean>(false);
  const [nonSerologyConsumable, setSerologyConsumable] = useState<boolean>(false);
  const [showSubmitted, setShowSubmitted] = useState<boolean>(false);
  const [showSurveyForm, setShowSurveyForm] = useState<boolean>(false);

  const userAccess = useAccess();

  const [fieldsOpen, setFieldsOpen] = useState<boolean>(false);
  const resetConsumableFieldsCallbacks: any[] = [];
  const resetSerelogyFieldsCallbacks: any[] = [];

  const setItemName = (value: any) => {
    inputFieldValues[value.key][value.index][value.name] = isNaN(parseInt(value.value))
      ? value.value
      : parseInt(value.value);
    setInputFieldValues({ ...inputFieldValues });
  };

  const disabledDate = (current: any) => {
    // Can not select days after today
    return current && current > moment().endOf('day');
  };

  const surveyValues = (value: any) => {
    if (value.type === 'date') {
      inputFieldValuesSurvey[value.key] = value.value;
    } else {
      inputFieldValuesSurvey[value.key] = isNaN(parseInt(value.value))
        ? value.value
        : parseInt(value.value);
    }
    setInputFieldValuesSurvey({ ...inputFieldValuesSurvey });
  };

  const onFinish = () => {
    let totalTest = 0;
    let totalRetest = 0;
    const surveyArray = Object.entries(inputFieldValuesSurvey).map((item: any) => {
      if (item[0] === 'test_total_no_of_tests_done') {
        totalTest = item[1];
      }
      if (item[0] === 'machine_total_no_of_samples_retested') {
        totalRetest = item[1];
      }
      return { key: item[0], value: item[1] };
    });

    const keysOfOptionsarrays: any = Object.keys(inputFieldValues);
    const arrayOfOptionsarrays: any = Object.values(inputFieldValues);
    const optionsArray = [];

    for (var i = 0; i < arrayOfOptionsarrays.length; i++) {
      for (let j = 0; j < arrayOfOptionsarrays[i].length; j++) {
        optionsArray.push({ ...arrayOfOptionsarrays[i][j], key: keysOfOptionsarrays[i] });
      }
    }

    // validations

    if (surveyArray.length !== 11) {
      message.error('Please fill all the fields');
      return;
    }
    if (totalTest < totalRetest) {
      message.error('Total numer of Test should be greater than Sample Retested');
      return;
    }
    const tempOptionsArray = optionsArray.filter((option: any) => {
      return !['machine_malfunctioning', 'serology_malfunctioning_machines'].includes(option.key);
    });
    for (var i = 0; i < tempOptionsArray.length; i++) {
      if (
        Object.values(tempOptionsArray[i]).some((val) => {
          return val === null;
        })
      ) {
        message.error('Please fill all the fields!');
        return;
      }
    }

    // Validation for Optional Fields
    const tempOptionalArray = optionsArray.filter((option: any) => {
      return ['machine_malfunctioning', 'serology_malfunctioning_machines'].includes(option.key);
    });
    for (let j = 0; j < tempOptionalArray.length; j++) {
      if (
        (tempOptionalArray[j].dropdownValue === null && tempOptionalArray[j].issue !== null) ||
        (tempOptionalArray[j].dropdownValue !== null && tempOptionalArray[j].issue === null)
      ) {
        message.error('Please fill all the fields');
        return;
      }
    }
    //
    // -------------validation Ends

    const filteredOptionsArray = optionsArray.filter((option) => option.dropdownValue);

    mohService.getSurveyFormStatus(mohProfile.locationId).then((isSubmitted) => {
      if (isSubmitted) {
        message.error('Form was already submitted');
      } else if (props.dispatch) {
        props.dispatch({
          type: 'mohSurvey/saveSurvey',
          payload: [...surveyArray],
        });

        props.dispatch({
          type: 'mohSurvey/saveOptions',
          payload: [...filteredOptionsArray],
        });

        props.dispatch({
          type: 'mohSurvey/submitForm',
          payload: {
            survey: surveyArray,
            options: filteredOptionsArray,
            locationId: mohProfile.locationId,
          },
        });
      }
    });
  };

  const saveAsDraft = () => {
    mohService.getSurveyFormStatus(mohProfile.locationId).then((isSubmitted) => {
      if (isSubmitted) {
        message.error('Form was already submitted');
      } else if (props.dispatch) {
        props.dispatch({
          type: 'mohSurvey/saveSurveyFormDraft',
          payload: {
            survey: inputFieldValuesSurvey,
            options: inputFieldValues,
            locationId: mohProfile.locationId,
          },
        });
      }
    });
  };

  const showHideFieldsReagentConsumable = (value: any) => {
    if (value.value === true) {
      setNonReagentConsumable(true);
    } else {
      resetConsumableFieldsCallbacks.forEach((cb) => cb());
      delete inputFieldValues.stock_storage_consumable;
      setInputFieldValues({ ...inputFieldValues });
      setNonReagentConsumable(false);
    }
  };

  const showHideFieldsSerologyConsumable = (value: any) => {
    if (value.value === true) {
      setSerologyConsumable(true);
    } else {
      resetSerelogyFieldsCallbacks.forEach((cb) => cb());
      delete inputFieldValues.serology_consumables;
      setInputFieldValues({ ...inputFieldValues });
      setSerologyConsumable(false);
    }
  };

  const addNewRow = (questionKey: any, rowSchema: any) => {
    // {machine: {}}
    inputFieldValues[questionKey] = inputFieldValues[questionKey] || [];
    // {machine:{mx0: []}}
    inputFieldValues[questionKey].push(rowSchema);
    // {machine:{mx0: [{}]}}
    setInputFieldValues({ ...inputFieldValues });
  };

  const removeRow = (questionKey: any, index: number) => {
    inputFieldValues[questionKey]?.splice(index, 1);
    setInputFieldValues({ ...inputFieldValues });
  };

  useEffect(() => {
    mohService.getSurveyFormStatus(mohProfile.locationId).then((isSubmitted) => {
      if (isSubmitted) {
        setShowSubmitted(true);
      } else {
        mohService.getSurveyDraftForm(mohProfile.locationId).then((res) => {
          if (!res.data) {
            setShowSurveyForm(true);
          } else {
            tableData = res.data.options; // for nested Fields
            surveyData = res.data.survey;

            setInputFieldValuesSurvey({ ...surveyData });
            if (surveyData.serology_shortage_in_fourteen_days) {
              setSerologyConsumable(true);
            }
            if (surveyData.stock_shortage_non_reagent_consumable) {
              setNonReagentConsumable(true);
            }
            setShowSurveyForm(true);
          }
        });
      }
      setLoading(false);
    });
  }, []);

  if (showSubmitted && userAccess?.canUpdateMohSurvey()) return <Success />;
  if (showSurveyForm || !userAccess?.canUpdateMohSurvey()) {
    return (
      <PageContainer title="Ministry of Health form" className={styles.main}>
        <Spin spinning={loading} size="large" />
        <Row gutter={[24, 24]}>
          {/* Sidebar */}
          <Col span={6}>
            <Affix offsetTop={72}>
              <div className={styles.sidebar}>
                <Anchor className={styles.sidebarMenu}>
                  <Link href="#machines" title="Machines" />
                  <Link href="#tests" title="Tests" />
                  <Link href="#stock" title="Stock" />
                  <Link href="#serology" title="Serology" />
                </Anchor>
                <div className={styles.info}>
                  {/* Email */}
                  <Divider />
                  <div className={styles.infoEmail}>
                    <Paragraph>
                      <Text>Email me at:</Text>
                      <br />
                      <a href="mailto:hesham.alnasser@ascend.com.sa">
                        hesham.alnasser@ascend.com.sa
                      </a>
                    </Paragraph>
                  </div>
                  <Divider />

                  {/* Info */}
                  <div className={styles.infoContent}>
                    <ol>
                      <li>If any Questions has been missed in the Survey</li>
                      <li>For Any Suggestion to Improve the survey</li>
                    </ol>
                  </div>
                </div>
              </div>
            </Affix>
          </Col>

          {/* Form */}
          <Col span={18}>
            {props.formContent.map((section: any) => {
              return (
                <Card
                  id={section.sectionName.toLocaleLowerCase()}
                  className={styles.section}
                  title={section.sectionName}
                >
                  {section.contents.map((content: any) => {
                    return content.enableTable === true && content.enableFormFields === true ? (
                      <Card
                        type="inner"
                        title={content.questionInArabic}
                        style={{ marginTop: '2%' }}
                      >
                        <Form
                          scrollToFirstError
                          layout="vertical"
                          // autoComplete="off"
                          name={content.key}
                          initialValues={{}}
                        >
                          <Form.List name={section.sectionName}>
                            {(fields, { add, remove }) => {
                              if (!fieldsOpen) {
                                setFieldsOpen(true);
                                if (Object.keys(tableData).length > 0) {
                                  for (let i = 0; i < tableData[content.key].length; i++) {
                                    add();
                                    addNewRow(content.key, tableData[content.key][i]);
                                  }
                                } else {
                                  add();
                                  addNewRow(
                                    content.key,
                                    content.formFields.reduce((acc, field) => {
                                      return { ...acc, [field.name]: null };
                                    }, {}),
                                  );
                                }
                              }

                              return (
                                <div className={styles.formFieldContainer}>
                                  {fields.map((field: any, fieldIndex) => (
                                    <div>
                                      {content.formFields.map((inputField: any, index: number) => {
                                        return inputField.valueType === 'input' ? (
                                          <Form.Item
                                            className={styles.formField}
                                            label={inputField.label}
                                            {...field}
                                            name={[field.name, inputField.name]}
                                            key={inputField.name + index}
                                            initialValue={
                                              inputFieldValues[content.key][field.name][
                                                inputField.name
                                              ]
                                            }
                                            rules={[
                                              {
                                                required: content.required,
                                                message: 'Required',
                                              },
                                              {
                                                type: 'number',
                                                min: 0,
                                                message: 'Should be more than 0',
                                              },
                                            ]}
                                          >
                                            <InputNumber
                                              style={{ width: '200px' }}
                                              min={0}
                                              placeholder=""
                                              // type={inputField.inputType}
                                              disabled={(() => {
                                                const selectfield = content.formFields.find(
                                                  (field: any) => field.valueType === 'select',
                                                );
                                                if (!selectfield) {
                                                  return false;
                                                }
                                                return !inputFieldValues[content.key][fieldIndex][
                                                  selectfield.name
                                                ];
                                              })()}
                                              onChange={(value) =>
                                                setItemName({
                                                  value,
                                                  name: inputField.name,
                                                  index: fieldIndex,
                                                  key: content.key,
                                                })
                                              }
                                            />
                                          </Form.Item>
                                        ) : (
                                          <Form.Item
                                            className={styles.formField}
                                            label={inputField.label}
                                            key={inputField.name + index}
                                            // style={{ width: '200px' }}
                                            name={[field.name, inputField.name]}
                                            initialValue={
                                              inputFieldValues[content.key][field.name][
                                                inputField.name
                                              ]
                                            }
                                            rules={[
                                              {
                                                required: content.required,
                                                message: 'Required',
                                              },
                                            ]}
                                          >
                                            <Select
                                              style={{ width: '350px' }}
                                              disabled={(() => {
                                                const selectfield = content.formFields.find(
                                                  (field: any) => field.valueType === 'select',
                                                );
                                                if (!selectfield) {
                                                  return false;
                                                }
                                                return (
                                                  inputField.name === 'issue' &&
                                                  !inputFieldValues[content.key][fieldIndex][
                                                    selectfield.name
                                                  ]
                                                );
                                              })()}
                                              onChange={(e) =>
                                                setItemName({
                                                  value: e,
                                                  name: inputField.name,
                                                  section: section.sectionName,
                                                  index: fieldIndex,
                                                  key: content.key,
                                                })
                                              }
                                            >
                                              {inputField.selectOptions.map((option: any) => (
                                                <Select.Option
                                                  key={option.key}
                                                  value={option.key}
                                                  disabled={inputFieldValues[content.key]?.find(
                                                    (val: any) => {
                                                      return val.dropdownValue === option.key;
                                                    },
                                                  )}
                                                >
                                                  {option.value}
                                                </Select.Option>
                                              ))}
                                            </Select>
                                          </Form.Item>
                                        );
                                      })}

                                      <MinusCircleOutlined
                                        style={{ marginBottom: '1.5%' }}
                                        onClick={() => {
                                          if (fields.length > 1) {
                                            remove(field.name);
                                            removeRow(content.key, fieldIndex);
                                          }
                                        }}
                                      />
                                    </div>
                                  ))}

                                  <Form.Item>
                                    <Button
                                      type="dashed"
                                      onClick={() => {
                                        add();
                                        addNewRow(
                                          content.key,
                                          content.formFields.reduce((acc, field) => {
                                            return { ...acc, [field.name]: null };
                                          }, {}),
                                        );
                                      }}
                                    >
                                      <PlusOutlined /> Add field
                                    </Button>
                                  </Form.Item>
                                </div>
                              );
                            }}
                          </Form.List>
                        </Form>
                      </Card>
                    ) : content.enableTable === false && content.enableFormFields === true ? (
                      <Card type="inner" style={{ marginTop: '2%' }}>
                        <Form
                          scrollToFirstError
                          layout="vertical"
                          autoComplete="off"
                          name={content.key}
                        >
                          {content.surveyFields.type === 'radio' ? (
                            <Form.Item
                              initialValue={surveyData[content.key]}
                              name={content.key}
                              label={content.questionInArabic}
                              rules={[{ required: content.required, message: 'Required' }]}
                            >
                              <Radio.Group
                                onChange={(e) =>
                                  surveyValues({
                                    value: e.target.value,
                                    key: content.key,
                                    type: 'radio',
                                  })
                                }
                              >
                                <Radio value>Yes</Radio>
                                <Radio value={false}>No</Radio>
                              </Radio.Group>
                            </Form.Item>
                          ) : content.surveyFields.type === 'input' ? (
                            <Form.Item
                              name={content.key}
                              initialValue={surveyData[content.key]}
                              label={content.questionInArabic}
                              rules={[
                                { required: content.required, message: 'Required' },
                                {
                                  type: 'number',
                                  min: 0,
                                  message: 'Should be more than 0',
                                },
                              ]}
                            >
                              <InputNumber
                                style={{ width: '200px' }}
                                min={0}
                                placeholder=""
                                // type={inputField.inputType}
                                onChange={(value) =>
                                  surveyValues({
                                    value,
                                    key: content.key,
                                    type: 'input',
                                  })
                                }
                              />
                            </Form.Item>
                          ) : (
                            <Form.Item
                              name={content.key}
                              // initialValue={optionData[content.key]}
                              initialValue={
                                surveyData[content.key] ? moment(surveyData[content.key]) : ''
                              }
                              label={content.questionInArabic}
                              rules={[{ required: content.required, message: 'Required' }]}
                            >
                              <DatePicker
                                disabledDate={disabledDate}
                                style={{ width: '200px' }}
                                onChange={(value, dateString) => {
                                  surveyValues({
                                    value: dateString.toString(),
                                    key: content.key,
                                    type: 'date',
                                  });
                                }}
                              />
                            </Form.Item>
                          )}
                        </Form>
                      </Card>
                    ) : content.enableTable === true &&
                      content.enableFormFields === false &&
                      content.key === 'stock_storage_consumable' ? (
                      <Card type="inner" style={{ marginTop: '2%' }}>
                        <Form
                          scrollToFirstError
                          layout="vertical"
                          autoComplete="off"
                          name={content.key}
                        >
                          <Form.Item
                            initialValue={surveyData.stock_shortage_non_reagent_consumable}
                            name={content.key}
                            label={content.questionInArabic}
                            rules={[{ required: content.required, message: 'Required' }]}
                          >
                            <Radio.Group
                              onChange={(e) => {
                                showHideFieldsReagentConsumable({
                                  key: content.key,
                                  value: e.target.value,
                                });
                                surveyValues({
                                  value: e.target.value,
                                  key: 'stock_shortage_non_reagent_consumable',
                                  type: 'radio',
                                });
                              }}
                            >
                              <Radio value>Yes</Radio>
                              <Radio value={false}>No</Radio>
                            </Radio.Group>
                          </Form.Item>

                          {nonReagentConsumable === true ? (
                            <Form.List
                              name={section.sectionName}
                              key={nonReagentConsumable.toString()}
                            >
                              {(fields, { add, remove }) => {
                                if (!fieldsOpen) {
                                  setFieldsOpen(true);
                                  if (tableData[content.key]) {
                                    for (let i = 0; i < tableData[content.key].length; i++) {
                                      add();
                                      addNewRow(content.key, tableData[content.key][i]);
                                    }
                                  } else {
                                    add();
                                    addNewRow(
                                      content.key,
                                      content.formFields.reduce((acc, field) => {
                                        return { ...acc, [field.name]: null };
                                      }, {}),
                                    );
                                  }
                                }

                                return (
                                  <div className={styles.formFieldContainer}>
                                    {fields.map((field: any, fieldIndex) => (
                                      <div>
                                        {content.formFields.map((inputField, index) => {
                                          resetConsumableFieldsCallbacks.push(() => {
                                            remove(field.name);
                                            removeRow(content.key, fieldIndex);
                                          });

                                          return inputField.valueType === 'input' ? (
                                            <Form.Item
                                              className={styles.formField}
                                              label={inputField.label}
                                              initialValue={
                                                inputFieldValues[content.key][field.name][
                                                  inputField.name
                                                ]
                                              }
                                              {...field}
                                              name={[field.name, inputField.name]}
                                              rules={[
                                                { required: content.required, message: 'Required' },
                                                {
                                                  type: 'number',
                                                  min: 0,
                                                  message: 'Should be more than 0',
                                                },
                                              ]}
                                            >
                                              <InputNumber
                                                style={{ width: '200px' }}
                                                min={0}
                                                placeholder=""
                                                // type={inputField.inputType}
                                                // disabled={(() => {
                                                //   const selectfield = content?.formFields?.find(
                                                //     (field) => field.valueType === 'select',
                                                //   );
                                                //   if (!selectfield) {
                                                //     return false;
                                                //   } else {
                                                //     return !inputFieldValues[content.key][fieldIndex][
                                                //       selectfield.name
                                                //     ];
                                                //   }
                                                // })()}
                                                onChange={(value) =>
                                                  setItemName({
                                                    value,
                                                    name: inputField.name,
                                                    index: fieldIndex,
                                                    key: content.key,
                                                  })
                                                }
                                              />
                                            </Form.Item>
                                          ) : (
                                            <Form.Item
                                              className={styles.formField}
                                              label={inputField.label}
                                              key={inputField.name + index}
                                              initialValue={
                                                inputFieldValues[content.key][field.name][
                                                  inputField.name
                                                ]
                                              }
                                              name={[field.name, inputField.name]}
                                              rules={[
                                                { required: content.required, message: 'Required' },
                                              ]}
                                            >
                                              <Select
                                                style={{ width: '350px' }}
                                                onChange={(e) =>
                                                  setItemName({
                                                    value: e,
                                                    name: inputField.name,
                                                    index: fieldIndex,
                                                    key: content.key,
                                                  })
                                                }
                                              >
                                                {inputField.selectOptions.map((option: any) => (
                                                  <Select.Option
                                                    key={option.key}
                                                    value={option.key}
                                                    disabled={inputFieldValues[content.key].find(
                                                      (val: any) => {
                                                        return val.dropdownValue === option.key;
                                                      },
                                                    )}
                                                  >
                                                    {option.value}
                                                  </Select.Option>
                                                ))}
                                              </Select>
                                            </Form.Item>
                                          );
                                        })}

                                        <MinusCircleOutlined
                                          style={{ marginBottom: '1.5%' }}
                                          onClick={() => {
                                            remove(field.name);
                                            removeRow(content.key, fieldIndex);
                                          }}
                                        />
                                      </div>
                                    ))}

                                    <Form.Item>
                                      <Button
                                        type="dashed"
                                        onClick={() => {
                                          add();
                                          addNewRow(
                                            content.key,
                                            content.formFields.reduce((acc, field) => {
                                              return { ...acc, [field.name]: null };
                                            }, {}),
                                          );
                                        }}
                                      >
                                        <PlusOutlined /> Add field
                                      </Button>
                                    </Form.Item>
                                  </div>
                                );
                              }}
                            </Form.List>
                          ) : null}
                        </Form>
                      </Card>
                    ) : (
                      // Serology Consumable

                      <Card type="inner" style={{ marginTop: '2%' }}>
                        <Form
                          scrollToFirstError
                          layout="vertical"
                          autoComplete="off"
                          name={content.key}
                        >
                          <Form.Item
                            initialValue={surveyData.serology_shortage_in_fourteen_days}
                            name={content.key}
                            label={content.questionInArabic}
                            rules={[{ required: content.required, message: 'Required' }]}
                          >
                            <Radio.Group
                              onChange={(e) => {
                                showHideFieldsSerologyConsumable({
                                  key: content.key,
                                  value: e.target.value,
                                });
                                surveyValues({
                                  value: e.target.value,
                                  key: 'serology_shortage_in_fourteen_days',
                                  type: 'radio',
                                });
                              }}
                            >
                              <Radio value>Yes</Radio>
                              <Radio value={false}>No</Radio>
                            </Radio.Group>
                          </Form.Item>

                          {nonSerologyConsumable === true ? (
                            <Form.List
                              name={section.sectionName}
                              key={nonSerologyConsumable.toString()}
                            >
                              {(fields, { add, remove }) => {
                                if (!fieldsOpen) {
                                  setFieldsOpen(true);
                                  if (tableData[content.key]) {
                                    for (let i = 0; i < tableData[content.key].length; i++) {
                                      add();
                                      addNewRow(content.key, tableData[content.key][i]);
                                    }
                                  } else {
                                    add();
                                    addNewRow(
                                      content.key,
                                      content.formFields.reduce((acc, field) => {
                                        return { ...acc, [field.name]: null };
                                      }, {}),
                                    );
                                  }
                                }
                                return (
                                  <div className={styles.formFieldContainer}>
                                    {fields.map((field: any, fieldIndex) => (
                                      <div>
                                        {content.formFields.map((inputField, index) => {
                                          resetSerelogyFieldsCallbacks.push(() => {
                                            remove(field.name);
                                            removeRow(content.key, fieldIndex);
                                          });
                                          return inputField.valueType === 'input' ? (
                                            <Form.Item
                                              className={styles.formField}
                                              label={inputField.label}
                                              {...field}
                                              name={[field.name, inputField.name]}
                                              initialValue={
                                                inputFieldValues[content.key][field.name][
                                                  inputField.name
                                                ]
                                              }
                                              rules={[
                                                { required: content.required, message: 'Required' },
                                                {
                                                  type: 'number',
                                                  min: 0,
                                                  message: 'Should be more than 0',
                                                },
                                              ]}
                                            >
                                              <InputNumber
                                                style={{ width: '200px' }}
                                                min={0}
                                                placeholder=""
                                                // type={inputField.inputType}
                                                // disabled={(() => {
                                                //   const selectfield = content.formFields.find(
                                                //     (field) => field.valueType === 'select',
                                                //   );
                                                //   if (!selectfield) {
                                                //     return false;
                                                //   } else {
                                                //     return !inputFieldValues[content.key][fieldIndex][
                                                //       selectfield.name
                                                //     ];
                                                //   }
                                                // })()}
                                                onChange={(value) =>
                                                  setItemName({
                                                    value,
                                                    name: inputField.name,
                                                    index: fieldIndex,
                                                    key: content.key,
                                                  })
                                                }
                                              />
                                            </Form.Item>
                                          ) : (
                                            <Form.Item
                                              className={styles.formField}
                                              label={inputField.label}
                                              initialValue={
                                                inputFieldValues[content.key][field.name][
                                                  inputField.name
                                                ]
                                              }
                                              key={inputField.name + index}
                                              // style={{ width: '25em' }}
                                              name={[field.name, inputField.name]}
                                              rules={[
                                                { required: content.required, message: 'Required' },
                                              ]}
                                            >
                                              <Select
                                                style={{ width: '300px' }}
                                                onChange={(e) =>
                                                  setItemName({
                                                    value: e,
                                                    name: inputField.name,
                                                    index: fieldIndex,
                                                    key: content.key,
                                                  })
                                                }
                                              >
                                                {inputField.selectOptions.map((option: any) => (
                                                  <Select.Option
                                                    key={option.key}
                                                    value={option.key}
                                                    disabled={inputFieldValues[content.key].find(
                                                      (val: any) => {
                                                        return val.dropdownValue === option.key;
                                                      },
                                                    )}
                                                  >
                                                    {option.value}
                                                  </Select.Option>
                                                ))}
                                              </Select>
                                            </Form.Item>
                                          );
                                        })}

                                        <MinusCircleOutlined
                                          style={{ marginBottom: '1.5%' }}
                                          onClick={() => {
                                            if (fields.length > 0) {
                                              remove(field.name);
                                              removeRow(content.key, fieldIndex);
                                            }
                                          }}
                                        />
                                      </div>
                                    ))}

                                    <Form.Item>
                                      <Button
                                        type="dashed"
                                        onClick={() => {
                                          add();
                                          addNewRow(
                                            content.key,
                                            content.formFields.reduce((acc, field) => {
                                              return { ...acc, [field.name]: null };
                                            }, {}),
                                          );
                                        }}
                                      >
                                        <PlusOutlined /> Add field
                                      </Button>
                                    </Form.Item>
                                  </div>
                                );
                              }}
                            </Form.List>
                          ) : (
                            <h1 />
                          )}
                        </Form>
                      </Card>
                    );
                  })}
                </Card>
              );
            })}
            <Access accessible={userAccess?.canUpdateMohSurvey()}>
              <Row gutter={[24, 24]}>
                <Col span={3}>
                  <Button type="primary" onClick={onFinish}>
                    Submit
                  </Button>
                </Col>

                <Col span={3}>
                  <Button type="primary" onClick={saveAsDraft}>
                    Save as Draft
                  </Button>
                </Col>
              </Row>
            </Access>
          </Col>
        </Row>
      </PageContainer>
    );
  }
  return null;
};

const MohSurvey: React.FC<{}> = (props) => {
  const { initialState, loading } = useModel('@@initialState');
  const { currentUser }: App.InitialStateType = initialState;
  const mohProfile = currentUser?.modules.find((module) => module.name === ModuleTypes.MOH);

  return loading ? <Spin /> : <SurveyForm {...props} mohProfile={mohProfile} />;
};

export default connect(({ mohSurvey }: { mohSurvey: StateType }) => ({
  formContent: mohSurvey.formContent,
}))(MohSurvey);
