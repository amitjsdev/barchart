import { Effect, Reducer } from 'umi';

import mohService from '../services/moh.service';
import { ISurveySection } from './surveyInterface';

export interface StateType {
  survey: any[];
  options: any[];
  formContent: ISurveySection[];
}

export interface ModelType {
  namespace: string;
  state: StateType;
  effects: {
    submitForm: Effect;
    sbmitBgiForm: Effect;
    saveSurveyFormDraft: Effect;
  };
  reducers: {
    saveSurvey: Reducer<StateType>;
    saveOptions: Reducer<StateType>;

    saveBgiForm: Reducer<StateType>;
  };
}

const formContent: ISurveySection[] = [
  {
    sectionName: 'Machines',
    contents: [
      {
        question: 'Select Name and enter number of Working Machines for Extraction',
        questionInArabic:
          'حدد اسم جهاز الاستخلاص وادخل عدد الأجهزه التي تعمل وعدد الفحوصات اليومي لكل نوع من الأجهزة',
        key: 'machine_extraction_working',
        enableTable: true,
        surveyFields: {},
        required: true,
        formFields: [
          {
            valueType: 'select',
            type: '',
            name: 'dropdownValue',
            label: 'Extraction Machines Name',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              {
                key: 'me1',
                value: 'Bioneer',
              },
              {
                key: 'me2',
                value: 'Thermo Fisher',
              },
              {
                key: 'me3',
                value: 'Perkin Elmer',
              },
              {
                key: 'me4',
                value: 'Abbott m24sp',
              },
              {
                key: 'me5',
                value: 'Abbott m2000sp',
              },
              {
                key: 'me6',
                value: 'Extraction MBGI',
              },
              {
                key: 'me7',
                value: 'Mag NA Pure',
              },
              // {
              //   key: 'me8',
              //   value: 'C 6800',
              // },
              {
                key: 'me9',
                value: 'EZ1',
              },
              {
                key: 'me0',
                value: 'Others',
              },
            ],
            onChange: () => {},
          },
          {
            valueType: 'input',
            type: 'quantity',
            name: 'machineCount',
            label: 'No. of machines',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
          {
            valueType: 'input',
            type: 'tests',
            name: 'testsCount',
            label: 'Daily Extraction Tests',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
        ],
        enableFormFields: true,
      },
      {
        question: 'Select Name and enter number of Working Machines for PCR',
        questionInArabic:
          'حدد اسم جهاز البي سي آر وادخل عدد الأجهزه التي تعمل  وعدد الفحوصات اليومي لكل نوع من الأجهزة',
        key: 'machine_pcr_working',
        enableTable: true,
        surveyFields: {},
        required: true,
        formFields: [
          {
            valueType: 'select',
            type: '',
            name: 'dropdownValue',
            label: 'PCR Machines Name',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              {
                key: 'mpcr1',
                value: 'ABI RT PCR',
              },
              {
                key: 'mpcr2',
                value: 'ROCH -LIGHTCYCLER',
              },
              {
                key: 'mpcr3',
                value: 'BGI PCR',
              },
              {
                key: 'mpcr4',
                value: 'Abbott m2000rt RealTime PCR',
              },
              {
                key: 'mpcr5',
                value: 'Real-Time PCR Rotor GENE',
              },
              {
                key: 'mpcr6',
                value: 'Real-Time PCR Applied Biosystem 7500',
              },
            ],
            onChange: () => {},
          },
          {
            valueType: 'input',
            type: 'quantity',
            name: 'machineCount',
            label: 'No. of machines',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
          {
            valueType: 'input',
            type: 'tests',
            name: 'testsCount',
            label: 'Daily PCR Tests',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
        ],
        enableFormFields: true,
      },

      {
        question: 'Select Name and enter number of Working Fully Automated Machines',
        questionInArabic:
          'يرجى إدخال عدد أجهزة الكوباس ٦٨٠٠ المستعملة و مجموع الفحوصات اليومية على جهاز الكوباس',
        key: 'machine_auto_working',
        enableTable: true,
        surveyFields: {},
        required: true,
        formFields: [
          {
            valueType: 'select',
            type: '',
            name: 'dropdownValue',
            label: 'Automated Machines Name',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              {
                key: 'mauto1',
                value: 'C6800',
              },
            ],
            onChange: () => {},
          },
          {
            valueType: 'input',
            type: 'quantity',
            name: 'machineCount',
            label: 'No. of machines',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
          {
            valueType: 'input',
            type: 'tests',
            name: 'testsCount',
            label: 'Daily Automated Tests',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
        ],
        enableFormFields: true,
      },

      {
        question: 'Select Malfunction Machine and Type of Malfunction',
        questionInArabic: 'حدد الأجهزه المتعطلة ونوع العطل ',
        key: 'machine_malfunctioning',
        enableTable: true,
        surveyFields: {},
        required: false,
        formFields: [
          {
            valueType: 'select',
            type: '',
            name: 'dropdownValue',
            label: 'Malfunction Machines Name',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              {
                key: 'me1',
                value: 'Bioneer',
              },
              {
                key: 'me2',
                value: 'Thermo Fisher',
              },
              {
                key: 'me3',
                value: 'Perkin Elmer',
              },
              {
                key: 'me4',
                value: 'Abbott m24sp',
              },
              {
                key: 'me5',
                value: 'Abbott m2000sp',
              },
              {
                key: 'me6',
                value: 'Extraction MBGI',
              },
              {
                key: 'me7',
                value: 'Mag NA Pure',
              },
              {
                key: 'me8',
                value: 'C 6800',
              },
              {
                key: 'me9',
                value: 'EZ1',
              },
              {
                key: 'me0',
                value: 'Others',
              },
              {
                key: 'mpcr1',
                value: 'ABI RT PCR',
              },
              {
                key: 'mpcr2',
                value: 'ROCH -LIGHTCYCLER',
              },
              {
                key: 'mpcr3',
                value: 'BGI PCR',
              },
              {
                key: 'mpcr4',
                value: 'Abbott m2000rt RealTime PCR',
              },
              {
                key: 'mpcr5',
                value: 'Real-Time PCR Rotor GENE',
              },
              {
                key: 'mpcr6',
                value: 'Real-Time PCR Applied Biosystem 7500',
              },
            ],
            onChange: () => {},
          },
          {
            valueType: 'select',
            type: 'dimension',
            name: 'issue',
            label: 'Type of Malfunction',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              {
                key: 'issue1',
                value: 'Malfunction in one of the machine parts',
              },
              {
                key: 'issue2',
                value: 'Electrical issue',
              },
              {
                key: 'issue3',
                value: 'Missing part',
              },
              {
                key: 'issue4',
                value: 'Machine not installed yet',
              },
              {
                key: 'issue5',
                value: 'Temperature inconsistency',
              },
              {
                key: 'issue0',
                value: 'Others',
              },
            ],
            onChange: () => {},
          },
        ],
        enableFormFields: true,
      },
      {
        question: 'Are machines maintained regularly ?',
        questionInArabic: 'هل يتم فحص الأجهزة بشكل دوري؟',
        key: 'machine_regular_maintainence',
        required: true,
        enableTable: false,
        surveyFields: {
          type: 'radio',
          defaultValue: false,
          optionfields: [],
        },
        formFields: [],
        enableFormFields: true,
      },

      {
        question: 'Last day of inspection of machines ?',
        questionInArabic: 'متى كانت آخر زيارة لإجراء فحص الأجهزة؟',
        key: 'machine_last_maintainence_date',
        enableTable: false,
        required: true,
        surveyFields: {
          type: 'date',
          optionfields: [],
          inputType: 'number',
        },
        formFields: [],
        enableFormFields: true,
      },
      {
        question: 'Total number of Samples Retested',
        questionInArabic: 'مجموع عدد العينات المعاد فحصها ',
        key: 'machine_total_no_of_samples_retested',
        enableTable: false,
        required: true,
        surveyFields: {
          type: 'input',
          optionfields: [],
          inputType: 'number',
        },
        formFields: [],
        enableFormFields: true,
      },
    ],
  },

  {
    sectionName: 'Tests',
    contents: [
      {
        question: 'Total number of Tests done today ?',
        questionInArabic: 'إجمالي عدد الفحوصات التي تم إجراؤها اليوم؟',
        key: 'test_total_no_of_tests_done',
        enableTable: false,
        required: true,
        surveyFields: {
          type: 'input',
          optionfields: [],
          inputType: 'number',
        },
        formFields: [],
        enableFormFields: true,
      },
      {
        question: 'Total number of received samples ?',
        questionInArabic: 'إجمالي عدد الفحوصات المستلمة',
        key: 'test_total_of_received_samples',
        enableTable: false,
        required: true,
        surveyFields: {
          type: 'input',
          optionfields: [],
          inputType: 'number',
        },
        formFields: [],
        enableFormFields: true,
      },
    ],
  },

  {
    sectionName: 'Stock',
    contents: [
      {
        question: 'Total Number of Extraction Reagents',
        questionInArabic: 'حدد اسم محلول الاستخلاص  أدناه وأدخل الكمية الموجودة في المخزون',
        key: 'stock_reagent',
        required: true,
        enableTable: true,
        surveyFields: {},
        formFields: [
          {
            valueType: 'select',
            type: 'tests',
            name: 'dropdownValue',
            label: 'Select name of Reagent below and enter Quantity',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              {
                key: 're1',
                value: 'MagNA Pure 96 DNA and Viral NA SV Kit from Roche',
              },
              {
                key: 're2',
                value: 'EXTRACTION  (Thermo Fisher)',
              },
              {
                key: 're3',
                value: 'cobas® SARS-CoV-2 fro, Roche',
              },
              {
                key: 're4',
                value: 'DNA/RNA Extraction  Abbott',
              },
              {
                key: 're5',
                value: 'EXTRACTION (Boineer)',
              },
              {
                key: 're6',
                value: 'EXTRACTION (Perkin Elmer)',
              },
              {
                key: 're7',
                value: 'Qiagen EZ1 Extraction',
              },
            ],
            onChange: () => {},
          },
          {
            valueType: 'input',
            type: 'tests',
            name: 'machineCount',
            label: 'Quantity available',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
        ],
        enableFormFields: true,
      },
      {
        question: 'Total Number of PCR Reagents',
        questionInArabic: 'حدد اسم محلول البي سي آر  أدناه وأدخل الكمية الموجودة في المخزون',
        key: 'stock_pcr_reagent',
        required: true,
        enableTable: true,
        surveyFields: {},
        formFields: [
          {
            valueType: 'select',
            type: 'tests',
            name: 'dropdownValue',
            label: 'Name of Reagent',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              {
                key: 'rpcr1',
                value: 'KOGENE',
              },
              {
                key: 'rpcr2',
                value: 'QUIDEL',
              },
              {
                key: 'rpcr3',
                value: 'Solgent - nCoV PCR Test',
              },
              {
                key: 'rpcr4',
                value: 'Abbott SARS-CoV-2 Amplification Reagent (PCR)',
              },
              {
                key: 'rpcr5',
                value: 'CO-DIAGNOSTICS',
              },
              {
                key: 'rpcr6',
                value: 'ALTONA SARS CoV-2 PCR KIT 1.0',
              },
              {
                key: 'rpcr7',
                value: 'RdRb',
              },
              {
                key: 'rpcr0',
                value: 'Others',
              },
            ],
            onChange: () => {},
          },
          {
            valueType: 'input',
            type: 'tests',
            name: 'machineCount',
            label: 'Quantity',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
        ],
        enableFormFields: true,
      },
      {
        question: 'Current Inventory of Reagents that will be fully consumed in 14 days?',
        questionInArabic:
          'اختر محاليل البي سي آر والاستخلاص والتي متوقع نفاذها بالكامل في غضون 14 يوما',
        key: 'stock_reagent_inventory_fourteen_days',
        required: true,
        enableTable: true,
        surveyFields: {},
        formFields: [
          {
            valueType: 'select',
            type: 'tests',
            name: 'dropdownValue',
            label: 'Name of Reagent',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              {
                key: 're1',
                value: 'MagNA Pure 96 DNA and Viral NA SV Kit from Roche',
              },
              {
                key: 're2',
                value: 'EXTRACTION  (Thermo Fisher)',
              },
              {
                key: 're3',
                value: 'cobas® SARS-CoV-2 fro, Roche',
              },
              {
                key: 're4',
                value: 'DNA/RNA Extraction  Abbott',
              },
              {
                key: 're5',
                value: 'EXTRACTION (Boineer)',
              },
              {
                key: 're6',
                value: 'EXTRACTION (Perkin Elmer)',
              },
              {
                key: 're7',
                value: 'Qiagen EZ1 Extraction',
              },
              {
                key: 'rpcr1',
                value: 'KOGENE',
              },
              {
                key: 'rpcr2',
                value: 'QUIDEL',
              },
              {
                key: 'rpcr3',
                value: 'Solgent - nCoV PCR Test',
              },
              {
                key: 'rpcr4',
                value: 'Abbott SARS-CoV-2 Amplification Reagent (PCR)',
              },
              {
                key: 'rpcr5',
                value: 'CO-DIAGNOSTICS',
              },
              {
                key: 'rpcr6',
                value: 'ALTONA SARS CoV-2 PCR KIT 1.0',
              },
              {
                key: 'rpcr7',
                value: 'RdRb',
              },
              {
                key: 'rpcr0',
                value: 'Others',
              },
            ],
            onChange: () => {},
          },
          {
            valueType: 'input',
            type: 'tests',
            name: 'machineCount',
            label: 'Demanded Quantity',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
        ],
        enableFormFields: true,
      },
      {
        question: 'Do we have any other shortage for any non-reagent consumable?',
        questionInArabic: 'هل لديك أي نقص آخر في المستهلكات من غير المحاليل؟ ',
        key: 'stock_storage_consumable',
        required: true,
        enableTable: true,
        surveyFields: {},
        formFields: [
          {
            valueType: 'select',
            type: 'tests',
            name: 'dropdownValue',
            label: 'Select the consumable',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              {
                key: 'consumable_pcr0',
                value: 'Others',
              },
              {
                key: 'consumable_pcr1',
                value: 'Processing Cartridges',
              },
              {
                key: 'consumable_pcr2',
                value: '1000ul tips',
              },
              {
                key: 'consumable_pcr3',
                value: '300ul tips',
              },

              {
                key: 'consumable_pcr4',
                value: '200ul tips',
              },
              {
                key: 'consumable_pcr5',
                value: '100ul tips',
              },
              {
                key: 'consumable_pcr6',
                value: '10ul tips',
              },
              {
                key: 'consumable_pcr7',
                value: 'Tips-comb plate',
              },
            ],
            onChange: () => {},
          },
          {
            valueType: 'input',
            type: 'tests',
            name: 'machineCount',
            label: 'Quantity (الرجاء كتابة الكمية التي يحتاجها المختبر للعمل لمدة 14 يوما)',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
        ],
        enableFormFields: false,
      },
      {
        question: 'Total Number of Filter Tips per type?',
        questionInArabic: 'الرجاء إدخال الكميات المتوفرة في المخزون من الفلتر تيبس',
        key: 'stock_total_no_of_filter_tips_type',
        required: true,
        enableTable: true,
        surveyFields: {},
        formFields: [
          {
            valueType: 'select',
            type: 'tests',
            name: 'dropdownValue',
            label: 'Name of Filter',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              // {
              //   key: 'stock_filter_tiptype0',
              //   value: 'Others',
              // },
              {
                key: 'stock_filter_tiptype1',
                value: '10ul',
              },
              {
                key: 'stock_filter_tiptype2',
                value: '20ul',
              },
              {
                key: 'stock_filter_tiptype3',
                value: '100ul',
              },
              {
                key: 'stock_filter_tiptype4',
                value: '200ul',
              },
              {
                key: 'stock_filter_tiptype5',
                value: '300ul',
              },
              {
                key: 'stock_filter_tiptype6',
                value: '1000ul',
              },
            ],
            onChange: () => {},
          },
          {
            valueType: 'input',
            type: 'tests',
            name: 'machineCount',
            label: 'Quantity',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
        ],
        enableFormFields: true,
      },
    ],
  },

  {
    sectionName: 'Serology',
    contents: [
      {
        question: 'Number of working machines & daily test count',
        questionInArabic:
          'مجموع عدد الأجهزة التي تعمل و الاختبارات اليومية للفحوصات المناعية لكوفيد-19 ',
        key: 'serology_working_machines',
        required: true,
        enableTable: true,
        surveyFields: {},
        formFields: [
          {
            valueType: 'select',
            type: '',
            name: 'dropdownValue',
            label: 'Serology Machine Name',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              {
                key: 'ms1',
                value: 'PEBIII',
              },
              {
                key: 'ms2',
                value: 'TECAN',
              },
              {
                key: 'ms3',
                value: 'BGI',
              },
              {
                key: 'ms4',
                value: 'Evolis',
              },
              {
                key: 'ms5',
                value: 'ET-Max',
              },
              {
                key: 'ms6',
                value: 'DEMO',
              },
              {
                key: 'ms7',
                value: 'DYNIX',
              },
              {
                key: 'ms8',
                value: 'ARCHITECT i2000',
              },
              {
                key: 'ms9',
                value: 'IMMAGE 800',
              },
              {
                key: 'ms0',
                value: 'Others',
              },
            ],
            onChange: () => {},
          },
          {
            valueType: 'input',
            type: 'tests',
            name: 'machineCount',
            label: 'No. of machines',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
          {
            valueType: 'input',
            type: 'tests',
            name: 'testsCount',
            label: 'Daily Serology Tests',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
        ],
        enableFormFields: true,
      },
      {
        question: 'Total Number of Malfunctioned Machines with Malfunction Type',
        questionInArabic: ' حدد الأجهزه المعطله ونوع العطل ',
        key: 'serology_malfunctioning_machines',
        required: false,
        enableTable: true,
        surveyFields: {},
        formFields: [
          {
            valueType: 'select',
            type: '',
            name: 'dropdownValue',
            label: 'Malfunctioned Machine Name',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              {
                key: 'ms1',
                value: 'PEBIII',
              },
              {
                key: 'ms2',
                value: 'TECAN',
              },
              {
                key: 'ms3',
                value: 'BGI',
              },
              {
                key: 'ms4',
                value: 'Evolis',
              },
              {
                key: 'ms5',
                value: 'ET-Max',
              },
              {
                key: 'ms6',
                value: 'DEMO',
              },
              {
                key: 'ms7',
                value: 'DYNIX',
              },
              {
                key: 'ms8',
                value: 'ARCHITECT i2000',
              },
              {
                key: 'ms9',
                value: 'IMMAGE 800',
              },
              {
                key: 'ms0',
                value: 'Others',
              },
            ],
            onChange: () => {},
          },
          {
            valueType: 'select',
            type: '',
            name: 'issue',
            label: 'Types of Malfunction',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              {
                key: 'issue1',
                value: 'Malfunction in one of the machine parts',
              },
              {
                key: 'issue2',
                value: 'Electrical issue',
              },
              {
                key: 'issue3',
                value: 'Missing part',
              },
              {
                key: 'issue4',
                value: 'Machine not installed yet',
              },
              {
                key: 'issue5',
                value: 'Temperature inconsistency',
              },
              {
                key: 'issue0',
                value: 'Others',
              },
            ],
            onChange: () => {},
          },
        ],
        enableFormFields: true,
      },
      {
        question: 'Are machines being maintained regularly ?',
        questionInArabic: 'هل يتم فحص الأجهزة بشكل دوري؟',
        key: 'serology_regular_maintainence',
        required: true,
        enableTable: false,
        surveyFields: {
          type: 'radio',
          defaultValue: false,
          optionfields: [],
          inputType: 'number',
        },
        formFields: [],
        enableFormFields: true,
      },

      {
        question: 'Last day of Inspection of Machine ?',
        questionInArabic: 'متى كانت آخر زيارة لإجراء فحص الأجهزة؟',
        key: 'serology_last_maintainence_date',
        required: true,
        enableTable: false,
        surveyFields: {
          type: 'date',
          optionfields: [],
          inputType: 'number',
        },
        formFields: [],
        enableFormFields: true,
      },

      {
        question: 'How many IgG / Antiobody Test kits are available?',
        questionInArabic: 'المتبقي من الأجسام المضادة (kit) IgG',
        key: 'serology_total_no_of_antibody_testkits',
        required: true,
        enableTable: false,
        surveyFields: {
          type: 'input',
          optionfields: [],
          inputType: 'number',
        },
        formFields: [],
        enableFormFields: true,
      },
      // Change my keys
      {
        question: 'How many IgM / Antiobody Test kits are available?',
        questionInArabic: 'المتبقي من الأجسام المضادة (kit) IgM',
        key: 'serology_total_no_of_igm_antibody_testkits',
        required: true,
        enableTable: false,
        surveyFields: {
          type: 'input',
          optionfields: [],
          inputType: 'number',
        },
        formFields: [],
        enableFormFields: true,
      },

      {
        question: 'How many Total Filter Tips are avilable?',
        questionInArabic: 'العدد المتبقي من ال  tips المستخدمة لفحوصات المناعة لكوفيد-19 فقط',
        key: 'serology_filter_tips_type',
        required: true,
        enableTable: true,
        surveyFields: {},
        formFields: [
          {
            valueType: 'select',
            type: '',
            name: 'dropdownValue',
            label: 'Select the Serology Tips Type',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              // {
              //   key: 'filter_tiptype0',
              //   value: 'Others',
              // },
              // {
              //   key: 'filter_tiptype1',
              //   value: '1000ul',
              // },
              {
                key: 'filter_tiptype2',
                value: '300ul',
              },
              // {
              //   key: 'filter_tiptype3',
              //   value: '200ul',
              // },
              // {
              //   key: 'filter_tiptype4',
              //   value: '100ul',
              // },
              // {
              //   key: 'filter_tiptype5',
              //   value: '10ul',
              // },
              {
                key: 'filter_tiptype6',
                value: '1100ul',
              },
            ],
            onChange: () => {},
          },
          {
            valueType: 'input',
            type: '',
            name: 'machineCount',
            label: 'QTY Available',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
        ],
        enableFormFields: true,
      },

      {
        question: 'Will you have a shortage in consumable in 14 days?',
        questionInArabic: 'هل يوجد نقص في المخزون في غضون ال 14 يوما القادمة؟',
        key: 'serology_consumables',
        required: true,
        enableTable: true,
        surveyFields: {},
        formFields: [
          {
            valueType: 'select',
            type: 'tests',
            name: 'dropdownValue',
            label: 'Select the consumable',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              {
                key: 'serology_consumable0',
                value: 'Others',
              },
              {
                key: 'serology_consumable1',
                value: 'Antibodies',
              },
              {
                key: 'serology_consumable2',
                value: '1000ul',
              },
              {
                key: 'serology_consumable3',
                value: '300ul',
              },

              {
                key: 'serology_consumable4',
                value: '200ul',
              },
              {
                key: 'serology_consumable5',
                value: '100ul',
              },
              {
                key: 'serology_consumable6',
                value: '10ul',
              },

              // Change my keys
              {
                key: 'serology_consumable7',
                value: 'IgG',
              },

              // Change my keys
              {
                key: 'serology_consumable8',
                value: 'IgM',
              },
            ],
            onChange: () => {},
          },
          {
            valueType: 'input',
            type: 'tests',
            name: 'machineCount',
            label: 'Quantity (الرجاء كتابة الكمية التي يحتاجها المختبر للعمل لمدة 14 يوما)',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
        ],
        enableFormFields: false,
      },
    ],
  },
];

const Model: ModelType = {
  namespace: 'mohSurvey',
  state: {
    survey: [],
    options: [],
    formContent,
  },

  effects: {
    async *submitForm({ payload }) {
      const dataBody = [];

      const today = new Date();
      const dd = String(today.getDate()).padStart(2, '0');
      const mm = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
      const yyyy = today.getFullYear();

      const _date = `${yyyy}-${mm}-${dd}`;

      const payloadToSend = {
        date: _date,
        ...payload,
      };

      await mohService.submitSurvey(payloadToSend);
      window.location.reload();
    },

    async *saveSurveyFormDraft({ payload }) {
      const { locationId } = payload;
      const today = new Date();
      const dd = String(today.getDate()).padStart(2, '0');
      const mm = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
      const yyyy = today.getFullYear();

      const _date = `${yyyy}-${mm}-${dd}`;

      await mohService.saveSurveyFormAsDraft(payload, _date, locationId);
      window.location.reload();
    },
  },

  reducers: {
    saveSurvey(state, { payload }) {
      return {
        ...state,
        survey: [...(state as StateType).survey, ...payload],
      };
    },

    saveOptions(state, { payload }) {
      return {
        ...state,
        options: [...(state as StateType).options, ...payload],
      };
    },

    saveBgiForm(state, { payload }) {
      return {
        ...state,
        options: [...(state as StateType).options, payload],
      };
    },
  },
};

const mandatorySurveyKeys = [
  'machine_regular_maintainence',
  'machine_total_no_of_samples_retested',
  'test_total_no_of_tests_done',
  'serology_regular_maintainence',
];

const notMandatoryOptionFields = ['machine_malfunctioning', 'serology_malfunctioning_machines'];
export { formContent, mandatorySurveyKeys, notMandatoryOptionFields };
export default Model;
