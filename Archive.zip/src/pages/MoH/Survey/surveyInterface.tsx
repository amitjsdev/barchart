interface ISurveySection {
  sectionName: string;
  contents: ISurveyQuestion[];
}

interface ISurveyQuestion {
  question: string;
  questionInArabic: string;
  enableTable: boolean;
  key: string;
  formFields: ISurveyFormField[];
  surveyFields: {};
  required: boolean;
  enableFormFields: boolean;
}

interface ISurveyFormField {
  valueType: 'input' | 'select' | 'radio';
  type: string;
  name: string;
  label: string;
  defaultValue: any;
  inputType: string;
  onChange: any;
  selectOptions: {}[];
}

export { ISurveySection, ISurveyQuestion, ISurveyFormField };
