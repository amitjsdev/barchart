import React, { useState, useEffect } from 'react';
import { Button, Form, Modal, Table, Input, Select, message, Row, Col } from 'antd';
import axios from 'axios';
import { API_URL } from '@/api/apis';
import { storageService } from '@/services/storage';
import { getAllLabs, getAllRegions, getAllUsers, createUser } from '../services';

const UserListComponent = () => {
  const [locations, setLocations] = useState([]);
  const [regions, setRegions] = useState([]);
  const [users, setUsers] = useState([]);
  const { Option } = Select;
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [labType, setLabType] = useState('');
  const [role, setRole] = useState('');

  const [uniqueRegion, setUniqueRegion] = useState([]);

  const roles = {
    planner: 'Planner',
    inCharge: 'In Charge',
    manager: 'Manager',
    surveyor: 'Surveyor',
    tms: 'TMS User',
    superApprover: 'Super Approver',
    superManager: 'Super Manager',
    readSurveyor: 'Read Surveyor',
    regionManager: 'Blood bank - Regional Manager',
  };

  const roleByLabType = {
    bgi: {
      manager: 'Manager',
      superApprover: 'Super Approver',
      superManager: 'Super Manager',
    },
    moh: {
      surveyor: 'Surveyor',
      readSurveyor: 'Read Surveyor',
    },
    nonmoh: {
      manager: 'Manager',
      superApprover: 'Super Approver',
    },
    tms: {
      tms: 'TMS User',
    },
    centralbloodbank: {
      regionManager: 'Blood bank - Regional Manager',
      superApprover: 'Super Approver',
    },
    branchbloodbank: {
      regionManager: 'Blood bank - Regional Manager',
      superApprover: 'Super Approver',
    },
    peripheralbloodbank: {
      regionManager: 'Blood bank - Regional Manager',
      superApprover: 'Super Approver',
    },
  };

  const labTypes = {
    bgi: 'BGI',
    moh: 'Moh',
    nonmoh: 'Non-Moh',
    tms: 'TMS',
    centralbloodbank: 'Central Blood Banks',
    branchbloodbank: 'Branch Blood Banks',
    peripheralbloodbank: 'Peripheral Blood Banks',
  };

  const [form] = Form.useForm();

  useEffect(() => {
    getLocations();
    getRegions();
    fetchUsers();
  }, []);

  const handleSubmit = async (values) => {
    setLoading(true);

    const defaultValue = { locationId: null, regionId: null };
    try {
      const result = await createUser({ ...defaultValue, ...values });
      setShowModal(false);
      setLoading(false);
      form.resetFields();
      message.success('User Added Successfully');
      setUsers([...users, values]);
    } catch (error) {}
  };

  const fetchUsers = async () => {
    try {
      const data = await getAllUsers();
      setUsers(data);
    } catch (error) {}
  };

  const getLocations = async () => {
    try {
      const data = await getAllLabs();

      setLocations(data);
    } catch (error) {}
  };

  const getRegions = async () => {
    try {
      const data = await getAllRegions();
      setRegions(data);
    } catch (error) {}
  };
  let uniqueRegionArrray: any[] = [];
  let regionArrray: any[] = [];

  return (
    <div>
      <div style={{ textAlign: 'end' }}>
        <Button onClick={() => setShowModal(true)} type="primary" style={{ marginBottom: 16 }}>
          Add User
        </Button>
      </div>

      <Table
        dataSource={users}
        columns={[
          {
            title: 'Name',
            dataIndex: 'name',
          },
          {
            title: 'Email',
            dataIndex: 'email',
          },
          {
            title: 'Location',
            dataIndex: 'locationName',
          },
          {
            title: 'Role',
            dataIndex: 'role',
            render: (text) => roles[text],
          },
        ]}
      />

      <Modal
        title="Add User Modal"
        visible={showModal}
        onOk={handleSubmit}
        onCancel={() => setShowModal(false)}
        footer={null}
        maskClosable={false}
      >
        <div>
          <Form
            layout="vertical"
            form={form}
            initialValues={{ name: '', email: '', role: '', locationId: '' }}
            // labelCol={{ span: 5 }}
            // wrapperCol={{ span: 16 }}
            onFinish={handleSubmit}
          >
            <Form.Item
              label="Name"
              name="name"
              rules={[{ required: true, message: 'Please input your name!' }]}
            >
              <Input />
            </Form.Item>

            <Form.Item
              label="Email"
              name="email"
              rules={[{ required: true, message: 'Please input your username!' }]}
            >
              <Input type="email" />
            </Form.Item>

            <Form.Item label="Lab Type" name="type">
              <Select
                defaultValue=""
                onChange={(value) => {
                  setLabType(value);
                  form.resetFields(['role', 'regionId', 'locationId']);
                }}
              >
                <Option value="">Please select</Option>
                {Object.entries(labTypes).map((item, index) => (
                  <Option key={index} value={item[0]}>
                    {item[1]}
                  </Option>
                ))}
              </Select>
            </Form.Item>

            <Form.Item label="Role" name="role">
              <Select
                defaultValue=""
                onChange={(value) => {
                  setRole(value);
                  form.resetFields(['regionId', 'locationId']);

                  regionArrray = locations
                    .filter((loc: any) => loc.labType === labType)
                    .map((item: any, index) => item.regionId);

                  const uniqueSet = [...new Set(regionArrray)];
                  uniqueRegionArrray = uniqueSet;
                  setUniqueRegion(uniqueSet);
                }}
              >
                <Option value="">Please select</Option>
                {labType.length > 1
                  ? Object.entries(roleByLabType[labType]).map((item, index) => (
                      <Option key={index} value={item[0]}>
                        {item[1]}
                      </Option>
                    ))
                  : null}
              </Select>
            </Form.Item>

            {labType === 'peripheralbloodbank' ||
            labType === 'centralbloodbank' ||
            labType === 'branchbloodbank' ? (
              <Form.Item label="Location" name="regionId">
                <Select
                  defaultValue=""
                  onChange={(value) => {
                    form.setFieldsValue({ region: value });
                  }}
                >
                  <Option value="">Please Select</Option>
                  {regions
                    .filter((loc: any) => uniqueRegion.includes(loc.id))
                    .map((item: any, index) => (
                      <Option key={index} value={item.id}>
                        {item.name}
                      </Option>
                    ))}
                </Select>
              </Form.Item>
            ) : (
              <Form.Item label="Location" name="locationId">
                <Select
                  defaultValue=""
                  onChange={(value, OptionData) => {
                    form.setFieldsValue({ location: value });
                  }}
                >
                  <Option value="">Please Select</Option>
                  {locations
                    .filter((loc: any) => loc.labType === labType)
                    .map((item: any, index) => (
                      <Option key={index} value={item.id}>
                        {item.name}
                      </Option>
                    ))}
                </Select>
              </Form.Item>
            )}

            <Row>
              <Col flex={4} />
              <Col flex={4}>
                <Form.Item>
                  <Button type="primary" htmlType="submit" loading={loading} block>
                    Submit
                  </Button>
                </Form.Item>
              </Col>
              <Col flex={4} />
            </Row>
          </Form>
        </div>
      </Modal>
    </div>
  );
};

export default UserListComponent;
