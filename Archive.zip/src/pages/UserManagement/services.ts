import Apis from '@/api/apis';

const getAllLabs = () => {
  return Apis.getUserLocations();
};

const getAllRegions = () => {
  return Apis.getUserRegions();
};

const getAllUsers = () => {
  return Apis.getAllUsers();
};

const createUser = (user: any) => {
  return Apis.createUser(user);
};

export { getAllLabs, getAllRegions, getAllUsers, createUser };
