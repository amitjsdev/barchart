import { PageContainer } from '@ant-design/pro-layout';
import React, { useState, useEffect } from 'react';
import { Spin } from 'antd';
import { history } from 'umi';
import axios from 'axios';
import { API_URL } from '@/api/apis';

import { storageService } from '@/services/storage';
import UserTable from './UserTable';
import styles from './index.less';

export default () => {
  const [loading, setLoading] = useState<boolean>(true);
  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 3000);
    verifyAuth();
  }, []);

  const verifyAuth = async () => {
    try {
      if (!storageService.getItem('auth-token')) {
        history.push('/user/login');
      }
      await axios.get(`${API_URL.user}/profile`, {
        headers: { token: `${storageService.getItem('auth-token')}` },
      });
    } catch (error) {
      if (error || error.response.status === 401) {
        storageService.removeItem('auth-token');
        history.push('/user/login');
      }
    }
  };

  return (
    <PageContainer content="" className={styles.main}>
      <UserTable />
      <div
        style={{
          paddingTop: 100,
          textAlign: 'center',
        }}
      >
        <Spin spinning={loading} size="large" />
      </div>
    </PageContainer>
  );
};
