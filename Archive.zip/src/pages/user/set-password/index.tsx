import React from 'react';
import { Link, history } from 'umi';
import { Button, Form, Input, message } from 'antd';
import axios from 'axios';
import { API_URL } from '@/api/apis';

import styles from '../login/style.less';

const SetPassword = () => {
  const handleSubmit = async (values: any) => {
    try {
      if (history.location.query.k) {
        const { data } = await axios.post(`${API_URL.auth}/password/reset`, {
          key: history.location.query.k,
          newPassword: values.password,
        });
        if (data.code === 200) {
          message.success(data.message);
          history.push('/user/login');
        }
      }
    } catch (error) {
      message.error(error.response.data.message);
    }
  };
  return (
    <div className={styles.container}>
      <div className={styles.lang}>{/* <SelectLang /> */}</div>
      <div className={styles.content}>
        <div className={styles.top}>
          <div className={styles.header}>
            <Link to="/">
              {/* <img alt="logo" className={styles.logo} src={logo} /> */}
              <span className={styles.title}>Salehiya</span>
            </Link>
          </div>
          <div className={styles.desc} />
        </div>

        <div className={styles.main}>
          <Form initialValues={{ password: '' }} onFinish={handleSubmit}>
            <Form.Item
              name="password"
              rules={[{ required: true, message: 'Please input your username!' }]}
            >
              <Input placeholder="Password" type="password" />
            </Form.Item>

            <Form.Item>
              <Button block type="primary" htmlType="submit">
                Submit
              </Button>
            </Form.Item>
          </Form>
        </div>
      </div>
      {/* <Footer /> */}
    </div>
  );
};

export default SetPassword;
