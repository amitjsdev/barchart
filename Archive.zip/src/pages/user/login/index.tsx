import React, { useState } from 'react';
import { Link, useModel, history } from 'umi';

import authService from '@/services/auth.service';
import { storageService } from '@/services/storage';
import homeRouteResolver from '@/utils/homeRouteResolver';
import logo from '@/assets/MoH-logo.png';
import Apis from '../../../api/apis';
import LoginFrom from './components/Login';
import styles from './style.less';

interface ILoginParams {
  email: string;
  password: string;
}

const { Tab, Username, Password, Submit } = LoginFrom;

const LoginMessage: React.FC<{
  content: string;
}> = ({ content }) => (
  <Alert
    style={{
      marginBottom: 24,
    }}
    message={content}
    type="error"
    showIcon
  />
);

const Login: React.FC<{}> = () => {
  const [userLoginState, setUserLoginState] = useState<API.LoginStateType>({});
  const [submitting, setSubmitting] = useState(false);
  const { setInitialState } = useModel('@@initialState');
  const [type, setType] = useState<string>('account');

  const login = async (userCredentials) => {
    const { token } = await await authService.login(userCredentials);
    storageService.setItem('auth-token', token);
  };

  const handleSubmit = async (userCredentials: ILoginParams) => {
    setSubmitting(true);

    try {
      await login(userCredentials);

      Apis.getProfile().then(async (data) => {
        const userProfile: API.Profile = data;
        const defaultModule =
          userProfile.modules.find((module) => module.default)?.name || userProfile.modules[0].name;

        setUserLoginState({ status: 'ok', type });
        // setUserProfileInLocal(userProfile);
        setInitialState({
          currentUser: {
            ...userProfile,
            defaultModule,
            currentModule: defaultModule,
          },
        });

        storageService.setItem('current-app', defaultModule);

        const cubejsToken = await authService.getCubeJsToken();

        storageService.setItem('cubejs-token', cubejsToken);

        const homeRoute = homeRouteResolver(userProfile.role);

        // history.push(homeRoute);
        history.push('/');
      });
    } catch (err) {
      console.error(err);
    }

    setSubmitting(false);
  };

  const { status } = userLoginState;

  return (
    <div className={styles.container}>
      <div className={styles.lang}>{/* <SelectLang /> */}</div>
      <div className={styles.content}>
        <div className={styles.top}>
          <div className={styles.header}>
            <Link to="/">
              <img alt="logo" className={styles.logo} src={logo} />
              <span className={styles.title}>Ministry of Health</span>
            </Link>
          </div>
          <div className={styles.desc} />
        </div>

        <div className={styles.main}>
          <LoginFrom activeKey={type} onTabChange={setType} onSubmit={handleSubmit}>
            <Tab key="account" tab="Email">
              {status === 'error' && loginType === 'account' && !submitting && (
                <LoginMessage content="Incorrect email or password!" />
              )}

              <Username
                name="email"
                placeholder="Enter email"
                rules={[
                  {
                    required: true,
                    message: 'Invalid!',
                  },
                ]}
              />
              <Password
                name="password"
                placeholder="Enter Password"
                rules={[
                  {
                    required: true,
                    message: 'Invalid！',
                  },
                ]}
              />
            </Tab>
            <div>
              {/* <Checkbox checked={autoLogin} onChange={(e) => setAutoLogin(e.target.checked)}>
                Remember Me
              </Checkbox> */}
              <a
                style={{
                  float: 'right',
                }}
              >
                Forgot Password?
              </a>
            </div>
            <Submit loading={submitting}>Submit</Submit>
            <div className={styles.other}>
              {/* <Link className={styles.register} to="/user/register">
                Register Account
              </Link> */}
            </div>
          </LoginFrom>
        </div>
      </div>
      {/* <Footer /> */}
    </div>
  );
};

export default Login;
