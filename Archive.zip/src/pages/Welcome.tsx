import React, { useEffect } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { Card, Alert, Typography } from 'antd';
import { Redirect, useModel } from 'umi';
import { storageService } from '@/services/storage';
import homeRouteResolver from '@/utils/homeRouteResolver';
import styles from './Welcome.less';

const CodePreview: React.FC<{}> = ({ children }) => (
  <pre className={styles.pre}>
    <code>
      <Typography.Text copyable>{children}</Typography.Text>
    </code>
  </pre>
);

const getHomeRoute = (defaultModule: App.LabType | undefined) => {
  return defaultModule ? homeRouteResolver(defaultModule) : '/user/login';
};

export default (props): React.ReactNode => {
  const { initialState } = useModel('@@initialState');

  useEffect(() => {
    window.location.replace(getHomeRoute(initialState?.currentUser.defaultModule));
    // const currentRole:any = storageService.getItem('role') || 'guest';
    /* (!storageService.getItem('auth-token'))  ? history.push('/user/login') 
    : (storageService.getItem('auth-token') && currentRole === 'superAdmin') ? window.location.replace('/user-management')
    : (storageService.getItem('auth-token') && ['planner', 'inCharge', 'manager', 'superManager'].includes(currentRole)) ? window.location.replace('/inventory')
    : (storageService.getItem('auth-token') && currentRole === 'surveyor') ? window.location.replace('/survey')
    : (storageService.getItem('auth-token') && currentRole === 'superApprover') ? window.location.replace('/purchase')
    : null */
  }, []);

  return <Redirect to={getHomeRoute(initialState?.currentUser.defaultModule)} />;
};
