import { message } from 'antd';

import httpService from '@/services/http.service';
import errorHandler from '@/services/errorHandler';
import apiService from '@/shared/services/api.service';
import { LabTypes, ApiUrlFragments } from '@/services/Constants';
 import { saveAs } from 'file-saver';
 import moment from "moment"
export default {
  getInventory: (payload: { locationId: number; page: number }) => {
    const limit = 150;
    const { locationId, page } = payload;

    return httpService
      .get<API.InventoryResponse>(`${ApiUrlFragments.INVENTORY}/inventories/${locationId}`, {
        params: { page, limit },
      })
      .then((res) => res.results)
      .catch((err) => errorHandler(err));
  },

  getFilteredInventory: (payload: {
    locationId: number;
    page: number;
    filter: { status: string; type: string , expiry: string};
  }) => {
    const limit = 150;
    const { locationId, page, filter } = payload;
    const params = {
      page,
      limit,
    };

    if (filter.status !== 'clear') params[filter.status] = true;
    if (filter.type !== 'clear') params.classification = filter.type;
    if (filter.expiry !== 'clear') params.updateFrequency = filter.expiry;


    return httpService
      .get<API.InventoryResponse>(`${ApiUrlFragments.INVENTORY}/inventories/${locationId}`, {
        params,
      })
      .then((res) => res.results)
      .catch((err) => errorHandler(err));
  },

  getLocations: () => {
    return apiService.getLocationsByLabType(LabTypes.BGI);
  },

  getOrders: (locationId: number, status: App.PurchaseOrderStatus, isApproved = null) => {
    return apiService
      .getOrders(LabTypes.BGI, locationId, status, isApproved)
      .then((res: any) => res.data);
  },

  getTickets: ({ locationId }) => {
    return apiService.getImsTickets(LabTypes.BGI, locationId);
  },

  getBatches: (skuId: number) => {
    return apiService.getBatches(skuId);
  },

  updateBatches: (update: API.UpdateBatchRequest) => {
    return apiService
      .updateBatches(update)
      .then(() => message.success('Batches updated successfully'));
  },

  updateDailyConsumption: (update: API.UpdateDailyConsumptionRequest) => {
    return apiService
      .updateDailyConsumption(update)
      .then(() => message.success('Daily consumption updated successfully'));
  },

  deleteBatch: (batchId: number) => {
    return apiService.deleteBatch(batchId).then(() => message.success('Batch deleted'));
  },

  updateOrder: (orderId: number, data: any) => {
    return apiService.updateOrder(orderId, data).then(() => message.success('Order updated'));
  },

  approveOrder: (orderId: number) => {
    return apiService.approveOrder(orderId).then(() => message.success('Order approved'));
  },

  deleteOrder: (orderId: number) => {
    return apiService.deleteOrder(orderId).then(() => message.success('Order deleted'));
  },

  closeTicket: (ticketId: number) => {
    return apiService
      .closeImsTicket(ticketId)
      .then(() => message.success(`Ticket no. ${ticketId} was closed successfully!`));
  },

  getSurveyFormStatus: (locationId: number) => {
    return apiService
      .getSurveyFormStatus(locationId)
      .then((data: any) => data.message)
      .catch((err) => errorHandler(err));
  },
  submitSurvey: (surveyData: any) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/surveys/bgi-create`, surveyData)
      .then(() => message.success('Survey submitted successfully'))
      .catch((err) => errorHandler(err));
  },
  downloadInventory: (locationId: number,locationName:string) => {
    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/inventories/report/bgi`, { params:{locationId},responseType:"arraybuffer" })
      .then((res: any) =>  {
      const blob = new Blob([res],  { type: "text/csv;charset=utf-8" });
      saveAs(blob, `inventory_${locationName}_${moment().format('YYYY-MM-DD')}.xlsx`)})
      .catch((err) => errorHandler(err));
  },
};
