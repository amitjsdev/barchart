/* eslint-disable no-else-return */
import React, { useEffect, useState } from 'react';
import { useModel } from 'umi';
import { Spin, Result } from 'antd';

import { ModuleTypes } from '@/services/Constants';
import BgiForm from './components/BgiForm';
import bgiService from '../services/bgi.service';

const Success: React.FC<any> = (props) => {
  return (
    <div style={{ padding: '10%' }}>
      <Result
        status="success"
        title="Form Successfully Submitted"
        subTitle="Please come tomorrow to take the survey."
        extra={[]}
      />
    </div>
  );
};

const BgiSurvey: React.FC<{}> = (props) => {
  const { initialState, loading } = useModel('@@initialState');
  const { currentUser }: App.InitialStateType = initialState;
  const [doesSurveyExist, setDoesSurveyExist] = useState(undefined);
  const bgiProfile = currentUser?.modules.find((module) => module.name === ModuleTypes.BGI);

  useEffect(() => {
    if (bgiProfile) {
      bgiService.getSurveyFormStatus(bgiProfile?.locationId).then((isSubmitted) => {
        setDoesSurveyExist(isSubmitted);
      });
    }
  }, []);

  if (loading) return <Spin />;

  return doesSurveyExist ? (
    // <></>
    <Success />
  ) : (
    <BgiForm bgiProfile={bgiProfile} />
  );
};

export default BgiSurvey;
