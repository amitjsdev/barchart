import React, { useState } from 'react';
import { Row, Card, Form, Button, message, InputNumber, Col } from 'antd';
import { connect } from 'umi';
import { PageContainer } from '@ant-design/pro-layout';
import bgiService from '../../../services/bgi.service';
import { StateType } from '../../model';

import styles from './index.less';

// const { Link } = Anchor;
// const { Text, Paragraph } = Typography;

const BgiForm: React.FC<any> = (props) => {
  const { bgiProfile, dispatch } = props;

  const [inputFieldValuesSurvey, setInputFieldValuesSurvey] = useState({});

  const surveyValues = (value: any) => {
    inputFieldValuesSurvey[value.key] = isNaN(parseInt(value.value, 10))
      ? value.value
      : parseInt(value.value, 10);
    setInputFieldValuesSurvey({ ...inputFieldValuesSurvey });
  };

  const onFinish = () => {
    if (
      inputFieldValuesSurvey.hasOwnProperty('numberOfAttendees') &&
      inputFieldValuesSurvey.hasOwnProperty('samplesPerDay') &&
      inputFieldValuesSurvey.numberOfAttendees != null &&
      inputFieldValuesSurvey.samplesPerDay != null
    ) {
      bgiService.getSurveyFormStatus(bgiProfile.locationId).then((isSubmitted) => {
        if (isSubmitted) {
          message.error('Form was already submitted');
        } else {
          dispatch({
            type: 'bgiSurvey/saveBgiForm',
            payload: { ...inputFieldValuesSurvey, locationId: bgiProfile.locationId },
          });

          dispatch({
            type: 'bgiSurvey/submitForm',
            payload: { ...inputFieldValuesSurvey, locationId: bgiProfile.locationId },
          });
        }
      });
    } else {
      message.error('Please fill all the fields');
    }
  };

  return (
    <PageContainer title="BGI FORM" className={styles.main}>
      <div className={styles.main}>
        <Row gutter={[24, 24]}>
          <Col span={24}>
            <Card>
              {props.formContent[0].contents.map((content: any) => {
                return (
                  <Card type="inner" style={{ marginTop: '2%' }}>
                    <Form
                      layout="vertical"
                      autoComplete="off"
                      name={content.key}
                      initialValues={{}}
                    >
                      <Form.Item
                        name={content.key}
                        label={content.question}
                        rules={[
                          { required: content.required, message: 'Required' },
                          {
                            type: 'number',
                            min: 0,
                            message: 'Should be more than 0',
                          },
                        ]}
                      >
                        <InputNumber
                          style={{ width: '200px' }}
                          min={0}
                          placeholder=""
                          onChange={(value) =>
                            surveyValues({
                              value,
                              key: content.key,
                              type: 'input',
                            })
                          }
                        />
                      </Form.Item>
                    </Form>
                  </Card>
                );
              })}
              <br />
              <div style={{ textAlign: 'right' }}>
                <Button type="primary" onClick={onFinish}>
                  Submit
                </Button>
              </div>
            </Card>
          </Col>
        </Row>
      </div>
    </PageContainer>
  );
};

export default connect(({ bgiSurvey }: { bgiSurvey: StateType }) => ({
  formContent: bgiSurvey.bgiFormContent,
}))(BgiForm);
