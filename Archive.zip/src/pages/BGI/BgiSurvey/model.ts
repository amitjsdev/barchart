import { Effect, Reducer } from 'umi';

import bgiService from '../services/bgi.service';

interface ISurveySection {
  sectionName: string;
  contents: ISurveyQuestion[];
}

export interface StateType {
  survey: any[];
  options: any[];
  bgiFormContent: ISurveySection[];
}

export interface ModelType {
  namespace: string;
  state: StateType;
  effects: {
    submitForm: Effect;
  };
  reducers: {
    saveSurvey: Reducer<StateType>;
    saveOptions: Reducer<StateType>;

    saveBgiForm: Reducer<StateType>;
  };
}

const bgiFormContent: ISurveySection[] = [
  {
    sectionName: 'Form',
    contents: [
      {
        question: 'Total number of Attendees',
        questionInArabic: 'مجموع عدد العينات المعاد فحصها ',
        key: 'numberOfAttendees',
        enableTable: false,
        required: true,
        surveyFields: {
          type: 'input',
          optionfields: [],
          inputType: 'number',
        },
        formFields: [],
        enableFormFields: true,
      },
      {
        question: 'Total number of Samples Per Day',
        questionInArabic: 'مجموع عدد العينات المعاد فحصها ',
        key: 'samplesPerDay',
        enableTable: false,
        required: true,
        surveyFields: {
          type: 'input',
          optionfields: [],
          inputType: 'number',
        },
        formFields: [],
        enableFormFields: true,
      },
    ],
  },
];

const Model: ModelType = {
  namespace: 'bgiSurvey',
  state: {
    survey: [],
    options: [],
    bgiFormContent,
  },

  effects: {
    async *submitForm({ payload }) {
      await bgiService.submitSurvey(payload);
      window.location.reload();
    },
  },

  reducers: {
    saveSurvey(state, { payload }) {
      return {
        ...state,
        survey: [...(state as StateType).survey, ...payload],
      };
    },

    saveOptions(state, { payload }) {
      return {
        ...state,
        options: [...(state as StateType).options, ...payload],
      };
    },

    saveBgiForm(state, { payload }) {
      return {
        ...state,
        options: [...(state as StateType).options, payload],
      };
    },
  },
};

export default Model;
