import React from 'react';
import { Row, Col, Typography } from 'antd';

import { LabTypeMap } from '../../Constants';
import StockChart from './StockChart';

import styles from '../../index.less';

const { Text } = Typography;

const CategoryStockChart: React.FC<BloodBank.CategoryStockChartProps> = (props) => {
  const { title, location, category, labType, region } = props;

  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels} ${styles.heatMapContent} `;
  return (
    <div className={`${styles.kpiCard}`}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }} align="middle" justify="space-between">
          <Col>
            <Text className={styles.chartTitle}>{title}</Text>
          </Col>
          <Col className={styles.filters} style={{ width: '250px' }}>
            <div className={styles.dropdownWidth}>
              {props.children}
              {/* <FilterSelect
                  filter={filter}
                  onChange={(val: string) => {
                    setCategoryFilter(val);
                  }}
                /> */}
            </div>
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <StockChart location={location} category={category} labType={LabTypeMap[labType]} region={region} />
      </div>
    </div>
  );
};

export default CategoryStockChart;
