import React from 'react';
import { Table, Spin } from 'antd';

const getFormattedColumns = (defaultColumns) => {
  return [
    {
      dataIndex: defaultColumns[0].dataIndex,
      key: defaultColumns[0].key,
      shortTitle: 'Description',
      title: 'Products Description',
      type: 'string',
    },
    {
      dataIndex: defaultColumns[1].dataIndex,
      key: defaultColumns[1].key,
      shortTitle: 'Machine',
      title: 'Machine',
      type: 'text',
    },
    {
      dataIndex: defaultColumns[2].dataIndex,
      key: defaultColumns[2].key,
      shortTitle: 'Quantities',
      title: 'Daily Consumption',
      type: 'number',
      render: (text) => Math.round(text),
    },
  ];
};

const ItemDetailTable = ({ resultSet, pivotConfig }) => {
  return resultSet ? (
    <Table
      pagination={false}
      columns={getFormattedColumns(resultSet.tableColumns(pivotConfig))}
      dataSource={resultSet.tablePivot(pivotConfig)}
    />
  ) : (
    <Spin />
  );
};

export default ItemDetailTable;
