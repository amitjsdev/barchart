import React, { useState } from 'react';
import { Spin, Empty, Modal } from 'antd';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';

import { getCubejsApiParams } from '@/services/cubejs';
import { REGION_FILTER_DIMENSION } from '../../Constants';
import hostname from '@/hostname';
import DrilldownDetailTable from './Drilldown';
import { DonutChart } from 'bizcharts';

enum status {
  'Working Count' = 'working',
  'Down Count' = 'down',
  'Partially Down Count' = 'partiallyDown',
  'Backup Count' = 'backup',
  'Retired Count' = 'retired',
}

enum tableTitle {
  working = 'Working Count',
  down = 'Down Count',
  partiallyDown = 'Partially Down Count',
  backup = 'Backup Count',
  retired = 'Retired Count',
}

enum InventoryType {
  'Instruments.backupCount' = 'Backup Count',
  'Instruments.workingCount' = 'Working Count',
  'Instruments.downCount' = 'Down Count',
  'Instruments.partiallyDownCount' = 'Partially Down Count',
  'Instruments.retiredCount' = 'Retired Count',
}

// CubeJS
const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint
const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);
var setRegionName: string;

// CubeJS
const cubeQueryRender = (props: any) => {
  const{labType,location,region}=props
  const [drillDownQuery, setDrillDownQuery] = useState();
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [tableDescription, setTableDescription] = useState();

  let filters = [];
  if (labType && labType !== 'allLocations') {
    filters.push({ dimension: 'Instruments.labtype', operator: 'equals', values: [labType] });
  }
  if (location && location !== 'All locations') {
    filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
    filters.push({
      dimension: REGION_FILTER_DIMENSION,
      operator: 'equals',
      values: [setRegionName],
    });
  }

  if (region && region !== 'All locations') {
    filters.push({
      dimension: REGION_FILTER_DIMENSION,
      operator: 'equals',
      values: [region],
    });
    setRegionName = region;
  }

  const baseDrillDownQuery = {
    dimensions: [
      'Instruments.equipmentname',
      'Instruments.labtype',
      'Locations.name',
      'Instruments.serialnumber',
    ],
  };

  const getItemDetailQuery = (selectedStatus) => {
    const filters = [
      {
        dimension: 'Instruments.state',
        operator: 'equals',
        values: [selectedStatus],
      },
    ];


    if (location && location !== 'All locations') {
      filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
    }
    if (labType && labType !== 'allLocations') {
      filters.push({
        dimension: 'Instruments.labtype',
        operator: 'equals',
        values: [labType],
      });
    }
    if (region && region !== 'All locations') {
      filters.push({
        dimension: REGION_FILTER_DIMENSION,
        operator: 'equals',
        values: [region],
      });
    }

    return { ...baseDrillDownQuery, filters };
  };

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: [
        'Instruments.workingCount',
        'Instruments.downCount',
        'Instruments.partiallyDownCount',
        'Instruments.backupCount',
        'Instruments.retiredCount',
      ],
      timeDimensions: [],
      filters,
      order: {},
    },
    {
      cubejsApi,
    },
  );

  const drillDownResponse = useCubeQuery(drillDownQuery, {
    skip: !drillDownQuery,
    cubejsApi,
  });

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const handleClickOnChart = (selectedStatus) => {
    // const machine = data.x;
    setTableDescription(tableTitle[selectedStatus]);
    setDrillDownQuery(getItemDetailQuery(selectedStatus));

    // let selectedLocation = 'All locations';

    // if (location !== 'All locations') selectedLocation = location;

    // if (region !== 'All locations') selectedLocation = region;

    if (drillDownResponse) {
      //   setTableDescription({
      //     machineFullName: data.x,
      //     type: data.x,
      //     location: selectedLocation,
      //   });
      setIsModalVisible(true);
    }
  };

  const handleModalOk = () => setIsModalVisible(false);
  const handleModalCancel = () => setIsModalVisible(false);

  const dataSource = resultSet.tablePivot();

  const pieData = Object.keys(dataSource[0]).map((type) => {
    return {
      type: InventoryType[type],
      value: dataSource[0][type],
    };
  });

  return (
    <>
      <InventoryCompositionPie data={pieData} handleClickOnChart={handleClickOnChart}  />
      <Modal
        title={tableDescription}
        centered
        visible={isModalVisible}
        width={720}
        onOk={handleModalOk}
        onCancel={handleModalCancel}
        destroyOnClose
        footer={false}
      >
        <DrilldownDetailTable
          resultSet={drillDownResponse.resultSet}
          pivotConfig={drillDownResponse.pivotConfig || null}
        />
      </Modal>
    </>
  );
};

const InventoryCompositionPie: React.FC = ({ data, handleClickOnChart }) => {
  if (data.some((item) => item.value !== 0)) {
    return (
      <DonutChart
        radius={1}
        innerRadius={0.7}
        data={data}
        angleField="value"
        colorField="type"
        color={['#008755', '#C8102E','#DC582A','#009ACE', '#753BBD' ]}
        pieStyle={{
          stroke: 'transparent',
        }}
        label={{ visible: false }}
        statistic={{
          visible: true,
          totalLabel: '',
        }}
        tooltip={{
          visible: true,
        }}
        events={{
          onRingClick: (event, chart) => {
            handleClickOnChart(status[event.data.type]);
          },
        }}
      />
    );
  } else {
    return <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
  }
};

export default cubeQueryRender;
