import React from 'react';
import { Table, Spin } from 'antd';

const getFormattedColumns = (defaultColumns) => {
    return [
      {
        dataIndex: 'Instruments.serialnumber',
        key: 'Instruments.serialnumber',
        shortTitle: 'Serial Number',
        title: 'Serial Number',
        type: 'string',
      },
      {
        dataIndex: 'Instruments.equipmentname',
        key: 'Instruments.equipmentname',
        shortTitle: 'Equipment Name',
        title: 'Equipment Name',
        type: 'string',
      },
      {
        dataIndex: 'Instruments.labtype',
        key: 'Instruments.labtype',
        shortTitle: 'LabType',
        title: 'LabType',
        type: 'string',
      },
      
      {
        dataIndex: 'Locations.name',
        key: 'Locations.name',
        shortTitle: 'Location',
        title: 'Location',
        type: 'string',
      },
    ];
  };

const DrilldownDetailTable = ({ resultSet, pivotConfig }) => {
    return resultSet ? (
      <Table
        pagination={false}
        columns={getFormattedColumns(resultSet.tableColumns(pivotConfig))}
        dataSource={resultSet.tablePivot(pivotConfig)}
      />
    ) : (
      <Spin />
    );
}

export default DrilldownDetailTable;
