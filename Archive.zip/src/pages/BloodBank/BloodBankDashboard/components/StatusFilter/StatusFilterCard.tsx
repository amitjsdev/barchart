import React from 'react';

import { LabTypeMap } from '../../Constants';
import KpiCard from '../KpiCard/KpiCard';
import StatusFilter from './StatusFilter';

const StatusFilterCard: React.FC<BloodBank.KpiCardProps> = (props) => {
  return (
    <KpiCard title={props.title} >
      <StatusFilter {...props}/>
    </KpiCard>
  );
};

export default StatusFilterCard;
