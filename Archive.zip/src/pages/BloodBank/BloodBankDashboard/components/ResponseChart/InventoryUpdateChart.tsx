import React from 'react';
import { Row, Col, Typography } from 'antd';

import ResponseChart from './ResponseChart';

import styles from '../../index.less';

const { Text } = Typography;

const InventoryUpdateChart: React.FC<BloodBank.InventoryUpdateChartProps> = (props) => {
  const { title, labType, dateRangeFilter, totalLabs } = props;
  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;

  return (
    <div className={styles.kpiCard}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{title}</Text>
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <ResponseChart
          labType={labType}
          dateRangeFilter={dateRangeFilter}
          totalLabs={totalLabs}
        />
      </div>
    </div>
  );
};

export default InventoryUpdateChart;