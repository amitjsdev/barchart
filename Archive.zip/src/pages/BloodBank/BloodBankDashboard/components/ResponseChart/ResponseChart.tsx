import React, { useState } from 'react';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { Spin, Empty, Modal, Typography, Row, Col } from 'antd';
import { Chart, Axis, Tooltip, Interval } from 'bizcharts';
import moment from 'moment';

import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';
import LabDetailsTable from './LabDetailsTable';

const { Title, Text } = Typography;

const ResponseChart = (props) => {
  const { dateRangeFilter, labType, totalLabs } = props;

  const [drillDownQuery, setDrillDownQuery] = useState();
  const [allLocationsQuery, setAllLocationsQuery] = useState();

  const [isModalVisible, setIsModalVisible] = useState(false);
  const [tableDescription, setTableDescription] = useState();
  let dateWiseLabs = null;

  const formatResultSet = (resultSet) => {
    const { data } = resultSet.loadResponses[0];
    if (data) {
      dateWiseLabs = data.reduce((acc, cur) => {
        const date = cur['DailyConsumptions.consumptiondate'];
        const lab = cur['Locations.name'];
        acc[date] ? acc[date].push(lab) : (acc[date] = [lab]);
        return acc;
      }, {});
    }

    const newData = Object.keys(dateWiseLabs).map((date) => {
      return {
        'DailyConsumptions.count': dateWiseLabs[date].length,
        'DailyConsumptions.reorderquantity': totalLabs - dateWiseLabs[date].length,
        'DailyConsumptions.consumptiondate': date,
        'Locations.name': ' ',
      };
    });

    resultSet.loadResponses[0].data = newData;

    return resultSet;
  };

  const formatData = (data) => {
    return data.map((item) => {
      const formattedItem = { ...item };
      const [date] = formattedItem.x.split(',');
      formattedItem.x = moment(date).format('DD-MM-YYYY');
      if (formattedItem.color === 'DailyConsumptions.reorderquantity') {
        formattedItem.color = 'Labs not updated inventory';
        // formattedItem.measure = 26;
        return formattedItem;
      }

      formattedItem.color = 'Labs updated inventory';
      return formattedItem;
    });
    /* .map((item) => {
        
        if (item.x === startDate || item.x === endDate) item.measure = 0;
        return item;
      }); */
  };

  const stackedChartData = (resultSet) => {
    const data = resultSet
      .pivot()
      .map(({ xValues, yValuesArray }) =>
        yValuesArray.map(([yValues, m]) => ({
          x: resultSet.axisValuesString(xValues, ', '),
          color: resultSet.axisValuesString(yValues, ', '),
          measure: m && Number.parseFloat(m),
        })),
      )
      .reduce((a, b) => a.concat(b), []);

    return formatData(data);
    // return data
  };

  const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

  const cubejsParams = getCubejsApiParams(API_URL);

  const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

  const filters = [
    {
      dimension: 'Locations.labType',
      operator: 'equals',
      values: [labType],
    },
    {
      member: 'DailyConsumptions.consumptiondate',
      operator: 'inDateRange',
      values: [dateRangeFilter.dateRange[0], dateRangeFilter.dateRange[1]],
    },
  ];

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['DailyConsumptions.count', 'DailyConsumptions.reorderquantity'],
      timeDimensions: [],
      dimensions: ['DailyConsumptions.consumptiondate', 'Locations.name'],
      filters,
      segments: [],
      order: { 'DailyConsumptions.consumptiondate': 'asc' },
    },
    {
      cubejsApi,
    },
  );

  const allLocationsResponse = useCubeQuery(allLocationsQuery, {
    skip: !allLocationsQuery,
    cubejsApi,
  });

  const drillDownResponse = useCubeQuery(drillDownQuery, {
    skip: !drillDownQuery,
    cubejsApi,
  });

  if (isLoading || !totalLabs) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  //   Drill down
  const baseItemDetailsQuery = {
    measures: ['DailyConsumptions.count'],
    timeDimensions: [],
    dimensions: ['Locations.name'],
    filters: [],
  };

  const getItemDetailQuery = (key, date) => {
    const filters = [
      {
        dimension: 'Locations.labType',
        operator: 'equals',
        values: [labType],
      },
      {
        dimension: 'DailyConsumptions.consumptiondate',
        operator: 'equals',
        values: [moment(date, 'DD-MM-YYYY').format('YYYY-MM-DD')],
      },
    ];

    return { ...baseItemDetailsQuery, filters };
  };

  const handleClickOnChart = (data) => {
    // const query = getXAndYValues(geomId);

    const query = {
      key: data.color,
      date: data.x,
    };

    setAllLocationsQuery({
      dimensions: ['Locations.name'],
      filters: [
        {
          dimension: 'Locations.labType',
          operator: 'equals',
          values: [labType],
        },
      ],
    });

    if (allLocationsResponse.resultSet) {
      const dataSource = allLocationsResponse.resultSet.tablePivot();
      const columns = allLocationsResponse.resultSet.tableColumns();

      // setIsModalVisible(true);
    }

    setDrillDownQuery(getItemDetailQuery(query.key, query.date));

    if (drillDownResponse) {
      setTableDescription({
        date: query.date,
        key: query.key,
      });
      setIsModalVisible(true);
    }
  };

  const parseResultSet = (allLocationsResultSet) => {
    return allLocationsResultSet ? allLocationsResultSet.loadResponses[0].data : null;
  };

  const colors = ['color', ['#753BBD', '#291940']];
  const BarRender = ({ resultSet }) => {
    return (
      <Chart
        scale={{ x: { tickCount: 8 } }}
        // height={280}
        data={stackedChartData(formatResultSet(resultSet))}
        autoFit
        padding="auto"
        onIntervalClick={(e, chart) => {
          handleClickOnChart(e.data.data);
        }}
      >
        <Axis name="x" label={false} tickLine={false} />
        <Axis name="measure" />
        <Tooltip />
        {/* <Geom type="interval" position={`x*measure`} color={colors} /> */}
        <Interval
          adjust={[{ type: 'stack', reverseOrder: false }]}
          position="x*measure"
          color={colors}
        />
      </Chart>
    );
  };

  const ModalHeader = () => (
    <Row>
      <Col>
        <Title level={4}>{tableDescription.key}</Title>
        <Text type="secondary" level={5}>
          {tableDescription.date}
        </Text>
      </Col>
    </Row>
  );

  const handleModalOk = () => setIsModalVisible(false);
  const handleModalCancel = () => setIsModalVisible(false);
  const allLabs = parseResultSet(allLocationsResponse.resultSet);
  const labsTakenSurvey = parseResultSet(drillDownResponse.resultSet);

  const data = resultSet?.loadResponses[0].data || null;

  return data && data.length ? (
    <>
      <BarRender resultSet={resultSet} />
      <Modal
        title="Responses"
        centered
        visible={isModalVisible}
        width={800}
        onOk={handleModalOk}
        onCancel={handleModalCancel}
        destroyOnClose
        footer={false}
      >
        {allLabs && labsTakenSurvey ? (
          <LabDetailsTable allLabs={allLabs} labsTakenSurvey={labsTakenSurvey} />
        ) : null}
      </Modal>
    </>
  ) : (
    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
  );
};
export default ResponseChart;
