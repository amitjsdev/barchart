import React from 'react';
import { Typography, Popover } from 'antd';
import { InfoCircleOutlined } from '@ant-design/icons';

import styles from './index.less';

const { Text } = Typography;

const KpiStatisticsCard: React.FC<BloodBank.KpiStatisticsCardProps> = (props) => (
  <div className={styles.kpiStatisticsCard}>
    <div className={styles.kpiCardTitleBar}>
      <div>
        <Text className={styles.chartTitle}>{props.title}</Text>
        {props.info ? (
          <Popover content={props.info} title="Info">
            <InfoCircleOutlined style={{ padding: '8px' }} />
          </Popover>
        ) : null}
      </div>
    </div>
    <div className={styles.kpiStatisticsCardContent}>
      {props.children}
    </div>
  </div>
);

export default KpiStatisticsCard;