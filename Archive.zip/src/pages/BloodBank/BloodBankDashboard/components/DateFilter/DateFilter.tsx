import React, { useState } from 'react';
import { DatePicker, Space, Radio } from 'antd';
import moment from 'moment';

import { FilterType } from '../../Types';

const { RangePicker } = DatePicker;

const DATE_FORMAT = 'YYYY-MM-DD';

export default (props) => {
  const { onDateChange, onGranularityChange } = props;
  // const [granularity, setGranularity] = useState('day');
  // const [dateRange, setDateRange] = useState([moment(), moment()]);
  const currentWeekNumber = moment().week();
  const granularityOptions = [
    { label: 'Day', value: 'day' },
    { label: 'Week', value: 'week' },
    { label: 'Month', value: 'month' },
    { label: 'Year', value: 'year' },
  ];

  /* const onFilterChange = (value, filterType: FilterType) => {
    if (filterType === 'granularity' ) {
      
      setGranularity(value);
    } else if (filterType === 'dateRange') {
      (value) ? setDateRange(value) : setDateRange([moment(), moment()]);
      onChange({
        granularity,
        dateRange
      });
    }
  }; */

  return (
    <Space size={12}>
      {/* <Radio.Group buttonStyle="solid" defaultValue={'day'} onChange={(e) => onGranularityChange(e.target.value)}>
        {
          granularityOptions.map(option => <Radio.Button value={option.value}>{option.label}</Radio.Button>)
        }
      </Radio.Group> */}
      <RangePicker
        onChange={(dates, dateStrings) => onDateChange(dates)}
        defaultValue={[moment(), moment()]}
        // value={dateRange}
        ranges={{
          Today: [moment(), moment()],
          'Last week': [
            moment()
              .week(currentWeekNumber - 1)
              .startOf('week'),
            moment()
              .week(currentWeekNumber - 1)
              .endOf('week'),
          ],
          'Last month': [
            moment().subtract(1, 'month').startOf('month'),
            moment().subtract(1, 'month').endOf('month'),
          ],
          'Last quarter': [
            moment().subtract(1, 'quarter').startOf('quarter'),
            moment().subtract(1, 'quarter').endOf('quarter'),
          ],
        }}
      />
    </Space>
  );
};
