import React, { useState, useEffect } from 'react';
import { useHistory } from 'umi';
import { Spin, Row, Col, Typography } from 'antd';
import moment from 'moment';

import bloodBankService from '@/pages/BloodBank/services/bloodBank.service';
import { DATE_FORMAT } from '../../Constants';
import LocationSelector from '../LocationSelector/LocationSelector';
import DateFilter from '../DateFilter/DateFilter';

import styles from '../../index.less';

const { Title } = Typography;

const DashboardContainer: React.FC<BloodBank.DashboardContainerProps> = (props) => {
  const history = useHistory();
  const bloodBankLabType = bloodBankService.getLabTypeFromUrlFragment(history.location.pathname);

  const [currentLab, setCurrentLab] = useState('');
  const [currentRegion, setCurrentRegion] = useState('');

  const [labNames, setLabNames] = useState(['All locations']);
  const [regionsName, setRegionsNames] = useState(['Riyadh']);

  const [loading, setLoading] = useState<boolean>(true);
  const [totalLabCount, setTotalLabCount] = useState(0);
  const [regionsAndLabs, setRegionsAndLabs] = useState([
    { value: 'All locations', label: 'All locations', children: [] },
  ]);

  const defaultFilterSetting = {
    granularity: 'day',
    dateRange: [moment().format(DATE_FORMAT), moment().format(DATE_FORMAT)],
  };
  const [dateRangeFilter, setDateRangeFilter] = useState(defaultFilterSetting);

  const onDateChange = (filter) => {
    setDateRangeFilter({
      granularity: dateRangeFilter.granularity,
      dateRange: [
        filter ? filter[0].format(DATE_FORMAT) : moment().format(DATE_FORMAT),
        filter ? filter[1].format(DATE_FORMAT) : moment().format(DATE_FORMAT),
      ],
    });
  };

  const locDropdown: {} = {};

  useEffect(() => {
    bloodBankService.getLocationsByLabType(bloodBankLabType).then((locations: any) => {
      setTotalLabCount(locations.length);
      const lab_Name = locations.map((lab: any) => {
        if (lab.region in locDropdown) {
          locDropdown[lab.region].push(lab.name);
        } else {
          locDropdown[lab.region] = [lab.name];
        }
      });
      const arr: any[] = [];
      Object.entries(locDropdown).map((entry) => {
        const temp = entry[1].map((data) => ({
          value: data,
          label: data,
        }));
        arr.push({
          value: entry[0],
          label: entry[0],
          children: temp,
        });
      });

      setRegionsAndLabs(regionsAndLabs.concat(arr));
      setLabNames(labNames.concat(lab_Name));
      bloodBankService.getRegionsByLabType(bloodBankLabType).then((region) => {
        const regionNames = region.map(({ name }) => name);
        // setRegionsNames(regionsName.concat(regionNames));
        setRegionsNames(regionNames);
      });

      setCurrentLab('All locations');
      setCurrentRegion('All locations');
      setLoading(false);
    });
  }, []);

  return (
    <div className={styles.main}>
      {loading ? (
        <Spin spinning={loading} size="large" />
      ) : (
        <>
          <Row className={styles.locationPanel} align="middle" justify="space-between">
            <Col>
              <Title level={4}>Dashboard</Title>
            </Col>
            <Col>
              <Row gutter={[24, 24]} align="middle" style={{ margin: '0px' }}>
                <Col>
                  <LocationSelector
                    onLabChange={setCurrentLab}
                    onRegionChange={setCurrentRegion}
                    regionsAndLabs={regionsAndLabs}
                  />
                </Col>
                <Col>
                  <DateFilter onDateChange={onDateChange} />
                </Col>
              </Row>
            </Col>
          </Row>

          {React.Children.map(props.children, (child) => {
            return (
              React.isValidElement(child) &&
              React.cloneElement(child, {
                currentLab,
                currentRegion,
                dateRangeFilter,
                totalLabCount,
                regionsName,
                labType: bloodBankLabType
              })
            );
          })}
        </>
      )}
    </div>
  );
};

export default DashboardContainer;
