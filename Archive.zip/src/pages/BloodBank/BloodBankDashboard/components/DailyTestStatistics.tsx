import React, { useState } from 'react';
import { Spin, Statistic, Space, Typography, Modal, Row, Col, Button } from 'antd';
import { InboxOutlined } from '@ant-design/icons';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';

import { getCubejsApiParams } from '@/services/cubejs';
import { REGION_FILTER_DIMENSION } from '../Constants';
import ItemDetailTable from './DailyTests/ItemDetailTable';

const { Text } = Typography;

// CubeJS
const cubejsParams = getCubejsApiParams();

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const cubeQueryRender = (props) => {
  const { Title, Paragraph, Text } = Typography;
  const { location, labType, dateRangeFilter, region } = props;

  const [drillDownQuery, setDrillDownQuery] = useState();
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [tableDescription, setTableDescription] = useState();

  const filters = [
    {
      member: 'DailyConsumptions.consumptiondate',
      operator: 'inDateRange',
      values: dateRangeFilter.dateRange,
    },
    {
      dimension: 'Locations.labType',
      operator: 'equals',
      values: [labType],
    },
  ];

  if (location && location !== 'All locations') {
    filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
  }

  if (region && region !== 'All locations') {
    filters.push({ dimension: REGION_FILTER_DIMENSION, operator: 'equals', values: [region] });
  }

  const formatData = (data) => {
    return data.map((item) => {
      const formattedItem = { ...item };

      if (formattedItem.color.endsWith('availableQuantities')) {
        formattedItem.color = 'Available quantities';
        return formattedItem;
      }
    });
  };

  const stackedChartData = (resultSet) => {
    const data = resultSet
      .pivot()
      .map(({ xValues, yValuesArray }) =>
        yValuesArray.map(([yValues, m]) => ({
          x: resultSet.axisValuesString(xValues, ', '),
          color: resultSet.axisValuesString(yValues, ', '),
          measure: m && Math.round(Number.parseFloat(m)),
        })),
      )
      .reduce((a, b) => a.concat(b), []);

    return data;
  };


  const cubejsParams = getCubejsApiParams();

  const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

  const baseDrillDownQuery = {
    measures: ['DailyConsumptions.consumption'],
    dimensions: ['Products.description', 'Products.category'],
  };

  const getItemDetailQuery = (type) => {
    const filters = [
      {
        member: 'DailyConsumptions.consumptiondate',
        operator: 'inDateRange',
        values: dateRangeFilter.dateRange,
      },
      {
        dimension: 'Locations.labType',
        operator: 'equals',
        values: [labType],
      },
      {
        dimension: 'Products.classification',
        operator: 'equals',
        values: [type],
      },
    ];

    if (type.length && location && location !== 'All locations') {
      filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
    }

    if (type.length && region && region !== 'All locations') {
      filters.push({ dimension: REGION_FILTER_DIMENSION, operator: 'equals', values: [region] });
    }

    const order = {};
    // order[stockType] = 'desc';

    return { ...baseDrillDownQuery, filters };
  };

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      dimensions: ['Products.classification'],
      measures: [`DailyConsumptions.consumption`],
      filters,
      order: {
        'DailyConsumptions.consumption': 'desc',
      },
    },
    {
      cubejsApi,
    },
  );

  const drillDownResponse = useCubeQuery(drillDownQuery, {
    skip: !drillDownQuery,
    cubejsApi,
  });

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const handleClickOnChart = (data) => {
    const machine = data.x;

    setDrillDownQuery(getItemDetailQuery(machine));

    let selectedLocation = 'All locations';

    if (location !== 'All locations') selectedLocation = location;

    if (region !== 'All locations') selectedLocation = region;


    if (drillDownResponse) {
      setTableDescription({
        machineFullName: data.x,
        type: data.x,
        location: selectedLocation,
      });
      setIsModalVisible(true);
    }
  };

  const handleModalOk = () => setIsModalVisible(false);
  const handleModalCancel = () => setIsModalVisible(false);

  const dataSource = resultSet.tablePivot();

  //
  //   'Sum of samples',
  //   dataSource?.reduce((acc, cur) => acc + cur['BgiSurveys.samplesPerDay'], 0) || 0,
  // );

  let avgSamplesPerDay = null;

  if (dataSource && dataSource.length)
    avgSamplesPerDay = dataSource[0]['DailyConsumptions.consumption'];

  const RenderStatistics = ({ resultSet }) => {
    return avgSamplesPerDay ? (
      <>
        <Row type="flex" justify="center" align="middle" style={{ height: '70%' }}>
          <Col>
            {resultSet.seriesNames().map((s) => (
              <Statistic value={resultSet.totalRow()[s.key]} />
            ))}
          </Col>
        </Row>
        <Row type="flex" justify="center" align="middle" style={{ height: '30%' }}>
          <Button
            type="primary"
            onClick={(e) => {
              handleClickOnChart({
                x: 'Phenotyping',
                color: 'DailyConsumptions.consumption',
                measure: avgSamplesPerDay,
              });
            }}
          >
            Details
          </Button>
        </Row>
      </>
    ) : (
      <Space size={12}>
        <InboxOutlined />
        <Text type="secondary">No data</Text>
      </Space>
    );
  };

  const ModalHeader = () => (
    <Row>
      <Col>
        <Title level={4}>{tableDescription.machineFullName}</Title>
        <Text type="secondary" level={5}>
          {tableDescription.location}
        </Text>
      </Col>
    </Row>
  );

  return (
    <>
      <RenderStatistics resultSet={resultSet} />
      <Modal
        title={<ModalHeader />}
        centered
        visible={isModalVisible}
        width={720}
        onOk={handleModalOk}
        onCancel={handleModalCancel}
        destroyOnClose
        footer={false}
      >
        <ItemDetailTable
          resultSet={drillDownResponse.resultSet}
          pivotConfig={drillDownResponse.pivotConfig || null}
        />
      </Modal>
    </>
  );
};

export default cubeQueryRender;
