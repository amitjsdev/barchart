import React from 'react';
import { Row, Col, Typography } from 'antd';

import { LabTypeMap } from '../../Constants';
import AverageConsumableDays from './AverageConsumableDays';

import styles from '../../index.less';

const { Text } = Typography;

const AverageConsumableDaysChart: React.FC<BloodBank.AverageConsumableDaysChartProps> = (props) => {
  const { title, labType, region, daysFilter, location } = props;
  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;

  return (
    <div className={styles.kpiCard}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{title}</Text>
          </Col>
          <Col flex={2} className={styles.filters}>
            {props.children}
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <AverageConsumableDays
          labType={LabTypeMap[labType]}
          region={region}
          location={location}
          daysFilter={daysFilter}
        />
      </div>
    </div>
  );
};

export default AverageConsumableDaysChart;
