import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Spin } from 'antd';
import { Chart, Axis, Tooltip, Geom } from 'bizcharts';

import { getCubejsApiParams } from '@/services/cubejs';
import { DaysToOosFilters } from '../../Constants';

const stackedChartData = (resultSet) => {
  const data = resultSet
    .pivot()
    .map(({ xValues, yValuesArray }) =>
      yValuesArray.map(([yValues, m]) => ({
        x: resultSet.axisValuesString(xValues, ', '),
        color: resultSet.axisValuesString(yValues, ', '),
        measure: m && Number.parseFloat(m),
      })),
    )
    .reduce((a, b) => a.concat(b), []);

  return data;
};

const label = { style: { fill: '#ffffff' } };

const barRender = ({ resultSet }) => (
  <Chart scale={{ x: { tickCount: 24 } }} data={stackedChartData(resultSet)} autoFit>
    <Axis name="x" label={false} />
    <Axis name="measure" label={label} />
    <Tooltip />
    <Geom type="interval" position="x*measure" color="x" />
  </Chart>
);

const cubejsParams = getCubejsApiParams();

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) =>
  (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
  (error && error.toString()) || <Spin />;

const ChartRenderer = (props) => {
  const { labType, region, daysFilter, location } = props;
  const filters = [];

  const filterToSegmentMap = {
    [DaysToOosFilters.LESS_THAN_FIFTEEN_DAYS]: [`${labType}.oos`],
    [DaysToOosFilters.FIFTEEN_TO_THIRTY_DAYS]: [`${labType}.noos`],
    [DaysToOosFilters.THIRTY_TO_EIGHTY_DAYS]: [`${labType}.ss`],
    [DaysToOosFilters.MORE_THAN_EIGHTY_DAYS]: [`${labType}.os`],
  };

  const segments = filterToSegmentMap[daysFilter];

  if (region !== 'All locations') {
    filters.push({
      dimension: 'IRegions.name',
      operator: 'equals',
      values: [region],
    });
  }
  if (location !== 'All locations') {
    filters.push({
      dimension: 'Locations.name',
      operator: 'equals',
      values: [location],
    });
  }
  return (
    <QueryRenderer
      query={{
        dimensions: ['Locations.name'],
        measures: [`${labType}.consumableDays`],
        filters,
        segments,
      }}
      cubejsApi={cubejsApi}
      render={renderChart(barRender, {
        x: [],
        y: ['Locations.name', 'measures'],
        fillMissingDates: true,
        joinDateRange: false,
      })}
    />
  );
};

export default ChartRenderer;
