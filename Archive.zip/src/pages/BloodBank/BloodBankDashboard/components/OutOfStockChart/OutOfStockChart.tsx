import React from 'react';
import { Row, Col, Typography } from 'antd';

import { LabTypeMap } from '../../Constants';
import OutOfStock from './OutOfStock';

import styles from '../../index.less';

const { Text } = Typography;

const OutOfStockChart: React.FC<BloodBank.OutOfStockChartProps> = (props) => {
  const { title, location, labType, daysFilter, region } = props;
  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;

  return (
    <div className={styles.kpiCard}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{title}</Text>
          </Col>
          <Col flex={2} className={styles.filters}>
            <div>{props.children}</div>
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <OutOfStock
          location={location}
          labType={LabTypeMap[labType]}
          daysFilter={daysFilter}
          region={region}
        />
      </div>
    </div>
  );
};

export default OutOfStockChart;
