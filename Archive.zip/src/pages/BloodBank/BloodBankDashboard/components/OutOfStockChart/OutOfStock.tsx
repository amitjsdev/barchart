/* eslint-disable no-else-return */
import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Spin, Empty } from 'antd';
import { Chart, Axis, Tooltip, Legend, Interval } from 'bizcharts';

import { getCubejsApiParams } from '@/services/cubejs';
import { ProductTypeNames, DaysToOosFilters, REGION_FILTER_DIMENSION } from '../../Constants';

const formatData = (data) => {
  return data.map((sku) => {
    const value = sku.x;

    if (value.endsWith(ProductTypeNames.Serology)) {
      return { ...sku, type: ProductTypeNames.Serology };
    } else if (value.endsWith(ProductTypeNames.NAT)) {
      return { ...sku, type: ProductTypeNames.NAT };
    } else if (value.endsWith(ProductTypeNames.Phenotyping)) {
      return { ...sku, type: ProductTypeNames.Phenotyping };
    } else if (value.endsWith(ProductTypeNames['Bacterial Detection'])) {
      return { ...sku, type: ProductTypeNames['Bacterial Detection'] };
    } else {
      return { ...sku, type: ProductTypeNames['Donation bags & Plasma'] };
    }
  });
};

const stackedChartData = (resultSet) => {
  const data = resultSet
    .pivot()
    .map(({ xValues, yValuesArray }) =>
      yValuesArray.map(([yValues, m]) => ({
        x: resultSet.axisValuesString(xValues, ', '),
        color: resultSet.axisValuesString(yValues, ', '),
        measure: m && Number.parseFloat(m),
      })),
    )
    .reduce((a, b) => a.concat(b), []);

  return formatData(data);
};

const label = { style: { fill: '#ffffff' } };
const colors = [
  '#1DAD28',
  '#79D2DE',
  '#753BBD',
  '#E1BE4C',
  '#9971D0',
  '#F092DD',
  '#EEC8E0',
  '#392F5A',
  '#A8C7BB',
  '#B54553',
];

const setColorByCategory = (value: string) => {
  if (value.endsWith('Ultrio elite assay reagent, NAT')) {
    return '#A8C7BB';
  } else if (value.endsWith(ProductTypeNames.Serology)) {
    return '#753BBD';
  } else if (value.endsWith(ProductTypeNames.NAT)) {
    return '#E1BE4C';
  } else if (value.endsWith(ProductTypeNames.Phenotyping)) {
    return '#9971D0';
  } else if (value.endsWith(ProductTypeNames['Bacterial Detection'])) {
    return '#392F5A';
  } else {
    return '#B54553';
  }
};

const barRender = ({ resultSet }) => (
  <Chart
    scale={{ x: { tickCount: 24 } }}
    data={stackedChartData(resultSet)}
    autoFit
    // renderer={'svg'}
  >
    <Axis name="x" label={false} />
    <Axis name="measure" label={label} />
    <Tooltip />
    <Interval position="x*measure" color={['x', setColorByCategory]} />
    <Legend name="type" />
  </Chart>
);

const cubejsParams = getCubejsApiParams();

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) => {
  const data = resultSet?.loadResponses[0]?.data;
  const result = (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
    (error && error.toString()) || <Spin />;

  return data && data.length ? result : <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
};

const ChartRenderer = (props) => {
  const { labType, location, daysFilter, region } = props;

  const chartMeasure = `${labType}.consumableDays`;
  const filters = [];

  const filterToSegmentMap = {
    [DaysToOosFilters.LESS_THAN_FIFTEEN_DAYS]: [`${labType}.oos`],
    [DaysToOosFilters.FIFTEEN_TO_THIRTY_DAYS]: [`${labType}.noos`],
    [DaysToOosFilters.THIRTY_TO_EIGHTY_DAYS]: [`${labType}.ss`],
    [DaysToOosFilters.MORE_THAN_EIGHTY_DAYS]: [`${labType}.os`],
  };

  const segments = filterToSegmentMap[daysFilter];

  if (labType === 'CentralBloodBankInventories') {
    filters.push({
      dimension: 'Products.classification',
      operator: 'equals',
      values: ['Serology', 'NAT'],
    });
  }

  if (location && location !== 'All locations') {
    filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
  }

  if (region && region !== 'All locations') {
    filters.push({ dimension: REGION_FILTER_DIMENSION, operator: 'equals', values: [region] });
  }

  const order = {};
  // order[chartMeasure] = 'desc';
  order['Products.classification'] = 'asc';

  return (
    <QueryRenderer
      query={{
        dimensions: ['Products.description', 'Products.classification'],
        measures: [chartMeasure],
        filters,
        order,
        segments,
      }}
      cubejsApi={cubejsApi}
      render={renderChart(barRender, {
        x: [],
        y: ['Locations.name', 'measures'],
        fillMissingDates: true,
        joinDateRange: false,
      })}
    />
  );
};

export default ChartRenderer;
