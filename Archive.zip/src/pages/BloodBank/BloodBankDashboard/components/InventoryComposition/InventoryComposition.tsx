import React, { useState } from 'react';
import { Pie } from '@ant-design/charts';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';

import { Spin } from 'antd';
import styles from './index.less';

const colors = {
  safeStock: '#27a29e',
  nearOos: '#E38F3C',
  oos: '#E33C3C',
  os: '#753BBD',
};

/* const data = [
  {
    type: 'Safe stock',
    value: 25,
  },
  {
    type: 'Near OOS',
    value: 20,
  },
  {
    type: 'OOS',
    value: 13,
  },
]; */

const InventoryCompositionPie: React.FC = (props) => {
  // ANT Chart
  const config = {
    renderer: 'svg',
    autoFit: true,
    appendPadding: 10,
    data: props.data,
    angleField: 'value',
    colorField: 'type',
    color: [colors.oos, colors.nearOos, colors.safeStock, colors.os],
    /* color: (type: string) => {
      if (type === 'Safe stock') return colors.safeStock;
      if (type === 'Near OOS') return colors.nearOos;
      if (type === 'OOS') return colors.oos;
    }, */
    radius: 1,
    innerRadius: 0.7,
    pieStyle: {
      stroke: 0,
    },
    label: {
      type: 'inner',
      offset: '-0.5',
      content: '{percentage}',
      style: {
        fill: '#fff',
        fontSize: 0,
        textAlign: 'center',
      },
    },
    legend: {
      layout: 'horizontal',
      position: 'bottom',
    },
    /* statistic: {
      title: false,
      content: { formatter: () => `${data.reduce((acc, cur) => acc + cur.value, 0)}` },
    }, */
    statistic: { title: false },
  };
  return <Pie className={styles.fixValue} {...config} />;
};

// CubeJS
const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint
const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

// CubeJS
const cubeQueryRender = (props) => {
  enum InventoryType {}
  // 'CentralBloodBankInventories.ssInventory' = 'Safe stock',
  // 'CentralBloodBankInventories.noosInventory' = 'Near OOS',
  // 'CentralBloodBankInventories.oosInventory' = 'OOS',
  // 'CentralBloodBankInventories.osInventory' = 'OS',

  InventoryType[`${props.labtype}.ssInventory`] = 'Safe stock';
  InventoryType[`${props.labtype}.noosInventory`] = 'Near OOS';
  InventoryType[`${props.labtype}.oosInventory`] = 'OOS';
  InventoryType[`${props.labtype}.osInventory`] = 'OS';

  let filters = [];

  if (props.location && props.location !== 'All locations') {
    filters = [{ dimension: 'Locations.name', operator: 'equals', values: [props.location] }];
  }
  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: [
        `${props.labtype}.oosInventory`,
        `${props.labtype}.noosInventory`,
        `${props.labtype}.ssInventory`,
        `${props.labtype}.osInventory`,
        `${props.labtype}.count`,
      ],
      timeDimensions: [],
      filters,
      order: {},
    },
    {
      cubejsApi,
    },
  );

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const dataSource = resultSet.tablePivot();

  const pieData = Object.keys(dataSource[0])
    .filter((type) => type !== `${props.labtype}.count`)
    .map((type) => {
      return {
        type: InventoryType[type],
        value: dataSource[0][type],
      };
    });

  return <InventoryCompositionPie data={pieData} />;
};

export default cubeQueryRender;
