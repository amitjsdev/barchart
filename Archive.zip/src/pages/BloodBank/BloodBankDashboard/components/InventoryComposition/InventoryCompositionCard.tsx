import React from 'react';

import { LabTypeMap } from '../../Constants';
import KpiCard from '../KpiCard/KpiCard';
import InventoryComposition from './InventoryComposition';

const InventoryCompositionCard: React.FC<BloodBank.InventoryCompositionCardProps> = (props) => {
  const { title, location, labType } = props;

  return (
    <KpiCard title={title}>
      <InventoryComposition location={location} labtype={LabTypeMap[labType]} />
    </KpiCard>
  );
};

export default InventoryCompositionCard;
