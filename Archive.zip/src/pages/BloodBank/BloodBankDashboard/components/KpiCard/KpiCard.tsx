import React from 'react';
import { Typography, Row, Col, Popover } from 'antd';
import { InfoCircleOutlined } from '@ant-design/icons';

import styles from './index.less';

const { Text } = Typography;

const KpiCard: React.FC<BloodBank.KpiCardProps> = (props) => {
  return (
    <div className={styles.kpiCard}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <div>
              <Text className={styles.chartTitle}>{props.title}</Text>
              {props.info ? (
                <Popover content={props.info} title="Info">
                  <InfoCircleOutlined style={{ padding: '8px' }} />
                </Popover>
              ) : null}
            </div>
          </Col>
          <Col flex={2} className={styles.filters}>
            <div></div>
          </Col>
        </Row>
      </div>
      <div className={styles.kpiCardContent}>{props.children}</div>
    </div>
  );
};

export default KpiCard;
