import React from 'react';
import { Cascader } from 'antd';

import { DEFAULT_LOCATION_KEY } from '../../Constants';

const LocationSelector: React.FC<BloodBank.LocationSelectorProps> = (props) => {

  const { regionsAndLabs, onLabChange, onRegionChange } = props;
  const onChange = (value) => {
    const [region, lab] = value;

    if (lab) {
      onLabChange(lab);
      onRegionChange(DEFAULT_LOCATION_KEY);
    } else {
      onLabChange(DEFAULT_LOCATION_KEY);
      onRegionChange(region);
    }
  };

  return (
    <Cascader
      allowClear={false}
      options={regionsAndLabs}
      onChange={(value) => onChange(value)}
      changeOnSelect
      defaultValue={[DEFAULT_LOCATION_KEY]}
      placeholder="Please select"
      displayRender={(value) => {
        const [region, lab] = value;
        return lab || region;
      }}
    />
  );
};

export default LocationSelector;
