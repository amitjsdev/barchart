import React from 'react';
import { Spin, Tooltip } from 'antd';
import { Gauge } from '@ant-design/charts';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';

import { getCubejsApiParams } from '@/services/cubejs';

import styles from './index.less';
import { REGION_FILTER_DIMENSION } from '../../Constants';
const gaugeData = {
  min: 15,
  max: 80,
  value: 61,
};

const gaugeColors = {
  safeStock: '#008755',
  nearOos: '#DC582A',
  oos: '#C8102E',
  other: '#753BBD',
};

const AvgDayStockGauge: React.FC = (props) => {
  const { value } = props;
  const config = {
    // renderer: 'svg',
    autoFit: true,
    // height: 200,
    min: gaugeData.min / 100,
    max: gaugeData.max / 100,
    percent: value / 100,

    range: {
      ticks: [0, 0.15, 0.3, 0.8, 1, 100],
      color: [
        gaugeColors.oos,
        gaugeColors.nearOos,
        gaugeColors.safeStock,
        gaugeColors.other,
        gaugeColors.other,
      ],
    },
    axis: {
      label: {
        formatter(v: string) {
          return Number(v) * 100;
        },
      },
    },
    statistic: {
      content: {
        formatter: ({ percent }) => `${Math.round(percent * 100)}`,
        style: {
          fill: '#ffffff',
          textAlign: 'center',
          fontWeight: 'bold',
          fontSize: '34px',
          opacity: 1,
        },
      },
    },
  };
  return <Gauge className={props.className} {...config} />;
};

const cubejsParams = getCubejsApiParams();

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

// CubeJS
const cubeQueryRender = (props) => {
  const { labType, region, location } = props;
  let filters: any[] = [];

  if (location && location !== 'All locations') {
    filters = [{ dimension: 'Locations.name', operator: 'equals', values: [props.location] }];
  }

  if (region && region !== 'All locations') {
    filters = [{ dimension: REGION_FILTER_DIMENSION, operator: 'equals', values: [props.region] }];
  }

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: [`${labType}.consumableDays`],
      filters,
    },
    {
      cubejsApi,
    },
  );

  if (isLoading || location === '') {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const dataSource = resultSet.tablePivot();

  const cssClasses = `${styles.fixValue} ${styles.fixAxisLine} ${styles.fixGridLines}`;

  const value: number = dataSource[0][`${labType}.consumableDays`];
  const roundedValue: number = Math.round(value);

  return (
    <>
      <AvgDayStockGauge className={cssClasses} value={roundedValue} />

      <ul className={styles.guageLegends}>
        <li className={styles.red}>OOS</li>
        <li className={styles.orange}>Near OOS</li>
        <li className={styles.green}>Safe Stock</li>
        <li className={styles.purple}>Other</li>
      </ul>
    </>
  );
};

export default cubeQueryRender;
