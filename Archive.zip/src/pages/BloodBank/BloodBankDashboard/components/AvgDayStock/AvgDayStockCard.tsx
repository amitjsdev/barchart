import React from 'react';

import { LabTypeMap } from '../../Constants';
import KpiCard from '../KpiCard/KpiCard';
import AvgDayStock from './AvgDayStock';
import styles from './index.less'

const infoTooltip = (
  <div>
    <p>
      <b>&lt; 15:</b> OOS
    </p>
    <p>
      <b>15-30:</b> NOOS,
    </p>
    <p>
      <b>30-80:</b> SS,
    </p>
    <p>
      <b>&gt; 80:</b> OS
    </p>
  </div>
);

const AvgDayStockCard: React.FC<BloodBank.KpiCardProps> = (props) => {
  const { location, labType, title, region } = props;
  return (
    <div className={styles.kpiCard} >
    <KpiCard  title={title} info={infoTooltip}>
      <AvgDayStock location={location} region={region} labType={LabTypeMap[labType]} />
    </KpiCard>
    </div>
  );
};

export default AvgDayStockCard;
