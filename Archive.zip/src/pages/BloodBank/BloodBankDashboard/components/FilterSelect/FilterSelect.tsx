import React from 'react';
import { Select } from 'antd';

const FilterSelect: React.FC<BloodBank.FilterSelectProps> = (props) => {
  return (
    <Select
      style={{ width: props.width || '120px' }}
      defaultValue={props.options[0]?.value}
      onChange={props.onChange}
    >
      {props.options.map((option: any) => (
        <Select.Option key={option.value} value={option.value}>
          {option.label}
        </Select.Option>
      ))}
    </Select>
  );
};

export default FilterSelect;
