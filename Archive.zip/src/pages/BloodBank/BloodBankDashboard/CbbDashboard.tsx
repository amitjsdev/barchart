import React, { useState } from 'react';
import { Row, Col } from 'antd';

import {
  PRODUCT_TYPES,
  DAYS_TO_OOS_FILTER_OPTIONS,
  KpiTitles,
  ChartTitles,
  ProductTypeNames,
} from './Constants';

import DashboardContainer from './components/DashboardContainer/DashboardContainer';
import KpiStatisticsCard from './components/KpiStatisticsCard/KpiStatisticsCard';
import FilterSelect from './components/FilterSelect/FilterSelect';
import TotalSerologyTestsStatistics from './components/TotalSerologyTestsStatistics';
import TotalNatTestsStatistics from './components/TotalNatTestsStatistics';
import AvgServiceTat from './components/AvgServiceTat';
import AvgDayStockCard from './components/AvgDayStock/AvgDayStockCard';
import AverageConsumableDaysChart from './components/AverageConsumableDaysChart/AverageConsumableDaysChart';
import CategoryStockChart from './components/StockChart/CategoryStockChart';
import DailyTestsChart from './components/DailyTests/DailyTestsChart';
import OutOfStockChart from './components/OutOfStockChart/OutOfStockChart';
import InventoryUpdateChart from './components/ResponseChart/InventoryUpdateChart';

import styles from './index.less';
import StatusFilterCard from './components/StatusFilter/StatusFilterCard';

const Dashboard: React.FC<BloodBank.BasicDashboardProps> = (props) => {
  const { currentLab, currentRegion, dateRangeFilter, totalLabCount, regionsName, labType } = props;
  const categoryStockChartFilterOptions = PRODUCT_TYPES.map((product) => ({
    label: ProductTypeNames[product],
    value: product,
  }));

  const [categoryStockFilter, setCategoryStockFilter] = useState(
    categoryStockChartFilterOptions[0].value,
  );

  const daysToOosChartFilterOptions = DAYS_TO_OOS_FILTER_OPTIONS.map((option) => ({
    label: option,
    value: option,
  }));

  const [daysToOosChartFilter, setDaysToOosChartFilter] = useState(
    daysToOosChartFilterOptions[0].value,
  );

  const avgStockDaysChartFilterOptions = DAYS_TO_OOS_FILTER_OPTIONS.map((option) => ({
    label: option,
    value: option,
  }));

  const [avgStockDaysChartFilter, setAvgStockDaysChartFilter] = useState(
    avgStockDaysChartFilterOptions[0].value,
  );

  return (
    <div className={styles.main}>
      {/* Row 1 */}
      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <KpiStatisticsCard title={KpiTitles.TOTAL_SEROLOGY_TESTS}>
            <TotalSerologyTestsStatistics
              location={currentLab}
              region={currentRegion}
              dateRangeFilter={dateRangeFilter}
              labType={labType}
            />
          </KpiStatisticsCard>
        </Col>
        <Col flex={1}>
          <KpiStatisticsCard title={KpiTitles.TOTAL_NAT_TESTS}>
            <TotalNatTestsStatistics
              location={currentLab}
              region={currentRegion}
              dateRangeFilter={dateRangeFilter}
              labType={labType}
            />
          </KpiStatisticsCard>
        </Col>

        <Col flex={1}>
          <KpiStatisticsCard title={KpiTitles.AVG_SERVICE_TATS}>
            <AvgServiceTat
              location={currentLab}
              region={currentRegion}
              dateRangeFilter={dateRangeFilter}
              labType={labType}
            />
          </KpiStatisticsCard>
        </Col>
      </Row>
      {/* Row 2 */}

      <Row gutter={[24, 24]}>
        <Col span={12}>
          <AvgDayStockCard
            title={ChartTitles.AVG_DAY_STOCK}
            location={currentLab}
            region={currentRegion}
            labType={labType}
          />
        </Col>
        <Col span={12}>
          <StatusFilterCard
            title={ChartTitles.STATUS_FILTER}
            location={currentLab}
            region={currentRegion}
            labType={labType}
          />
        </Col>
      </Row>

      {/* Row 3 */}

      <Row gutter={[24, 24]}>
        <Col span={24}>
          <AverageConsumableDaysChart
            title={ChartTitles.AVG_STOCK_DAYS}
            region={currentRegion}
            location={currentLab}
            labType={labType}
            daysFilter={avgStockDaysChartFilter}
          >
            <FilterSelect
              width="180px"
              options={avgStockDaysChartFilterOptions}
              onChange={setAvgStockDaysChartFilter}
            />
          </AverageConsumableDaysChart>
        </Col>
      </Row>
      {/* Row 4 */}
      <Row gutter={[24, 24]}>
        <Col span={12}>
          <CategoryStockChart
            title={ChartTitles.STOCK_CHART}
            location={currentLab}
            region={currentRegion}
            labType={labType}
            category={categoryStockFilter}
          >
            <FilterSelect
              options={categoryStockChartFilterOptions}
              onChange={setCategoryStockFilter}
            />
          </CategoryStockChart>
        </Col>
        <Col span={12}>
          <DailyTestsChart
            title={ChartTitles.DAILY_TESTS}
            location={currentLab}
            region={currentRegion}
            labType={labType}
            dateRangeFilter={dateRangeFilter}
          />
        </Col>
      </Row>
      {/* Row 5 */}
      <Row gutter={[24, 24]}>
        <Col span={12}>
          <OutOfStockChart
            title={ChartTitles.OOS_CHART}
            location={currentLab}
            region={currentRegion}
            labType={labType}
            daysFilter={daysToOosChartFilter}
          >
            <FilterSelect
              width="180px"
              options={daysToOosChartFilterOptions}
              onChange={setDaysToOosChartFilter}
            />
          </OutOfStockChart>
        </Col>
        <Col span={12}>
          <InventoryUpdateChart
            title={ChartTitles.INVENTORY_UPDATE}
            labType={labType}
            dateRangeFilter={dateRangeFilter}
            totalLabs={totalLabCount}
          />
        </Col>
      </Row>
    </div>
  );
};

const CbbDashboard: React.FC<{}> = (props) => {
  return (
    <DashboardContainer>
      <Dashboard />
    </DashboardContainer>
  );
};

export default CbbDashboard;
