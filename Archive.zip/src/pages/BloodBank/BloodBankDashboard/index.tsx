import React, { useState, useEffect } from 'react';
import { Typography, List, Divider, Row, Col, Spin, Card, Select, Popover } from 'antd';
import { InfoCircleOutlined } from '@ant-design/icons';
import moment from 'moment';

import { LabTypes } from '@/services/Constants';
import { useAccess, useHistory, useModel } from 'umi';
import LocationSelector from './components/LocationSelector/LocationSelector';
import AverageConsumableDays from './components/AverageConsumableDaysChart/AverageConsumableDays';

import AvgDayStock from './components/AvgDayStock/AvgDayStock';
import InventoryComposition from './components/InventoryComposition/InventoryComposition';
import StockChart from './components/StockChart/StockChart';
import OutOfStockChart from './components/OutOfStockChart/OutOfStock';
import DailyTests from './components/DailyTests/DailyTests';
import ResponseChart from './components/ResponseChart/ResponseChart';
import TotalSerologyTestsStatistics from './components/TotalSerologyTestsStatistics';
import TotalNatTestsStatistics from './components/TotalNatTestsStatistics';
import DailyTestsStatistics from './components/DailyTestStatistics';

import DateFilter from './components/DateFilter/DateFilter';

import bloodBankService from '../services/bloodBank.service';
import {
  ProductTypeNames,
  PRODUCT_TYPES,
  BBBPRODUCT_TYPES,
  DAYS_TO_OOS_FILTER_OPTIONS,
} from './Constants';
import styles from './index.less';

const { Title, Text } = Typography;
const DATE_FORMAT = 'YYYY-MM-DD';

const labTypeKey = {
  branchbloodbank: 'BranchBloodBankInventories',
  centralbloodbank: 'CentralBloodBankInventories',
  peripheralbloodbank: 'PeripheralBloodBankInventories',
};
interface IKpiCardProps {
  title: string;
  info?: string;
  filters?: any;
  children?: React.ReactNode;
  location?: string;
}

interface IKpiStatisticsCardProps {
  title: string;
  info?: string;
  value: string;
  children?: React.ReactNode;
}

const chartTitles = {
  AVG_DAY_STOCK: 'Average day stock',
  INVENTORY_COMPOSITION: 'Inventory composition',
  AVG_STOCK_DAYS: 'Average stock days',
  STOCK_CHART: 'Stock chart',
  OOS_CHART: 'Days to OOS',
  DAILY_TESTS: 'Daily tests',
  INVENTORY_UPDATE: 'Responses',
};

const kpiTitles = {
  TOTAL_SEROLOGY_TESTS: 'Total serology tests',
  TOTAL_NAT_TESTS: 'Total NAT tests',
};

const avgConsumableDaysFilters = {
  name: 'Category filter',
  onChange: (option: string) => {
    avgConsumableDaysFilters[0] = {
      ...avgConsumableDaysFilters,
      selectedOption: [option],
    };
  },
  options: [],
  selectedOption: '',
};

let cbbCategoryStockChartFilters = {
  name: 'Category filter',
  options: PRODUCT_TYPES.map((product) => ({
    label: ProductTypeNames[product],
    value: product,
  })),
  onChange: (option: string) => {
    cbbCategoryStockChartFilters = {
      ...cbbCategoryStockChartFilters,
      selectedOption: option,
    };
  },
  selectedOption: PRODUCT_TYPES[0],
};

let pbbAndBbbCategoryStockChartFilters = {
  name: 'Category filter',
  options: BBBPRODUCT_TYPES.map((product: any) => ({
    label: ProductTypeNames[product],
    value: product,
  })),
  onChange: (option: string) => {
    pbbAndBbbCategoryStockChartFilters = {
      ...pbbAndBbbCategoryStockChartFilters,
      selectedOption: option,
    };
  },
  selectedOption: PRODUCT_TYPES[0],
};

const getCategoryStockChartFilters = (labType: App.LabType) => {
  return labType === LabTypes.CBB
    ? cbbCategoryStockChartFilters
    : pbbAndBbbCategoryStockChartFilters;
};

let daysToOosChartFilters = {
  name: 'Days filter',
  options: DAYS_TO_OOS_FILTER_OPTIONS.map((option) => ({ label: option, value: option })),
  onChange: (option: string) => {
    daysToOosChartFilters = {
      ...daysToOosChartFilters,
      selectedOption: option,
    };
  },
  selectedOption: DAYS_TO_OOS_FILTER_OPTIONS[0],
};

const FilterSelect: React.FC<{}> = (props: any) => {
  return (
    <Select
      style={{ width: '120px' }}
      defaultValue={props?.filter?.options[0]?.value}
      onChange={props.onChange}
    >
      {props.filter.options.map((option: any) => (
        <Select.Option key={option.value} value={option.value}>
          {option.label}
        </Select.Option>
      ))}
    </Select>
  );
};

// KPI card
const KpiCard: React.FC<IKpiCardProps> = (props) => {
  return (
    <div className={styles.kpiCard}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <div>
              <Text className={styles.chartTitle}>{props.title}</Text>
              {props.info ? (
                <Popover content={props.info} title="Info">
                  <InfoCircleOutlined style={{ padding: '8px' }} />
                </Popover>
              ) : null}
            </div>
          </Col>
          <Col flex={2} className={styles.filters}>
            <div>
              {props.filters?.map((filter) => (
                <FilterSelect filter={filter} />
              ))}
            </div>
          </Col>
        </Row>
      </div>
      <div className={styles.kpiCardContent}>{props.children}</div>
    </div>
  );
};

// KPI statistics card
const KpiStatisticsCard: React.FC<IKpiStatisticsCardProps> = (props) => (
  <div className={styles.kpiStatisticsCard}>
    <div className={styles.kpiCardTitleBar}>
      <div>
        <Text className={styles.chartTitle}>{props.title}</Text>
        {props.info ? (
          <Popover content={props.info} title="Info">
            <InfoCircleOutlined style={{ padding: '8px' }} />
          </Popover>
        ) : null}
      </div>
    </div>
    <div className={styles.kpiStatisticsCardContent}>
      {/* <div>
        <Title level={3}>{props.value}</Title>
      </div> */}
      {props.children}
    </div>
  </div>
);

// KPI statistics card

// KPI card
const AverageConsumableDaysChart: React.FC<IKpiCardProps> = (props) => {
  const { labtype } = props;
  const filter = {
    ...props.filters,
    options: props.regions.map((value) => {
      return { label: value, value };
    }),
  };

  // const chartDimension = avgConsumableDaysFilters[0].selectedOption;
  const [chartDimension, setChartDimension] = useState(['Riyadh']);
  // const [chartDimension, setChartDimension] = useState(avgConsumableDaysFilters[0]?.selectedOption);
  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;
  // const filter = {
  //   ...props.filters,
  //   options: props.regions.map((value) => {
  //
  //     return { 'label': value, 'value': value };
  //   }),
  // };
  return (
    <div className={styles.kpiCard}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{props.title}</Text>
          </Col>
          <Col flex={2} className={styles.filters}>
            {labtype === LabTypes.CBB ? (
              ''
            ) : (
              <div>
                <FilterSelect
                  filter={filter}
                  onChange={(val) => {
                    setChartDimension([val]);
                  }}
                />
              </div>
            )}
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <AverageConsumableDays
          dimensions={chartDimension}
          labtype={labTypeKey[labtype]}
          location={props.location}
        />
      </div>
    </div>
  );
};

const CategoryStockChart: React.FC<IKpiCardProps> = (props) => {
  const { location, labtype } = props;
  const [categoryFilter, setCategoryFilter] = useState(
    getCategoryStockChartFilters(labtype).selectedOption,
  );

  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels} ${styles.heatMapContent} `;
  return (
    <div className={`${styles.kpiCard}`}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }} align="middle" justify="space-between">
          <Col>
            <Text className={styles.chartTitle}>{props.title}</Text>
          </Col>
          <Col className={styles.filters} style={{ width: '250px' }}>
            {labtype === LabTypes.PBB ? (
              ''
            ) : (
              <div className={styles.dropdownWidth}>
                <FilterSelect
                  filter={getCategoryStockChartFilters(labtype)}
                  onChange={(val) => {
                    setCategoryFilter(val);
                  }}
                />
              </div>
            )}
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        {labtype === LabTypes.PBB ? (
          <StockChart location={location} category="Phenotyping" labtype={labTypeKey[labtype]} />
        ) : (
          <StockChart location={location} category={categoryFilter} labtype={labTypeKey[labtype]} />
        )}
      </div>
    </div>
  );
};

const OosChart: React.FC<IKpiCardProps> = (props) => {
  const { location, labtype, filter } = props;
  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;
  const [daysFilter, setDaysFilter] = useState(filter.selectedOption);

  return (
    <div className={styles.kpiCard}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{props.title}</Text>
          </Col>
          <Col flex={2} className={styles.filters}>
            <div>
              <FilterSelect
                filter={filter}
                onChange={(val) => {
                  setDaysFilter(val);
                }}
              />
            </div>
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <OutOfStockChart location={location} labtype={labTypeKey[labtype]} filter={daysFilter} />
      </div>
    </div>
  );
};

const DailyTestsChart: React.FC<{}> = (props) => {
  const { location, labtype, dateRangeFilter } = props;
  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;

  return (
    <div className={styles.kpiCard}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{props.title}</Text>
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <DailyTests
          location={location}
          labtype={labtype}
          dateRangeFilter={dateRangeFilter}
          labtype={labtype}
        />
      </div>
    </div>
  );
};

const InventoryUpdateChart: React.FC<{}> = (props) => {
  const { location, labtype, dateRangeFilter, locationlength } = props;
  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;

  return (
    <div className={styles.kpiCard}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{props.title}</Text>
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <ResponseChart
          labtype={labtype}
          dateRangeFilter={dateRangeFilter}
          labtype={labtype}
          locLength={locationlength}
        />
      </div>
    </div>
  );
};

const Dashboard: React.FC<any> = (props) => {
  const { bloodBankLabType } = props;
  const [selectedLocation, setLocation] = useState('');
  const [labNames, setLabNames] = useState(['All locations']);
  const [regionsName, setRegionsNames] = useState(['Riyadh']);
  const [loading, setLoading] = useState<boolean>(true);
  const [locLength, setLocLength] = useState(0);
  const [labDropdowns, setLabDropdowns] = useState([
    { value: 'All locations', label: 'All locations' },
  ]);

  const defaultFilterSetting = {
    granularity: 'day',
    dateRange: [moment().format(DATE_FORMAT), moment().format(DATE_FORMAT)],
  };
  const [dateRangeFilter, setDateRangeFilter] = useState(defaultFilterSetting);

  const onDateChange = (filter) => {
    setDateRangeFilter({
      granularity: dateRangeFilter.granularity,
      dateRange: [
        filter ? filter[0].format(DATE_FORMAT) : moment().format(DATE_FORMAT),
        filter ? filter[1].format(DATE_FORMAT) : moment().format(DATE_FORMAT),
      ],
    });
  };

  const locDropdown: {} = {};

  useEffect(() => {
    bloodBankService.getLocationsByLabType(bloodBankLabType).then((locations: any) => {
      setLocLength(locations.length);
      const lab_Name = locations.map((lab: any) => {
        if (lab.region in locDropdown) {
          locDropdown[lab.region].push(lab.name);
        } else {
          locDropdown[lab.region] = [lab.name];
        }
      });
      const arr: any[] = [];
      Object.entries(locDropdown).map((entry) => {
        
        const temp = entry[1].map((data) => ({
          value: data,
          label: data,
        }));
        if(entry[0]!=="null"){
        arr.push({
          value: entry[0],
          label: entry[0],
          children: temp,
        });
      }
      });

      setLabDropdowns(labDropdowns.concat(arr));
      setLabNames(labNames.concat(lab_Name));
      bloodBankService.getRegionsByLabType(bloodBankLabType).then((region) => {
        const regionNames = region.map(({ name }) => name);
        // setRegionsNames(regionsName.concat(regionNames));
        setRegionsNames(regionNames);
      });
    });
    setTimeout(() => {
      setLoading(false);
      setLocation('All locations');
    }, 1000);
  }, []);

  return bloodBankLabType === LabTypes.CBB ? (
    <div className={styles.main}>
      <Spin spinning={loading} size="large" />
      <Row className={styles.locationPanel} align="middle" justify="space-between">
        <Col>
          <Title level={4}>Dashboard</Title>
        </Col>
        <Col>
          <Row gutter={[24, 24]} align="middle" style={{ margin: '0px' }}>
            <Col>
              <LocationSelector
                onChange={setLocation}
                locations={labNames}
                locDrop={labDropdowns}
              />
            </Col>
            <Col>
              <DateFilter onDateChange={onDateChange} />
            </Col>
          </Row>
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col span={8}>
          <Row gutter={[24, 24]}>
            <Col flex={1}>
              <KpiStatisticsCard title={kpiTitles.TOTAL_SEROLOGY_TESTS}>
                <TotalSerologyTestsStatistics
                  location={selectedLocation}
                  dateRangeFilter={dateRangeFilter}
                  labtype={bloodBankLabType}
                />
              </KpiStatisticsCard>
            </Col>
          </Row>
          <Row gutter={[24, 24]}>
            <Col flex={1}>
              <KpiStatisticsCard title={kpiTitles.TOTAL_NAT_TESTS}>
                <TotalNatTestsStatistics
                  location={selectedLocation}
                  dateRangeFilter={dateRangeFilter}
                  labtype={bloodBankLabType}
                />
              </KpiStatisticsCard>
            </Col>
          </Row>
        </Col>
        <Col span={8}>
          <KpiCard
            title={chartTitles.AVG_DAY_STOCK}
            info={() => (
              <div>
                <p>
                  <b>&lt; 15:</b> OOS
                </p>
                <p>
                  <b>15-30:</b> NOOS,
                </p>
                <p>
                  <b>30-80:</b> SS,
                </p>
                <p>
                  <b>&gt; 80:</b> OS
                </p>
              </div>
            )}
          >
            <AvgDayStock location={selectedLocation} labtype={labTypeKey[bloodBankLabType]} />
          </KpiCard>
        </Col>
        <Col span={8}>
          <KpiCard title={chartTitles.INVENTORY_COMPOSITION}>
            <InventoryComposition
              location={selectedLocation}
              labtype={labTypeKey[bloodBankLabType]}
            />
          </KpiCard>
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col span={24}>
          <AverageConsumableDaysChart
            title={chartTitles.AVG_STOCK_DAYS}
            filters={avgConsumableDaysFilters}
            location={selectedLocation}
            regions={regionsName}
            labtype={bloodBankLabType}
          />
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col span={12}>
          <CategoryStockChart
            location={selectedLocation}
            title={chartTitles.STOCK_CHART}
            labtype={bloodBankLabType}
          />
        </Col>
        <Col span={12}>
          <DailyTestsChart
            location={selectedLocation}
            dateRangeFilter={dateRangeFilter}
            labtype={bloodBankLabType}
            title={chartTitles.DAILY_TESTS}
          />
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col span={12}>
          <OosChart
            filter={daysToOosChartFilters}
            location={selectedLocation}
            title={chartTitles.OOS_CHART}
            labtype={bloodBankLabType}
          />
        </Col>
        <Col span={12}>
          <InventoryUpdateChart
            labtype={bloodBankLabType}
            dateRangeFilter={dateRangeFilter}
            title={chartTitles.INVENTORY_UPDATE}
            locationlength={locLength}
          />
        </Col>
      </Row>
    </div>
  ) : bloodBankLabType === LabTypes.BBB ? (
    <div className={styles.main}>
      <Spin spinning={loading} size="large" />
      <Row className={styles.locationPanel} align="middle" justify="space-between">
        <Col>
          <Title level={4}>Dashboard</Title>
        </Col>
        <Col>
          <Row gutter={[24, 24]} align="middle" style={{ margin: '0px' }}>
            <Col>
              <LocationSelector
                onChange={setLocation}
                locations={labNames}
                locDrop={labDropdowns}
              />
            </Col>
            <Col>
              <DateFilter onDateChange={onDateChange} />
            </Col>
          </Row>
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col span={12}>
          <KpiCard
            title={chartTitles.AVG_DAY_STOCK}
            info={() => (
              <div>
                <p>
                  <b>&lt; 15:</b> OOS
                </p>
                <p>
                  <b>15-30:</b> NOOS,
                </p>
                <p>
                  <b>30-80:</b> SS,
                </p>
                <p>
                  <b>&gt; 80:</b> OS
                </p>
              </div>
            )}
          >
            <AvgDayStock location={selectedLocation} labtype={labTypeKey[bloodBankLabType]} />
          </KpiCard>
        </Col>
        <Col span={12}>
          <KpiCard title={chartTitles.INVENTORY_COMPOSITION}>
            <InventoryComposition
              location={selectedLocation}
              labtype={labTypeKey[bloodBankLabType]}
            />
          </KpiCard>
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col span={24}>
          <AverageConsumableDaysChart
            title={chartTitles.AVG_STOCK_DAYS}
            filters={avgConsumableDaysFilters}
            location={selectedLocation}
            regions={regionsName}
            labtype={bloodBankLabType}
          />
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col span={12}>
          <CategoryStockChart
            location={selectedLocation}
            title={chartTitles.STOCK_CHART}
            labtype={bloodBankLabType}
          />
        </Col>
        <Col span={12}>
          <DailyTestsChart
            location={selectedLocation}
            dateRangeFilter={dateRangeFilter}
            labtype={bloodBankLabType}
            title={chartTitles.DAILY_TESTS}
          />
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col span={12}>
          <OosChart
            filter={daysToOosChartFilters}
            location={selectedLocation}
            title={chartTitles.OOS_CHART}
            labtype={bloodBankLabType}
          />
        </Col>
        <Col span={12}>
          <InventoryUpdateChart
            labtype={bloodBankLabType}
            dateRangeFilter={dateRangeFilter}
            title={chartTitles.INVENTORY_UPDATE}
            locationlength={locLength}
          />
        </Col>
      </Row>
    </div>
  ) : (
    <div className={styles.main}>
      <Spin spinning={loading} size="large" />
      <Row className={styles.locationPanel} align="middle" justify="space-between">
        <Col>
          <Title level={4}>Dashboard</Title>
        </Col>
        <Col>
          <Row gutter={[24, 24]} align="middle" style={{ margin: '0px' }}>
            <Col>
              <LocationSelector
                onChange={setLocation}
                locations={labNames}
                locDrop={labDropdowns}
              />
            </Col>
            <Col>
              <DateFilter onDateChange={onDateChange} />
            </Col>
          </Row>
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col span={8}>
          <KpiCard title={chartTitles.DAILY_TESTS}>
            <DailyTestsStatistics
              location={selectedLocation}
              dateRangeFilter={dateRangeFilter}
              labtype={bloodBankLabType}
            />
          </KpiCard>
        </Col>
        <Col span={8}>
          <KpiCard
            title={chartTitles.AVG_DAY_STOCK}
            info={() => (
              <div>
                <p>
                  <b>&lt; 15:</b> OOS
                </p>
                <p>
                  <b>15-30:</b> NOOS,
                </p>
                <p>
                  <b>30-80:</b> SS,
                </p>
                <p>
                  <b>&gt; 80:</b> OS
                </p>
              </div>
            )}
          >
            <AvgDayStock location={selectedLocation} labtype={labTypeKey[bloodBankLabType]} />
          </KpiCard>
        </Col>
        <Col span={8}>
          <KpiCard title={chartTitles.INVENTORY_COMPOSITION}>
            <InventoryComposition
              location={selectedLocation}
              labtype={labTypeKey[bloodBankLabType]}
            />
          </KpiCard>
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col span={24}>
          <AverageConsumableDaysChart
            title={chartTitles.AVG_STOCK_DAYS}
            filters={avgConsumableDaysFilters}
            regions={regionsName}
            location={selectedLocation}
            labtype={bloodBankLabType}
          />
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col span={12}>
          <CategoryStockChart
            location={selectedLocation}
            title={chartTitles.STOCK_CHART}
            labtype={bloodBankLabType}
          />
        </Col>
        <Col span={12}>
          <InventoryUpdateChart
            labtype={bloodBankLabType}
            dateRangeFilter={dateRangeFilter}
            title={chartTitles.INVENTORY_UPDATE}
            locationlength={locLength}
          />
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col span={24}>
          <OosChart
            filter={daysToOosChartFilters}
            location={selectedLocation}
            title={chartTitles.OOS_CHART}
            labtype={bloodBankLabType}
          />
        </Col>
      </Row>
    </div>
  );
};

const DashboardWrapper: React.FC<any> = (props) => {
  const { initialState, loading } = useModel('@@initialState');
  const access = useAccess();
  const history = useHistory();
  const bloodBankLabType = bloodBankService.getLabTypeFromUrlFragment(history.location.pathname);

  return loading ? (
    <Spin />
  ) : (
    <Dashboard
      {...props}
      currentUser={initialState?.currentUser}
      access={access}
      bloodBankLabType={bloodBankLabType}
    />
  );
};

export default DashboardWrapper;
