enum ProductTypeNames {
  'Phenotyping' = 'Phenotyping',
  'Serology' = 'Serology',
  'NAT' = 'NAT',
  'Donation bags & Plasma' = 'Donation',
  'Bacterial Detection' = 'Bacterial Detection',
}

const PRODUCT_TYPES = [
  'Phenotyping',
  'Serology',
  'NAT',
  'Donation bags & Plasma',
  'Bacterial Detection',
];

const BBBPRODUCT_TYPES = ['Phenotyping', 'Donation bags & Plasma', 'Bacterial Detection'];

enum DaysToOosFilters {
  LESS_THAN_FIFTEEN_DAYS = '< 15 days (OOS)',
  FIFTEEN_TO_THIRTY_DAYS = '15 - 30 days (NOOS)',
  THIRTY_TO_EIGHTY_DAYS = '30 - 80 days (Safe stock)',
  MORE_THAN_EIGHTY_DAYS = '> 80 days (OS)',
}

const DAYS_TO_OOS_FILTER_OPTIONS = [
  DaysToOosFilters.LESS_THAN_FIFTEEN_DAYS,
  DaysToOosFilters.FIFTEEN_TO_THIRTY_DAYS,
  DaysToOosFilters.THIRTY_TO_EIGHTY_DAYS,
  DaysToOosFilters.MORE_THAN_EIGHTY_DAYS,
];

enum ChartTitles {
  AVG_DAY_STOCK = 'Average day stock',
  INVENTORY_COMPOSITION = 'Inventory composition',
  AVG_STOCK_DAYS = 'Average stock days',
  STOCK_CHART = 'Stock chart',
  OOS_CHART = 'Days to OOS',
  DAILY_TESTS = 'Daily tests',
  INVENTORY_UPDATE = 'Responses',
  STATUS_FILTER= 'Instrument Status'
}

enum KpiTitles {
  TOTAL_SEROLOGY_TESTS = 'Total serology tests',
  TOTAL_NAT_TESTS = 'Total NAT tests',
  AVG_SERVICE_TATS = 'Average Service Tat'
}

enum LabTypeMap {
  'branchbloodbank' = 'BranchBloodBankInventories',
  'centralbloodbank' = 'CentralBloodBankInventories',
  'peripheralbloodbank' = 'PeripheralBloodBankInventories',
}

const DATE_FORMAT = 'YYYY-MM-DD';
const DEFAULT_LOCATION_KEY = 'All locations';
const REGION_FILTER_DIMENSION = 'IRegions.name';

export {
  ProductTypeNames,
  DaysToOosFilters,
  ChartTitles,
  KpiTitles,
  LabTypeMap,
  PRODUCT_TYPES,
  BBBPRODUCT_TYPES,
  DAYS_TO_OOS_FILTER_OPTIONS,
  DATE_FORMAT,
  DEFAULT_LOCATION_KEY,
  REGION_FILTER_DIMENSION,
};
