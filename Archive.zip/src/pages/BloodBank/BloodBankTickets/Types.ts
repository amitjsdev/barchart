interface ITicket {
  id: number;
  type: TicketType;
  status: TicketStatus;
  priority: TicketPriority;
  duration: number;
  resolvedBy: any;
  dueDate: any;
  productId: number;
  productCode: string;
  productDescription: string;
  inventoryId: string;
  locationId: number;
  locationCode: string;
  createdAt: string;
  updatedAt: string;
}

type TicketType =
  | 'near_fourteen_days'
  | 'above_fifteen_days'
  | 'above_eighty_days'
  | 'near_full_capacity'
  | 'not_completed_po'
  | 'near_expiry'
  | 'out_of_stock';

type TicketStatus = 'created' | 'completed';

type TicketPriority = 'low' | 'medium' | 'high' | 'critical';

enum TicketTypeNames {
  'near_fourteen_days' = 'Nearly Out of Stock',
  'above_fifteen_days' = '15-30 days Stock',
  'above_eighty_days' = 'Over Stock',
  'near_full_capacity' = 'Lab Capacity Limit Reached',
  'not_completed_po' = 'Item Delivery Pending',
  // 'near_expiry' = 'Reagent Nearing Expiry',
  'out_of_stock' = 'Out of Stock',
}

enum PriorityColors {
  'low' = 'green',
  'medium' = 'gold',
  'high' = 'volcano',
  'critical' = 'red',
}

export { ITicket, TicketType, TicketStatus, TicketPriority, TicketTypeNames, PriorityColors };
