import React, { Component, useState, useEffect, useRef } from 'react';
import { connect, useAccess, useHistory, useModel } from 'umi';
import { Spin, Tabs, Tooltip, Row, Col } from 'antd';

import BloodBankTicketsTable from './components/BloodBankTicketsTable/BloodBankTicketsTable';
import bloodBankService from '../services/bloodBank.service';

import styles from './index.less';

const { TabPane } = Tabs;

const TicketsListContianer = (props) => {
  const {
    tickets,
    userLocationId,
    userLocation,
    locationKeys,
    onChangeTab,
    currentLocationId,
    onUpdate,
    labType,
  } = props;
  const [height, setHeight] = useState(0);
  const ref = useRef(null);

  useEffect(() => {
    setHeight(ref.current.clientHeight);
  });

  const onChange = (activeKey) => {
    onChangeTab(activeKey);
  };

  return (
    <div className={styles.main}>
      <div className={styles.container}>
        <Row gutter={[24, 24]}>
          <Col>
            <div ref={ref} className={styles.tableContainer}>
              <Tabs activeKey={locationKeys[currentLocationId]} onChange={onChange}>
                {Object.keys(tickets)
                  ?.map((locationKey) => tickets[locationKey])
                  .map((location) => {
                    const key = locationKeys[location.locationDetails.id];
                    return (
                      <TabPane
                        key={key}
                        tab={
                          <Tooltip title={location.locationDetails.name}>
                            {location.locationDetails.code}
                          </Tooltip>
                        }
                      >
                        <BloodBankTicketsTable
                          tickets={location.tickets}
                          tableHeight={height}
                          onUpdate={onUpdate}
                          labType={labType}
                        />
                      </TabPane>
                    );
                  })}
              </Tabs>
            </div>
          </Col>
        </Row>
      </div>
    </div>
  );
};

class BloodBankTickets extends Component {
  constructor(props) {
    super(props);

    const { currentUser }: App.InitialStateType = props;
    const bloodBankProfile = currentUser?.modules.find(
      (module) => module.name === this.props.labType,
    );
    const userLocationId = bloodBankProfile?.locationId;

    this.state = {
      userLocationId,
      userLocation: '',
      currentLocationId: userLocationId,
      locationKeys: null,
      isLoading: true,
    };

    this.onChangeTab = this.onChangeTab.bind(this);
  }

  async componentDidMount() {
    const { dispatch, labType } = this.props;
    const allLocations = await bloodBankService.getLocationsByLabType(labType);

    const locationKeys = {};
    allLocations.forEach((location: any) => {
      locationKeys[location.id] = location.code;
    });

    this.setState({
      locationKeys,
      userLocation: locationKeys[allLocations[0].id],
      currentLocationId: allLocations[0].id,
      userLocationId: allLocations[0].id,
    });

    dispatch({
      type: 'blood_bankTickets/initTickets',
      payload: {
        allLocations,
        userLocation: this.state.userLocation,
        locationId: this.state.userLocationId,
        labType,
      },
    });

    this.setState({ isLoading: false });
  }

  onChangeTab(activeKey) {
    this.fetchTicketsByLocation(activeKey);
  }

  getLocationId(locationKey: string) {
    const { locationKeys } = this.state;
    return Object.keys(locationKeys).find((key) => locationKeys[key] === locationKey);
  }

  fetchTicketsByLocation(locationKey) {
    const { dispatch, labType } = this.props;
    const locationId = this.getLocationId(locationKey);

    this.setState({
      currentLocationId: locationId,
    });
    dispatch({
      type: 'blood_bankTickets/fetchTicketsByLocation',
      payload: {
        locationKey,
        locationId,
        labType,
      },
    });
  }

  handleUpdate() {
    const { currentLocationId: locationId, locationKeys } = this.state;
    const locationKey = locationKeys[locationId];
    this.fetchTicketsByLocation(locationKey);
  }

  render() {
    const { tickets } = this.props;
    const { isLoading, userLocation, userLocationId, locationKeys, currentLocationId } = this.state;

    return !isLoading ? (
      <TicketsListContianer
        tickets={tickets}
        userLocation={userLocation}
        userLocationId={userLocationId}
        locationKeys={locationKeys}
        currentLocationId={currentLocationId}
        onChangeTab={this.onChangeTab}
        onUpdate={this.handleUpdate}
        labType={this.props.labType}
      />
    ) : (
      <Spin />
    );
  }
}

const BloodBankTicketsWrapper: React.FC<any> = (props) => {
  const { initialState, loading } = useModel('@@initialState');
  const access = useAccess();
  const history = useHistory();
  const labType = bloodBankService.getLabTypeFromUrlFragment(history.location.pathname);

  return loading ? (
    <Spin />
  ) : (
    <BloodBankTickets
      {...props}
      currentUser={initialState.currentUser}
      access={access}
      labType={labType}
    />
  );
};

export default connect(({ blood_bankTickets }: { blood_bankTickets: any }) => {
  return {
    tickets: blood_bankTickets,
  };
})(BloodBankTicketsWrapper);
