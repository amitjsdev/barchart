import { Modal, Button, Input } from 'antd';
import Apis from '@/api/apis';
import { ProfileTwoTone, CheckOutlined } from '@ant-design/icons';

import { storageService } from '@/services/storage';
import { useState } from 'react';
import { Tooltip } from 'antd/es';
import styles from './styles';

class ApproveModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      loading: false,
      switchComplete: false,
      orderName: 'DefaultOrder',
      orderNotes: '',
      inputList: [{ product: '', quantity: '', note: '', id: '' }],
      outputList: [{ product: '', quantity: '', note: '', id: '' }],
      orderOptions: [],
      role: storageService.getItem('role'),
      allowedLocation: storageService.getItem('locationId'),
    };
  }

  componentDidMount() {
    const { inputList } = this.props;
    this.setState({ inputList });
  }

  componentDidUpdate(prevProps) {
    const { inputList, index } = this.props;

    if (inputList !== prevProps.inputList) {
      const _data = [];
      inputList[index].orderItems?.forEach((el) => {
        _data.push({ product: el.productCode, quantity: el.quantity, id: el.id });
      });

      this.setState({ inputList: _data });
    }
  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleOk = async (e) => {
    const { inputList, index } = this.props;

    this.setState({
      // visible: false,
      loading: true,
    });

    const _data = JSON.parse(JSON.stringify(inputList));
    await Apis.appoveOrder(_data[index].id);
    this.setState({
      visible: false,
      loading: false,
    });
    this.props.getOrder();
  };

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  };

  checkPermission() {
    return !(
      ['planner', 'manager'].includes(this.state.role) &&
      this.state.allowedLocation == this.props.locationId
    );
  }

  render() {
    const { visible, orderName, orderOptions, loading } = this.state;
    const { inputList, outputList, switchComplete } = this.state;

    return (
      <>
        <Tooltip title="Approve">
          <Button
            // disabled={this.checkPermission()}
            type="primary"
            style={this.props.style}
            shape="circle"
            icon={<CheckOutlined />}
            onClick={this.showModal}
          />
        </Tooltip>

        {/* <Button disabled={this.checkPermission()} style={this.props.style} onClick={this.showModal}><ProfileTwoTone /></Button> */}
        <Modal
          title="Order"
          visible={visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          maskClosable={false}
          footer={[
            <Button key="back" onClick={this.handleCancel} disabled={loading}>
              Cancel
            </Button>,
            <Button key="submit" type="primary" loading={loading} onClick={this.handleOk}>
              Submit
            </Button>,
          ]}
        >
          {/* <br /> */}
          <span>Do you approve the purchase order?</span>

          {/* <Input style={styles.orderNotes} placeholder="Note" onChange={(event) => this.setState({ orderNotes: event.target.value}) } />
           */}
        </Modal>
      </>
    );
  }
}

export default ApproveModal;
