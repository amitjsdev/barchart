import React, { useState, useEffect } from 'react';
import { Modal, Form, Button, Switch, Radio, Input, InputNumber, Space } from 'antd';
import { Row, Col, Select, Divider, message } from 'antd/es';
import { PlusOutlined, MinusCircleOutlined } from '@ant-design/icons';
import Apis from '@/api/apis';
import styles from './styles';

const DisputeModalV2: React.FC<any> = (props) => {
  const { disputeModalData } = props;
  const [switchComplete, setswitchComplete] = useState(false);
  const [isDisputeSubmitEnabled, setDisputeSubmitEnabled] = useState(false);
  const [formNote, setformNote] = useState('');
  const [globalNote, setglobalNote] = useState('');
  const [loading, setLoading] = useState(false);
  const [form] = Form.useForm();
  const { TextArea } = Input;
  const layout = {
    labelCol: { span: 8 },
    wrapperCol: { span: 16 },
  };

  let prevOrderList = [];
  if (disputeModalData) {
    let _data = [];
    disputeModalData.orderItems.forEach((el) => {
      _data.push({ product: el.productCode, quantity: el.quantity, id: el.id });
    });
    prevOrderList = _data;
  }

  const onFinish = (values) => {
    setLoading(true);
    if (!values.batches) {
      message.error('Please add the product first!');
      setLoading(false);
    }
    if (values.batches.length > 0) {
      let formVal = values.batches.map((val) => {
        return {
          note: formNote,
          ...val,
        };
      });
      let payload = { status: 'completed', dispute: formVal };
      Apis.updateOrder(disputeModalData.id, payload).then((response) => {
        handleCancel();
        props.getOrder();
        setLoading(false);
      });
    }
  };

  const setFormNote = (value) => {
    setformNote(value);
  };

  const setGlobalNote = (value) => {
    setglobalNote(value);
  };

  const handleCancel = () => {
    props.handleCancel();
    form.resetFields();
    setswitchComplete(false);
  };

  const submitForm = () => {
    setLoading(true);
    let payload = {
      status: 'completed',
      dispute: [
        {
          product: '',
          quantity: '',
          note: '',
          id: '',
        },
        {
          note: globalNote,
        },
      ],
    };
    Apis.updateOrder(disputeModalData.id, payload).then((response) => {
      handleCancel();
      setLoading(false);
      props.getOrder();
    });
  };

  const setPreviousQty = (productDescription: string) => {
    return prevOrderList.find((item) => item.product === productDescription);
  };

  const getQtyByFormIndex = (index) => {
    return prevOrderList[index].quantity;
  };

  const formValueChange = (changedValues: any[], allValues: any[]) => {
    let keyLength = 0;
    if (!changedValues?.batches.some((propValue) => !propValue)) {
      const changedProductIndex = changedValues?.batches.findIndex((value) => {
        if (value) {
          keyLength = Object.keys(value).length;
        }
        return value ? value.product : null;
      });
      // changedProductIndex,Object.keys(changedValues?.batches[changedProductIndex]).length
      if (changedProductIndex >= 0 && keyLength < 2) {
        const changedProduct = allValues?.batches[changedProductIndex].product;
        const updatedBatchesList = {};
        updatedBatchesList['batches'] = [];
        updatedBatchesList['batches'][changedProductIndex] = setPreviousQty(changedProduct);
        const updatedProduct = {};
        allValues['batches'][changedProductIndex] = setPreviousQty(changedProduct);
        form.setFieldsValue({
          ...allValues,
        });
      }
    }
  };

  const onSwitch = (checked) => {
    setswitchComplete(checked);
    if (!checked) {
      form.resetFields();
    }
  };

  const isValidOption = (option) => {
    const selectedProduct = Object.values(form?.getFieldsValue()?.batches).find((val: any) => {
      return val?.product === option?.product;
    });

    if (selectedProduct) setDisputeSubmitEnabled(true);
    return selectedProduct;
  };

  return (
    <Modal
      title="Complete PO / Raise Dispute"
      visible={props.isVisible}
      footer={null}
      afterClose={() => handleCancel()}
      closable={false}
      destroyOnClose={true}
    >
      <span>Did you receive all the items listed in the purchase order? </span>
      {/* <Switch style={styles.switch} onChange={onSwitch} /> */}
      <Space align="center">
        <Radio.Group onChange={(e) => onSwitch(e.target.value)} value={switchComplete}>
          <Radio value={false}>No</Radio>
          <Radio value={true}>Yes</Radio>
        </Radio.Group>
      </Space>
      {switchComplete === false ? (
        <div style={styles.productFormDiv}>
          <br />
          <Form
            layout="vertical"
            form={form}
            name="control-hooks"
            onFinish={onFinish}
            onValuesChange={formValueChange}
          >
            <Form.List name="batches">
              {(fields, { add, remove }) => {
                return (
                  <div>
                    {fields.map((field, index) => (
                      <>
                        <Form.Item
                          {...field}
                          name={[field.name, 'id']}
                          fieldKey={[field.fieldKey, 'id']}
                          style={{ height: '0px', margin: '0px' }}
                        ></Form.Item>
                        <Row key={index} align="middle">
                          <Col flex={2}>
                            <Form.Item
                              {...field}
                              label="Products"
                              name={[field.name, 'product']}
                              fieldKey={[field.fieldKey, 'product']}
                              rules={[
                                {
                                  required: true,
                                  message: 'Required',
                                },
                              ]}
                            >
                              <Select style={{ width: '170px' }}>
                                {prevOrderList.map((option: any) => (
                                  <Select.Option
                                    key={option.product}
                                    value={option.product}
                                    disabled={
                                      form?.getFieldsValue()?.batches
                                        ? isValidOption(option)
                                        : false
                                    }
                                  >
                                    {option.product}
                                  </Select.Option>
                                ))}
                              </Select>
                            </Form.Item>
                          </Col>
                          <Col flex={2}>
                            <Form.Item
                              {...field}
                              label="Quantity"
                              name={[field.name, 'quantity']}
                              fieldKey={[field.fieldKey, 'quantity']}
                              rules={[
                                { required: true, message: 'Missing quantity' },
                                {
                                  type: 'number',
                                  min: 0,
                                  message: 'Should be 0 or more than 0',
                                },
                                {
                                  type: 'number',
                                  max: form.getFieldsValue()?.batches[index]?.quantity,
                                  message:
                                    'Should be less than ' +
                                    form.getFieldsValue()?.batches[index]?.quantity,
                                },
                              ]}
                            >
                              <InputNumber style={{ width: '70%' }} />
                            </Form.Item>
                          </Col>
                          <Col flex={1}>
                            <MinusCircleOutlined
                              style={{ marginBottom: '1.5%' }}
                              onClick={() => {
                                remove(field.name);
                                setDisputeSubmitEnabled(false);
                              }}
                            />
                          </Col>
                        </Row>
                        <Divider />
                      </>
                    ))}

                    {fields.length !== prevOrderList.length ? (
                      <Form.Item>
                        <Button
                          type="dashed"
                          onClick={() => {
                            add();
                          }}
                          block
                        >
                          <PlusOutlined /> Add Product
                        </Button>
                      </Form.Item>
                    ) : null}
                  </div>
                );
              }}
            </Form.List>

            <TextArea
              rows={4}
              placeholder="Note"
              onChange={(event) => setFormNote(event.target.value)}
            />
            <Row gutter={[24, 24]} style={{ marginTop: '2%' }}>
              <Col flex={1}>
                <Form.Item>
                  <Button
                    type="primary"
                    htmlType="submit"
                    loading={loading}
                    disabled={!isDisputeSubmitEnabled}
                    block
                  >
                    OK
                  </Button>
                </Form.Item>
              </Col>
              <Col flex={1}>
                <Form.Item>
                  <Button onClick={handleCancel} disabled={loading} block>
                    Cancel
                  </Button>
                </Form.Item>
              </Col>
            </Row>
          </Form>
        </div>
      ) : (
        <>
          <div>
            <br />
            <TextArea
              rows={4}
              placeholder="Note"
              onChange={(event) => setGlobalNote(event.target.value)}
            />
            <Row gutter={[24, 24]} style={{ marginTop: '2%' }}>
              <Col flex={1}>
                <Button type="primary" onClick={submitForm} loading={loading} block>
                  OK
                </Button>
              </Col>
              <Col flex={1}>
                <Button onClick={handleCancel} disabled={loading} block>
                  Cancel
                </Button>
              </Col>
            </Row>
          </div>
        </>
      )}
    </Modal>
  );
};

export default DisputeModalV2;
