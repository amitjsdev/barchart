import Apis from '@/api/apis';

export async function getOrders(locationId, status, isApproved) {
  return Apis.getOrder(locationId, status, isApproved);
}

export async function getAllRegions() {
  return Apis.getUserRegions();
}
