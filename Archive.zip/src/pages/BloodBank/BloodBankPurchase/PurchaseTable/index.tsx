import React from 'react';
import styles from './styles';
import './index.css';
import { Table, Button, Typography, Space } from 'antd';
import moment from 'moment';
import Apis from '@/api/apis';

import { ExclamationCircleTwoTone, EditTwoTone, CheckOutlined } from '@ant-design/icons';
import access from '@/access';
import { Tooltip } from 'antd/es';
import { createdColumns, completedColumns } from './columns';
import DeleteModal from '../Modals/DeleteModal';
import ApproveModal from '../Modals/ApproveModal';
import DisputeModalV2 from '../Modals/DisputeModalV2';

const { Title, Text } = Typography;

const tableChoice = {
  created: 'columns',
  approved: 'columns1',
  pending: 'columns1',
  completed: 'columns2',
  cancelled: 'cancelled',
};

const DATE_FORMAT = 'YYYY-MM-DD';

class PurchaseTable extends React.Component {
  state = {
    inputList: [{ product: '', quantity: '', note: '' }],
    showDisputeModal: false,
    disputeModalData: null,
    status: 'created',
    columns: [
      {
        title: 'PO No.',
        dataIndex: 'id',
        key: 'id',
      },
      {
        title: 'Quantity',
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: 'Created By',
        dataIndex: 'createdBy',
        key: 'createdBy',
      },
      {
        title: 'Created On',
        key: 'createdOn',
        dataIndex: 'createdOn',
        render: (text, record) => {
          return moment(text, DATE_FORMAT).format('YYYY-MM-DD');
        },
      },
      {
        title: 'Expected Delivery',
        dataIndex: 'expectedOn',
        key: 'expectedOn',
        render: (text, record, index) =>
          this.dateDiff(record.expectedOn) > 0 ? (
            <div>
              <ExclamationCircleTwoTone twoToneColor="#ff0000" />
              <Text>{moment(record.expectedOn).format('YYYY-MM-DD')}</Text>
            </div>
          ) : (
            <Text>{moment(record.expectedOn).format('YYYY-MM-DD')}</Text>
          ),
      },
      {
        title: 'Action',
        key: 'action',
        render: (text, record, index) => (
          <div style={styles.actions}>
            {/* <Button style={styles.actionButton}>
              <EditTwoTone />
            </Button> */}
            <Space size={12}>
              <DeleteModal
                style={styles.deleteModal}
                inputList={this.state.inputList}
                getOrder={this.props.getOrder}
                index={index}
              />
              <ApproveModal
                style={styles.disputeModal}
                inputList={this.state.inputList}
                index={index}
                getOrder={this.props.getOrder}
                locationId={this.props.locationId}
              />
            </Space>
          </div>
        ),
      },
    ],
    columns1: [
      {
        title: 'PO No.',
        dataIndex: 'id',
        key: 'id',
      },
      {
        title: 'Quantity',
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: 'Created By',
        dataIndex: 'createdBy',
        key: 'createdBy',
      },
      {
        title: 'Created On',
        key: 'createdOn',
        dataIndex: 'createdOn',
        render: (text, record) => {
          return moment(text, DATE_FORMAT).format('YYYY-MM-DD');
        },
      },
      {
        title: 'Expected Delivery',
        dataIndex: 'expectedOn',
        key: 'expectedOn',
        render: (text, record, index) =>
          this.dateDiff(record.expectedOn) > 0 ? (
            <div>
              <ExclamationCircleTwoTone twoToneColor="#ff0000" />
              <Text>{moment(record.expectedOn).format('YYYY-MM-DD')}</Text>
            </div>
          ) : (
            <Text>{moment(record.expectedOn).format('YYYY-MM-DD')}</Text>
          ),
      },
      // {
      //   title: 'Action',
      //   key: 'action',
      //   render: (text, record, index) => (
      //     <div style={styles.actions}>
      //       <DisputeModalV2
      //         style={styles.disputeModal2}
      //         inputList={this.state.inputList}
      //         index={index}
      //         getOrder={this.props.getOrder}
      //         locationId={this.props.locationId}
      //       />
      //     </div>
      //   ),
      // },
      {
        title: 'Action',
        width: '100px',
        key: 'action',
        render: (text, record, index) => {
          return (
            <Tooltip title="Complete PO / Raise Dispute">
              <Button
                type="primary"
                // style={this.props.style}
                shape="circle"
                icon={<CheckOutlined />}
                onClick={(e) => this.disputeModal(record)}
              />
            </Tooltip>
          );
        },
      },
    ],
    columns2: [
      {
        title: 'PO No.',
        dataIndex: 'id',
        key: 'id',
      },
      {
        title: 'Quantity',
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: 'Created By',
        dataIndex: 'createdBy',
        key: 'createdBy',
      },
      {
        title: 'Created On',
        key: 'createdOn',
        dataIndex: 'createdOn',
        render: (text, record) => {
          return moment(text).format('YYYY-MM-DD');
        },
      },
      {
        title: 'Delivered Date',
        dataIndex: 'deliveredOn',
        key: 'deliveredOn',
        render: (text, record) => {
          return moment(text).format('YYYY-MM-DD');
        },
      },
    ],
    cancelled: [
      {
        title: 'PO No.',
        dataIndex: 'id',
        key: 'id',
      },
      {
        title: 'Quantity',
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: 'Created By',
        dataIndex: 'createdBy',
        key: 'createdBy',
      },
      {
        title: 'Created On',
        key: 'createdOn',
        dataIndex: 'createdOn',
        render: (text, record) => {
          return moment(text).format('YYYY-MM-DD');
        },
      },
      {
        title: 'Rejected On',
        dataIndex: 'updatedAt',
        key: 'updatedAt',
        render: (text, record) => {
          return moment(text).format('YYYY-MM-DD');
        },
      },
    ],
    data: [],
    nestedColumns: [
      {
        title: 'Code',
        width: '200px',
        dataIndex: 'productCode',
        key: 'productCode',
      },
      {
        title: 'Description',
        width: '200px',
        dataIndex: 'description',
        key: 'description',
      },
      {
        title: 'Quantity',
        width: '150px',
        dataIndex: 'quantity',
        key: 'quantity',
      },
      {
        title: 'Updated At',
        width: '150px',
        dataIndex: 'updatedAt',
        key: 'updatedAt',
        render: (text, record) => moment(record.updatedAt).format('YYYY-MM-DD'),
      },
      {
        title: 'Created At',
        width: '150px',
        dataIndex: 'createdAt',
        key: 'createdAt', // moment(batch.manufactureDate).format(dateFormat)
        render: (text, record) => moment(record.createdAt).format('YYYY-MM-DD'),
      },
    ],
    expandRowData: [],
    expandedRowKeys: [],
  };

  disputeModal = (values) => {
    this.setState({
      showDisputeModal: true,
      disputeModalData: values,
    });
  };

  labCodeColumn = {
    title: 'Lab code',
    key: 'locationId',
    dataIndex: 'locationId',
    render: (text, record) => {
      // return text;
      const lab = this.props.labs.find((lab) => lab.id === text);
      return lab?.code || 'N/A';
    },
  };

  componentDidMount() {
    const { data, showAllLocations } = this.props;
    this.setState({ inputList: data });

    if (showAllLocations) {
      this.setState({
        columns: [this.labCodeColumn, ...this.state.columns],
        columns1: [this.labCodeColumn, ...this.state.columns1],
        columns2: [this.labCodeColumn, ...this.state.columns2],
        cancelled: [this.labCodeColumn, ...this.state.cancelled],
      });
    }
  }

  componentDidUpdate(prevProps) {
    const { data, status, locationId, showAllLocations } = this.props;

    if (prevProps.data !== data) this.setState({ inputList: data, locationId });

    if (prevProps.status !== status) {
      if (status === 'created') this.setState({ status });
      // this.changeToCreatedColumns();
      else if (status === 'completed') this.setState({ status });
      // this.changeToCompletedColumns();
      else if (status === 'cancelled') this.setState({ status });
    }

    /* 
    if (showAllLocations) {
      this.setState({
        columns: [this.labCodeColumn, ...this.state.columns],
        columns1: [this.labCodeColumn, ...this.state.columns1],
        columns2: [this.labCodeColumn, ...this.state.columns2],
      });
    } */
  }

  changeToCreatedColumns = () => {
    const { columns } = this.state;

    const index = columns.findIndex((x) => x.key === 'deliveredOn');
    columns[index] = {
      title: 'Expected Delivery Date',
      dataIndex: 'expectedOn',
      key: 'expectedOn',
    };

    this.setState({ columns });
  };

  changeToCompletedColumns = () => {
    const { columns } = this.state;
    const index = columns.findIndex((x) => x.key === 'expectedOn');
    columns[index] = {
      title: 'Delivered Date',
      dataIndex: 'deliveredOn',
      key: 'deliveredOn',
    };

    this.setState({ columns });
  };

  async updateStatus(id) {
    const { data, getOrder } = this.props;
    const _data = JSON.parse(JSON.stringify(data));

    const payload = { status: 'completed' };
    await Apis.updateOrder(_data[id].id, payload);
  }

  sideOptions(index) {
    const { status } = this.props;
    const { inputList } = this.state;

    if (status === 'created') {
      return (
        <span>
          <Button style={styles.actionButton}>Edit</Button>
          <Button style={styles.actionButton}>Delete</Button>
          <DisputeModalV2
            style={styles.disputeModal}
            inputList={inputList}
            index={index}
            locationId={this.props.locationId}
          />
        </span>
      );
    }
    return null;
  }

  dateDiff = (_date) => {
    const today = new Date();
    const yday = new Date(_date);
    const _diff = (today.getTime() - yday.getTime()) / (1000 * 3600 * 24);
    return _diff;
  };

  getTable = () => {
    //
    //  access().canApprovePurchaseOrder(this.props.locationId) ? this.state.columns.push()

    const { status } = this.props;
    let _column;
    if (status == 'created') {
      _column = access().canApprovePurchaseOrder(this.props.locationId)
        ? this.state[tableChoice[status]]
        : this.state[tableChoice[status]].filter((option: any) => {
            return !['Action'].includes(option.title);
          });
    } else if (status == 'approved') {
      _column = access().canCompletePurchaseOrder(this.props.locationId)
        ? this.state[tableChoice[status]]
        : this.state[tableChoice[status]].filter((option: any) => {
            return !['Action'].includes(option.title);
          });
    } else {
      _column = this.state[tableChoice[status]];
    }
    //  this.state[tableChoice[status]];
    return _column;
  };

  keys: any[] = [];

  getExpandableData = (recordId, dataItems) => {
    this.keys[0] === recordId ? (this.keys = []) : (this.keys[0] = recordId);
    this.setState({
      expandRowData: [],
      expandedRowKeys: this.keys,
    });
    const data = dataItems;
    this.setState({
      expandRowData: data,
    });
  };

  expandedRowRender = () => {
    return (
      <Table
        columns={this.state.nestedColumns}
        dataSource={this.state.expandRowData}
        pagination={false}
      />
    );
  };

  handleCancel = () => {
    this.setState({
      showDisputeModal: false,
    });
  };

  render() {
    const { columns, columns2 } = this.state;
    const { data, status } = this.props;

    const tableColumn = this.getTable();

    return (
      <div className={styles.container}>
        <div>
          <Table
            columns={tableColumn}
            dataSource={data}
            size="small"
            pagination={{ defaultPageSize: 10 }}
            rowKey={(record) => record.id}
            // rowClassName={(record, index) => (this.dateDiff(record.createdOn) > 7 ? "red" : "black")}

            onExpand={(expanded, record) => this.getExpandableData(record.id, record.orderItems)}
            expandedRowRender={(record) => this.expandedRowRender()}
            expandIconColumnIndex={0}
            expandedRowKeys={this.state.expandedRowKeys}
            expandIconAsCell={false}
          />
          <DisputeModalV2
            style={styles.disputeModal}
            isVisible={this.state.showDisputeModal}
            inputList={this.state.inputList}
            getOrder={this.props.getOrder}
            locationId={this.props.locationId}
            handleCancel={this.handleCancel}
            disputeModalData={this.state.disputeModalData}
          />
        </div>
      </div>
    );
  }
}

export default PurchaseTable;
