import { PageContainer } from '@ant-design/pro-layout';
import React from 'react';
import { Tabs, Radio, Tooltip } from 'antd';
import moment from 'moment';
import Apis from '@/api/apis';

import { getUserProfileFromLocal } from '@/utils/userProfile';
import PurchaseTable from './PurchaseTable';
import styles from './index.less';
import { getOrders, getAllRegions } from './services';

const { TabPane } = Tabs;

class EditableTable extends React.Component {
  constructor(props) {
    super(props);
    const userProfile = getUserProfileFromLocal();

    this.state = {
      status: 'created',
      isApproved: false,
      labs: [{ name: 'NHL', id: '1' }], // ["NHL", "MAK", "MAD", "ASR", "DAM"];
      locationId: '',
      dataSource: [],
      regions: [],
      showAllLocations: !!['superApprover', 'regionManager'].includes(userProfile.role),
      userProfile,
    };
  }

  getLabsByRole(labs: any[]) {
    const { userProfile } = this.state;
    const allLocationsOption = { id: 0, code: 'All', name: 'All' };
    if (userProfile.role === 'manager') {
      return labs.filter((lab) => lab.id === userProfile.locationId);
    }
    if (userProfile.role === 'regionManager') {
      const labsInUserRegion = labs.filter((lab) => lab.regionId === userProfile.regionId);
      this.setState({ labsInUserRegion });
      return [allLocationsOption, ...labsInUserRegion];
    }
    return [allLocationsOption, ...labs];
  }

  async componentDidMount() {
    // Make a request for a user with a given ID
    const labs = await Apis.getLocations();
    const regions = await getAllRegions();
    const userProfile = getUserProfileFromLocal();
    this.setState({ userProfile });
    if (userProfile.role === 'superApprover') this.setState({ showAllLocations: true });

    this.setState({
      labs: this.getLabsByRole(labs),
    });

    this.changeLocation(this.state.labs[0].id);
  }

  async getOrder() {
    const { status, isApproved, locationId, userProfile, labsInUserRegion } = this.state;

    let orderData = await getOrders(locationId, status, isApproved);
    const orderStateData = [];

    if (userProfile.role === 'regionManager')
      orderData = orderData.filter((order) => {
        return labsInUserRegion.find((lab) => lab.id === order.locationId);
      });

    if (orderData === undefined || orderData === null) return;

    orderData.forEach((el, index) => {
      orderStateData.push({
        name: el.userName || 'NA',
        quantity: el.quantity,
        createdOn: moment(el.createdAt).format('YYYY-MM-DD'),
        createdBy: el.userName,
        id: el.id,
        orderItems: el.orderItems,
        deliveredOn: el.expectedDeliveryDate,
        expectedOn: el.expectedDeliveryDate,
        locationId: el.locationId,
      });
    });

    this.setState({ dataSource: orderStateData });
  }

  changeLocation = async (key) => {
    this.setState({ locationId: key }, () => this.getOrder());
  };

  refreshOrder() {
    this.getOrder();
  }

  async changeStatus(_status, _isApproved) {
    this.setState({ status: _status, isApproved: _isApproved }, () => this.getOrder());
  }

  filters = (
    <Radio.Group
      defaultValue="created"
      buttonStyle="solid"
      onChange={(e) => this.changeStatus(e.target.value, null)}
    >
      <Radio.Button value="created">Created</Radio.Button>
      <Radio.Button value="approved">Approved</Radio.Button>
      <Radio.Button value="cancelled">Rejected</Radio.Button>
      <Radio.Button value="completed">Completed</Radio.Button>
    </Radio.Group>
  );

  render() {
    const { labs, dataSource, status } = this.state;

    return (
      <PageContainer content="" className={styles.main}>
        <div className={styles.divContain}>
          <Tabs
            defaultActiveKey={labs[0].id}
            onChange={this.changeLocation}
            tabBarExtraContent={this.filters}
          >
            {labs.map((item, i) => (
              <TabPane tab={<Tooltip title={item.name}>{item.code}</Tooltip>} key={item.id} />
            ))}
          </Tabs>

          {/* <Button type="primary" className={styles.addItem} >Add Item</Button> */}

          <PurchaseTable
            data={dataSource}
            status={status}
            getOrder={this.getOrder.bind(this)}
            locationId={this.state.locationId}
            labs={this.state.labs}
            showAllLocations={this.state.showAllLocations}
          />
        </div>
        <div
          style={{
            paddingTop: 100,
            textAlign: 'center',
          }}
        >
          {/* <Spin spinning={loading} size="large" /> */}
        </div>
      </PageContainer>
    );
  }
}

export default () => (
  <div className={styles.container}>
    <div id="components-table-demo-edit-cell">
      <EditableTable />
    </div>
  </div>
);
