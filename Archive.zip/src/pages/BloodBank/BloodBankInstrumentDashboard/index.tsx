/* eslint-disable no-else-return */
import React, { useState, useEffect, Component, useRef } from 'react';
import { connect, useModel, useHistory, useAccess } from 'umi';
import { Col, Row, Tabs, Menu, Dropdown, Button, Badge, Tooltip, Spin, Input } from 'antd';

import InventoryTable from './components/InventoryTable/InventoryTable';
import bloodBankService from '../services/bloodBank.service';
import { InventoryType } from './Types';
import { StateType } from './model';
const { Search } = Input;
import styles from './index.less';

const { TabPane } = Tabs;

enum StatusNames {
  'working' = 'Working',
  'down' = 'Down',
  'partiallyDown' = 'Partially down',
  'backup' = 'Backup',
  'retired' = 'Retired',
}

enum WarrantyNames {
  'out' = 'Out',
  'under' = 'Under',
}
const InventoryContainer = (props) => {
  const {
    inventories = [],
    userLocation,
    userLocationId,
    onChangeTab,
    currentInventoryLocationId,
    onFilter,
    onUpdate,
    tableHeight,
    locationsKeys,
    labType,
    access,
  } = props;

  const { bloodBankProfile } = props;

  const [height, setHeight] = useState(0);
  const ref = useRef(null);

  const [filters, setFilters] = useState({
    state: 'clear',
    warranty: 'clear',
  });

  useEffect(() => {
    setHeight(ref.current.clientHeight);
  }, []);

  const Filters = (props) => {
    const onFilterChange = (value, key) => {
      const newFilters = { ...filters, [key]: value };
      setFilters(newFilters);
      onFilter(newFilters);
    };

    const stateFilter = (
      <Menu onClick={(e) => onFilterChange(e.key, 'state')}>
        <Menu.Item key="working">Working</Menu.Item>
        <Menu.Item key="down">Down</Menu.Item>
        <Menu.Item key="partiallyDown">Partially down</Menu.Item>
        <Menu.Item key="backup">Backup</Menu.Item>
        <Menu.Item key="retired">Retired</Menu.Item>
        <Menu.Item key="clear">Clear State</Menu.Item>
      </Menu>
    );

    const warrantyFilter = (
      <Menu onClick={(e) => onFilterChange(e.key, 'warranty')}>
        <Menu.Item key="under">Under</Menu.Item>
        <Menu.Item key="out">Out</Menu.Item>
        <Menu.Item key="clear">Clear Warranty</Menu.Item>
      </Menu>
    );

    return (
      <>
        <Dropdown className={styles.filterDropdown} overlay={stateFilter} placement="bottomRight">
          <Button type={filters.state !== 'clear' ? 'primary' : 'default'}>
            {filters.state !== 'clear' ? StatusNames[filters.state] : 'State'}
          </Button>
        </Dropdown>

        <Dropdown
          className={styles.filterDropdown}
          overlay={warrantyFilter}
          placement="bottomRight"
        >
          <Button type={filters.warranty !== 'clear' ? 'primary' : 'default'}>
            {filters.warranty !== 'clear' ? WarrantyNames[filters.warranty] : 'Warranty'}
          </Button>
        </Dropdown>
      </>
    );
  };

  const onChange = (activeKey?) => {
    setFilters({
      state: 'clear',
      warranty: 'clear',
    });
    onChangeTab(activeKey);
    // setCurrentTab(activeKey);
  };

  const getLocationCode = (id) => {
    const location = locationsKeys?.find((location) => location.id === id);
    return location?.code;
  };

  const getInventories = (allInventories: any[]) => {
    // const userRegion =

    const inventoryList = Object.keys(allInventories).map((locationKey) => {
      return allInventories[locationKey];
    });

    return access.canReadAllBloodBankInventories(labType)
      ? inventoryList
      : inventoryList.filter(
          (inventory) => inventory?.locationDetails?.region === bloodBankProfile.regionName,
        );
  };

  return (
    <div className={styles.main}>
      <div className={styles.container}>
        <Row gutter={[24, 24]}>
          <Col>
            <div ref={ref} className={styles.tableContainer}>
              <Tabs
                activeKey={getLocationCode(currentInventoryLocationId)}
                onChange={onChange}
                tabBarExtraContent={Filters(props.onFilter)}
              >
                {getInventories(inventories).map((inventory: InventoryType) => {
                  const key = getLocationCode(inventory.locationDetails.id);
                  return (
                    <TabPane
                      key={key}
                      tab={
                        <Tooltip title={inventory.locationDetails.name}>
                          {inventory.locationDetails.instrumentSpanEndCount > 0
                            ? `${inventory.locationDetails.code} (${inventory.locationDetails.instrumentSpanEndCount})`
                            : inventory.locationDetails.code}
                        </Tooltip>
                      }
                    >
                      <InventoryTable
                        skus={inventory.skus}
                        labType={labType}
                        locationDetails={inventory.locationDetails}
                        userLocationId={userLocationId}
                        inventoryLocationId={inventory.locationDetails.id}
                        onUpdate={props.onUpdate}
                        tableHeight={height}
                        bloodBankProfile={bloodBankProfile}
                        refreshInstruments={props.refreshInstruments}
                      />
                    </TabPane>
                  );
                })}
              </Tabs>
            </div>
          </Col>
        </Row>
      </div>
    </div>
  );
};

// const locationsKeys = ['nhl', 'mak', 'mad', 'asr', 'dam'];
let locationsKeys: {} = {};

const SideMenu = (props) => {
  const { onSideMenuClick, regions, defaultRegion, access, labType } = props;
  const defaultKey = defaultRegion || regions[0];
  const canReadAllBloodBankInventories = access.canReadAllBloodBankInventories();

  return regions?.length ? (
    <div className={styles.sideMenu}>
      <Menu
        onClick={(e) => onSideMenuClick(e.key)}
        defaultSelectedKeys={[defaultKey]}
        mode="inline"
      >
        {access.canReadAllBloodBankInventories(labType) ? (
          regions.map((region) => <Menu.Item key={region}>{region}</Menu.Item>)
        ) : (
          <Menu.Item key={defaultRegion}>{defaultRegion}</Menu.Item>
        )}
      </Menu>
    </div>
  ) : null;
};

interface PropsType {
  currentUser: App.CurrentUser;
  labType: App.LabType;
  access: any;
  dispatch: any;
}

class BloodBankInventory extends Component<PropsType, any> {
  bloodBankProfile: App.Module | undefined;

  constructor(props) {
    super(props);

    const { currentUser }: App.InitialStateType = props;
    this.bloodBankProfile = currentUser?.modules.find(
      (module) => module.name === this.props.labType,
    );
    const userLocationId = this.bloodBankProfile?.locationId;

    this.state = {
      userLocationId,
      userLocation: '',
      currentInventoryLocationId: userLocationId,
      inventories: {},
      searchText: '',
      // isInventoryStatusUpdated: false
    };

    this.onChangeTab = this.onChangeTab.bind(this);
    this.handleSideMenuClick = this.handleSideMenuClick.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.handleSearchInput = this.handleSearchInput.bind(this);
    this.refreshInstruments = this.refreshInstruments.bind(this);
  }

  async componentDidMount() {
    const { dispatch, labType, inventories } = this.props;
    const allLocationDetails = await bloodBankService.getInstrumentSpanEndCount(labType);
    const allRegions = await bloodBankService.getRegionsByLabType(labType);
    locationsKeys = allLocationDetails.reduce((acc, cur) => {
      const currentLocation = {
        id: cur.id,
        code: cur.code,
        region: cur.region,
      };
      acc[cur.region] = acc[cur.region] ? [...acc[cur.region], currentLocation] : [currentLocation];
      return acc;
    }, {});

    const userRegionId = this.bloodBankProfile?.regionId;

    let userLocation = null;
    let userRegion = null;

    userLocation = allLocationDetails.find((location: any) => location.regionId === userRegionId);
    userRegion = allRegions.find((region) => region.id === userRegionId)?.name;

    this.setState({
      userLocation: userLocation?.code,
      userRegion,
      currentRegion: userRegion,
      locations: allLocationDetails,
      currentInventoryLocationId: userLocation?.id,
      inventories,
    });

    dispatch({
      type: 'instrumentalMachines/initInventories',
      payload: {
        allLocationDetails,
        userLocation: this.state.userLocation,
        locationId: userLocation?.id,
        page: 0,
      },
    });
  }
  static getDerivedStateFromProps(props: any, currentState: any) {
    if (props.inventories !== currentState.inventories && currentState.searchText === '') {
      return {
        inventories: props.inventories,
      };
    }
  }
  onChangeTab(activeKey, currentRegion = this.state.currentRegion) {
    const { dispatch } = this.props;
    const locations = locationsKeys[currentRegion];
    const selectedLocation = locations.find((location) => location.code === activeKey);
    this.setState({
      currentInventoryLocationId: selectedLocation.id,
      searchText: '',
      userLocation: activeKey,
    });
    dispatch({
      type: 'instrumentalMachines/fetchInventory',
      payload: {
        locationKey: activeKey,
        locationId: selectedLocation.id,
        page: 0,
      },
    });
  }

  handleSideMenuClick(selectedRegion: string) {
    const defaultLocation = locationsKeys[selectedRegion][0];
    this.setState({
      currentRegion: selectedRegion,
      searchText: '',
    });
    this.onChangeTab(defaultLocation.code, selectedRegion);
  }

  refreshInstruments() {
    const selectedRegion = this.state.currentRegion;
    const defaultLocation = this.state.userLocation;
    this.onChangeTab(defaultLocation, selectedRegion);
  }

  handleSearch() {
    const { userLocation, searchText } = this.state;
    const { inventories } = this.props;
    const currentInventories =
      inventories && Object.keys(inventories).length > 0 ? { ...inventories[userLocation] } : {};
    if (searchText !== '') {
      let filterLocationInventories = [];
      if (currentInventories.skus.length > 0) {
        filterLocationInventories = currentInventories.skus.filter((inventory) => {
          let arr = [
            'equipmentName',
            'serialNumber',
            'model',
            'manufacturer',
            'state',
            'utilization',
            'warranty',
            'ppm',
            'lastPpmDate',
            'nextPpmDate',
            'maintenance',
          ];
          return Object.keys(inventory).some((val) => {
            if (arr.includes(val)) {
              if (
                val === 'serialNumber' ||
                val === 'ppm' ||
                val === 'lastPpmDate' ||
                val === 'nextPpmDate'
              ) {
                return String(inventory[val]).startsWith(searchText);
              }
              if (typeof inventory[val] === 'string') {
                return inventory[val].toLowerCase().includes(searchText);
              }
            }
          });
        });
      }
      let filterInventories =
        inventories && Object.keys(inventories).length > 0 ? { ...inventories } : {};
      filterInventories[userLocation] = {
        ...currentInventories,
        skus: filterLocationInventories,
      };
      this.setState({
        inventories: filterInventories,
      });
    } else {
      this.refreshInventory({ state: 'clear' });
    }
  }
  handleSearchInput(e: any) {
    this.setState(
      {
        searchText: e.target.value.toLowerCase(),
      },
      () => {
        this.handleSearch();
      },
    );
  }

  getLocationCode = (id) => {
    const { currentRegion } = this.state;
    const location = locationsKeys[currentRegion]?.find((location) => location.id === id);
    return location?.code;
  };

  refreshInventory = async (filter, key?) => {
    const { dispatch } = this.props;
    if (filter.state === 'clear' && filter.warranty === 'clear') {
      dispatch({
        type: 'instrumentalMachines/fetchInventory',
        payload: {
          locationId: this.state.currentInventoryLocationId,
          page: 0,
          locationKey: this.getLocationCode(this.state.currentInventoryLocationId),
        },
      });
    } else {
      const payload = {
        filter,
        locationId: this.state.currentInventoryLocationId,
        locationKey: this.getLocationCode(this.state.currentInventoryLocationId),
      };

      dispatch({
        type: 'instrumentalMachines/fetchFilteredInventory',
        payload,
      });
    }
  };

  render() {
    const { currentRegion, userRegion, inventories, searchText } = this.state;
    const currentRegionLocations = locationsKeys[currentRegion];
    const currentRegionInventories = Object.keys(inventories).reduce((acc, locationKey) => {
      if (currentRegionLocations?.find((location) => location.code === locationKey)) {
        return {
          ...acc,
          [locationKey]: inventories[locationKey],
        };
      }
      return acc;
    }, {});

    return (
      <Row className={styles.main}>
        <Col span={4}>
          <SideMenu
            onSideMenuClick={this.handleSideMenuClick}
            regions={Object.keys(locationsKeys)}
            defaultRegion={userRegion}
            access={this.props.access}
            labType={this.props.labType}
          />
        </Col>
        <Col span={20}>
          <div style={{ textAlign: 'right' }}>
            <Search
              placeholder="Search Instrument"
              onSearch={this.handleSearch}
              allowClear={true}
              className={styles.search}
              enterButton
              onChange={this.handleSearchInput}
              value={searchText}
            />
          </div>

          <InventoryContainer
            inventories={currentRegionInventories}
            userLocation={this.state.userLocation}
            userLocationId={this.state.userLocationId}
            onChangeTab={this.onChangeTab}
            refreshInstruments={this.refreshInstruments}
            currentInventoryLocationId={this.state.currentInventoryLocationId}
            onFilter={(filter) => this.refreshInventory(filter)}
            onUpdate={(key) => this.refreshInventory({ state: 'clear', warranty: 'clear' })}
            locationsKeys={currentRegionLocations}
            labType={this.props.labType}
            access={this.props.access}
            bloodBankProfile={this.bloodBankProfile}
          />
        </Col>
      </Row>
    );
  }
}

const BloodBankInventoryWrapper: React.FC<any> = (props) => {
  const { initialState, loading } = useModel('@@initialState');
  const access = useAccess();
  const history = useHistory();
  const labType = bloodBankService.getLabTypeFromUrlFragment(history.location.pathname);

  return loading ? (
    <Spin />
  ) : (
    <BloodBankInventory
      {...props}
      currentUser={initialState?.currentUser}
      access={access}
      labType={labType}
    />
  );
};

export default connect(({ instrumentalMachines }: { instrumentalMachines: StateType }) => {
  return {
    inventories: instrumentalMachines,
  };
})(BloodBankInventoryWrapper);
