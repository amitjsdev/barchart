interface ColumnType {
  title: string;
  width?: string;
  dataIndex: string;
  key: string;
  fixed?: string;
  render?: any;
}

type ProductClassificationType =
  | 'PHENOTYPING'
  | 'Serology'
  | 'NAT'
  | 'Donation'
  | 'Bacterial Detection';

interface ProductType {
  category: string;
  classification: ProductClassificationType;
  code: string;
  createdAt: string;
  description: string;
  id: number;
  unitOfMeasures: string;
  updatedAt: string;
}

interface BatchType {
  id: number;
  productId: number;
  inventoryId: number;
  locationId: number;
  batchNumber: string;
  expiryDate: string;
  manufactureDate: string;
  quantity: number;
  hasExpiry: true;
  createdAt: string;
  updatedAt: string;
}

interface SKUType {
  availableQuantities: number;
  consumableDays: number;
  createdAt: string;
  dailyConsumption: number;
  consumption: number;
  dailyDemand: number;
  expiryDate: string;
  id: number;
  locationId: number;
  monthlyConsumption: number;
  product: ProductType;
  productId: number;
  quantitiesInTransit: number;
  quantity: number;
  reOrderLevel: number;
  reOrderQuantity: number;
  updatedAt: string;
}

interface InstrumentalMachineSKU {
  id: number,
  locationId: number,
  labType: string,
  regionId: number,
  equipmentName: string,
  serialNumber: string,
  model: string,
  manufacturer: string,
  state: string,
  utilization: string,
  warranty: string,
  ppm: number,
  anualPpm: string,
  lastPpmDate: string,
  nextPpmDate: string,
  maintenance: string,
  createdAt: string,
  updatedAt: string
}

interface LocationType {
  code: string;
  createdAt: string;
  email: string;
  id: number;
  labCapacity: number;
  instrumentSpanEndCount:number;
  labType: string;
  locationType: string;
  name: string;
  numberOfAttendees: number;
  primaryContact: string;
  primaryMobile: string;
  samplesPerDay: number;
  updatedAt: string;
  region: string;
}

interface InventoryType {
  locationDetails: LocationType;
  skus: SKUType[];
}

enum TagColors {
  'down' = '#C8102E',
  'partiallyDown' = '#DC582A',
  'backup' = '#009ACE',
  'retired' = '#753BBD',
  'working'='#008755'
}


export { ColumnType, ProductType, BatchType, SKUType, InventoryType, LocationType ,InstrumentalMachineSKU,TagColors};
