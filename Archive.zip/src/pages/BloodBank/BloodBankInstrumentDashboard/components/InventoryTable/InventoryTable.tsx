import { Access, useAccess, history } from 'umi';
import { Badge, Button, Col, Row, Space, Table, Tooltip, Typography, Tag, Menu, Dropdown } from 'antd';
import { ColumnType, InstrumentalMachineSKU, TagColors } from '../../Types';
/* eslint-disable class-methods-use-this */
import React, { Component, useState } from 'react';

import OrderModal from '@/components/Modal/OrderModal';
import {
  EditOutlined,
  ScheduleOutlined,
  InfoOutlined,
  FallOutlined,
  UndoOutlined,
  ArrowDownOutlined,
  StopOutlined,
  CloseOutlined,
} from '@ant-design/icons';
import { Modal } from 'antd/es';
import TransferModal from '../TransferModal/TransferModal';
import AddInventory from '../AddInventory/AddInventory';
import bgiService from '../../../services/bloodBank.service';
import moment from 'moment';
import styles from '../InventoryTable/index.less';
import EditStateModal from '../EditStateModal/EditStateModal';
import EditModal from '../EditModal/EditModal';
import DrilldownDetailTable from '../TransactionDrilldown/Drilldown';
import bloodBankService from '@/pages/BloodBank/services/bloodBank.service';
import { filter } from 'lodash';

const { Text } = Typography;

// Excluding Checkbox column
const getTotalColumnWidth = (columns: ColumnType[]): number => {
  return columns.reduce((acc, cur) => acc + parseInt(cur.width, 10), 0);
};
enum StatusNames {
  'working' = 'Working',
  'down' = 'Down',
  'partiallyDown' = 'Partially down',
  'backup' = 'Backup',
  'retired' = 'Retired',
}

enum WarrantyNames {
  'true' = 'Planned',
  'false' = 'Unplanned',
}
interface StateType {
  skuColumns: ColumnType[];
  skus: InstrumentalMachineSKU[];
  showEditModal: boolean;
  showRequestTransferModal: boolean;
  showAddInventoryModal: boolean;
  showDrilldownModal: boolean;
  showEditStateModal: boolean;
  userLocationId: number;
  editModalContent: InstrumentalMachineSKU | null;
  editModalBatches: any | null;
  selectedRowKeys: any;
  selectedOrder: any;
  expandRowData: any[];
  nestedColumns: any[];
  loadEpandableRowdata: boolean;
  expandedRowKeys: any[];
  inventoryLocationId: number;
  currentStatus: string;
  drillDownResponse: any[];
}

interface PropsType {
  skus: InstrumentalMachineSKU[];
  userLocationId: number;
  inventoryLocationId: number;
  tableHeight: number;
  access: any;
  bloodBankProfile: App.Module;
}

class InventoryTable extends Component<PropsType, StateType> {
  constructor(props) {
    super(props);

    this.state = {
      currentStatus: '',
      skuColumns: [
        {
          title: 'S. No.',
          width: '100px',
          dataIndex: 'serialNum',
          key: 'serialNum',
          fixed: 'left',
          render: (text, record, index) => (
            <>
              <Space>
                <Badge status={!record.isSpanEnd ? 'success' : 'error'} />
                <Text>{index + 1}</Text>
              </Space>
            </>
          ),
        },
        {
          title: 'Equipment Name',
          width: '200px',
          dataIndex: 'equipmentName',
          key: 'equipmentName',
          fixed: 'left',
          render: (text, record, index) => (
            <>
              <Space>
                {record.state !== 'working' && (
                  <Tag
                    icon={
                      <Tooltip title={record.state}>
                        {record.state === 'partiallyDown' ? (
                          <FallOutlined
                            className={styles.statusTags}
                            style={{ color: TagColors[record.state] }}
                          />
                        ) : record.state === 'backup' ? (
                          <UndoOutlined style={{ color: TagColors[record.state] }} />
                        ) : record.state === 'down' ? (
                          <CloseOutlined style={{ color: TagColors[record.state] }} />
                        ) : (
                          <StopOutlined style={{ color: TagColors[record.state] }} />
                        )}
                      </Tooltip>
                    }
                    className={styles.statusTags}
                  />
                )}
                <Text>{record.equipmentName}</Text>
              </Space>
            </>
          ),
        },
        {
          title: 'Serial Number',
          width: '200px',
          dataIndex: 'serialNumber',
          key: 'serialNumber',
          fixed: 'left',
        },
        {
          title: 'Model',
          width: '200px',
          dataIndex: 'model',
          key: 'model',
        },
        {
          title: 'Manufacturer',
          width: '200px',
          dataIndex: 'manufacturer',
          key: 'manufacturer',
        },
        {
          title: 'Current Status',
          width: '200px',
          dataIndex: 'state',
          key: 'state',
        },
        {
          title: 'Utilization',
          width: '200px',
          dataIndex: 'utilization',
          key: 'utilization',
        },
        {
          title: 'Warranty',
          width: '200px',
          dataIndex: 'warranty',
          key: 'warranty',
        },
        {
          title: 'PPM Cycle (Months)',
          width: '200px',
          dataIndex: 'ppm',
          key: 'ppm',
        },
        {
          title: 'Last PPM date',
          width: '200px',
          dataIndex: 'lastPpmDate',
          key: 'lastPpmDate',
        },
        {
          title: 'Next PPM date',
          width: '200px',
          dataIndex: 'nextPpmDate',
          key: 'nextPpmDate',
        },
        {
          title: 'Name of Maintenance Company (HMC)',
          width: '200px',
          dataIndex: 'maintenance',
          key: 'maintenance',
        },
      ],
      skus: this.props.skus,
      showEditStateModal: false,
      showEditModal: false,
      showRequestTransferModal: false,
      showAddInventoryModal: false,
      showDrilldownModal: false,
      loadEpandableRowdata: true,
      expandedRowKeys: [],
      expandRowData: [],
      userLocationId: this.props.userLocationId,
      inventoryLocationId: this.props.inventoryLocationId,
      editModalContent: null,
      selectedRowKeys: [],
      selectedOrder: null,
      drillDownResponse: [],
      filterResponse:{},
      filters:{}
    };

    this.editButton = this.editButton.bind(this);
    this.onEditState = this.onEditState.bind(this);
    this.onEdit = this.onEdit.bind(this);
    this.requestTransfer = this.requestTransfer.bind(this);
    this.addInventories = this.addInventories.bind(this);
    this.configureRowSelection = this.configureRowSelection.bind(this);
    this.filterDrillDownData=this.filterDrillDownData.bind(this)
  }

  static getDerivedStateFromProps(props, currentState) {
    return {
      skus: props.skus,
    };
  }

  private async onEditState(sku) {
    this.setState({
      currentStatus: sku.state,
      editModalContent: sku,
      showEditStateModal: true,
    });
  }
  private async onEdit(sku) {
    this.setState({
      currentStatus: sku.state,
      editModalContent: sku,
      showEditModal: true,
    });
  }
  private async requestTransfer() {
    this.setState({
      showRequestTransferModal: !this.state.showRequestTransferModal,
    });
  }

  private async addInventories() {
    this.setState({
      showAddInventoryModal: !this.state.showAddInventoryModal,
    });
  }

  private async openDrilldown(sku) {
    bloodBankService.getTransactionHistory(sku?.id).then((data) => {
      this.setState({
        drillDownResponse: data,
        filterResponse:data
      });
    });
    this.setState({
      editModalContent: [],
      showDrilldownModal: true,
    });
  }



  private isUpdatedToday(sku: InstrumentalMachineSKU) {
    const lastUpdatedOn = sku.updatedAt;
    const today = moment();

    return moment(lastUpdatedOn).isSame(today, 'day');
  }

  // Excluding Checkbox column
  private getTotalColumnWidth(columns: ColumnType[]): number {
    return columns.reduce((acc, cur) => acc + parseInt(cur.width, 10), 0);
  }

  handleOk = async (updates) => {
    await bloodBankService.updateStateInstrumentalMachine(updates, this.state.editModalContent?.id);

    this.props.onUpdate();
    this.setState({
      showEditModal: false,
      showDrilldownModal: false,
      showEditStateModal: false,
      editModalBatches: null,
      editModalContent: null,
    });
    // window.location.reload();
  };

  handleEditOk = async (updates) => {
    await bloodBankService.addUpdateInstrumentalMachine(updates);

    this.props.onUpdate();
    this.setState({
      showEditModal: false,
      showDrilldownModal: false,
      showEditStateModal: false,
      editModalBatches: null,
      editModalContent: null,
    });
  };
  handleTransfer = async (transferData: any) => {
    const { selectedOrder } = this.state;
    const { locationDetails } = this.props;
    const items = selectedOrder.map((order) => {
      return {
        locationId: locationDetails.id,
        labType: order.labType,
        regionId: locationDetails.regionId,
        regionName: locationDetails.region,
        instrumentId: order.id,
        locationName: locationDetails.name,
        locationCode: locationDetails.code,
      };
    });
    const data = {
      toLocationId: transferData.location.id,
      toLabType: transferData.labType,
      toRegionId: transferData.region.id,
      toLocationName: transferData.location.name,
      toLocationCode: transferData.location.code,
      toRegionName: transferData.region.name,
      items: items,
    };
    await bgiService.createTransferRequest(data);
    this.setState({
      showRequestTransferModal: false,
      selectedOrder: [],
      selectedRowKeys: [],
    });
  };
  handleAddInventory = async (inventoryData: any) => {
    const { labType, locationDetails } = this.props;

    const data = [
      {
        labType,
        ...inventoryData,
        locationId: locationDetails.id,
        regionId: locationDetails.regionId,
      },
    ];
    await bgiService.createInstrumentInventory(data);
    this.setState({
      showAddInventoryModal: false,
    });
    if (this.props.refreshInstruments) {
      this.props.refreshInstruments();
    }
  };
   filterDrillDownData=(filters)=>{
    const response={...this.state.drillDownResponse}
    let data = [...response.data];
    if (filters.state !== 'clear') {
      data = data.filter(a => a.state === filters.state)
    }
    if (filters.planned !== 'clear') {
      data = data.filter(a => a.planned === (filters.planned === 'true'))
    }

    response.data = data;
this.setState({
  filterResponse:response
})
  }
  handleCancel = () => {
    this.setState({
      showEditModal: false,
      showDrilldownModal: false,
      showEditStateModal: false,
      editModalBatches: null,
      editModalContent: null,
      showRequestTransferModal: false,
      showAddInventoryModal: false,
      drillDownResponse: [],
    });
  };

  editButton(sku) {
    const { access, bloodBankProfile } = this.props;
    return (
      <>
        <Access accessible={access.canUpdateBloodBankInventory(bloodBankProfile.name)}>
          <Tooltip title="Edit Status">
            <Button
              style={{ marginRight: '10px' }}
              type="primary"
              shape="circle"
              icon={<ScheduleOutlined />}
              onClick={() => this.onEditState(sku)}
            />
          </Tooltip>
          <Tooltip title="Edit">
            <Button
              style={{ marginRight: '10px' }}
              type="primary"
              shape="circle"
              icon={<EditOutlined />}
              onClick={() => this.onEdit(sku)}
            />
          </Tooltip>

          <Tooltip title="Info">
            <Button
              type="primary"
              shape="circle"
              icon={<InfoOutlined />}
              onClick={() => this.openDrilldown(sku)}
            />
          </Tooltip>
        </Access>
      </>
    );
  }

  keys: any[] = [];

  onSelectChange = (selectedRowKeys: any[]) => {
    const { skus } = this.state;

    this.setState({ selectedRowKeys });

    const selectedOrderData = [];
    selectedRowKeys.forEach((el, index) => {
      const selectedRow = skus.find((sku) => sku.id === el);
      selectedOrderData.push(selectedRow);
    });
    this.setState({ selectedOrder: selectedOrderData });
  };
  private configureRowSelection() {
    return {
      selectedRowKeys: this.state.selectedRowKeys,
      onChange: (selectedRowKeys, selectedRows) => {
        this.onSelectChange(selectedRowKeys);
      },
      getCheckboxProps: (record: SKUType) => {
        return {
          id: record.id,
          disabled: false,
        };
      },
    };
  }
 
  
  render() {
    const { access, bloodBankProfile, labType, locationDetails } = this.props;

    let extraColumns = [];
    if (this.state.skus.length && access.canUpdateBloodBankInventory(bloodBankProfile.name)) {
      extraColumns = [
        {
          title: 'Actions',
          width: '150px',
          dataIndex: 'actions',
          key: 'actions',
          fixed: 'right',
          render: (text, record) => this.editButton(record),
        },
      ];
    }
    return (
      <>
        <Table
          id="table-element"
          columns={[...this.state.skuColumns, ...extraColumns]}
          rowSelection={this.configureRowSelection()}
          dataSource={this.state.skus}
          rowKey={(record) => record.id}
          pagination={false}
          scroll={{
            x:
              this.getTotalColumnWidth(this.state.skuColumns) + // All columns
              300, // Checkbox
            y: this.props.tableHeight - 100,
          }}
        />

        <EditStateModal
          isVisible={this.state.showEditStateModal}
          currentStatus={this.state.currentStatus}
          modalContent={this.state.editModalContent}
          handleOk={(edits) => this.handleOk(edits)}
          handleCancel={this.handleCancel}
        />
        <TransferModal
          labType={labType}
          locationDetails={locationDetails}
          isVisible={this.state.showRequestTransferModal}
          currentStatus={this.state.currentStatus}
          handleOk={(transferData: any) => this.handleTransfer(transferData)}
          handleCancel={this.handleCancel}
        />
        <AddInventory
          labType={labType}
          isVisible={this.state.showAddInventoryModal}
          currentStatus={this.state.currentStatus}
          handleOk={(transferData: any) => this.handleAddInventory(transferData)}
          handleCancel={this.handleCancel}
        />

        <Row className={styles.stickyFooter} gutter={[12, 0]}>
          <Col>
            <Button type="primary" onClick={this.addInventories}>
              Add Inventory
            </Button>
          </Col>
          {this.state.selectedRowKeys.length > 0 ? (
            <>
              <Col>
                <Button type="primary" onClick={this.requestTransfer}>
                  Request Transfer
                </Button>
              </Col>
              <Access accessible={false}>
                <Row className={styles.stickyFooter}>
                  <Col>
                    <OrderModal
                      inputList={this.state.selectedOrder}
                      locationId={this.state.inventoryLocationId}
                      count={this.state.selectedOrder.length}
                      btnName="Place order"
                    />
                  </Col>
                </Row>
              </Access>
            </>
          ) : null}
        </Row>
        <EditModal
          isVisible={this.state.showEditModal}
          modalContent={this.state.editModalContent}
          handleEditOk={(edits) => this.handleEditOk(edits)}
          handleCancel={this.handleCancel}
        />

        <Modal
          title={<>
          <p>Transaction History</p>  
              <Filters filterDrillDownData={this.filterDrillDownData}/>
            </>}
          centered
          visible={this.state.showDrilldownModal}
          width={720}
          onOk={this.handleCancel}
          onCancel={this.handleCancel}
          destroyOnClose
          footer={false}
        >
          <DrilldownDetailTable resultSet={this.state.filterResponse} />
        </Modal>
      </>
    );
  }
}

const InventoryTableWrapper = (props: any) => <InventoryTable {...props} access={useAccess()} />;
const Filters = (props) => {
  const[filters,setFilters]=useState({state:"clear",planned:"clear"})
  const onFilterChange = (value, key) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters)
    props.filterDrillDownData(newFilters)
  };

  const stateFilter = (
    <Menu onClick={(e) => onFilterChange(e.key, 'state')}>
      <Menu.Item key="working">Working</Menu.Item>
      <Menu.Item key="down">Down</Menu.Item>
      <Menu.Item key="partiallyDown">Partially down</Menu.Item>
      <Menu.Item key="backup">Backup</Menu.Item>
      <Menu.Item key="retired">Retired</Menu.Item>
      <Menu.Item key="clear">Clear State</Menu.Item>
    </Menu>
  );

  const warrantyFilter = (
    <Menu onClick={(e) => onFilterChange(e.key, 'planned')}>
      <Menu.Item key="true">Planned</Menu.Item>
      <Menu.Item key="false">Unplanned</Menu.Item>
      <Menu.Item key="clear">Clear</Menu.Item>
    </Menu>
  );

  return (
    <>
      <Dropdown className={styles.filterDropdown} overlay={stateFilter} placement="bottomRight">
        <Button type={filters.state !== 'clear' ? 'primary' : 'default'}>
          {filters.state !== 'clear' ? StatusNames[filters.state] : 'State'}
        </Button>
      </Dropdown>

      <Dropdown
        className={styles.filterDropdown}
        overlay={warrantyFilter}
        placement="bottomRight"
      >
        <Button type={filters.planned !== 'clear' ? 'primary' : 'default'}>
          {filters.planned !== 'clear' ? WarrantyNames[filters.planned] : 'Planned/Unplanned'}
        </Button>
      </Dropdown>

    </>
  );
};
export default InventoryTableWrapper;
