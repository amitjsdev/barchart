import React, { useState } from 'react';
import {
  Form,
  Input,
  Button,
  Row,
  Col,
  Modal,
  DatePicker,
  Select,
  Upload,
  message,
  Radio,
} from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import moment from 'moment';

const { Option } = Select;

const BasicEditForm = (props: any) => {
  const [form] = Form.useForm();
  const [planned, setPlannedStatus] = useState('Unplanned');
  const [selectedState, setSelectedState] = useState(props.currentStatus);
  const [fileUploadStatus, setFileUploadStatus] = useState(false);
  const [countFiles, setCountFiles] = useState(0);

  const onFinish = (values: any) => {
    if (values.state == props.currentStatus) {
      message.error('Previous and current status cannot be same', 4);
    } else {
      if (values.supportFile.file.type !== 'application/pdf') {
        message.error('Only Pdf files can be uploaded', 4);
      } else {
        if (fileUploadStatus) {
          const payload = {
            ...values,
            supportFile: values.supportFile.file,
            fixDate: moment(values.fixDate).format(dateFormat),
            planned: planned === 'Planned' ? true : false,
          };

          props.handleOk(payload);
        } else {
          message.error('File is not uploaded', 4);
        }
      }
    }
  };

  const onCancel = () => {
    props.handleCancel();
  };

  const disabledPastDates = (current: any) => {
    // Can not select days after today
    return current && current < moment().endOf('day');
  };
  const dateFormat = 'YYYY-MM-DD';

  const onStateChange = (value: any) => {
    setSelectedState(value);
  };

  const fileSave = (info: any) => {
    setCountFiles(info.fileList.length);
    if (info.file.status !== 'uploading') {
    }
    if (info.file.status === 'done') {
      setFileUploadStatus(true);
      message.success(`${info.file.name} file uploaded successfully`);
    } else if (info.file.status === 'error') {
      setFileUploadStatus(true);
      // message.error(`${info.file.name} file upload failed.`);
    }
  };

  return (
    <Form layout="vertical" form={form} name="basicEditForm" onFinish={onFinish}>
      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item
            name="state"
            label="State"
            rules={[{ required: true, message: 'Please Change the state' }]}
          >
            <Select
              defaultValue={props.currentStatus}
              // placeholder="Select a option and change input text above"
              onChange={onStateChange}
            >
              <Option value="working">Working</Option>
              <Option value="down">Down</Option>
              <Option value="partiallyDown">Partially Down</Option>
              <Option value="backup">Backup</Option>
              <Option value="retired">Retired</Option>
            </Select>
          </Form.Item>
        </Col>
      </Row>
      {selectedState != 'working' ? (
        <Row gutter={[24, 24]}>
          <Col flex={1}>
            <Form.Item
              label="Target resolution Date"
              name="fixDate"
              // fieldKey={[index, 'manufactureDate']}
              // initialValue={batch?.manufactureDate ? moment(batch?.manufactureDate) : ''}
              rules={[{ required: true, message: 'Date is required' }]}
            >
              <DatePicker
                // defaultValue={moment(batch?.manufactureDate, dateFormat)}
                // defaultPickerValue={moment(batch?.manufactureDate, dateFormat)}
                disabledDate={disabledPastDates}
                format={dateFormat}
                style={{ width: '100%' }}
              />
            </Form.Item>
          </Col>
        </Row>
      ) : (
        <></>
      )}
      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item name="planned" label="Planned / Unplanned">
            <Radio.Group
              options={['Unplanned', 'Planned']}
              onChange={(e) => setPlannedStatus(e.target.value)}
              value={planned}
              defaultValue={planned}
            />
          </Form.Item>
        </Col>
      </Row>
      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item
            name="supportFile"
            rules={[{ required: true, message: 'File Upload is required' }]}
          >
            <Upload accept="application/pdf" multiple={false} onChange={fileSave}>
              <Button disabled={countFiles == 1} icon={<UploadOutlined />}>
                PDF to Upload
              </Button>
            </Upload>
          </Form.Item>
        </Col>
      </Row>
      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item
            name="comment"
            label="Comment"
            rules={[{ required: true, message: 'Comment is required' }]}
          >
            <Input.TextArea />
          </Form.Item>
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item>
            <Button type="primary" htmlType="submit" block>
              Apply
            </Button>
          </Form.Item>
        </Col>
        <Col flex={1}>
          <Form.Item>
            <Button onClick={onCancel} block>
              Cancel
            </Button>
          </Form.Item>
        </Col>
      </Row>
    </Form>
  );
};

const EditStateModal = (props: any) => {
  const { currentStatus, modalContent, handleOk, handleCancel, isVisible } = props;
  return (
    <>
      {/* <Spin spinning={!isVisible} /> */}
      <Modal
        title="EDIT"
        visible={isVisible}
        afterClose={() => handleCancel()}
        destroyOnClose
        closable={false}
        footer={false}
      >
        <BasicEditForm
          currentStatus={currentStatus}
          modalContent={modalContent}
          // batches={batchDetails?.batches || null}
          // currentDailyConsumption={skuDetails.dailyConsumption}
          handleOk={(updatedBatches: any) => handleOk(updatedBatches)}
          handleCancel={() => handleCancel()}
        />
      </Modal>
    </>
  );
};

export default EditStateModal;
