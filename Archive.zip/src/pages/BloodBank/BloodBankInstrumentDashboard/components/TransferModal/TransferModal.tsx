import React, { useState } from 'react';
import { Form, Button, Row, Col, Modal, Select } from 'antd';
import bloodBankService from '../../../services/bloodBank.service';
const { Option } = Select;
import moment from "moment"
const BasicTransferForm = (props: any) => {
  const {
    regions,
    selectedRegion,
    setSelectedRegion,
    selectedLocation,
    setSelectedLocation,
    locations,
    selectedBloodBank,
    setSelectedBloodBank,
    locationDetails,
    regionName,
    locationName
  } = props;
  const [form] = Form.useForm();
  const onFinish = (values: any) => {
    const location = (locations || []).find((loc) => loc.id === selectedLocation);
    const region = (regions || []).find((region) => region.id === selectedRegion);
    const payload = {
      region,
      location,
      labType: selectedBloodBank,
    };
    props.handleOk(payload);
  };

  const onCancel = () => {
    props.handleCancel();
  };
  const bloodBanks = [
    { name: 'Central Blood Bank', id: 'centralbloodbank' },
    { name: 'Peripheral Blood Bank', id: 'peripheralbloodbank' },
    { name: 'Branch Blood Bank', id: 'branchbloodbank' },
  ];
  return (
    <Form layout="vertical" form={form} name="basicEditForm" onFinish={onFinish}>
      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item
            name="Blood Bank"
            label="Blood Bank"
            rules={[{ required: true, message: 'Please Change the Blood Bank' }]}
          >
            <Select value={selectedBloodBank} onChange={(value) => setSelectedBloodBank(value)}>
              {bloodBanks &&
                bloodBanks.map((bank) => {
                  return (
                    <Option key={bank.id} value={bank.id}>
                      {bank.name}
                    </Option>
                  );
                })}
            </Select>
          </Form.Item>
        </Col>
      </Row>
      {selectedBloodBank ? (
        <Row key={selectedBloodBank} gutter={[24, 24]}>
          <Col flex={1}>
            <Form.Item
              name={regionName}
              label="Region"
              rules={[{ required: true, message: 'Please Change the Region' }]}
            >
              {regions && regions.length > 0 && (
                <Select value={selectedRegion} onChange={(value) => setSelectedRegion(value)}>
                  {regions &&
                    regions.map((region) => {
                      return (
                        <Option key={region.id} value={region.id}>
                          {region.name}
                        </Option>
                      );
                    })}
                </Select>
              )}
            </Form.Item>
          </Col>
        </Row>
      ) : (
        <></>
      )}
      {selectedRegion ? (
        <Row key={selectedRegion}gutter={[24, 24]}>
          <Col flex={1}>
            <Form.Item
              label="Location"
              name={locationName}
              rules={[{ required: true, message: 'Please Change the Location' }]}
            >
             { locations && locations.length>0 &&<Select value={selectedLocation} onChange={(value) => setSelectedLocation(value)}>
                {locations &&
                  locations.map((location) => {
                    if (location.id !== locationDetails.id) {
                      return (
                        <Option key={location.id} value={location.id}>
                          {location.name}
                        </Option>
                      );
                    }
                  })}
              </Select>}
            </Form.Item>
          </Col>
        </Row>
      ) : (
        <></>
      )}

      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item>
            <Button type="primary" htmlType="submit" block>
              Apply
            </Button>
          </Form.Item>
        </Col>
        <Col flex={1}>
          <Form.Item>
            <Button onClick={onCancel} block>
              Cancel
            </Button>
          </Form.Item>
        </Col>
      </Row>
    </Form>
  );
};

const TransferModal = (props: any) => {
  const { currentStatus, handleOk, handleCancel, isVisible, locationDetails } = props;
  const [regions, setRegions] = useState([]);
  const [selectedRegion, setSelectedRegion] = useState('');
  const [selectedBloodBank, setSelectedBloodBank] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');
  const [regionName, setRegionName] = useState('');
  const [locationName, setLocationName] = useState('');
  const [locations, setLocations] = useState([]);
  const locDropdown: [] = [];

  const selectRegion = (region: any) => {
    setSelectedRegion(region);
    setSelectedLocation(null);
    setLocations([]);
    setLocationName(new Date().getTime())
    bloodBankService.getLocationsByLabType(selectedBloodBank).then((locations: any) => {
      locations.map((lab: any) => {
        if (lab.regionId === region) {
          locDropdown.push(lab);
        }
      });
      setLocations(locDropdown);
    });
  };

  const selectBloodBank = (bloodBank: any) => {
    setSelectedBloodBank(bloodBank);
    setSelectedLocation(null);
    setRegions([]);
    setRegionName(new Date().getTime())
    setLocations([]);
    setSelectedRegion(null);
    bloodBankService.getRegionsByLabType(selectedBloodBank).then((region) => {
      setRegions(region);
    });
    bloodBankService.getLocationsByLabType(selectedBloodBank).then((locations: any) => {
      locations.map((lab: any) => {
        locDropdown.push(lab);
      });
      setLocations(locDropdown);
    });
  };
  return (
    <>
      <Modal
        title="TRANSFER"
        visible={isVisible}
        afterClose={() => handleCancel()}
        destroyOnClose
        closable={false}
        footer={false}
      >
        <BasicTransferForm
        locationName={locationName}
        regionName={regionName}
          currentStatus={currentStatus}
          setSelectedRegion={selectRegion}
          selectedBloodBank={selectedBloodBank}
          selectedLocation={selectedLocation}
          selectedRegion={selectedRegion}
          setSelectedLocation={setSelectedLocation}
          setSelectedBloodBank={selectBloodBank}
          locations={locations}
          locationDetails={locationDetails}
          regions={regions}
          handleOk={(updatedBatches: any) => handleOk(updatedBatches)}
          handleCancel={() => handleCancel()}
        />
      </Modal>
    </>
  );
};

export default TransferModal;
