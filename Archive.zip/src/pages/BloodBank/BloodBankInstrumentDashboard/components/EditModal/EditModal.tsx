import React  from 'react';
import {
  Form,
  Button,
  Row,
  Col,
  Modal,
  Select,
} from 'antd';

const { Option } = Select;

const BasicEditForm = (props:any) => {
  const [form] = Form.useForm();

  const onFinish = (values:any) => {
      const payload = [{
        id: props.modalContent.id,
          ...values,
        } ]
      props.handleEditOk(payload);
}

  const onCancel = () => {
    props.handleCancel();
  };

  return (
    <Form layout="vertical" form={form} name="basicEditForm" onFinish={onFinish}>
      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item
            name="utilization"
            label="Utilization"
          >
            <Select
              defaultValue={props.modalContent.utilization}
            >
              <Option value="heavilyUsed">Heavily Used</Option>
              <Option value="medium">Medium</Option>
              <Option value="low">Low</Option>
              <Option value="notUsed">Not Used</Option>
            </Select>
          </Form.Item>
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item
            name="warranty"
            label="Warranty"
          >
            <Select
              defaultValue={props.modalContent.warranty}
            >
              <Option value="under">Under</Option>
              <Option value="out">Out</Option>
            </Select>
          </Form.Item>
        </Col>
      </Row>
      

      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item>
            <Button type="primary" htmlType="submit" block>
              Apply
            </Button>
          </Form.Item>
        </Col>
        <Col flex={1}>
          <Form.Item>
            <Button onClick={onCancel} block>
              Cancel
            </Button>
          </Form.Item>
        </Col>
      </Row>
    </Form>
  );
};

const EditModal = (props:any) => {
  const {  modalContent, handleEditOk, handleCancel, isVisible } = props;
  return (
    <>
      <Modal
        title="EDIT"
        visible={isVisible}
        afterClose={() => handleCancel()}
        destroyOnClose
        closable={false}
        footer={false}
      >
        <BasicEditForm
          modalContent={modalContent}
          handleEditOk={(updatedBatches:any) => handleEditOk(updatedBatches)}
          handleCancel={() => handleCancel()}
        />
      </Modal>
    </>
  );
};

export default EditModal;
