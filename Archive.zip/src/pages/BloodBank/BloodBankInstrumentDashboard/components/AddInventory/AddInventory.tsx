import React, { useState } from 'react';
import { Form, Button, Row, Col, Modal, Select, Input, DatePicker } from 'antd';
const { Option } = Select;
import moment from 'moment';
import styles from './index.less';
const dateFormat = 'YYYY-MM-DD';

const BasicAddForm = (props: any) => {
  const { fields, handleOk, onChange, inventoryData } = props;
  const [errorType, setErrorType] = useState('');
  const [errorText, setErrorText] = useState('');
  const [form] = Form.useForm();
  const disabledFutureDates = (current: any) => {
    return current && current > moment().add(0, 'days');
  };

  const onCancel = () => {
    props.handleCancel();
  };

  const validate = (obj: any) => {
    var regex = new RegExp(/^[0-9]*$/);
    const testRegex = regex.test(obj.value);
    if (!testRegex && obj.type.includes('number')) {
      setErrorType(obj.item.id);
      setErrorText(`Please Enter a valid ${obj.item.label}`);
    } else {
      setErrorType('');
      setErrorText('');
    }
  };
  return (
    <Form layout="vertical" form={form} name="basicEditForm" onFinish={handleOk}>
      <Row gutter={[24, 24]}>
        {fields &&
          fields.map((item: any) => {
            return (
              <Col xs={24} md={12}>
                <Form.Item
                  name={item.id}
                  label={item.label}
                  rules={[{ required: true, message: `Please Add ${item.name}` }]}
                >
                  {item.type.includes('input') ? (
                    <Input
                      name={item.id}
                      type={item.type === 'input' ? 'text' : 'number'}
                      onInput={(e) => validate({ item, value: e.target.value, type: item.type })}
                      value={inventoryData[item.id]}
                      onChange={(e) => onChange({ name: item.id, value: e.target.value })}
                    />
                  ) : item.type === 'dropdown' ? (
                    <Select
                      value={inventoryData[item.id]}
                      onChange={(value) => onChange({ name: item.id, value })}
                    >
                      {item.values &&
                        item.values.map((data: any) => {
                          return <Option value={data.value}>{data.label}</Option>;
                        })}
                    </Select>
                  ) : (
                    <DatePicker
                      onChange={(value) => onChange({ name: item.id, value })}
                      defaultValue={null}
                      format={dateFormat}
                      disabledDate={disabledFutureDates}
                      value={inventoryData[item.id]}
                      style={{ width: '100%' }}
                    />
                  )}
                </Form.Item>
                {errorType === item.id && <span style={{ color: 'red' }}>{errorText}</span>}
              </Col>
            );
          })}
      </Row>
      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item>
            <Button type="primary" htmlType="submit" block disabled={errorText !== ''}>
              Add Inventory
            </Button>
          </Form.Item>
        </Col>
        <Col flex={1}>
          <Form.Item>
            <Button onClick={onCancel} block>
              Cancel
            </Button>
          </Form.Item>
        </Col>
      </Row>
    </Form>
  );
};

const AddInventory = (props: any) => {
  const { handleOk, handleCancel, isVisible } = props;
  const [inventoryData, setInventoryData] = useState({});
  const fields = [
    { id: 'equipmentName', name: 'Equipment Name', label: 'Equipment Name', type: 'input' },
    { id: 'serialNumber', name: 'Serial Number', label: 'Serial Number', type: 'inputnumber' },
    { id: 'model', name: 'Model', label: 'Model', type: 'input' },
    { id: 'manufacturer', name: 'Manufacturer', label: 'Manufacturer', type: 'input' },
    {
      id: 'state',
      name: 'Current State',
      label: 'Current State',
      type: 'dropdown',
      values: [
        { label: 'Working', value: 'working' },
        { label: 'Down', value: 'down' },
        { label: 'Partially Down', value: 'partiallyDown' },
        { label: 'BackUp', value: 'backup' },
        { label: 'Retired', value: 'retired' },
      ],
    },
    {
      id: 'utilization',
      name: 'Utilization',
      label: 'Utilization',
      type: 'dropdown',
      values: [
        { label: 'Low', value: 'low' },
        { label: 'Medium', value: 'medium' },
        { label: 'Heavily Used', value: 'heavilyUsed' },
        { label: 'Not Used', value: 'notUsed' },
      ],
    },
    {
      id: 'warranty',
      name: 'Warranty',
      label: 'Warranty',
      type: 'dropdown',
      values: [
        { label: 'Under', value: 'under' },
        { label: 'Out', value: 'out' },
      ],
    },
    { id: 'ppm', name: 'PPM Cycle (Months)', label: 'PPM Cycle (Months)', type: 'inputnumber' },
    { id: 'lastPpmDate', name: 'Last PPM date', label: 'Last PPM date', type: 'date' },
    {
      id: 'maintenance',
      name: 'Name of Maintenance Company (HMC)',
      label: 'Name of Maintenance Company (HMC)',
      type: 'input',
    },
  ];

  const onFieldChange = (obj: any) => {
    let value = obj.value;
    if (obj.name.includes('ppm')) {
      value = parseInt(obj.value);
    }
    setInventoryData({
      ...inventoryData,
      [obj.name]: value,
    });
  };

  const onFinish = () => {
    handleOk(inventoryData);
  };

  return (
    <>
      <Modal
        className={styles.modal}
        title="Add Inventory"
        visible={isVisible}
        afterClose={() => handleCancel()}
        destroyOnClose
        closable={false}
        footer={false}
      >
        <BasicAddForm
          fields={fields}
          onChange={onFieldChange}
          inventoryData={inventoryData}
          handleOk={(updatedData: any) => onFinish(updatedData)}
          handleCancel={() => handleCancel()}
        />
      </Modal>
    </>
  );
};

export default AddInventory;
