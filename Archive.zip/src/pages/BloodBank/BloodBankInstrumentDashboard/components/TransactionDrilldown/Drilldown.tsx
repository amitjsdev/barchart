import React from 'react';
import { Table, Spin, Button } from 'antd';
import bloodBankService from '@/pages/BloodBank/services/bloodBank.service';
import { DownloadOutlined } from '@ant-design/icons';
import moment from 'moment';

const getFormattedColumns = [
  {
    title: 'State',
    width: '100px',
    dataIndex: 'state',
    key: 'state',
  },
  {
    title: 'Updated At',
    width: '200px',
    dataIndex: 'updatedAt',
    key: 'updatedAt',
    render: (text, record) => moment(record.updatedAt).format('YYYY-MM-DD'),
  },
  {
    title: 'Planned / Unplanned',
    width: '100px',
    dataIndex: 'planned',
    key: 'planned',
    render: (text, record) => {
      return record.planned ? 'Planned' : 'Unplanned';
    },
  },
  {
    title: 'Comment',
    width: '200px',
    dataIndex: 'comment',
    key: 'comment',
  },
  {
    title: 'File',
    width: '200px',
    dataIndex: 'supportFile',
    key: 'supportFile',
    render: (text: string, record) => {
      return (
        <Button type="primary" onClick={(value) => downloadPdf(text, record)}>
          <DownloadOutlined />
        </Button>
      );
    },
  },
];

const downloadPdf = (text, record) => {
  bloodBankService.downloadPdf(text, record.labType, record.id);
};

const DrilldownDetailTable = ({ resultSet }) => {
  return resultSet.data ? (
    <Table pagination={false} columns={getFormattedColumns} dataSource={resultSet.data} />
  ) : (
    <Spin />
  );
};

export default DrilldownDetailTable;
