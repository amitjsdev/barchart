import Apis from '@/api/apis';

interface IInventoryParams {
  locationId: number;
  page: number;
}

export async function getLocations() {
  return Apis.getLocations();
}

export async function getAllRegions() {
  return Apis.getRegionsByLabType();
}
