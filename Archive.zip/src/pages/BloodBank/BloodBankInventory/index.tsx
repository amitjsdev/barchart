/* eslint-disable no-else-return */
import React, { useState, useEffect, Component, useRef } from 'react';
import { connect, useModel, useHistory, useAccess } from 'umi';
import { Col, Row, Tabs, Menu, Dropdown, Button, Badge, Tooltip, Spin } from 'antd';

import InventoryTable from './components/InventoryTable/InventoryTable';
import bloodBankService from '../services/bloodBank.service';
import { InventoryType } from './Types';
import { StateType } from './model';

import styles from './index.less';

const { TabPane } = Tabs;

enum StatusNames {
  'outOfStock' = 'OOS',
  'nearOutOfStock' = 'NOOS',
  'safeStock' = 'SS',
  'overStock' = 'OS',
}

enum ProductTypeNames {
  'Phenotyping' = 'Phenotyping',
  'Serology' = 'Serology',
  'NAT' = 'NAT',
  'Donation bags & Plasma' = 'Donation',
  'Bacterial Detection' = 'Bacterial Detection',
}

const productTypes = [
  'Phenotyping',
  'Serology',
  'NAT',
  'Donation bags & Plasma',
  'Bacterial Detection',
];

const machinesToBeSeparated = [
  'ORTHO',
  'Gel method , IH500 & IH1000',
  'Architect i1000, Architect i2000, Alinity I & Alinity S',
];
const separatedMachineList = {
  ORTHO: ['Ortho Autovue', 'Ortho Vision', 'Ortho Max-Vision'],
  'Gel method , IH500 & IH1000': ['Gel method', 'IH500', 'IH1000'],
  'Architect i1000, Architect i2000, Alinity I & Alinity S': [
    'Architect i1000',
    'Architect i2000',
    'Alinity I',
    'Alinity SEdit',
  ],
};

const InventoryContainer = (props) => {
  const {
    inventories = [],
    userLocation,
    userLocationId,
    onChangeTab,
    currentInventoryLocationId,
    onFilter,
    onUpdate,
    tableHeight,
    locationsKeys,
    labType,
    access,
  } = props;

  const { bloodBankProfile } = props;

  const [height, setHeight] = useState(0);
  const [machines, setMachines] = useState([]);
  const [proMac, setPorMac] = useState([]);
  const proNames: [] = [];
  const ref = useRef(null);

  const [filters, setFilters] = useState({
    status: 'clear',
    type: 'clear',
    machine: 'clear',
  });

  const getMachines = async () => {
    const machineData = await bloodBankService.getAllMachinesByLabType(labType).then((data) => {
      return data
        .filter((machine) => {
          const types = productTypes.map((type) => type.toLowerCase());

          if (
            types.includes(machine.classification.toLowerCase()) &&
            !proNames.includes(machine.classification)
          ) {
            proNames.push(machine.classification);
          }
          return types.includes(machine.classification.toLowerCase());
        })
        .map((machine) => ({ name: machine.category, type: machine.classification }))
        .map((machine) => {
          if (machinesToBeSeparated.includes(machine.name)) {
            return separatedMachineList[machine.name].map((machineName) => ({
              name: machineName,
              type: machine.type,
            }));
          }
          return machine;
        })
        .flat();
    });

    setPorMac(proNames);
    if (machineData.length) setMachines(machineData);
  };

  useEffect(() => {
    setHeight(ref.current.clientHeight);
    getMachines();
  }, []);

  const Filters = (props) => {
    const onFilterChange = (value, key) => {
      let newFilters;
      newFilters = { ...filters, [key]: value };

      if (key === 'type') newFilters.machine = 'clear';

      setFilters({ ...newFilters });

      const separatedMachines = Object.keys(separatedMachineList)
        .map((machineKey) => {
          return separatedMachineList[machineKey].map((machine) => ({
            name: machine,
            filterName: machineKey,
          }));
        })
        .flat();
      const selectedSeparatedMachine = separatedMachines.find(
        (machine) => machine.name === newFilters.machine,
      );

      if (selectedSeparatedMachine) newFilters.machine = selectedSeparatedMachine.filterName;

      onFilter(newFilters);
    };

    const menu = (
      <Menu onClick={(e) => onFilterChange(e.key, 'status')}>
        <Menu.Item key="outOfStock">
          <Badge color="red" /> OOS
        </Menu.Item>
        <Menu.Item key="nearOutOfStock">
          <Badge color="orange" /> NOOS
        </Menu.Item>
        <Menu.Item key="safeStock">
          <Badge color="green" />
          SS
        </Menu.Item>
        <Menu.Item key="overStock">
          <Badge color="purple" />
          OS
        </Menu.Item>
        <Menu.Item key="clear">Clear Status</Menu.Item>
      </Menu>
    );

    const productClassificationMenu = (
      <Menu onClick={(e) => onFilterChange(e.key, 'type')}>
        {proMac.map((type) => (
          <Menu.Item key={type}>{ProductTypeNames[type]}</Menu.Item>
        ))}
        <Menu.Item key="clear">Clear Type</Menu.Item>
      </Menu>
    );

    const machinesMenu = (
      <Menu onClick={(e) => onFilterChange(e.key, 'machine')}>
        {machines
          .filter((machine) => machine.type.toLowerCase() === filters.type.toLowerCase())
          .map((machine) => (
            <Menu.Item key={machine.name}>{machine.name}</Menu.Item>
          ))}
        <Menu.Item key="clear">Clear Machine</Menu.Item>
      </Menu>
    );

    return (
      <>
        <Dropdown
          className={styles.filterDropdown}
          overlay={productClassificationMenu}
          placement="bottomRight"
        >
          <Button type={filters.type !== 'clear' ? 'primary' : 'default'}>
            {filters.type !== 'clear'
              ? filters.type !== 'Donation bags & Plasma'
                ? filters.type
                : 'Donation'
              : 'Type'}
          </Button>
        </Dropdown>
        <Dropdown className={styles.filterDropdown} overlay={machinesMenu} placement="bottomRight">
          <Button type={filters.machine !== 'clear' ? 'primary' : 'default'}>
            {filters.machine !== 'clear' ? filters.machine : 'Machine'}
          </Button>
        </Dropdown>
        <Dropdown className={styles.filterDropdown} overlay={menu} placement="bottomRight">
          <Button type={filters.status !== 'clear' ? 'primary' : 'default'}>
            {filters.status !== 'clear' ? StatusNames[filters.status] : 'Status'}
          </Button>
        </Dropdown>
      </>
    );
  };

  const onChange = (activeKey?) => {

    setFilters({
      status: 'clear',
      type: 'clear',
      machine: 'clear',
    });
    onChangeTab(activeKey);
    // setCurrentTab(activeKey);
  };

  const getLocationCode = (id) => {
    const location = locationsKeys?.find((location) => location.id === id);
    return location?.code;
  };

  const getInventories = (allInventories: any[]) => {
    // const userRegion =

    const inventoryList = Object.keys(allInventories).map((locationKey) => {
      return allInventories[locationKey];
    });

    return access.canReadAllBloodBankInventories(labType)
      ? inventoryList
      : inventoryList.filter(
          (inventory) => inventory?.locationDetails?.region === bloodBankProfile.regionName,
        );
  };

  return (
    <div className={styles.main}>
      <div className={styles.container}>
        <Row gutter={[24, 24]}>
          <Col>
            <div ref={ref} className={styles.tableContainer}>
              <Tabs
                activeKey={getLocationCode(currentInventoryLocationId)}
                onChange={onChange}
                tabBarExtraContent={Filters(props.onFilter)}
              >
                {getInventories(inventories).map((inventory: InventoryType) => {
                  const key = getLocationCode(inventory.locationDetails.id);
                  return (
                    <TabPane
                      key={key}
                      tab={
                        <Tooltip title={inventory.locationDetails.name}>
                          {inventory.locationDetails.code}
                        </Tooltip>
                      }
                    >
                      <InventoryTable
                        skus={inventory.skus}
                        locationDetails={inventory.locationDetails}
                        userLocationId={userLocationId}
                        inventoryLocationId={inventory.locationDetails.id}
                        onUpdate={props.onUpdate}
                        tableHeight={height}
                        bloodBankProfile={bloodBankProfile}
                      />
                    </TabPane>
                  );
                })}
              </Tabs>
            </div>
          </Col>
        </Row>
      </div>
    </div>
  );
};

// const locationsKeys = ['nhl', 'mak', 'mad', 'asr', 'dam'];
let locationsKeys: {} = {};

const SideMenu = (props) => {
  const { onSideMenuClick, regions, defaultRegion, access, labType } = props;
  const defaultKey = defaultRegion || regions[0];
  const canReadAllBloodBankInventories = access.canReadAllBloodBankInventories();

  return regions?.length ? (
    <div className={styles.sideMenu}>
      <Menu
        onClick={(e) => onSideMenuClick(e.key)}
        defaultSelectedKeys={[defaultKey]}
        mode="inline"
      >
        {access.canReadAllBloodBankInventories(labType) ? (
          regions.map((region) => <Menu.Item key={region}>{region}</Menu.Item>)
        ) : (
          <Menu.Item key={defaultRegion}>{defaultRegion}</Menu.Item>
        )}
      </Menu>
    </div>
  ) : null;
};

interface PropsType {
  currentUser: App.CurrentUser;
  labType: App.LabType;
  access: any;
  dispatch: any;
}

class BloodBankInventory extends Component<PropsType, any> {
  bloodBankProfile: App.Module | undefined;

  constructor(props) {
    super(props);

    const { currentUser }: App.InitialStateType = props;
    this.bloodBankProfile = currentUser?.modules.find(
      (module) => module.name === this.props.labType,
    );
    const userLocationId = this.bloodBankProfile?.locationId;

    this.state = {
      userLocationId,
      userLocation: '',
      currentInventoryLocationId: userLocationId,
      // isInventoryStatusUpdated: false
    };

    this.onChangeTab = this.onChangeTab.bind(this);
    this.handleSideMenuClick = this.handleSideMenuClick.bind(this);
  }

  async componentDidMount() {
    const { dispatch, labType } = this.props;
    const allLocationDetails = await bloodBankService.getLocationsByLabType(labType);
    const allRegions = await bloodBankService.getRegionsByLabType(labType);

    locationsKeys = allLocationDetails.reduce((acc, cur) => {
      const currentLocation = {
        id: cur.id,
        code: cur.code,
        region: cur.region,
      };
      acc[cur.region] = acc[cur.region] ? [...acc[cur.region], currentLocation] : [currentLocation];
      return acc;
    }, {});

    const userRegionId = this.bloodBankProfile?.regionId;

    let userLocation = null;
    let userRegion = null;

    userLocation = allLocationDetails.find((location: any) => location.regionId === userRegionId);
    userRegion = allRegions.find((region) => region.id === userRegionId)?.name;

    this.setState({
      userLocation: userLocation?.code,
      userRegion,
      currentRegion: userRegion,
      locations: allLocationDetails,
      currentInventoryLocationId: userLocation?.id,
    });

    dispatch({
      type: 'bloodBankInventory/initInventories',
      payload: {
        allLocationDetails,
        userLocation: this.state.userLocation,
        locationId: userLocation?.id,
        page: 0,
      },
    });
  }

  onChangeTab(activeKey, currentRegion = this.state.currentRegion) {
    const { dispatch } = this.props;
    const locations = locationsKeys[currentRegion];
    const selectedLocation = locations.find((location) => location.code === activeKey);
    this.setState({
      currentInventoryLocationId: selectedLocation.id,
    });
    dispatch({
      type: 'bloodBankInventory/fetchInventory',
      payload: {
        locationKey: activeKey,
        locationId: selectedLocation.id,
        page: 0,
      },
    });
  }

  handleSideMenuClick(selectedRegion: string) {
    const defaultLocation = locationsKeys[selectedRegion][0];
    this.setState({
      currentRegion: selectedRegion,
    });
    this.onChangeTab(defaultLocation.code, selectedRegion);
  }

  getLocationCode = (id) => {
    const { currentRegion } = this.state;
    const location = locationsKeys[currentRegion]?.find((location) => location.id === id);
    return location?.code;
  };

  refreshInventory = async (filter, key?) => {
    const { dispatch } = this.props;

    if (filter.status === 'clear' && filter.type === 'clear') {
      dispatch({
        type: 'bloodBankInventory/fetchInventory',
        payload: {
          locationId: this.state.currentInventoryLocationId,
          page: 0,
          locationKey: this.getLocationCode(this.state.currentInventoryLocationId),
        },
      });
    } else {
      const payload = {
        filter,
        locationId: this.state.currentInventoryLocationId,
        page: 0,
        locationKey: this.getLocationCode(this.state.currentInventoryLocationId),
      };

      dispatch({
        type: 'bloodBankInventory/fetchFilteredInventory',
        payload,
      });
    }
  };

  render() {
    const { inventories } = this.props;
    const { currentRegion, userRegion } = this.state;

    const currentRegionLocations = locationsKeys[currentRegion];

    const currentRegionInventories = Object.keys(inventories).reduce((acc, locationKey) => {
      if (currentRegionLocations?.find((location) => location.code === locationKey)) {
        return {
          ...acc,
          [locationKey]: inventories[locationKey],
        };
      }
      return acc;
    }, {});

    return (
      <Row className={styles.main}>
        <Col span={4}>
          <SideMenu
            onSideMenuClick={this.handleSideMenuClick}
            regions={Object.keys(locationsKeys)}
            defaultRegion={userRegion}
            access={this.props.access}
            labType={this.props.labType}
          />
        </Col>
        <Col span={20}>
          <InventoryContainer
            inventories={currentRegionInventories}
            userLocation={this.state.userLocation}
            userLocationId={this.state.userLocationId}
            onChangeTab={this.onChangeTab}
            currentInventoryLocationId={this.state.currentInventoryLocationId}
            onFilter={(filter) => this.refreshInventory(filter)}
            onUpdate={(key) => this.refreshInventory({ status: 'clear', type: 'clear' })}
            locationsKeys={currentRegionLocations}
            labType={this.props.labType}
            access={this.props.access}
            bloodBankProfile={this.bloodBankProfile}
          />
        </Col>
      </Row>
    );

    /* return inventories[this.state.userLocation] ? (
      <InventoryContainer inventories={inventories} userLocation={this.state.userLocation} userLocationId={this.state.userLocationId} onChangeTab={this.onChangeTab} />
    ) : (
      <Spin />
    ); */
  }
}

const BloodBankInventoryWrapper: React.FC<any> = (props) => {
  const { initialState, loading } = useModel('@@initialState');
  const access = useAccess();
  const history = useHistory();
  const labType = bloodBankService.getLabTypeFromUrlFragment(history.location.pathname);

  return loading ? (
    <Spin />
  ) : (
    <BloodBankInventory
      {...props}
      currentUser={initialState?.currentUser}
      access={access}
      labType={labType}
    />
  );
};

export default connect(({ bloodBankInventory }: { bloodBankInventory: StateType }) => {
  return {
    inventories: bloodBankInventory,
  };
})(BloodBankInventoryWrapper);
