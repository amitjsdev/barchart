import { Effect, Reducer } from 'umi';

import bloodBankService from '../services/bloodBank.service';
import { LocationType } from './Types';

export interface StateType {
  // other: InventoryType | null;
  // RLRI: InventoryType | null;
  // RLJE: InventoryType | null;
  // RLMA: InventoryType | null;
  // RLME: InventoryType | null;
}

export interface ModelType {
  namespace: string;
  state: StateType;
  effects: {
    initInventories: Effect;
    fetchInventory: Effect;
    fetchLocations: Effect;
    updateProduct: Effect;
    placeOrder: Effect;
    fetchFilteredInventory: Effect;
  };
  reducers: {
    updateInventories: Reducer<StateType>;
    addLocations: Reducer<StateType>;
    addSkus: Reducer<StateType>;
    updateQuantity: Reducer<StateType>;
    updateBatch: Reducer<StateType>;
  };
}

const locationsKeys: {} = {};

const Model: ModelType = {
  namespace: 'bloodBankInventory',
  state: {
    // RLRI: null,
    // RLMA: null,
    // RLME: null,
    // RLJE: null,
    // other: null,
  },
  effects: {
    // Init store
    *initInventories({ payload }, { call, put }) {
      const { userLocation, allLocationDetails, ...getInventoryParams } = payload;
      const { data } = yield call(bloodBankService.getInventory, getInventoryParams);
      const inventories = {};

      allLocationDetails.forEach((location: LocationType) => {
        locationsKeys[location.id] = location.code;
        const locationKey = location.code;
        inventories[locationKey] = { locationDetails: location, skus: [] };
      });

      inventories[userLocation].skus = data;

      yield put({
        type: 'updateInventories',
        payload: inventories,
      });
    },
    // Fetch data from server and store
    *fetchInventory({ payload }, { call, put }) {
      const { locationKey, ...getInventoryParams } = payload;
      const { data } = yield call(bloodBankService.getInventory, getInventoryParams);

      yield put({
        type: 'addSkus',
        payload: {
          locationKey,
          skus: data,
        },
      });
    },
    *fetchFilteredInventory({ payload }, { call, put }) {
      const { locationKey, ...getInventoryParams } = payload;
      const { data } = yield call(bloodBankService.getFilteredInventory, getInventoryParams);

      yield put({
        type: 'addSkus',
        payload: {
          locationKey,
          skus: data,
        },
      });
    },
    *fetchLocations({ payload }, { call, put }) {
      const locations = yield call(bloodBankService.getLocationsByLabType, payload);

      yield put({
        type: 'addLocations',
        payload: locations,
      });
    },
    // Update product
    *updateProduct({ payload }, { call, put }) {
      yield;
    },
    *placeOrder({ payload }, { call, put }) {
      yield;
    },
  },
  reducers: {
    updateInventories(state, { payload }) {
      return { ...state, ...payload };
    },
    // Add location details to inventories
    addLocations(state, { payload }) {
      const inventoryLocationDetails = {};

      payload.forEach((location: LocationType) => {
        const locationKey = locationsKeys[location.id];
        inventoryLocationDetails[locationKey] = { locationDetails: location };
      });

      const newState = {};
      Object.values(locationsKeys).forEach((location) => {
        newState[location] = {
          locationDetails: inventoryLocationDetails[location],
          skus: state[location].skus,
        };
      });

      return newState;
    },
    // Add skus to the store
    addSkus(state, { payload }) {
      const inventoryKey = payload.locationKey;
      const inventoryToBeAdded = {};

      inventoryToBeAdded[inventoryKey] = {
        locationDetails: state[inventoryKey].locationDetails,
        skus: payload.skus,
      };

      return {
        ...state,
        ...inventoryToBeAdded,
      };
    },
    // Update quantity in hand of a product
    updateQuantity(state, { payload }) {
      return {
        ...state,
      };
    },
    updateBatch(state, { payload }) {
      return {
        ...state,
      };
    },
  },
};

export default Model;
