import { ApiUrlFragments, LabTypes } from '@/services/Constants';

import apiService from '@/shared/services/api.service';
import errorHandler from '@/services/errorHandler';
import httpService from '@/services/http.service';
import { message } from 'antd';

export default {
  getLabTypeFromUrlFragment: (url: string) => {
    const [x, bloodBankRoute] = url.split('/');
    const labTypeMap = {
      cbb: LabTypes.CBB,
      pbb: LabTypes.PBB,
      bbb: LabTypes.BBB,
    };

    return labTypeMap[bloodBankRoute];
  },

  getInventory: (payload: { locationId: number; page: number }) => {
    const limit = 150;
    const { locationId, page } = payload;

    return httpService
      .get<API.InventoryResponse>(`${ApiUrlFragments.INVENTORY}/cbb-inventories/${locationId}`, {
        params: { page, limit },
      })
      .then((res) => res.results)
      .catch((err) => errorHandler(err));
  },

  getFilteredInventory: (payload: {
    locationId: number;
    page: number;
    filter: { status: string; type: string; machine: string };
  }) => {
    const limit = 150;
    const { locationId, page, filter } = payload;
    const params = {
      page,
      limit,
    };

    if (filter.status !== 'clear') params[filter.status] = true;
    if (filter.type !== 'clear') params.classification = filter.type;
    if (filter.machine !== 'clear') params.category = filter.machine;

    return httpService
      .get<API.InventoryResponse>(`${ApiUrlFragments.INVENTORY}/cbb-inventories/${locationId}`, {
        params,
      })
      .then((res) => res.results)
      .catch((err) => errorHandler(err));
  },
  getFilteredTransfer: (payload: {
    locationId: number;
    filter: { status: string;};
  }) => {
    const { locationId,  filter } = payload;
    const params = {
    };

    if (filter.status !== 'clear') params[filter.status] = status;
  

    return httpService
      .get<API.InventoryResponse>(`${ApiUrlFragments.INVENTORY}/instruments/transactions/${locationId}`, {
        params,
      })
      .then((res) => res.results)
      .catch((err) => errorHandler(err));
  },

  getLocationsByLabType: (labType: App.LabType) => apiService.getLocationsByLabType(labType),

  getInstrumentSpanEndCount: (labType: App.LabType) => apiService.getInstrumentSpanEndCount(labType).then((data: any) => data.data),

  getBatches: (skuId: number) => apiService.getBatches(skuId),

  updateQuantityAndDailyConsumption: (
    update: BloodBank.API.UpdateQuantityAndDailyConsumptionRequest,
    skuId: number,
  ) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/cbb-inventories/inventory/${skuId}`, update)
      .then(() => message.success('SKU updated successfully'));
  },
  updateTransferRequestStatus: (
    transferId: number,
    status:string
  ) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/instruments/transactions/${transferId}`,{status})
      .then(() => message.success('Transfer Status updated successfully'));
  },

  createTransferRequest: (data: any) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/instruments/transactions`, data)
      .then(() => message.success('Tranfer Request Generated Successfully'));
  },
  createInstrumentInventory:(data:any)=>{
    return httpService
    .post(`${ApiUrlFragments.INVENTORY}/instruments`, data)
    .then(() => message.success('Inventory Added Successfully'))
    .catch((err) =>message.error("Please enter unique serial number"));
  },
  getAllMachinesByLabType: (labType: App.LabType) =>
    apiService.getProductsByLabType(labType).then((data: any) => data.results.data),

  getRegionsByLabType: (labType: App.LabType) => apiService.getRegionsByLabType(labType),

  getTickets: ({ locationId, labType }) => {
    return apiService.getImsTickets(labType, locationId);
  },
  getTransferRequest: ({ locationId, status,outGoing,params }) => {
    return apiService.getInstrumentalTransferRequest(locationId,status,outGoing,params);
  },


  closeTicket: (ticketId: number) => {
    return apiService
      .closeImsTicket(ticketId)
      .then(() => message.success(`Ticket no. ${ticketId} was closed successfully!`));
  },

  getInstrumentalMachines: (payload: { locationId: number; page: number }) => {
    const { locationId, page } = payload;

    return httpService
      .get<API.InstrumentalMachineResponse>(
        `${ApiUrlFragments.INVENTORY}/instruments/${locationId}`,
      )
      .then((data) => data.data)
      .catch((err) => errorHandler(err));
  },

  getFilteredInstrumentalMachines: (payload: {
    locationId: number;
    filter: { state: string; warranty: string };
  }) => {
    const { locationId, filter } = payload;

    const params = {
    };

    if (filter.state !== 'clear') params['state'] = filter.state;
    if (filter.warranty !== 'clear') params['warranty'] = filter.warranty;

    return httpService
      .get<API.InstrumentalMachineResponse>(
        `${ApiUrlFragments.INVENTORY}/instruments/${locationId}`,
        {
          params,
        },
      )
      .then((data) => data.data)
      .catch((err) => errorHandler(err));
  },

  updateStateInstrumentalMachine: (payload: any, id: any) => {
    const parameter = {
      comment: payload.comment,
      state: payload.state,
      
    };
    if(payload.planned)  parameter['planned'] = payload.planned; 
    if (payload.state !== 'working') parameter['fixDate'] = payload.fixDate;

    const formData = new FormData();
    formData.append('supportFile', payload.supportFile.originFileObj, payload.supportFile.name);

    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/instruments/service/${id}`, formData, {
        params: {
          ...parameter,
        },
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      })
      .then((res) => {
        message.success('Inventory status updated successfully');
        return res;
      })
      .catch((err) => errorHandler(err, null));
  },

  addUpdateInstrumentalMachine: (payload) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/instruments`, payload)
      .then((res) => {
        message.success('Inventory updated successfully');
        return res;
      })
      .catch((err) => errorHandler(err, null));
  },

  getTransactionHistory: (id: any) => {
    return httpService
      .get<API.TransactionHistory>(`${ApiUrlFragments.INVENTORY}/instruments/service/${id}`)
      .then((res) => res)
      .catch((err) => errorHandler(err));
  },

  downloadPdf: (downloadId: string, labType: string, id: number) => {
    return httpService
      .get<any>(`${ApiUrlFragments.DOWNLOAD}/${downloadId}`, { responseType: 'arraybuffer' })
      .then((res) => {
        const blob = new Blob([res], { type: 'application/pdf' });
        saveAs(blob, `${labType}/${id}.pdf`);
      })
      .catch((err) => errorHandler(err));
  },
};
