/* eslint-disable no-else-return */
import React, { useState, useEffect, Component, useRef, useCallback } from 'react';
import { connect, useModel, useHistory, useAccess } from 'umi';
import { Col, Row, Tabs, Menu, Button, Tooltip, Spin } from 'antd';
import TransferTable from './components/TransferTable';
import { PageContainer } from '@ant-design/pro-layout';
import bloodBankService from '../services/bloodBank.service';
import { TransferType } from './Types';
import { StateType } from './model';

import styles from './index.less';

const { TabPane } = Tabs;

const TransferContainer = (props) => {
  const {
    transfer = [],
    onChangeTab,
    currentTransferRequestLocationId,
    onLocationChange,
    getLocationCode,
    onUpdate,
    labType,
    access,
    pages,
    setPages,
    userRegion,
  } = props;

  const { bloodBankProfile } = props;

  const [filters, setFilters] = useState({ type: 'created' });

  const [activeTab, setActiveTab] = useState('incoming');

  useEffect(() => {
    setFilters({ type: 'created' });
    setActiveTab('incoming');
  }, [props.sideMenuClicked]);

  const Filters = (onChange: any) => {
    const filtersData = ['created', 'completed', 'rejected'];
    return (
      <>
        {filtersData &&
          filtersData.map((item) => {
            return (
              <Button
                type={filters.type === item ? 'primary' : 'default'}
                onClick={(e) => onChange(e, item)}
              >
                {item.charAt(0).toUpperCase() + item.slice(1)}
              </Button>
            );
          })}
      </>
    );
  };

  const onFilterChange = useCallback(
    (e: any, value: string) => {
      setFilters({
        type: value,
      });
      const locationCode = getLocationCode(currentTransferRequestLocationId);
      onChangeTab(locationCode, userRegion, activeTab !== 'incoming', value, pages);
    },
    [currentTransferRequestLocationId, transfer, activeTab],
  );

  const onChangeIncoming = (activeKey: string) => {
    const locationCode = getLocationCode(currentTransferRequestLocationId);
    setActiveTab(activeKey);
    onChangeTab(locationCode, userRegion, activeKey !== 'incoming', filters.type, pages);
  };

  const onLocationChangeRequest = (activeKey: string) => {
    setActiveTab('incoming');
    setFilters({ type: 'created' });
    onLocationChange(activeKey);
  };

  const refreshTransferRequest = () => {
    onChangeTab(
      getLocationCode(currentTransferRequestLocationId),
      userRegion,
      activeTab !== 'incoming',
      filters.type,
      pages,
    );
  };
  const getMoreTransferRequest = (data) => {
    onChangeTab(
      getLocationCode(currentTransferRequestLocationId),
      userRegion,
      activeTab !== 'incoming',
      filters.type,
      data,
    );
  };
  const getTransfer = (allTransfer: any[]) => {
    const transferList = Object.keys(allTransfer).map((locationKey) => {
      const transferItem = allTransfer[locationKey];
      return {
        ...transferItem,
        transfer: transferItem.transfer.map((item) => {
          return {
            ...item,
            fromRegionName:
              item && item.items && item.items.length > 0 && item.items[0]
                ? item.items[0].regionName
                : '',
            fromLocationName:
              item && item.items && item.items.length > 0 && item.items[0]
                ? item.items[0].locationName
                : '',
            fromLabType:
              item && item.items && item.items.length > 0 && item.items[0]
                ? item.items[0].labType
                : '',
          };
        }),
      };
    });

    return access.canReadAllBloodBankInventories(labType)
      ? transferList
      : transferList.filter(
          (transfer) => transfer?.locationDetails?.region === bloodBankProfile.regionName,
        );
  };

  return (
    <div className={styles.main}>
      <div className={styles.container}>
        <Row gutter={[24, 24]}>
          <Col span={24}>
            <div className={styles.tableContainer}>
              <Tabs
                activeKey={getLocationCode(currentTransferRequestLocationId)}
                onChange={onLocationChangeRequest}
                tabBarExtraContent={Filters(onFilterChange)}
              >
                {getTransfer(transfer).map((transferItem: TransferType) => {
                  const key = getLocationCode(transferItem.locationDetails.id);
                  return (
                    <TabPane
                      key={key}
                      tab={
                        <Tooltip title={transferItem.locationDetails.name}>
                          {transferItem.locationDetails.code}
                        </Tooltip>
                      }
                    >
                      <Tabs activeKey={activeTab} onChange={onChangeIncoming}>
                        <TabPane key="incoming" tab={<Tooltip title="Incoming">Incoming</Tooltip>}>
                          {' '}
                          <PageContainer content="">
                            <TransferTable
                              data={transferItem.transfer}
                              activeTab={activeTab}
                              status={filters.type}
                              locationId={transferItem.locationDetails.id}
                              onUpdate={onUpdate}
                              labType={labType}
                              onChange={refreshTransferRequest}
                              getMoreTransferRequest={getMoreTransferRequest}
                              pages={pages}
                              setPages={setPages}
                            />
                          </PageContainer>
                        </TabPane>
                        <TabPane key="outgoing" tab={<Tooltip title="Outgoing">Outgoing</Tooltip>}>
                          <PageContainer content="">
                            <TransferTable
                              activeTab={activeTab}
                              data={transferItem.transfer}
                              status={filters.type}
                              locationId={transferItem.locationDetails.id}
                              onUpdate={onUpdate}
                              labType={labType}
                              onChange={refreshTransferRequest}
                              getMoreTransferRequest={getMoreTransferRequest}
                              pages={pages}
                              setPages={setPages}
                            />
                          </PageContainer>
                        </TabPane>
                      </Tabs>
                    </TabPane>
                  );
                })}
              </Tabs>
            </div>
          </Col>
        </Row>
      </div>
    </div>
  );
};

let locationsKeys: {} = {};

const SideMenu = (props) => {
  const { onSideMenuClick, regions, defaultRegion, access, labType } = props;
  const defaultKey = defaultRegion || regions[0];

  return regions?.length ? (
    <div className={styles.sideMenu}>
      <Menu
        onClick={(e) => onSideMenuClick(e.key)}
        defaultSelectedKeys={[defaultKey]}
        mode="inline"
      >
        {access.canReadAllBloodBankTransfer(labType) ? (
          regions.map((region) => <Menu.Item key={region}>{region}</Menu.Item>)
        ) : (
          <Menu.Item key={defaultRegion}>{defaultRegion}</Menu.Item>
        )}
      </Menu>
    </div>
  ) : null;
};

interface PropsType {
  currentUser: App.CurrentUser;
  labType: App.LabType;
  access: any;
  dispatch: any;
}

class BloodBankTransfer extends Component<PropsType, any> {
  bloodBankProfile: App.Module | undefined;

  constructor(props) {
    super(props);

    const { currentUser }: App.InitialStateType = props;
    this.bloodBankProfile = currentUser?.modules.find(
      (module) => module.name === this.props.labType,
    );
    const userLocationId = this.bloodBankProfile?.locationId;

    this.state = {
      userLocationId,
      userLocation: '',
      currentTransferRequestLocationId: userLocationId,
      status: '',
      sideMenuClicked: false,
      pages: [0, 2],
      // isInventoryStatusUpdated: false
    };

    this.onChangeTab = this.onChangeTab.bind(this);
    this.handleSideMenuClick = this.handleSideMenuClick.bind(this);
    this.onLocationChange = this.onLocationChange.bind(this);
  }
  setPages = (pages) => {
    this.setState({
      pages,
    });
  };
  async componentDidMount() {
    const { dispatch, labType } = this.props;
    const allLocationDetails = await bloodBankService.getLocationsByLabType(labType);
    const allRegions = await bloodBankService.getRegionsByLabType(labType);

    locationsKeys = allLocationDetails.reduce((acc, cur) => {
      const currentLocation = {
        id: cur.id,
        code: cur.code,
        region: cur.region,
      };
      acc[cur.region] = acc[cur.region] ? [...acc[cur.region], currentLocation] : [currentLocation];
      return acc;
    }, {});

    const userRegionId = this.bloodBankProfile?.regionId;

    let userLocation = null;
    let userRegion = null;

    userLocation = allLocationDetails.find((location: any) => location.regionId === userRegionId);
    userRegion = allRegions.find((region) => region.id === userRegionId)?.name;

    this.setState({
      userLocation: userLocation?.code,
      userRegion,
      currentRegion: userRegion,
      locations: allLocationDetails,
      currentTransferRequestLocationId: userLocation?.id,
    });

    dispatch({
      type: 'bloodBankTransfer/initTransfer',
      payload: {
        allLocationDetails,
        userLocation: this.state.userLocation,
        locationId: userLocation?.id,
        outGoing: false,
        status: 'created',
        params: { offset: 0, limit: 20 },
      },
    });
  }

  onChangeTab(
    locationKey,
    currentRegion = this.state.currentRegion,
    isOutGoing = false,
    filter = 'created',
  ) {
    const { dispatch, labType } = this.props;
    const locations = locationsKeys[currentRegion];
    const selectedLocation = locations.find((location) => location.code === locationKey);
    this.setState({
      currentInventoryLocationId: selectedLocation.id,
    });
    dispatch({
      type: 'bloodBankTransfer/fetchTransfer',
      payload: {
        locationKey,
        locationId: selectedLocation.id,
        params: { offset: 0, limit: 20 },
        labType,
        outGoing: isOutGoing,
        status: filter,
      },
    });
  }
  onLocationChange = (activeKey?: string) => {
    const { currentRegion } = this.state;
    const locations = locationsKeys[currentRegion];
    const location = locations.find((location) => location.code === activeKey);
    this.setState({
      currentTransferRequestLocationId: location.id,
    });
    this.onChangeTab(activeKey, currentRegion, false, 'created', { offset: 0, limit: 20 });
  };

  handleSideMenuClick(selectedRegion: string) {
    const defaultLocation = locationsKeys[selectedRegion][0];
    this.setState({
      currentRegion: selectedRegion,
      userRegion: selectedRegion,
      currentTransferRequestLocationId: defaultLocation.id,
      sideMenuClicked: !this.state.sideMenuClicked,
    });
    this.onChangeTab(defaultLocation.code, selectedRegion, false, 'created', {
      offset: 0,
      limit: 20,
    });
  }

  getLocationCode = (id: number) => {
    const { currentRegion } = this.state;
    const location = locationsKeys[currentRegion]?.find((location) => location.id === id);
    return location?.code;
  };

  render() {
    const { transfer } = this.props;
    const { currentRegion, userRegion, pages } = this.state;

    const currentRegionLocations = locationsKeys[currentRegion];

    const currentRegionTransfer = Object.keys(transfer).reduce((acc, locationKey) => {
      if (currentRegionLocations?.find((location) => location.code === locationKey)) {
        return {
          ...acc,
          [locationKey]: transfer[locationKey],
        };
      }
      return acc;
    }, {});

    return (
      <Row className={styles.main}>
        <Col span={4}>
          <SideMenu
            onSideMenuClick={this.handleSideMenuClick}
            regions={Object.keys(locationsKeys)}
            defaultRegion={userRegion}
            access={this.props.access}
            labType={this.props.labType}
          />
        </Col>
        <Col span={20}>
          <TransferContainer
            transfer={currentRegionTransfer}
            userLocation={this.state.userLocation}
            userLocationId={this.state.userLocationId}
            userRegion={userRegion}
            onChangeTab={this.onChangeTab}
            pages={pages}
            setPages={this.setPages}
            getLocationCode={this.getLocationCode}
            onLocationChange={this.onLocationChange}
            currentTransferRequestLocationId={this.state.currentTransferRequestLocationId}
            locationsKeys={currentRegionLocations}
            sideMenuClicked={this.state.sideMenuClicked}
            labType={this.props.labType}
            access={this.props.access}
            bloodBankProfile={this.bloodBankProfile}
          />
        </Col>
      </Row>
    );
  }
}

const BloodBankTransferWrapper: React.FC<any> = (props) => {
  const { initialState, loading } = useModel('@@initialState');
  const access = useAccess();
  const history = useHistory();
  const labType = bloodBankService.getLabTypeFromUrlFragment(history.location.pathname);

  return loading ? (
    <Spin />
  ) : (
    <BloodBankTransfer
      {...props}
      currentUser={initialState?.currentUser}
      access={access}
      labType={labType}
    />
  );
};

export default connect(({ bloodBankTransfer }: { bloodBankTransfer: StateType }) => {
  return {
    transfer: bloodBankTransfer,
  };
})(BloodBankTransferWrapper);
