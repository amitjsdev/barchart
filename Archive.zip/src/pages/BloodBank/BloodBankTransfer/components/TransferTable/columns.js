import React from 'react';
import moment from 'moment';
const DATE_FORMAT = 'YYYY-MM-DD';

export const IncomingColumns = [
  {
    title: 'Transfer No.',
    dataIndex: 'id',
    key: 'id',
  },
  {
    title: 'From Lab Type',
    dataIndex: 'fromLabType',
    key: 'fromLabType',
  },
  {
    title: 'From Region',
    dataIndex: 'fromRegionName',
    key: 'fromRegionName',
  },
  {
    title: 'From Location',
    dataIndex: 'fromLocationName',
    key: 'fromLocationName',
  },
  {
    title: 'Status',
    dataIndex: 'status',
    key: 'status',
  },
  {
    title: 'Created On',
    key: 'createdOn',
    dataIndex: 'createdAt',
    render: (text, record) => {
      return moment(text, DATE_FORMAT).format('YYYY-MM-DD');
    },
  },
];
export const OutcomingColumns = [
  {
    title: 'Transfer No.',
    dataIndex: 'id',
    key: 'id',
  },
  {
    title: 'To Lab',
    dataIndex: 'toLabType',
    key: 'toLabType',
  },
  {
    title: 'To Region',
    dataIndex: 'toRegionName',
    key: 'toRegionName',
  },
  {
    title: 'To Location',
    dataIndex: 'toLocationName',
    key: 'toLocationName',
  },
  {
    title: 'Status',
    dataIndex: 'status',
    key: 'status',
  },
  {
    title: 'Created On',
    key: 'createdOn',
    dataIndex: 'createdAt',
    render: (text, record) => {
      return moment(text, DATE_FORMAT).format('YYYY-MM-DD');
    },
  },
];
export const nestedColumns = [
  {
    title: 'Instrument Id',
    width: '200px',
    dataIndex: 'instrumentId',
    key: 'instrumentIds',
  },
  {
    title: 'Lab Type',
    width: '200px',
    dataIndex: 'labType',
    key: 'labTypes',
  },
  {
    title: 'Transaction Id',
    width: '150px',
    dataIndex: 'transactionId',
    key: 'transactionId',
  },
  {
    title: 'Updated At',
    width: '150px',
    dataIndex: 'updatedAt',
    key: 'updatedAt',
    render: (text, record) => moment(record.updatedAt).format('YYYY-MM-DD'),
  },
  {
    title: 'Created At',
    width: '150px',
    dataIndex: 'createdAt',
    key: 'createdAt',
    render: (text, record) => moment(record.createdAt).format('YYYY-MM-DD'),
  },
];
