import React from 'react';
import { useAccess } from 'umi';
import { Table, Space } from 'antd';
import './index.css';
import { nestedColumns, IncomingColumns, OutcomingColumns } from './columns';
import Modal from '../Modals/Modal';
import bloodBankService from '@/pages/BloodBank/services/bloodBank.service';


class TransferTable extends React.Component {
  state = {
    expandRowData: [],
    expandedRowKeys: [],
    pages:[0,2]
  };
  actionColumn = {
    title: 'Action',
    key: 'action',
    render: (text, record, index) => (
      <div>
        <Space size={12}>
          <Modal
            data={this.props.data}
            index={index}
            getTransfer={this.props.onChange}
            status={'rejected'}
          />
          <Modal
            data={this.props.data}
            index={index}
            getTransfer={this.props.onChange}
            status={'completed'}
          />
        </Space>
      </div>
    ),
  };
  keys: any[] = [];
componentDidUpdate(){
  this.getMoreTransferRequest(0, 1, 1);
}
  getExpandableData = (recordId, dataItems) => {
    this.keys[0] === recordId ? (this.keys = []) : (this.keys[0] = recordId);
    this.setState({
      expandRowData: [],
      expandedRowKeys: this.keys,
    });
    const data = dataItems;
    this.setState({
      expandRowData: data,
    });
  };

  expandedRowRender = () => (
    <Table columns={nestedColumns} dataSource={this.state.expandRowData} pagination={false} />
  );
   getMoreTransferRequest = (skip: any, pageNum: any, size: any) => {
    const {pages,data,getMoreTransferRequest}=this.props
    if (!pages.includes(pageNum)) {
    const addPage = [...pages, pageNum];
    skip = data.length; 
    getMoreTransferRequest({
      offset:skip,
      limit:20
    })
     this.props.setPages(addPage)
    }
   
  };
  render() {
    const { data, status, activeTab } = this.props;
    const columns =
      status === 'created' && activeTab === 'incoming'
        ? [...IncomingColumns, this.actionColumn]
        : activeTab === 'incoming'
        ? IncomingColumns
        : OutcomingColumns;
    return (
      <div>
        <div>
          <Table
            columns={columns}
            dataSource={data}
            size="small"
            rowKey={(record) => record.id}
            pagination={{ pageSize: 20, showSizeChanger: false }}
            onExpand={(expanded, record) => this.getExpandableData(record.id, record.items)}
            expandedRowRender={(record) => this.expandedRowRender()}
            expandIconColumnIndex={0}
            expandedRowKeys={this.state.expandedRowKeys}
            expandIconAsCell={false}
            
            onChange={(e) => {
              this.getMoreTransferRequest(0, +e.current + 1, e.pageSize);
            }}
          />
        </div>
      </div>
    );
  }
}

const TransferTableWrapper = (props: any) => <TransferTable {...props} access={useAccess()} />;
export default TransferTableWrapper;
