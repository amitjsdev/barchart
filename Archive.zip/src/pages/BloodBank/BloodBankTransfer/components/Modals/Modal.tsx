import React from 'react';
import { Modal, Button, Tooltip } from 'antd';
import { CheckOutlined } from '@ant-design/icons';
import { DeleteOutlined } from '@ant-design/icons';
import bgiService from '../../../services/bloodBank.service';

class ApproveRejectModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      loading: false,
    };
  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleOk = async (e) => {
    const { data, index } = this.props;
    const {status}=this.props
    this.setState({
      loading: true,
    });

    const _data = JSON.parse(JSON.stringify(data));
    await bgiService.updateTransferRequestStatus(_data[index].id,status);
    this.setState({
      visible: false,
      loading: false,
    });
    this.props.getTransfer();
  };

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  };

  render() {
    const { visible, loading } = this.state;
    const {status}=this.props
    return (
      <>
        <Tooltip title={status==="rejected"?"Reject":"Approve"}>
          <Button
            type="primary"
            style={this.props.style}
            shape="circle"
            icon={status==="rejected"?<DeleteOutlined/>:<CheckOutlined />}
            onClick={this.showModal}
          />
        </Tooltip>
        <Modal
          title="Transfer"
          visible={visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          maskClosable={false}
          footer={[
            <Button key="back" onClick={this.handleCancel} disabled={loading}>
              Cancel
            </Button>,
            <Button key="submit" type="primary" loading={loading} onClick={this.handleOk}>
              Submit
            </Button>,
          ]}
        >
          <span>{status==="rejected"?"Do you reject the transfer request?":"Do you approve the transfer request?"}</span>
        </Modal>
      </>
    );
  }
}

export default ApproveRejectModal;
