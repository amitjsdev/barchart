declare namespace BloodBank {
  export type LabType = 'centralbloodbank' | 'peripheralbloodbank' | 'branchbloodbank';

  export interface KpiCardProps {
    title: string;
    info?: any;
    filters?: any[];
    children?: React.ReactNode;
    location?: string;
    region?: string;
    labType?: string;
    onChange?: () => void;
  }

  export interface KpiStatisticsCardProps {
    title: string;
    info?: string;
    children?: React.ReactNode;
  }

  export interface BasicStatisticsProps {
    location?: string;
    labType?: LabType;
    region?: string;
  }

  export interface BasicChartProps {
    title: string;
    location?: string;
    labType?: LabType;
    region?: string;
  }

  export interface TotalSerologyTestsStatisticsProps extends BasicStatisticsProps {
    dateRangeFilter: DateRangeFilter;
  }

  export interface TotalNatTestsStatisticsProps extends BasicStatisticsProps {
    dateRangeFilter: DateRangeFilter;
  }

  export interface InventoryCompositionCardProps extends BasicChartProps {}

  export interface AverageConsumableDaysChartProps extends BasicChartProps {
    daysFilter: string;
  }

  export interface CategoryStockChartProps extends BasicChartProps {
    category: string;
  }

  export interface OutOfStockChartProps extends BasicChartProps {
    daysFilter: string;
  }

  export interface DailyTestsChartProps extends BasicChartProps {
    dateRangeFilter: DateRangeFilter;
  }

  export interface InventoryUpdateChartProps extends BasicChartProps {
    dateRangeFilter: DateRangeFilter;
    totalLabs: number;
  }

  export interface DateRangeFilter {
    dateRange: string[];
    granularity?: string;
  }
  
  export interface FilterSelectProps {
    options: FilterOption[];
    width?: string;
    onChange: (value: any) => void;
  }

  export interface FilterOption {
    value: any;
    label: string;
  }

  export interface KpiCardFilter {
    name: string;
    onChange: () => void;
    options: string[];
    selectedOption: string;
  }

  export interface DashboardContainerProps {
    children?: any;
  }

  export interface BasicDashboardProps {
    currentLab: string;
    currentRegion: string;
    dateRangeFilter: DateRangeFilter;
    totalLabCount: number;
    regionsName: string[];
    labType: LabType;
  }

  export interface LocationSelectorProps {
    regionsAndLabs: LocationSelectorOption[];
    onLabChange: (labName: string) => void;
    onRegionChange: (regionName: string) => void;
  }

  export interface LocationSelectorOption {
    value: string;
    label: string;
    children: {
      value: string;
      label: string;
    }[];
  }

  export interface RegionSelectorProps {
    regions: string[];
    onChange: () => void;
  }
  export interface CbbChartFilters {
    categoryStock: string;
  }

  export namespace API {
    export interface UpdateQuantityAndDailyConsumptionRequest {
      dailyConsumption: number;
      quantity: number;
    }
  }
 
}
