type FilterType = 'granularity' | 'dateRange';
type GranularityType = 'day' | 'week' | 'month' | 'year';
type DateRangeType = string[];

interface DateFilterType {
  granularity: GranularityType;
  dateRange: DateRangeType;
}

enum LabNames {
  'King Salman Military Hospital, Tabuk' = 'AFT',
  'The Military Hospital in Riyadh' = 'AFR',
  'King Fahd Military Medical Complex in Dhahran' = 'AFD',
  'King Faisal Specialist Hospital in Riyadh' = 'SHR',
  'King Faisal Specialist Hospital in Jeddah' = 'SHJ',
  'King Fahd Center for Research in Jeddah' = 'RLJ',
  'Guard Hospital in Jeddah' = 'NFJ',
  'King Abdulaziz City in the National Guard in Riyadh' = 'NFR',
  'Security Forces Hospital in Riyadh' = 'SFR',
  'King Khalid University Hospital in Riyadh' = 'UHR',
  'Royal Clinics' = 'RCT',
  'King Abdulaziz Hospital National Guard in Al-Ahsa' = 'NFH',
  'King Fahd Armed Forces Hospital in Jeddah' = 'AFJ',
  'King Faisal Specialized Hospital in Madinah' = 'SHM',
}

enum InflowOutflowPropertyNames {
  'Lab Name' = 'labName',
  'Code' = 'locationCode',
  'Inflow' = 'inflow',
  'Outflow' = 'outflow',
  'Pending Samples' = 'pendingInDay',
  'TAT More than 24 hrs' = 'tatOverDay',
  'Requested Samples but not received' = 'samplesNotReceived',
  'Pending Samples More than 24 hrs' = 'pendingOverDay',
  'Rejected Samples' = 'rejectedSamples',
  'Date' = 'date',
}

enum InflowOutflowMandatoryPropertyNames {
  'Code' = 'locationCode',
  'Inflow' = 'inflow',
  'Outflow' = 'outflow',
  'Pending Samples' = 'pendingInDay',
  'Pending Samples More than 24 hrs' = 'pendingOverDay',
  'Rejected Samples' = 'rejectedSamples',
  'Date' = 'date',
}

const INFLOW_OUTFLOW_FILE_COLUMNS = [
  'Lab Name',
  'Code',
  'Inflow',
  'Outflow',
  'Pending Samples',
  'TAT More than 24 hrs',
  'Requested Samples but not received',
  'Pending Samples More than 24 hrs',
  'Rejected Samples',
  'Date',
];

const INFLOW_OUTFLOW_MANDATORY_COLUMNS = [
  'Code',
  'Inflow',
  'Outflow',
  'Pending Samples',
  'Pending Samples More than 24 hrs',
  'Rejected Samples',
  'Date',
];

export {
  FilterType,
  GranularityType,
  DateRangeType,
  DateFilterType,
  LabNames,
  InflowOutflowPropertyNames,
  InflowOutflowMandatoryPropertyNames,
  INFLOW_OUTFLOW_FILE_COLUMNS,
  INFLOW_OUTFLOW_MANDATORY_COLUMNS,
};
