import { Card, Col, Divider, List, Popover, Row, Select, Spin, Typography } from 'antd';
import {
  ChartTitles,
  DAYS_TO_OOS_FILTER_OPTIONS,
} from '../../BloodBank/BloodBankDashboard/Constants';
import React, { useEffect, useState } from 'react';

import AverageConsumableDays from './components/AverageConsumableDaysChart/AverageConsumableDays';
import AvgDayStock from './components/AvgDayStock/AvgDaysStock';
import CategoryStockChart from '../BloodBankInsightsDashboard/components/StockChart/CategoryStockChart';
import ConsumableDays from './components/ConsumableDays/ConsumableDays';
import Consumption from './components/Consumption/Consumption';
import DateFilter from './components/DateFilter/DateFilter';
import FilterSelect from '../../BloodBank/BloodBankDashboard/components/FilterSelect/FilterSelect';
import { InfoCircleOutlined } from '@ant-design/icons';
import LocationSelector from './components/LocationSelector/LocationSelector';
import StatusFilterCard from '../../BloodBank/BloodBankDashboard/components/StatusFilter/StatusFilterCard';
import TotalNatTestsStatistics from './components/TotalNatTestsStatistics';
import TotalSerologyTestsStatistics from './components/TotalSerologyTestsStatistics';
import bloodBankService from '../../BloodBank/services/bloodBank.service';
import moment from 'moment';
import styles from './index.less';

const { Title, Text } = Typography;
const DATE_FORMAT = 'YYYY-MM-DD';

const labTypeKey = {
  allLocations: 'BloodBankInventories',
  branchbloodbank: 'BranchBloodBankInventories',
  centralbloodbank: 'CentralBloodBankInventories',
  peripheralbloodbank: 'PeripheralBloodBankInventories',
};
interface IKpiCardProps {
  title: string;
  info?: string;
  filters?: any;
  children?: React.ReactNode;
  location?: string;
}
const chartTitles = {
  AVG_DAY_STOCK: 'Average day stock',
  INVENTORY_COMPOSITION: 'Inventory composition',
  AVG_STOCK_DAYS: 'Average stock days',
  STOCK_CHART: 'Stock chart',
  OOS_CHART: 'Days to OOS',
  DAILY_TESTS: 'Daily tests',
  INVENTORY_UPDATE: 'Responses',
  STATUS_FILTER: 'Instrument Status',
};

const avgConsumableDaysFilters = {
  name: 'Category filter',
  onChange: (option: string) => {
    avgConsumableDaysFilters[0] = {
      ...avgConsumableDaysFilters,
      selectedOption: [option],
    };
  },
  options: [],
  selectedOption: '',
};
const KpiCard: React.FC<IKpiCardProps> = (props) => {
  return (
    <div className={`${styles.kpiCard} ${styles.kpiCardSm}`}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <div>
              <Text className={styles.chartTitle}>{props.title}</Text>
              {props.info ? (
                <Popover content={props.info} title="Info">
                  <InfoCircleOutlined style={{ padding: '8px' }} />
                </Popover>
              ) : null}
            </div>
          </Col>
        </Row>
      </div>
      <div className={styles.kpiCardContent}>{props.children}</div>
    </div>
  );
};

const itemExpiryFilters = [
  {
    name: 'Range filter',
    onChange: (option: string) => {
      itemExpiryFilters[0] = {
        ...itemExpiryFilters,
        selectedOption: [option],
      };
    },
    options: [
      { label: '< 1 month', value: '< 1 month' },
      { label: '1 - 3 months', value: '1 - 3 months' },
      { label: '3+ months', value: '3+ months' },
    ],
    selectedOption: '< 1 month',
  },
];

const AverageConsumableDaysChart: React.FC<IKpiCardProps> = (props) => {
  const { labtype, region, location, title, daysFilter } = props;
  const filter = {
    ...props.filters,
    options: props.regions.map((value) => {
      return { label: value, value };
    }),
  };

  // const chartDimension = avgConsumableDaysFilters[0].selectedOption;
  const [chartDimension, setChartDimension] = useState(['Riyadh']);
  // const [chartDimension, setChartDimension] = useState(avgConsumableDaysFilters[0]?.selectedOption);
  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;
  return (
    <div className={styles.kpiCard}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{title}</Text>
          </Col>
          <Col flex={2} className={styles.filters}>
            {props.children}
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <AverageConsumableDays
          labtype={labTypeKey[labtype]}
          region={region}
          daysFilter={daysFilter}
          location={location}
        />
      </div>
    </div>
  );
};

const KpiStatisticsCard: React.FC<IKpiStatisticsCardProps> = (props) => (
  <div className={styles.kpiStatisticsCard}>
    <div className={styles.kpiCardTitleBar}>
      <div>
        <Text className={styles.chartTitle}>{props.title}</Text>
        {props.info ? (
          <Popover content={props.info} title="Info">
            <InfoCircleOutlined style={{ padding: '8px' }} />
          </Popover>
        ) : null}
      </div>
    </div>
    <div className={styles.kpiStatisticsCardContent}>
      {/* <div>
        <Title level={3}>{props.value}</Title>
      </div> */}
      {props.children}
    </div>
  </div>
);
const DashboardWrapper = (props) => {
  const [bloodBankLabType, setBloodBankLabType] = useState('allLocations');
  const [locationVal, setLocationVal] = useState('All locations');
  const [labNames, setLabNames] = useState(['All locations']);
  const [regionsName, setRegionsNames] = useState(['All locations']);
  const [totalLabCount, setTotalLabCount] = useState(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [regionChart, setRegionChart] = useState('All locations');
  const [regionsAndLabs, setRegionsAndLabs] = useState([
    { value: 'allLocations', label: 'All locations', children: [] },
    { value: 'branchbloodbank', label: 'Branch Blood Bank', children: [] },
    { value: 'centralbloodbank', label: 'Central Blood Bank', children: [] },
    { value: 'peripheralbloodbank', label: 'Peripheral Blood Bank', children: [] },
  ]);
  const [currentLab, setCurrentLab] = useState('');
  const [currentRegion, setCurrentRegion] = useState('');
  const defaultFilterSetting = {
    granularity: 'day',
    dateRange: [moment().format(DATE_FORMAT), moment().format(DATE_FORMAT)],
  };
  const [dateRangeFilter, setDateRangeFilter] = useState(defaultFilterSetting);

  const onDateChange = (filter) => {
    setDateRangeFilter({
      granularity: dateRangeFilter.granularity,
      dateRange: [
        filter ? filter[0].format(DATE_FORMAT) : moment().format(DATE_FORMAT),
        filter ? filter[1].format(DATE_FORMAT) : moment().format(DATE_FORMAT),
      ],
    });
  };

  const onGranularityChange = (filter: any) => {
    setDateRangeFilter({
      granularity: filter,
      dateRange: dateRangeFilter.dateRange,
    });
  };

  const onlabChangeVal = (itemVal: any) => {
    if (itemVal[0]) {
      setBloodBankLabType(itemVal[0]);
      setRegionChart('All locations');
      setLocationVal('All locations');
    }
    if (itemVal[1]) {
      setRegionChart(itemVal[1]);
      setLocationVal('All locations');
    } else {
      setRegionChart('All locations');
    }
    if (itemVal[2]) {
      setLocationVal(itemVal[2]);
      // setRegionChart('All locations');
    }
  };

  const kpiTitles = {
    TOTAL_SEROLOGY_TESTS: 'Total serology tests',
    TOTAL_NAT_TESTS: 'Total NAT tests',
  };
  const locDropdown: {} = {};

  useEffect(() => {
    bloodBankService.getLocationsByLabType(bloodBankLabType).then((locations: any) => {
      setTotalLabCount(locations.length);
      const lab_Name = locations.map((lab: any) => {
        if (lab.region in locDropdown) {
          locDropdown[lab.region].push(lab.name);
        } else {
          locDropdown[lab.region] = [lab.name];
        }
      });
      const arr: any[] = [];
      Object.entries(locDropdown).map((entry) => {
        const temp = entry[1].map((data) => ({
          value: data,
          label: data,
        }));
        if (entry[0] !== 'null') {
          arr.push({
            value: entry[0],
            label: entry[0],
            children: temp,
          });
        }
      });

      //regionsAndLabs.push({arr});

      let dataFinal = regionsAndLabs.map((item) => {
        return {
          ...item,
          children: arr,
        };
      });
      setRegionsAndLabs(dataFinal);
      setLabNames(labNames.concat(lab_Name));
      bloodBankService.getRegionsByLabType(bloodBankLabType).then((region) => {
        const regionNames = region.map(({ name }) => name);
        // setRegionsNames(regionsName.concat(regionNames));
        setRegionsNames(regionNames);
      });

      setTimeout(() => {
        setCurrentLab('All locations');
        setCurrentRegion('All locations');
        setLoading(false);
      }, 1000);
    });
  }, [bloodBankLabType]);

  const ConsumableDaysChart: React.FC<any> = (props) => {
    const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;
    return (
      <div className={`${styles.kpiCard} ${styles.large}`}>
        <div className={styles.kpiCardTitleBar}>
          <Row style={{ flex: '1 1 auto' }} align="middle" justify="space-between">
            <Col>
              <Text className={styles.chartTitle}>Average Stock Days</Text>
            </Col>
          </Row>
        </div>
        <div className={contentCss}>
          <ConsumableDays {...props} />
        </div>
      </div>
    );
  };
  const ConsumptionChart: React.FC<any> = (props) => {
    const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;
    return (
      <div className={`${styles.kpiCard} ${styles.large}`}>
        <div className={styles.kpiCardTitleBar}>
          <Row style={{ flex: '1 1 auto' }} align="middle" justify="space-between">
            <Col>
              <Text className={styles.chartTitle}>Total Tests Done</Text>
            </Col>
          </Row>
        </div>
        <div className={contentCss}>
          <Consumption {...props} />
        </div>
      </div>
    );
  };
  const StockChart: React.FC<any> = (props) => {
    const { category, location, region } = props;
    const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;
    return (
      <div className={`${styles.kpiCard} ${styles.large}`}>
        <div className={contentCss}>
          <CategoryStockChart
            title={`${category} ${ChartTitles.STOCK_CHART}`}
            location={location}
            region={region}
            labType={labTypeKey[bloodBankLabType]}
            category={category}
          />
        </div>
      </div>
    );
  };
  const StockChartsCategory = [
    'Phenotyping',
    'Serology',
    'NAT',
    'Donation bags & Plasma',
    'Bacterial Detection',
  ];
  const daysToOosChartFilterOptions = DAYS_TO_OOS_FILTER_OPTIONS.map((option) => ({
    label: option,
    value: option,
  }));

  const [daysToOosChartFilter, setDaysToOosChartFilter] = useState(
    daysToOosChartFilterOptions[0].value,
  );

  const avgStockDaysChartFilterOptions = DAYS_TO_OOS_FILTER_OPTIONS.map((option) => ({
    label: option,
    value: option,
  }));

  const [avgStockDaysChartFilter, setAvgStockDaysChartFilter] = useState(
    avgStockDaysChartFilterOptions[0].value,
  );
  return (
    // <PageContainer className={styles.main} header={{ title: '' }}>
    <div className={styles.main}>
      <Spin spinning={loading} size="large" />
      <Row className={styles.locationPanel} align="middle" justify="space-between">
        <Col>
          <Title level={4}>Dashboard</Title>
        </Col>
        <Col style={{ padding: '0px' }}>
          {/* <LocationSelector onChange={setRegion} locations={labDropdowns} /> */}
          <LocationSelector
            onLabChange={onlabChangeVal}
            onRegionChange={setCurrentRegion}
            regionsAndLabs={regionsAndLabs}
          />
          <span style={{ paddingLeft: 8 }} />
          <DateFilter onDateChange={onDateChange} onGranularityChange={onGranularityChange} />
          {React.Children.map(props.children, (child) => {
            return (
              React.isValidElement(child) &&
              React.cloneElement(child, {
                currentLab,
                currentRegion,
                dateRangeFilter,
                totalLabCount,
                regionsName,
                labtype: bloodBankLabType,
              })
            );
          })}
        </Col>
      </Row>
      {/* KPI cards */}

      <Row gutter={[24, 24]}>
        <Col span={24}>
          <Row gutter={[24, 24]}>
            <Col xs={24} xl={8}>
              <Row gutter={[0, 0]}>
                <Col xs={24} md={12} xl={24}>
                  <KpiStatisticsCard title={kpiTitles.TOTAL_SEROLOGY_TESTS}>
                    <TotalSerologyTestsStatistics
                      location={locationVal}
                      region={regionChart}
                      dateRangeFilter={dateRangeFilter}
                      labtype={bloodBankLabType}
                    />
                  </KpiStatisticsCard>
                </Col>
                <Col xs={24} md={12} xl={24}>
                  <KpiStatisticsCard title={kpiTitles.TOTAL_NAT_TESTS}>
                    <TotalNatTestsStatistics
                      location={locationVal}
                      region={regionChart}
                      dateRangeFilter={dateRangeFilter}
                      labtype={bloodBankLabType}
                    />
                  </KpiStatisticsCard>
                </Col>
              </Row>
            </Col>
            <Col xs={24} xl={8}>
              <KpiCard
                title={chartTitles.AVG_DAY_STOCK}
                info={() => (
                  <div>
                    <p>
                      <b>&lt; 15:</b> OOS
                    </p>
                    <p>
                      <b>15-30:</b> NOOS,
                    </p>
                    <p>
                      <b>30-80:</b> SS,
                    </p>
                    <p>
                      <b>&gt; 80:</b> OS
                    </p>
                  </div>
                )}
              >
                <AvgDayStock
                  location={locationVal}
                  region={regionChart}
                  labType={labTypeKey[bloodBankLabType]}
                />
              </KpiCard>
            </Col>
            <Col xs={24} xl={8}>
              <StatusFilterCard
                title={chartTitles.STATUS_FILTER}
                location={locationVal}
                region={regionChart}
                labType={bloodBankLabType}
              />
            </Col>
          </Row>

          <Row gutter={[24, 24]}>
            <Col span={24}>
              <AverageConsumableDaysChart
                title={chartTitles.AVG_STOCK_DAYS}
                filters={avgConsumableDaysFilters}
                location={locationVal}
                regions={regionsName}
                region={regionChart}
                labtype={bloodBankLabType}
                daysFilter={avgStockDaysChartFilter}
              >
                {' '}
                <FilterSelect
                  width="180px"
                  options={avgStockDaysChartFilterOptions}
                  onChange={setAvgStockDaysChartFilter}
                />
              </AverageConsumableDaysChart>
            </Col>
          </Row>

          <Row gutter={[24, 24]}>
            <Col xs={24} md={12}>
              <ConsumableDaysChart
                dateRangeFilter={dateRangeFilter}
                location={locationVal}
                region={regionChart}
                filters={itemExpiryFilters}
                labtype={bloodBankLabType}
              />
            </Col>
            <Col xs={24} md={12}>
              <ConsumptionChart
                dateRangeFilter={dateRangeFilter}
                location={locationVal}
                region={regionChart}
                filters={itemExpiryFilters}
                labtype={bloodBankLabType}
              />
            </Col>
          </Row>
        </Col>
        {bloodBankLabType !== 'allLocations' && (
          <Col span={24}>
            <Row gutter={[24, 24]}>
              {StockChartsCategory &&
                StockChartsCategory.map((item) => {
                  return (
                    <Col xs={24} md={12}>
                      <StockChart category={item} location={locationVal} region={regionChart} />
                    </Col>
                  );
                })}
            </Row>
          </Col>
        )}
      </Row>
    </div>
  );
};

export default DashboardWrapper;
