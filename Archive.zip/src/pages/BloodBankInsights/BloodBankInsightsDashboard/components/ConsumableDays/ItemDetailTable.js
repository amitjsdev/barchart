import React from 'react';
import { Table, Spin } from 'antd';

const getFormattedColumns = () => {
  return [
    {
      dataIndex: 'IRegions.name',
      shortTitle: 'Region',
      title: 'Region Name',
      type: 'text',
    },
    {
      dataIndex: 'BloodBankInventories.consumableDays',
      shortTitle: 'Consumable Days',
      title: 'Consumable Days',
      type: 'number',
      render: (text) => Math.round(text)
    },
  ];
};

const getFormattedData = (dataSource) => {
  return dataSource;
};

const ItemDetailTable = ({ resultSet, pivotConfig }) => {
  return resultSet ? (
    // <div className={styles.tableContainer}>
    <Table
      pagination={false}
      columns={getFormattedColumns()}
      dataSource={getFormattedData(resultSet.tablePivot(pivotConfig))}
    />
  ) : (
    // </div>
    <Spin />
  );
};

export default ItemDetailTable;
