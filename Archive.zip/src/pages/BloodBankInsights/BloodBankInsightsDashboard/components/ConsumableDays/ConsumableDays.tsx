import React, { useState } from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer, useCubeQuery } from '@cubejs-client/react';
import { Spin, Empty, Modal, Row, Col, Typography } from 'antd';
import { Chart, Axis, Tooltip, Interval, Geom, Coord, Legend } from 'bizcharts';

import { getCubejsApiParams } from '@/services/cubejs';
import { LabTypeNameMap } from '../../Constants';
import ItemDetailTable from './ItemDetailTable';

const colors = ['color', ['#753BBD', '#008755', '#009ACE', '#F2CD00', '#753BBD']];

const MachineTestCount = (props) => {
  const { Title, Paragraph, Text } = Typography;
  const { dateRangeFilter, region, expiryfilter ,labtype,location} = props;

  const DATE_FORMAT = 'YYYY-MM-DD';

  const [drillDownQuery, setDrillDownQuery] = useState();
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [tableDescription, setTableDescription] = useState();

  const formatData = (data) => {
    return data.map((item) => {
      const formattedItem = { ...item };
      if (formattedItem.x === 'peripheralbloodbank') {
        formattedItem.x = 'Peripheral Blood Bank';
        formattedItem.color = 'Peripheral Consumable Days';
        return formattedItem;
      } else if (formattedItem.x === 'centralbloodbank') {
        formattedItem.x = 'Central Blood Bank';
        formattedItem.color = 'Central Consumable Days';
        return formattedItem;
      } else if (formattedItem.x === 'branchbloodbank') {
        formattedItem.x = 'Branch Blood Bank';
        formattedItem.color = 'Branch Consumable Days';
        return formattedItem;
      }
    });
  };

  const stackedChartData = (resultSet) => {
    const data = resultSet
      .pivot()
      .map(({ xValues, yValuesArray }) =>
        yValuesArray.map(([yValues, m]) => ({
          x: resultSet.axisValuesString(xValues, ', '),
          color: resultSet.axisValuesString(yValues, ', '),
          measure: m && Number.parseFloat(m),
        })),
      )
      .reduce((a, b) => a.concat(b), []);
    return formatData(data);
    // return data;
  };

  const cubejsParams = getCubejsApiParams();

  const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

  const filters = [];

  const baseItemDetailsQuery = {
    measures: ['BloodBankInventories.consumableDays'],
    timeDimensions: [],
    dimensions: ['IRegions.name'],
    filters: [],
    segments: [],
    order: {},
  };

  const getItemDetailQuery = (bloodBankType: BloodBank.LabType) => {
    const filters = [];

    if (bloodBankType.length) {
      filters.push({
        dimension: 'Locations.labType',
        operator: 'equals',
        values: [bloodBankType],
      });
    }
    const order = {};
    order['BloodBankInventories.consumableDays'] = 'desc';

    return { ...baseItemDetailsQuery, filters, order };
  };

  if (region && region !== 'All locations') {
    filters.push({ dimension: 'IRegions.name', operator: 'equals', values: [region] });
  }
  if (labtype && labtype !== 'allLocations') {
    filters.push({ dimension: 'Locations.labType', operator: 'equals', values: [labtype] });
  }
  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['BloodBankInventories.consumableDays'],
      timeDimensions: [],
      dimensions: ['BloodBankInventories.labType'],
      filters,
      segments: [],
      order: {},
    },
    {
      cubejsApi,
    },
  );
  const drillDownResponse = useCubeQuery(drillDownQuery, {
    skip: !drillDownQuery,
    cubejsApi,
  });

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const handleClickOnChart = (data) => {
    const bloodBankTypeName = data.x;
    setDrillDownQuery(getItemDetailQuery(LabTypeNameMap[bloodBankTypeName]));

    if (drillDownResponse) {
      setTableDescription({
        bloodBankTypeName,
      });
      setIsModalVisible(true);
    }
  };

  const handleModalOk = () => setIsModalVisible(false);
  const handleModalCancel = () => setIsModalVisible(false);

  const BarRender = ({ resultSet }) => {
    if (resultSet?.loadResponses[0]?.data.length > 0) {
      const data = stackedChartData(resultSet);
      return (
        <Chart
          scale={{ x: { tickCount: 8 } }}
          data={stackedChartData(resultSet)}
          autoFit
          padding="auto"
          onIntervalClick={(e, chart) => {
            handleClickOnChart(e.data.data);
          }}
        >
          <Axis name="x" label={false} tickLine={false} />
          <Axis name="measure" />
          <Tooltip />
          <Geom type="interval" position="x*measure" color={colors} />
        </Chart>
      );
    }
    return <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
  };

  const ModalHeader = () => (
    <Row>
      <Col>
        <Title level={4}>{tableDescription.bloodBankTypeName}</Title>
        {/* <Text type="secondary" level={5}>
          {tableDescription.region}
        </Text> */}
      </Col>
    </Row>
  );

  return (
    <>
      <BarRender resultSet={resultSet} />
      <Modal
        title={<ModalHeader />}
        centered
        visible={isModalVisible}
        width={720}
        onOk={handleModalOk}
        onCancel={handleModalCancel}
        destroyOnClose
        footer={false}
      >
        <ItemDetailTable
          resultSet={drillDownResponse.resultSet}
          pivotConfig={drillDownResponse.pivotConfig || null}
        />
      </Modal>
    </>
  );
};

export default MachineTestCount;
