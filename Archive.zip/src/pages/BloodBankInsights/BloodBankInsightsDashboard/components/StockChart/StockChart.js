import React, { useState } from 'react';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { Spin, Empty, Modal, Row, Col, Typography } from 'antd';
import { Chart, Axis, Geom } from 'bizcharts';

import { getCubejsApiParams } from '@/services/cubejs';
import { REGION_FILTER_DIMENSION } from '../../Constants';
import ItemDetailTable from './ItemDetailTable';

const colors = ['color', ['#753BBD']];

const StockChart = (props) => {
  const { Title, Paragraph, Text } = Typography;
  const { location, category, labType, region } = props;
  const [drillDownQuery, setDrillDownQuery] = useState();
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [tableDescription, setTableDescription] = useState();

  const filters = [
    {
      dimension: 'Products.classification',
      operator: 'equals',
      values: [category],
    },
  ];

  if (location && location !== 'All locations') {
    filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
  }

  if (region && region !== 'All locations') {
    filters.push({ dimension: REGION_FILTER_DIMENSION, operator: 'equals', values: [region] });
  }

  const formatData = (data) => {
    return data.map((item) => {
      const formattedItem = { ...item };

      if (formattedItem.color.endsWith('availableQuantities')) {
        formattedItem.color = 'Available quantities';
        return formattedItem;
      }
    });
  };

  const stackedChartData = (resultSet) => {
    const data = resultSet
      .pivot()
      .map(({ xValues, yValuesArray }) =>
        yValuesArray.map(([yValues, m]) => ({
          x: resultSet.axisValuesString(xValues, ', '),
          color: resultSet.axisValuesString(yValues, ', '),
          measure: m && Number.parseFloat(m),
        })),
      )
      .reduce((a, b) => a.concat(b), []);

    return formatData(data);
    // return data;
  };

  const cubejsParams = getCubejsApiParams();

  const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

  const baseDrillDownQuery = {
    measures: [`${labType}.availableQuantities`],
    dimensions: ['Products.description'],
  };

  const getItemDetailQuery = (machineName) => {
    const filters = [
      {
        dimension: 'Products.category',
        operator: 'equals',
        values: [machineName],
      },
    ];

    if (machineName.length && location && location !== 'All locations') {
      filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
    }
    if (machineName.length && region && region !== 'All locations') {
      filters.push({ dimension: REGION_FILTER_DIMENSION, operator: 'equals', values: [region] });
    }

    const order = {};
    // order[stockType] = 'desc';

    return { ...baseDrillDownQuery, filters };
  };

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      dimensions: ['Products.category'],
      measures: [`${labType}.availableQuantities`],
      filters,
    },
    {
      cubejsApi,
    },
  );

  const drillDownResponse = useCubeQuery(drillDownQuery, {
    skip: !drillDownQuery,
    cubejsApi,
  });

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const handleClickOnChart = (data) => {
    const machine = data.x;

    setDrillDownQuery(getItemDetailQuery(machine));

    let selectedLocation = 'All locations';

    if (location !== 'All locations') selectedLocation = location;

    if (region !== 'All locations') selectedLocation = region;

    if (drillDownResponse) {
      setTableDescription({
        machineFullName: data.x,
        machineName: data.x,
        location: selectedLocation,
      });
      setIsModalVisible(true);
    }
  };

  const handleModalOk = () => setIsModalVisible(false);
  const handleModalCancel = () => setIsModalVisible(false);

  const BarRender = ({ resultSet }) => {
    if (resultSet?.loadResponses[0]?.data.length > 0) {
      return (
        <Chart
          scale={{ x: { tickCount: 8 } }}
          data={stackedChartData(resultSet)}
          autoFit
          padding="auto"
          onIntervalClick={(e, chart) => {
            handleClickOnChart(e.data.data);
          }}
        >
          <Axis name="x" label={false} tickLine={false} />
          <Axis name="measure" />
          {/* <Tooltip>
            {(title, items) => {
              
              const itemTitle = items[0].title;
              
              return (
                <div style={{ padding: '10px' }}>
                  <div>{itemTitle?.value}</div>
                  <br />
                  <div>Test Count : {items[0]?.value}</div>
                </div>
              );
            }}
          </Tooltip> */}
          <Geom type="interval" position="x*measure" color={colors} />
        </Chart>
      );
    }
    return <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
  };

  const ModalHeader = () => (
    <Row>
      <Col>
        <Title level={4}>{tableDescription.machineFullName}</Title>
        <Text type="secondary" level={5}>
          {tableDescription.location}
        </Text>
      </Col>
    </Row>
  );

  return (
    <>
      <BarRender resultSet={resultSet} />
      <Modal
        title={<ModalHeader />}
        centered
        visible={isModalVisible}
        width={720}
        onOk={handleModalOk}
        onCancel={handleModalCancel}
        destroyOnClose
        footer={false}
      >
        <ItemDetailTable
          resultSet={drillDownResponse.resultSet}
          pivotConfig={drillDownResponse.pivotConfig || null}
        />
      </Modal>
    </>
  );
};

export default StockChart;
