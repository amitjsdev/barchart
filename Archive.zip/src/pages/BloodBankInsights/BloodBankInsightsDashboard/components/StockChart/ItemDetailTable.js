import React from 'react';
import { Table, Spin } from 'antd';

const getFormattedColumns = (defaultColumns) => {
  return [
    {
      dataIndex: defaultColumns[0].dataIndex,
      key: defaultColumns[0].key,
      shortTitle: 'Description',
      title: 'Products Description',
      type: 'text',
    },
    {
      dataIndex: defaultColumns[1].dataIndex,
      key: defaultColumns[1].key,
      shortTitle: 'Quantities',
      title: 'Available Quantities',
      type: 'number',
    },
  ];
};

const ItemDetailTable = ({ resultSet, pivotConfig }) => {
  return resultSet ? (
    <Table
      pagination={false}
      columns={getFormattedColumns(resultSet.tableColumns(pivotConfig))}
      dataSource={resultSet.tablePivot(pivotConfig)}
    />
  ) : (
    <Spin />
  );
};

export default ItemDetailTable;
