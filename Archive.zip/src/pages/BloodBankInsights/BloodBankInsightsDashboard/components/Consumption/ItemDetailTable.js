import React from 'react';
import { Table, Spin } from 'antd';

const getFormattedColumns = () => {
  return [
    {
      dataIndex: 'IRegions.name',
      shortTitle: 'Regions Name',
      title: 'Regions Name',
      type: 'number',
    },
    {
      dataIndex: 'DailyConsumptions.consumption',
      shortTitle: 'Daily Consumption',
      title: 'Daily Consumption',
      type: 'number',
    },
  ];
};

const getFormattedData = (dataSource) => {
  return dataSource;
};

const ItemDetailTable = ({ resultSet, pivotConfig }) => {
  return resultSet ? (
    // <div className={styles.tableContainer}>
    <Table
      pagination={false}
      columns={getFormattedColumns()}
      dataSource={getFormattedData(resultSet.tablePivot(pivotConfig))}
    />
  ) : (
    // </div>
    <Spin />
  );
};

export default ItemDetailTable;
