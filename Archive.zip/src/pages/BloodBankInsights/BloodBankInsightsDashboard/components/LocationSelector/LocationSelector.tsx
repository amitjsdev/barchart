import React, { useEffect } from 'react';
import { Select, Cascader } from 'antd';
import { connect } from 'react-redux';

import { DEFAULT_LOCATION_KEY } from '../../Constants';

const LocationSelector: React.FC<BloodBank.LocationSelectorProps> = (props) => {
  const { regionsAndLabs, onLabChange, onRegionChange,setBloodBankLabType } = props;
  const onChange = (value) => {
    const [region, lab] = value;
    if (value) {
      onLabChange(value);
      onRegionChange(DEFAULT_LOCATION_KEY);
    } else {
      onLabChange(DEFAULT_LOCATION_KEY);
      onRegionChange(region);
    }
  };

  return (
    <Cascader
      allowClear={false}
      options={regionsAndLabs}
      onChange={(value) => onChange(value)}
      changeOnSelect
      defaultValue={[DEFAULT_LOCATION_KEY]}
      placeholder="Please select"
      displayRender={(value) => {
        const [location,region, lab] = value;
        return lab || region||location;
      }}
    />
  );
};

export default LocationSelector;