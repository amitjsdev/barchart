import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Row, Col, Statistic, Spin, Space, Typography } from 'antd';
import { InboxOutlined } from '@ant-design/icons';

import { getCubejsApiParams } from '@/services/cubejs';
import { REGION_FILTER_DIMENSION } from '../Constants';

const { Text } = Typography;

const numberRender = ({ resultSet }) => (
  <Row type="flex" justify="center" align="middle" style={{ height: '100%' }}>
    <Col>
      {resultSet.seriesNames().map((s) => (
        <Statistic value={Math.round(resultSet.totalRow()[s.key])} />
      ))}
    </Col>
  </Row>
);

const cubejsParams = getCubejsApiParams();

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) => {
  const data = resultSet?.loadResponses[0]?.data;
  const result = (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
    (error && error.toString()) || <Spin />;

  return data && data.length && data[0]['DailyConsumptions.consumption'] ? (
    result
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

const ChartRenderer: React.FC<BloodBank.TotalNatTestsStatisticsProps> = (props) => {
  const { dateRangeFilter, location, labtype, region } = props;
  const filters = [
    {
      member: 'DailyConsumptions.consumptiondate',
      operator: 'inDateRange',
      values: dateRangeFilter.dateRange,
    },
    {
      dimension: 'Products.classification',
      operator: 'equals',
      values: ['NAT'],
    },
  ];

  if (location && location !== 'All locations') {
    filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
  }
  if (labtype && labtype !== 'allLocations') {
    filters.push({
        dimension: 'Locations.labType',
        operator: 'equals',
        values: [labtype],
      });
  }else {
      filters.push({
        dimension: 'Locations.labType',
        operator: 'contains',
        values: ['branchbloodbank', 'peripheralbloodbank', 'centralbloodbank'],
      });
    }
  if (region && region !== 'All locations') {
    filters.push({ dimension: REGION_FILTER_DIMENSION, operator: 'equals', values: [region] });
  }

  return (
    <QueryRenderer
      query={{
        measures: ['DailyConsumptions.consumption'],
        dimensions: ['Products.classification'],
        timeDimensions: [],
        filters,
      }}
      cubejsApi={cubejsApi}
      render={renderChart(numberRender, {
        x: [],
        y: ['measures'],
        fillMissingDates: true,
        joinDateRange: false,
      })}
    />
  );
};

export default ChartRenderer;
