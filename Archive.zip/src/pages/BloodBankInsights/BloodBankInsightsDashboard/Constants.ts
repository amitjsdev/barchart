
enum LabTypeNameMap {
  'Branch Blood Bank' = 'branchbloodbank',
  'Central Blood Bank' = 'centralbloodbank',
  'Peripheral Blood Bank' = 'peripheralbloodbank',
}
enum ChartTitles {
  STOCK_CHART = 'Stock chart',
}

enum DaysToOosFilters {
  LESS_THAN_FIFTEEN_DAYS = '< 15 days (OOS)',
  FIFTEEN_TO_THIRTY_DAYS = '15 - 30 days (NOOS)',
  THIRTY_TO_EIGHTY_DAYS = '30 - 80 days (Safe stock)',
  MORE_THAN_EIGHTY_DAYS = '> 80 days (OS)',
}

const DAYS_TO_OOS_FILTER_OPTIONS = [
  DaysToOosFilters.LESS_THAN_FIFTEEN_DAYS,
  DaysToOosFilters.FIFTEEN_TO_THIRTY_DAYS,
  DaysToOosFilters.THIRTY_TO_EIGHTY_DAYS,
  DaysToOosFilters.MORE_THAN_EIGHTY_DAYS,
];
const DATE_FORMAT = 'YYYY-MM-DD';
const DEFAULT_LOCATION_KEY = 'All locations';
const REGION_FILTER_DIMENSION = 'IRegions.name';

export {
  LabTypeNameMap,
  DaysToOosFilters,
  DAYS_TO_OOS_FILTER_OPTIONS,
  DATE_FORMAT,
  DEFAULT_LOCATION_KEY,
  REGION_FILTER_DIMENSION,
  ChartTitles
};
