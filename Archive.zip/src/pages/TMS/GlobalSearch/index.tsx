import React, { useState } from 'react';
import { Empty } from 'antd';

import moment from 'moment';
import SearchBar from './components/SearchBar/SearchBar';
import SearchResultTable from './components/SearchResultTable/SearchResultTable';
import { getSearchResults } from './services';
import { SEARCH_CATEGORIES } from './Constants';

import styles from './index.less';
import PocDetails from './components/PocDetails/PocDetails';
import PatientDetails from './components/PatientDetails/PatientDetails';

const date = moment().format('L');
const SearchResults = (props) => {
  const { category, results, poc, patient } = props;

  const resultContainer = {
    tickets: <SearchResultTable category={category} results={results} date={date} />,
    poc: <PocDetails poc={poc} date={date} />,
    'patient-code': <PatientDetails patient={patient} date={date} />,
  };

  return resultContainer[category];
};

export default () => {
  const [results, setResults] = useState([]);
  const [currentCategory, setCurrentCategory] = useState(SEARCH_CATEGORIES[0]);
  const [poc, setPoc] = useState();
  const [patientDetails, setPatientDetails] = useState();

  const handleCategoryChange = (newCategory) => {
    setCurrentCategory(newCategory);
    setResults([]);
    setPoc(null);
    setPatientDetails(null);
  };

  const getResults = async (searchTerm) => {
    if (currentCategory === 'tickets') {
      const regionId = undefined;
      const searchResults = await getSearchResults(regionId, searchTerm, currentCategory);

      setResults(searchResults.filter((ticket) => ticket.ticketStatus === 'success')); // Filter NHCC tickets
    } else if (currentCategory === 'poc') {
      setPoc(searchTerm);
    } else if (currentCategory === 'patient-code') {
      const regionId = undefined;
      const searchResults = await getSearchResults(regionId, searchTerm, currentCategory);

      setPatientDetails(searchResults);
    }
  };

  return (
    <div className={styles.main}>
      <div className={styles.searchBarContainer}>
        <SearchBar
          searchCategories={SEARCH_CATEGORIES}
          handleSearchResults={getResults}
          onCategoryChange={handleCategoryChange}
        />
      </div>
      <div className={styles.resultContainer}>
        {results.length || poc || patientDetails ? (
          <SearchResults
            category={currentCategory}
            results={results}
            poc={poc}
            patient={patientDetails}
          />
        ) : (
          <Empty />
        )}
      </div>
    </div>
  );
};
