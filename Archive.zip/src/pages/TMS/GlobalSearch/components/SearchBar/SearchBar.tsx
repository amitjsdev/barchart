import React, { useState } from 'react';
import { Row, Col, Spin, Input, Select, AutoComplete } from 'antd';
import debounce from 'lodash.debounce';

import { getAutocompleteResults } from '../../services';
import { ITicketsAutocomplete } from '../../Types';
import { AutocompleteCategories, SearchCategoryNames } from '../../Constants';

import styles from './index.less';

const { Option } = Select;

export default (props) => {
  const { handleSearchResults, searchCategories, onCategoryChange } = props;
  const [currentCategory, setCurrentCategory] = useState(searchCategories[0]);
  const [options, setOptions] = useState([]);
  const [isLoading, setLoading] = useState(false);

  const getRelatedSearchTerms = async (searchText, currentCategory) => {
    setLoading(true);
    const results: ITicketsAutocomplete = await getAutocompleteResults(searchText, currentCategory);

    const parsedResults = Object.keys(results)
      .map((category) => {
        return {
          label: AutocompleteCategories[category],
          options: results[category].map((value) => ({ value })),
        };
      })
      .filter((category) => category.options.length);

    setOptions(parsedResults);
    setLoading(false);
  };

  const handleSearch = debounce(getRelatedSearchTerms, 500);

  const handleCategoryChange = (category) => {
    setCurrentCategory(category);
    onCategoryChange(category);
    setOptions([]);
  };

  return (
    <div className={styles.container}>
      <Row gutter={[24, 24]} align="middle" justify="center">
        <Col>
          <Input.Group size="large">
            <Row>
              <Col span={8}>
                <Select
                  defaultValue={searchCategories[0]}
                  style={{ width: 200 }}
                  onChange={(value) => handleCategoryChange(value)}
                >
                  {searchCategories.map((category) => (
                    <Option value={category}>{SearchCategoryNames[category]}</Option>
                  ))}
                </Select>
              </Col>
              <Col span={16}>
                <AutoComplete
                  style={{ width: 400 }}
                  options={options}
                  onChange={() => setOptions([])}
                  onSearch={(searchText) => {
                    if (searchText && searchText.length >= 3)
                      handleSearch(searchText, currentCategory);
                  }}
                  onSelect={handleSearchResults}
                  notFoundContent="No data found"
                  allowClear
                />
              </Col>
            </Row>
          </Input.Group>
        </Col>
        <Col>
          <Spin spinning={isLoading} />
        </Col>
      </Row>
    </div>
  );
};
