import React, { useState } from 'react';
import { List, Statistic, Typography, Space, Row, Col, Spin, Button } from 'antd';
import { InboxOutlined } from '@ant-design/icons';

import { jsPDF } from 'jspdf';
import { useCubeData } from '../../services';
import { PocKpiNames, POC_KPIS } from '../../Constants';

import styles from './index.less';

const { Text, Title } = Typography;
const chartVal = {
  efficiency: '',
  samplesInTransit: '',
  missingSamples: '',
  tat: '',
  completedTrips: '',
};

const showPDFVal = {
  efficiency: 'SLA compliance',
  samplesInTransit: 'Samples in transit',
  missingSamples: 'Missing Samples',
  tat: 'TAT',
  completedTrips: 'Completed Trips',
};

const Efficiency = (props) => {
  const { pointOfCollection, date } = props;

  const measures = ['PodData.networkEfficiency'];
  const filters = [
    { dimension: 'PodData.pointOfCollection', operator: 'equals', values: [pointOfCollection] },
    {
      dimension: 'PodData.turnAroundTime',
      operator: 'gt',
      values: ['3'],
    },
  ];
  const query = {
    measures,
    filters,
  };
  const cubeData = useCubeData(query);

  if (!cubeData) {
    return null;
  }

  const { isLoading, dataSource, progress } = cubeData;

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  let efficiency = null;

  if (dataSource?.length) {
    efficiency = dataSource[0][measures[0]];
    chartVal.efficiency = `${parseFloat(efficiency).toFixed(2)}%`;
  }

  return efficiency ? (
    <Statistic value={parseFloat(efficiency).toFixed(2)} suffix="%" />
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

const TAT = (props) => {
  const { pointOfCollection } = props;
  const measures = ['PodData.turnAroundTime'];
  const filters = [
    { dimension: 'PodData.pointOfCollection', operator: 'equals', values: [pointOfCollection] },
  ];
  const query = {
    measures,
    filters,
  };
  const cubeData = useCubeData(query);

  if (!cubeData) {
    return null;
  }

  const { isLoading, dataSource, progress } = cubeData;

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  let tat = null;

  if (dataSource?.length) {
    tat = dataSource[0][measures[0]];
    chartVal.tat = `${Math.round(tat).toFixed(2)} hrs`;
  }

  return tat ? (
    <Statistic value={Math.round(tat)} suffix="hrs" />
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

const MissingSamples = (props) => {
  const { pointOfCollection } = props;
  const measures = ['PodData.invalidSamples'];
  const filters = [
    { dimension: 'PodData.pointOfCollection', operator: 'equals', values: [pointOfCollection] },
  ];
  const query = {
    measures,
    filters,
  };
  const cubeData = useCubeData(query);

  if (!cubeData) {
    return null;
  }

  const { isLoading, dataSource, progress } = cubeData;

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  let missingSamples = null;

  if (dataSource?.length) {
    missingSamples = dataSource[0][measures[0]];
    chartVal.missingSamples = missingSamples.toString();
  }

  return missingSamples !== null || undefined ? (
    <Statistic value={missingSamples} />
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

const SamplesInTransit = (props) => {
  const { pointOfCollection } = props;
  const measures = ['PodData.inTransitSamples'];
  const filters = [
    { dimension: 'PodData.pointOfCollection', operator: 'equals', values: [pointOfCollection] },
  ];
  const query = {
    measures,
    filters,
  };
  const cubeData = useCubeData(query);

  if (!cubeData) {
    return null;
  }

  const { isLoading, dataSource, progress } = cubeData;

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  let inTransitSamples = null;

  if (dataSource?.length) {
    inTransitSamples = dataSource[0][measures[0]];
    chartVal.samplesInTransit = inTransitSamples.toString();
  }

  return inTransitSamples !== null || undefined ? (
    <Statistic value={inTransitSamples} />
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

const CompletedTrips = (props) => {
  const { pointOfCollection } = props;
  const measures = ['PodData.count'];
  const filters = [
    { dimension: 'PodData.pointOfCollection', operator: 'equals', values: [pointOfCollection] },
    {
      dimension: 'PodData.status',
      operator: 'equals',
      values: ['completed'],
    },
  ];
  const query = {
    measures,
    filters,
    dimensions: ['PodData.status'],
  };
  const cubeData = useCubeData(query);

  if (!cubeData) {
    return null;
  }

  const { isLoading, dataSource, progress } = cubeData;

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  let completedTrips = null;

  if (dataSource?.length) {
    completedTrips = dataSource[0][measures[0]];
    chartVal.completedTrips = completedTrips.toString();
  }

  return completedTrips !== null || undefined ? (
    <Statistic value={completedTrips} />
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

export default (props) => {
  const { poc, date } = props;

  const [count, setCount] = useState(0);

  const setIncrement = () => {
    setCount(count + 1);
  };

  const dataSource = [
    {
      kpi: 'efficiency',
      value: <Efficiency pointOfCollection={poc} />,
    },
    { kpi: 'tat', value: <TAT pointOfCollection={poc} /> },
    {
      kpi: 'missingSamples',
      value: <MissingSamples pointOfCollection={poc} />,
    },
    {
      kpi: 'samplesInTransit',
      value: <SamplesInTransit pointOfCollection={poc} />,
    },
    { kpi: 'completedTrips', value: <CompletedTrips pointOfCollection={poc} /> },
  ];

  const convertInPDF = () => {
    const doc = new jsPDF();

    //
    const str = Object.entries(chartVal).reduce((text, cur) => {
      const newText = `${text}${showPDFVal[cur[0]]}: ${cur[1]}` + `\n`;
      return newText;
    }, '');

    doc.text(str, 10, 10);
    doc.save(`${date}` + '-' + 'POC' + `${poc}`);
  };

  return (
    <div className={styles.box}>
      <List
        bordered
        header={<Title level={4}>{poc}</Title>}
        className={styles.list}
        dataSource={dataSource}
        renderItem={(item) => (
          <List.Item>
            <Row className={styles.listItem} align="middle" justify="space-between">
              <Col>
                <Text strong>{PocKpiNames[item.kpi]}</Text>
              </Col>
              <Col>{item.value}</Col>
            </Row>
          </List.Item>
        )}
      />
      <br />
      <Button type="primary" onClick={convertInPDF} className={styles.button}>
        Download as PDF
      </Button>
    </div>
  );
};
