import React from 'react';
import { Table, Tag, Button, Typography, Tooltip, Modal } from 'antd';
import { DownloadOutlined, FileDoneOutlined } from '@ant-design/icons';
import moment from 'moment';
import { jsPDF } from 'jspdf';

import { ITableColumn } from '../../Types';
import {
  PriorityColors,
  TicketPropertyNames,
  TicketTableProperties,
  TicketPropertySuffix,
  TicketPropertyOrder,
  DATE_FORMAT,
} from '../../Constants';
import tmsService from '../../../services/tms.service';

import styles from './index.less';

const { Text } = Typography;

const getFormattedValueAndLabel = (
  ticketProperty: string,
  ticket: Tms.Ticket,
): { label: string; value: string; order: number } => {
  const formattedData = {
    order: TicketPropertyOrder[ticketProperty],
    label: TicketPropertyNames[ticketProperty],
    value: '',
  };

  if (ticketProperty === TicketTableProperties.DUE_DATE) {
    formattedData.value = moment(ticket.dueDate).format(DATE_FORMAT);
  } else if (ticketProperty === TicketTableProperties.TAT) {
    formattedData.value = (parseInt(ticket.turnAroundTime, 10) / 60).toFixed(2);
  } else if (
    [TicketTableProperties.PRIORITY, TicketTableProperties.STATUS].includes(ticketProperty)
  ) {
    formattedData.value = ticket[ticketProperty].toUpperCase();
  } else {
    formattedData.value = ticket[ticketProperty];
  }

  return formattedData;
};

const saveAsPDF = (ticket: Tms.Ticket, date: string) => {
  const pdf = new jsPDF();
  const formattedData = Object.keys(ticket)
    .filter((key) => TicketPropertyNames[key])
    .map((ticketProperty) => getFormattedValueAndLabel(ticketProperty, ticket));

  const pdfText = formattedData
    .sort((a, b) => a.order - b.order)
    .reduce((acc, data) => {
      return `${acc}${data.label}: ${data.value} ${TicketPropertySuffix[data.label]} \n`;
    }, '');

  pdf.text(pdfText, 10, 10);
  pdf.save(`${date}-Ticket-${ticket.externalTicketId}`);
};

export default (props) => {
  const { results, category, date } = props;

  const categoryWiseColumns = {
    tickets: [
      {
        title: 'Ticket number',
        dataIndex: 'externalTicketId',
        key: 'externalTicketId',
        width: '200px',
      },
      {
        title: 'Description',
        dataIndex: 'subject',
        key: 'subject',
        width: '300px',
      },
      {
        title: 'Target SLA',
        dataIndex: 'sla',
        key: 'sla',
        width: '200px',
        render: (text: any, record: any) => <Text>{text} hrs</Text>,
      },
      {
        title: 'TAT',
        dataIndex: 'turnAroundTime',
        key: 'turnAroundTime',
        width: '200px',
        render: (text: any, record: any) => {
          const hours = parseInt(text) / 60;
          return <Text>{hours.toFixed(2)} hrs</Text>;
        },
      },
      {
        title: 'Due date',
        dataIndex: 'dueDate',
        key: 'dueDate',
        width: '200px',
        render: (text, record) => {
          return moment(text).format(DATE_FORMAT);
        },
      },
      {
        title: 'Priority',
        dataIndex: 'priority',
        key: 'priority',
        width: '200px',
        render: (text) => (
          <Tag
            color={PriorityColors[text]}
            style={{
              textTransform: 'uppercase',
            }}
          >
            {text}
          </Tag>
        ),
      },
      {
        title: 'Status',
        dataIndex: 'status',
        key: 'status',
        width: '200px',
      },
      {
        title: 'Point of Collection',
        dataIndex: 'pointOfCollection',
        key: 'pointOfCollection',
        width: '300px',
      },
      {
        title: 'Actions',
        width: '100px',
        dataIndex: 'action',
        key: 'action',
        fixed: 'right',
        render: (text, record) => (
          <Tooltip title="Close ticket">
            <Button
              disabled={record.status === 'completed'}
              type="primary"
              shape="circle"
              icon={<FileDoneOutlined />}
              onClick={() => handleCloseTicket(record)}
            />
          </Tooltip>
        ),
      },
      {
        title: 'Download',
        dataIndex: 'downloadPdf',
        key: 'downloadPdf',
        width: '100px',
        render: (text, record, index) => {
          return (
            <Button type="primary" onClick={() => saveAsPDF(record, date)}>
              <DownloadOutlined />
            </Button>
          );
        },
      },
    ],
  };

  const columns: ITableColumn[] = categoryWiseColumns[category];

  const handleCloseTicket = (ticket: any) => {
    Modal.confirm({
      title: `Are you sure you want to close ticket no. ${ticket.externalTicketId}?`,
      onOk: () =>
        tmsService.closeTicket(ticket.id, ticket.externalTicketId).then(() => {
          window.location.reload();
        }),
      okText: 'Close ticket',
    });
  };

  return (
    <div className={styles.tableContainer}>
      <Table columns={columns} dataSource={results} />
    </div>
  );
};
