import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';

import { getCubejsApiParams } from '@/services/cubejs';
import tmsService from '../services/tms.service';
import { SearchCategoryUrlFragments } from './Constants';

// CubeJS
const cubejsParams = getCubejsApiParams();

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const useCubeData = (query: any) => {
  const { resultSet, isLoading, error, progress } = useCubeQuery(query, {
    cubejsApi,
  });

  if (isLoading) {
    return {
      isLoading,
      progress,
      dataSource: null,
    };
  }

  if (error) {
    return null;
  }

  if (!resultSet && !resultSet?.tablePivot()) {
    return null;
  }

  return {
    isLoading,
    dataSource: resultSet.tablePivot(),
    progress: null,
  };
};

const getAutocompleteResults = (searchTerm: string, searchCategory: string) => {
  return tmsService.getAutocompleteResults(searchTerm, SearchCategoryUrlFragments[searchCategory]);
};

const getSearchResults = (regionId: string | undefined, searchTerm: string, category: string) => {
  return category === 'tickets'
    ? tmsService.searchTickets(regionId, searchTerm)
    : tmsService.searchPodData(searchTerm);
};

export { getAutocompleteResults, getSearchResults, useCubeData };
