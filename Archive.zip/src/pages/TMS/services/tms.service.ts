import { message } from 'antd';

import httpService from '@/services/http.service';
import errorHandler from '@/services/errorHandler';
import apiService from '@/shared/services/api.service';
import { LabTypes, ApiUrlFragments } from '@/services/Constants';

export default {
  getAutocompleteResults: (searchTerm: string, searchCategory: string) => {
    return httpService
      .get(`${ApiUrlFragments.TRANSPORT}/auto-complete/${searchCategory}/${searchTerm}`)
      .then((data: any) => data.data)
      .catch((err) => errorHandler(err));
  },

  searchTickets: (regionId: string | undefined, searchTerm: string) => {
    const params = { search: searchTerm };
    if (regionId) params.regionId = regionId;

    return httpService
      .get(`${ApiUrlFragments.TRANSPORT}/tickets/`, { params })
      .then((data: any) => data.data)
      .catch((err) => errorHandler(err));
  },

  searchPodData: (searchTerm: string) => {
    const params = { patientCode: searchTerm };

    return httpService
      .get(`${ApiUrlFragments.TRANSPORT}/pod-data/`, { params })
      .then((data: any) => data.data)
      .catch((err) => errorHandler(err));
  },

  getTickets: (page: number, limit: number) => {
    const params = {
      offset: page,
      limit,
    };

    return httpService
      .get(`${ApiUrlFragments.TRANSPORT}/tickets/`, { params })
      .then((data) => data.data)
      .catch((err) => errorHandler(err));
  },

  closeTicket: (ticketId: number, ticketNumber: number) => {
    const payload = { status: 'completed' };

    return httpService
      .post(`${ApiUrlFragments.TRANSPORT}/tickets/${ticketId}`, payload)
      .then(() => message.success(`Ticket no. ${ticketNumber} was closed successfully`))
      .catch((err) => errorHandler(err));
  },

  sendMissingSamplesReportAsEmail: (params: any) => {
    return httpService
      .get(`${ApiUrlFragments.TRANSPORT}/pod-data/report`, { params })
      .then((data: any) => {
        if (data.success) message.success('Report sent successfully');
      })
      .catch((err) => errorHandler(err));
  },

  uploadDashboardData: (data: any) => {
    const formData = new FormData();
    formData.append('file', data.originFileObj, data.name);
    const requestConfig = {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    };

    return httpService
      .post(`${ApiUrlFragments.TRANSPORT}/upload`, formData, requestConfig)
      .then(() => message.success('File uploaded successfully'))
      .catch((err) => errorHandler(err));
  },
};
