export type FilterType = 'granularity' | 'dateRange';
export type GranularityType = 'day' | 'week' | 'month' | 'year';

export type DateRangeType = string[];

export interface DateFilterType {
  granularity: GranularityType;
  dateRange: DateRangeType;
}

export interface IKpiStatisticsCardProps {
  title: string;
  info?: string;
  value?: string;
  children?: React.ReactNode;
}

export interface IKpiCardProps {
  title: string;
  info?: string;
  filters?: any;
  children?: React.ReactNode;
  location?: string;
}
