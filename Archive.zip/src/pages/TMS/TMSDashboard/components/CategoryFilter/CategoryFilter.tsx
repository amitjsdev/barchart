import React, { useEffect } from 'react';
import { Select } from 'antd';

const CategoryFilter = (props) => {
  return (
    <Select defaultValue={props.category[0]} style={{ width: '215px' }} onChange={props.onChange}>
      {props.category.map((category) => {
        return (
          <Select.Option key={category} value={category}>
            {category}
          </Select.Option>
        );
      })}
    </Select>
  );
};

export default CategoryFilter;
