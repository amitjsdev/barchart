import React, { useState } from 'react';
import { DatePicker, Space, Radio } from 'antd';
import moment from 'moment';

import { FilterType } from '../../Types';

const { RangePicker } = DatePicker;

const DATE_FORMAT = 'YYYY-MM-DD';

export default (props) => {
  const { onDateChange, onGranularityChange } = props;
  // const [granularity, setGranularity] = useState('day');
  // const [dateRange, setDateRange] = useState([moment(), moment()]);
  const currentWeekNumber = moment().week();
  const granularityOptions = [
    { label: 'Day', value: 'day' },
    { label: 'Week', value: 'week' },
    { label: 'Month', value: 'month' },
    { label: 'Year', value: 'year' },
  ];

  const rangeOptions = {
    Today: [moment(), moment()],
    'Last week': [
      moment()
        .week(currentWeekNumber - 1)
        .startOf('week'),
      moment()
        .week(currentWeekNumber - 1)
        .endOf('week'),
    ],
    'Last month': [
      moment().subtract(1, 'month').startOf('month'),
      moment().subtract(1, 'month').endOf('month'),
    ],
    'Last quarter': [
      moment().subtract(1, 'quarter').startOf('quarter'),
      moment().subtract(1, 'quarter').endOf('quarter'),
    ],
  };

  return (
    <Space size={12}>
      <RangePicker
        onChange={(dates, dateStrings) => onDateChange(dates)}
        defaultValue={[moment().subtract(14, 'days'), moment().subtract(1, 'days')]}
        ranges={rangeOptions}
      />
    </Space>
  );
};
