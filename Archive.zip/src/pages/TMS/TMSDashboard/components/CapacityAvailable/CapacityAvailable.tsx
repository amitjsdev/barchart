import React, { useState, useEffect } from 'react';
import { RingProgress } from '@ant-design/charts';
import { Spin, Space, Typography } from 'antd';
import { InboxOutlined } from '@ant-design/icons';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '../../../../../hostname';

import styles from './index.less';

const { Text } = Typography;

/* const data = {
  samplePerDay: 9000,
  totalCapacity: 41200
} */

// CubeJS
const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint
const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const cubeQueryRender = (props) => {
  const { location, dateRangeFilter, service, category } = props;
  const filters = [
    {
      member: 'PodData.appointmentDate',
      operator: 'inDateRange',
      values: dateRangeFilter.dateRange,
    },
  ];

  if (location && location !== 'All locations') {
    filters.push({ member: 'Labs.name', operator: 'equals', values: [location] });
  }
  if (service && service !== 'All Services') {
    filters.push({ member: 'PodData.serviceProvider', operator: 'equals', values: [service] });
  }
  if (category && category !== 'All Categories') {
    filters.push({ member: 'PodData.category', operator: 'equals', values: [category] });
  }

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['PodData.validSamples', 'PodData.invalidSamples', 'PodData.count'],
      timeDimensions: [],
      filters,
      order: {},
    },
    {
      cubejsApi,
    },
  );

  if (isLoading || props.location === '') {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet && !resultSet?.tablePivot()) {
    return null;
  }

  const dataSource = resultSet.tablePivot();

  let totalCapacity = null;
  let samplePerDay = null;

  if (dataSource.length) {
    totalCapacity = dataSource[0]['Locations.totalCapacity'];
    samplePerDay = dataSource[0]['BgiSurveys.samplesPerDay'];
  }

  return true ? (
    <UtilizationRing
      className={styles.chartContainer}
      samplePerDay={samplePerDay}
      totalCapacity={totalCapacity}
    />
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

const UtilizationRing: React.FC = (props) => {
  const config = {
    // renderer: 'svg',
    height: 200,
    width: 200,
    autoFit: false,
    percent: 0.7, // props.samplePerDay / props.totalCapacity,
    color: ['#ED8936', '#292929'],
    statistic: {
      content: {
        formatter: ({ percent }) => `${Math.round(percent * 100)}%`,
        style: {
          fill: '#ffffff',
          textAlign: 'center',
          fontWeight: 500,
          fontSize: 52,
        },
      },
    },
  };
  return <RingProgress className={`${styles.fixValue} ${props.className}`} {...config} />;
};

export default cubeQueryRender;
