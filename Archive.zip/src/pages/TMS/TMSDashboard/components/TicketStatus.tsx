import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Spin } from 'antd';
import { Chart, Axis, Tooltip, Interval } from 'bizcharts';
import { getCubejsApiParams } from '@/services/cubejs';

enum TicketPriority {
  HIGH = 'High',
  MEDIUM = 'Medium',
  LOW = 'Low',
}

const cubejsParams = getCubejsApiParams();
const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const formatData = (data) => {
  return data.map((item) => {
    const formattedItem = { ...item };

    if (formattedItem.color.endsWith('Tickets.highTicket')) {
      formattedItem.color = TicketPriority.HIGH;
      return formattedItem;
    }
    if (formattedItem.color.endsWith('Tickets.mediumTicket')) {
      formattedItem.color = TicketPriority.MEDIUM;
      return formattedItem;
    }
    formattedItem.color = TicketPriority.LOW;
    return formattedItem;
  });
};

const stackedChartData = (resultSet) => {
  const data = resultSet
    .pivot()
    .map(({ xValues, yValuesArray }) =>
      yValuesArray.map(([yValues, m]) => ({
        x: resultSet.axisValuesString(xValues, ', '),
        color: resultSet.axisValuesString(yValues, ', '),
        measure: m && Number.parseFloat(m),
      })),
    )
    .reduce((a, b) => a.concat(b), []);

  return formatData(data);
};

const colors = [
  'color',
  (value: string) => {
    if (value === TicketPriority.HIGH) {
      return '#f5222d';
    }

    if (value === TicketPriority.MEDIUM) {
      return '#faad14';
    }

    return '#52c41a';
  },
];

const barRender = ({ resultSet }) => (
  <Chart scale={{ x: { tickCount: 8 } }} data={stackedChartData(resultSet)} autoFit>
    <Axis name="x" />
    <Axis name="measure" />
    <Tooltip />
    <Interval
      adjust={[
        {
          type: 'stack',
        },
      ]}
      position="x*measure"
      color={colors}
    />
  </Chart>
);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) =>
  (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
  (error && error.toString()) || <Spin />;

const ChartRenderer = () => (
  <QueryRenderer
    query={{
      dimensions: ['Tickets.status'],
      timeDimensions: [],
      // segments: ['Tickets.type'],
      measures: ['Tickets.lowTicket', 'Tickets.mediumTicket', 'Tickets.highTicket'],
      order: {},
      filters: [],
    }}
    cubejsApi={cubejsApi}
    render={renderChart(barRender, {
      x: [],
      y: ['Tickets.status', 'measures'],
      fillMissingDates: true,
      joinDateRange: false,
    })}
  />
);

export default ChartRenderer;
