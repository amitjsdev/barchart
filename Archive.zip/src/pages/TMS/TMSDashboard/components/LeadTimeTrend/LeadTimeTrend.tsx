import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Spin, Empty } from 'antd';
import { Chart, Axis, Tooltip, Slider, LineAdvance, Legend } from 'bizcharts';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';
import moment from 'moment';

const formatData = (data) => {
  return data.map((item) => {
    const formattedItem = { ...item };

    if (formattedItem.color.endsWith('Answers.totalExtractionMalfunctionCount')) {
      formattedItem.color = 'Extraction & PCR malfunction count';
      return formattedItem;
    }

    formattedItem.color = 'Serology malfunction count';
    return formattedItem;
  });
};

const stackedChartData = (resultSet) => {
  const data = resultSet
    .pivot()
    .map(({ xValues, yValuesArray }) =>
      yValuesArray.map(([yValues, m]) => ({
        x: resultSet.axisValuesString(xValues, ', '),
        color: resultSet.axisValuesString(yValues, ', '),
        measure: m && Number.parseFloat(m),
      })),
    )
    .reduce((a, b) => a.concat(b), []);

  //   return formatData(data);
  return data;
};

const colors = ['color', ['#753BBD', '#27a29e']];

const lineRender = ({ resultSet }) => (
  <Chart padding={40} scale={{ x: { tickCount: 8 } }} data={stackedChartData(resultSet)} autoFit>
    <Axis name="x" label={false} tickLine={false} />
    <Axis name="measure" />
    <LineAdvance shape="smooth" point area position="x*measure" color={colors} />
    <Slider
      start={0.5}
      textStyle={{ fill: '#fff' }}
      formatter={(val, datum) => {
        return moment(val).format('YYYY-MM-DD');
      }}
    />
    <Legend layout="vertical" position="top-right" visible={false} />
    <Tooltip />
  </Chart>
);

const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) => {
  const data = resultSet?.loadResponses[0]?.data;
  const result = (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
    (error && error.toString()) || <Spin />;

  return data && data.length ? result : <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
};

const ChartRenderer = (props) => {
  const { dateRangeFilter, location, service, category } = props;

  const timeDimensions = [
    {
      dimension: 'PodData.appointmentDate',
      granularity: dateRangeFilter.granularity,
      dateRange: dateRangeFilter.dateRange,
    },
  ];

  const filters = [];
  if (location && location !== 'All locations') {
    filters.push({ dimension: 'Labs.name', operator: 'equals', values: [location] });
  }
  if (service && service !== 'All Services') {
    filters.push({ dimension: 'PodData.serviceProvider', operator: 'equals', values: [service] });
  }
  if (category && category !== 'All Categories') {
    filters.push({ dimension: 'PodData.category', operator: 'equals', values: [category] });
  }

  return (
    <QueryRenderer
      query={{
        measures: ['PodData.turnAroundTime'],
        timeDimensions,
        filters,
        dimensions: [],
        /* order: {
          'PodData.appointmentDate': 'asc',
        }, */
      }}
      cubejsApi={cubejsApi}
      render={renderChart(lineRender, {
        x: ['PodData.appointmentDate.day'],
        y: ['measures'],
        fillMissingDates: true,
        joinDateRange: false,
      })}
    />
  );
};

export default ChartRenderer;
