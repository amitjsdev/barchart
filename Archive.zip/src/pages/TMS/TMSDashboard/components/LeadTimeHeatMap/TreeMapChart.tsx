/* eslint-disable no-restricted-syntax */
import React from 'react';
import DataSet from '@antv/data-set';
import { Chart, Interaction, Polygon, Tooltip, Legend } from 'bizcharts';

const TreeMapChart = (props) => {
  const { DataView } = DataSet;
  const { data, dataOrder } = props;

  const dv = new DataView();
  dv.source(data, {
    type: 'hierarchy',
  }).transform({
    field: 'value',
    type: 'hierarchy.treemap',
    tile: 'treemapResquarify',
    as: ['x', 'y'],
  });

  const nodes = [];
  for (const node of dv.getAllNodes()) {
    if (node.data.name === 'root') {
      continue;
    }
    const eachNode: any = {
      name: node.data.name,
      x: node.x,
      y: node.y,
      value: node.data.value,
    };

    nodes.push(eachNode);
  }

  const scale = {
    x: {
      nice: true,
    },
    y: {
      nice: true,
    },
  };

  /*   label(
    'brand*depth*name',
    (brand, depth, name) => {
      if (depth > 1 || name === '其他') {
        // 只有第一级显示文本，数值太小时不显示文本
        return {
          content: name,
          style: {
            shadowColor: 'rgba(0,0,0,0.5)',
            shadowBlur: 3,
          },
          offset: 0,
        };
      }
      return null;
    },
    {
      layout: {
        type: 'limit-in-shape',
      },
    }
  ); */

  const defLabel = [
    'name',
    {
      offset: 0,
      style: {
        textBaseline: 'middle',
      },
      content: (obj) => {
        if (obj.name !== 'root') {
          return obj.name;
        }
      },
    },
  ];

  const label = [
    'name*depth*value',
    (value, depth, root) => {
      if (depth > 1 || name === 'MAK') {
        return {
          content: name,
          style: {
            shadowColor: 'rgba(0,0,0,0.5)',
            shadowBlur: 3,
          },
          offset: 0,
        };
      }
      return null;
    },
    {
      layout: {
        type: 'limit-in-shape',
      },
    },
  ];

  const itemTpl =
    '<li data-index={index}>' +
    '<span style="background-color:{color};width:8px;height:8px;border-radius:50%;display:inline-block;margin-right:8px;"></span>' +
    '{name}: {value}' +
    '</li>';

  const TreeMap = (props) => {
    const { dataOrder } = props;
    const colors = {
      asc: ['name', '#E53E3E-#E38F3C-#57AF5E'],
      desc: ['name', '#57AF5E-#E38F3C-#E53E3E'],
    };

    return (
      <Chart
        padding="auto"
        scale={scale}
        pure
        autoFit
        data={nodes}
        onClick={(e: IEvent, chart: G2Instance) => {
          chart.showTooltip({ x: 10, y: 20 });
        }}
      >
        <Polygon
          color={colors[dataOrder]}
          position="x*y"
          style={{
            lineWidth: 2,
            stroke: '#191919',
          }}
          label={[
            'name',
            {
              offset: 0,
              style: {
                textBaseline: 'middle',
              },
              content: (obj) => {
                if (obj.name !== 'root') {
                  return `${Math.round(obj.value)}%`;
                }
              },
            },
          ]}
        />
        <Tooltip>
          {(title, items) => {
            const { color } = items[0];
            return (
              <div style={{ padding: '10px' }}>
                <span>{items[0].data.name}</span>
                <br />
                <br />
                <span>SLA Compliance: {Math.round(items[0].data.value)}%</span>
                <br />
                {/* <span>TAT: {Math.round(items[0].data.tat)}</span> */}
              </div>
            );
          }}
        </Tooltip>
        <Legend visible={false} />
      </Chart>
    );
  };

  return <TreeMap dataOrder={dataOrder} />;
};

export default TreeMapChart;
