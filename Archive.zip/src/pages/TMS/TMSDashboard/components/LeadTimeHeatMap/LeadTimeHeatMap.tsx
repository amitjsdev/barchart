import React, { useState, useEffect } from 'react';
import { RingProgress } from '@ant-design/charts';
import { Spin, Space, Typography } from 'antd';
import { InboxOutlined } from '@ant-design/icons';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '../../../../../hostname';

import TreeMapChart from './TreeMapChart';

import styles from './index.less';

const { Text } = Typography;

// CubeJS
const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint
const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const cubeQueryRender = (props) => {
  const { location, categoryFilter, dateRangeFilter, service, category } = props;

  const filters: any[] = [
    {
      member: 'PodData.appointmentDate',
      operator: 'inDateRange',
      values: dateRangeFilter.dateRange,
    },
    {
      dimension: 'PodData.networkEfficiency',
      operator: 'gt',
      values: ['0'],
    },
  ];
  let limit = null;
  let order = null;

  if (location && location !== 'All locations') {
    filters.push({ dimension: 'Labs.name', operator: 'equals', values: [location] });
  }
  if (service && service !== 'All Services') {
    filters.push({ dimension: 'PodData.serviceProvider', operator: 'equals', values: [service] });
  }
  if (category && category !== 'All Categories') {
    filters.push({ dimension: 'PodData.category', operator: 'equals', values: [category] });
  }

  if (categoryFilter && categoryFilter === 'Worst 25') {
    order = {
      'PodData.networkEfficiency': 'asc',
    };
    limit = 25;
  }

  if (categoryFilter && categoryFilter === 'Best 25') {
    order = {
      'PodData.networkEfficiency': 'desc',
    };
    limit = 25;
  }

  if (categoryFilter && categoryFilter === 'Worst 5') {
    order = {
      'PodData.networkEfficiency': 'asc',
    };
    limit = 5;
  }

  if (categoryFilter && categoryFilter === 'Best 5') {
    order = {
      'PodData.networkEfficiency': 'desc',
    };
    limit = 5;
  }

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['PodData.turnAroundTime', 'PodData.networkEfficiency'],
      timeDimensions: [],
      filters,
      dimensions: ['PodData.pointOfCollection'],
      limit,
      order,
    },
    {
      cubejsApi,
    },
  );

  if (isLoading || location === '') {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet && !resultSet?.tablePivot()) {
    return null;
  }

  const dataSource = resultSet.tablePivot();

  const chartData = {
    name: 'root',
    children: [
      { name: 'NHL', value: 42 },
      { name: 'MAK', value: 40 },
      { name: 'MAD', value: 34 },
      { name: 'ASR', value: 35 },
      { name: 'DAM', value: 34 },
    ],
  };

  chartData.children = dataSource.map((item) => ({
    name: item['PodData.pointOfCollection'],
    value: item['PodData.networkEfficiency'],
    tat: item['PodData.turnAroundTime'],
  }));

  return chartData.children.length ? (
    <TreeMapChart data={chartData} dataOrder={order['PodData.networkEfficiency']} />
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

export default cubeQueryRender;
