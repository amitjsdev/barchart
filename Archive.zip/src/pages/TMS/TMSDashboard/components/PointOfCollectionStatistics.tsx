import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Row, Col, Statistic, Table, Spin, Empty, Space, Typography } from 'antd';
import { InboxOutlined } from '@ant-design/icons';

import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '../../../../hostname';

const { Text } = Typography;

const numberRender = ({ resultSet, pivotConfig }) => (
  <Row type="flex" justify="center" align="middle" style={{ height: '100%' }}>
    <Col>
      {resultSet.seriesNames().map((s) => (
        <Statistic value={resultSet.totalRow()[s.key]} valueStyle={{ fontSize: '52px' }} />
      ))}
    </Col>
  </Row>
);

const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) => {
  const data = resultSet?.loadResponses[0]?.data;
  const result = (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
    (error && error.toString()) || <Spin />;
  return result;
  /* return data && data.length && data[0]['Answers.totalSamplesTested'] !== null ? (
    result
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  ); */
};

const ChartRenderer = (props) => {
  const { dateRangeFilter, location, service, category } = props;

  const filters = [
    {
      member: 'PodData.appointmentDate',
      operator: 'inDateRange',
      values: dateRangeFilter.dateRange,
    },
  ];

  if (location && location !== 'All locations') {
    filters.push({ member: 'Labs.name', operator: 'equals', values: [location] });
  }
  if (service && service !== 'All Services') {
    filters.push({ member: 'PodData.serviceProvider', operator: 'equals', values: [service] });
  }
  if (category && category !== 'All Categories') {
    filters.push({ member: 'PodData.category', operator: 'equals', values: [category] });
  }

  return (
    <QueryRenderer
      query={{
        measures: ['PodData.distinctPointOfCollection'],
        timeDimensions: [],
        filters,
        dimensions: [],
        order: {},
      }}
      cubejsApi={cubejsApi}
      render={renderChart(numberRender, {
        x: [],
        y: ['measures'],
        fillMissingDates: true,
        joinDateRange: false,
      })}
    />
  );
};

export default ChartRenderer;
