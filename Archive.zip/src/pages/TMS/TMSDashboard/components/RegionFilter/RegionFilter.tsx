import React, { useEffect } from 'react';
import { Select } from 'antd';

const RegionFilter = (props) => {
  return (
    <Select defaultValue={props.locations[0]} style={{ width: '215px' }} onChange={props.onChange}>
      {props.locations.map((location) => {
        return (
          <Select.Option key={location} value={location}>
            {location}
          </Select.Option>
        );
      })}
    </Select>
  );
};

export default RegionFilter;
