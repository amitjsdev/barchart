import React from 'react';
import { RingProgress } from '@ant-design/charts';
import { Spin, Space, Typography } from 'antd';
import { InboxOutlined } from '@ant-design/icons';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '../../../../../hostname';

import styles from './index.less';

const { Text } = Typography;

/* const data = {
  invalidSamples: 9000,
  totalSamples: 41200
} */

// CubeJS
const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint
const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const cubeQueryRender = (props) => {
  const { location, dateRangeFilter, service, category } = props;
  const filters = [
    {
      member: 'PodData.appointmentDate',
      operator: 'inDateRange',
      values: dateRangeFilter.dateRange,
    },
  ];

  if (location && location !== 'All locations') {
    filters.push({ member: 'Labs.name', operator: 'equals', values: [location] });
  }
  if (service && service !== 'All Services') {
    filters.push({ member: 'PodData.serviceProvider', operator: 'equals', values: [service] });
  }
  if (category && category !== 'All Categories') {
    filters.push({ member: 'PodData.category', operator: 'equals', values: [category] });
  }

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['PodData.validSamples', 'PodData.invalidSamples', 'PodData.count'],
      timeDimensions: [],
      filters,
      order: {},
    },
    {
      cubejsApi,
    },
  );

  if (isLoading || location === '') {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet && !resultSet?.tablePivot()) {
    return null;
  }

  const dataSource = resultSet.tablePivot();

  let invalidSamples = null;
  let totalSamples = null;

  if (dataSource.length) {
    invalidSamples = dataSource[0]['PodData.invalidSamples'];
    totalSamples = dataSource[0]['PodData.count'];
  }

  return true ? (
    <UtilizationRing
      className={styles.chartContainer}
      invalidSamples={invalidSamples}
      totalSamples={totalSamples}
    />
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

const UtilizationRing: React.FC = (props) => {
  const { invalidSamples, totalSamples } = props;

  const config = {
    // renderer: 'svg',
    height: 200,
    width: 200,
    autoFit: false,
    percent: invalidSamples && totalSamples ? invalidSamples / totalSamples : 0.01,
    color: ['#667EEA', '#292929'],
    statistic: {
      content: {
        formatter: ({ percent }) => `${Math.round(percent * 100)}%`,
        style: {
          fill: '#ffffff',
          textAlign: 'center',
          fontWeight: 500,
          fontSize: 52,
        },
      },
    },
  };
  return <RingProgress className={`${styles.fixValue} ${props.className}`} {...config} />;
};

export default cubeQueryRender;
