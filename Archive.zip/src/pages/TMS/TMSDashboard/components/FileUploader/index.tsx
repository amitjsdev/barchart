import React from 'react';
import { Modal, Button } from 'antd';

import UploadDrag from './UploadDrag';
import tmsService from '../../../services/tms.service';

class App extends React.Component {
  state = {
    visible: false,
    file: null,
  };

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleOk = async (e) => {
    await tmsService.uploadDashboardData(this.state.file);

    this.setState({
      visible: false,
    });
  };

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  };

  getFileData = (_file: any) => {
    this.setState({ file: _file.file });
  };

  render() {
    return (
      <div style={{ textAlign: 'right' }}>
        <Button type="primary" onClick={this.showModal}>
          Upload file
        </Button>
        <Modal
          title="Upload File"
          visible={this.state.visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          bodyStyle={{ background: 'black' }}
        >
          <UploadDrag onGetFileData={this.getFileData} />
        </Modal>
      </div>
    );
  }
}

export default () => (
  <div>
    <div id="components-modal-demo-basic">
      <App />
    </div>
  </div>
);
