import React from 'react';
import cubejs from '@cubejs-client/core';
import { Row, Col, Statistic, Table, Spin } from 'antd';

import itemNameMap from './itemNameMap';
import styles from './index.less';

const getFormattedColumns = (defaultColumns) => {
  return [
    {
      dataIndex: defaultColumns[0].dataIndex,
      key: defaultColumns[0].key,
      shortTitle: 'Name',
      title: 'Item name',
      type: 'string',
    },
    {
      dataIndex: defaultColumns[1].dataIndex,
      key: defaultColumns[1].key,
      shortTitle: 'Count',
      title: 'Total count',
      type: 'number',
    },
  ];
};

const getLocationName = (columns) => {
  return columns[0].title;
};

const getStockType = (columns) => {
  return columns[1].title;
};

const getFormattedData = (dataSource) => {
  if (dataSource) {
    return dataSource.map((row) => {
      const item = itemNameMap.find((item) => item.key === row['SurveyOptions.name']);

      if (item) row['SurveyOptions.name'] = item.value;

      return row;
    });
  }
  return dataSource;
};

const ItemDetailsTable = ({ resultSet, pivotConfig }) => {
  return resultSet ? (
    // <div className={styles.tableContainer}>
    <Table
      pagination={false}
      columns={getFormattedColumns(resultSet.tableColumns(pivotConfig))}
      dataSource={getFormattedData(resultSet.tablePivot(pivotConfig))}
    />
  ) : (
    // </div>
    <Spin />
  );
};

export default ItemDetailsTable;
