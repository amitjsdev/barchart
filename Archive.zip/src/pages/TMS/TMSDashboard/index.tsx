import React, { useEffect, useState } from 'react';
import { Row, Col, Popover, Typography, Space, Badge, Select, Tooltip, Button } from 'antd';
import moment from 'moment';

import { MailOutlined, InfoCircleOutlined } from '@ant-design/icons';
import DateFilter from './components/DateFilter/DateFilter';
import RegionFilter from './components/RegionFilter/RegionFilter';
import { DateFilterType, IKpiStatisticsCardProps, IKpiCardProps } from './Types';
import Constants from './Constants';
import { sendMissingSamplesReport } from './Services';

// KPIs
import LostSamples from './components/LostSamples/LostSamples';
import NetworkEfficiency from './components/NetworkEfficiency/NetworkEfficiency';
import CapacityAvailable from './components/CapacityAvailable/CapacityAvailable';
import PointOfCollectionStatistics from './components/PointOfCollectionStatistics';
import SampleCollectionTimeStatistics from './components/SampleCollectionTimeStatistics';
import TestingTimeStatistics from './components/TestingTimeStatistics';
import SamplesRatio from './components/SamplesRatio/SamplesRatio';
import SamplesPerDayCount from './components/SamplesRatio/SamplesPerDayCount';
import LostSamplesCount from './components/SamplesRatio/LostSamplesCount';
import LeadTimeHeatMap from './components/LeadTimeHeatMap/LeadTimeHeatMap';
import LeadTimeTrend from './components/LeadTimeTrend/LeadTimeTrend';
import TATStatistics from './components/TATStatistics';
import MissingSamplesCount from './components/MissingSamplesCount';
import TicketStatus from './components/TicketStatus';
import FileUploader from './components/FileUploader';

import styles from './index.less';
import CategoryFilter from './components/CategoryFilter/CategoryFilter';

const { Text, Title } = Typography;

const kpiStatisticsCardTitles = {
  LOST_SAMPLES: 'Missing Samples',
  NETWORK_EFFICIENCY: 'SLA Compliance',
  CAPACITY_AVAILABLE: 'Capacity Available',
  POINT_OF_COLLECTION: 'Collection sites',
  SAMPLE_COLLECTION_TIME: 'Delivery time (hrs)',
  TESTING_TIME: 'Response Time (hrs)',
  TAT: 'Turn-around time (hrs)',
};

const chartTitles = {
  AVG_TAT: 'Avg. turn-around time',
  TAT_TREND: 'Turn-around time trend',
  TICKET_STATUS: 'Ticket Status',
};

const heatMapFilter = {
  name: 'Category filter',
  options: [
    { label: 'Worst 25', value: 'Worst 25' },
    { label: 'Best 25', value: 'Best 25' },
    { label: 'Worst 5', value: 'Worst 5' },
    { label: 'Best 5', value: 'Best 5' },
  ],
  selectedOption: 'Worst 25',
};

const FilterSelect: React.FC<{}> = (props: any) => (
  <Select
    style={{ width: '120px' }}
    defaultValue={props.filter.options[0].value}
    onChange={props.onChange}
  >
    {props.filter.options.map((option: any) => (
      <Select.Option key={option.value} value={option.value}>
        {option.label}
      </Select.Option>
    ))}
  </Select>
);

const KpiStatisticsCard: React.FC<IKpiStatisticsCardProps> = (props) => (
  <div className={styles.kpiStatisticsCard}>
    <div className={styles.kpiCardTitleBar}>
      <div>
        <Text className={styles.chartTitle}>{props.title}</Text>
        {props.info ? (
          <Popover content={props.info} title="Info">
            <InfoCircleOutlined style={{ padding: '8px' }} />
          </Popover>
        ) : null}
      </div>
    </div>
    <div className={styles.kpiStatisticsCardContent}>
      {/* <div>
          <Title level={3}>{props.value}</Title>
        </div> */}
      {props.children}
    </div>
  </div>
);

const handleDownloadMissingSamples = (location: string, dateRange: DateFilterType) => {
  sendMissingSamplesReport(location, dateRange);
};

const MissingSamplesStatisticsCard: React.FC<{}> = (props) => {
  const { dateRangeFilter, location, service, category } = props;
  return (
    <div className={styles.kpiStatisticsCard}>
      <div className={styles.kpiCardTitleBar}>
        <div>
          <Text className={styles.chartTitle}>{kpiStatisticsCardTitles.LOST_SAMPLES}</Text>

          <Tooltip title="Get report in your email">
            <Button
              type="link"
              icon={<MailOutlined />}
              onClick={() => handleDownloadMissingSamples(location, dateRangeFilter)}
            />
          </Tooltip>
        </div>
      </div>
      <div className={styles.kpiStatisticsCardContent}>
        <MissingSamplesCount
          dateRangeFilter={dateRangeFilter}
          location={location}
          service={service}
          category={category}
        />
        <Text type="secondary">Count</Text>
      </div>
    </div>
  );
};

const KpiCard: React.FC<IKpiCardProps> = (props) => {
  return (
    <div className={styles.kpiCard}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <div>
              <Text className={styles.chartTitle}>{props.title}</Text>
              {props.info ? (
                <Popover content={props.info} title="Info">
                  <InfoCircleOutlined style={{ padding: '8px' }} />
                </Popover>
              ) : null}
            </div>
          </Col>
          <Col flex={2} className={styles.filters}>
            {/* <div>
              {props.filters?.map((filter) => (
                <FilterSelect filter={filter} />
              ))}
            </div> */}
          </Col>
        </Row>
      </div>
      <div className={styles.kpiCardContent}>{props.children}</div>
    </div>
  );
};

const LeadTimeHeatMapChart: React.FC<IKpiCardProps> = (props) => {
  const { dateRangeFilter, location, service, category } = props;
  const [filter, setFilter] = useState(heatMapFilter.selectedOption);

  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels} ${styles.heatMapContent}`;
  return (
    <div className={`${styles.kpiCard} ${styles.large}`}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }} align="middle" justify="space-between">
          <Col>
            <Text className={styles.chartTitle}>{chartTitles.AVG_TAT}</Text>
          </Col>
          <Col className={styles.filters}>
            <div>
              <FilterSelect
                filter={heatMapFilter}
                onChange={(val) => {
                  setFilter(val);
                }}
              />
            </div>
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <LeadTimeHeatMap
          location={location}
          categoryFilter={filter}
          dateRangeFilter={dateRangeFilter}
          service={service}
          category={category}
        />
      </div>
    </div>
  );
};

const LeadTimeChart: React.FC<IKpiCardProps> = (props) => {
  const { dateRangeFilter, location, service, category } = props;
  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels} ${styles.heatMapContent}`;
  return (
    <div className={`${styles.kpiCard} ${styles.large}`}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{chartTitles.TAT_TREND}</Text>
          </Col>
          <Col flex={2} className={styles.filters}>
            <div>
              {/* {props.filters?.map((filter) => (
                <FilterSelect
                  filter={filter}
                  onChange={(val) => {
                    
                    setChartDimension([val]);
                  }}
                />
              ))} */}
            </div>
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <LeadTimeTrend
          dateRangeFilter={dateRangeFilter}
          location={location}
          service={service}
          category={category}
        />
      </div>
    </div>
  );
};

const TicketStatusChart: React.FC<IKpiCardProps> = (props) => {
  const { dateRangeFilter, location, service, category } = props;
  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels} ${styles.heatMapContent}`;
  return (
    <div className={`${styles.kpiCard} ${styles.large}`}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{chartTitles.TICKET_STATUS}</Text>
          </Col>
          <Col flex={2} className={styles.filters}>
            <div>
              {/* {props.filters?.map((filter) => (
                <FilterSelect
                  filter={filter}
                  onChange={(val) => {
                    
                    setChartDimension([val]);
                  }}
                />
              ))} */}
            </div>
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <TicketStatus
          dateRangeFilter={dateRangeFilter}
          location={location}
          service={service}
          category={category}
        />
      </div>
    </div>
  );
};

const SamplesChart: React.FC<IKpiCardProps> = (props) => {
  const { dateRangeFilter, location, service, category } = props;
  const contentCss = `${styles.SampleRatioContent}`;
  return (
    <div className={`${styles.kpiCard} ${styles.large}`}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{chartTitles.NO_OF_DAILY_CHECKS}</Text>
          </Col>
          <Col flex={2} className={styles.filters}>
            <div>
              {/* {props.filters?.map((filter) => (
                <FilterSelect
                  filter={filter}
                  onChange={(val) => {
                    
                    setChartDimension([val]);
                  }}
                />
              ))} */}
            </div>
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <Row gutter={[12, 12]}>
          <Col>
            <SamplesRatio
              location={location}
              dateRangeFilter={dateRangeFilter}
              service={service}
              category={category}
            />
          </Col>
        </Row>
        <Row gutter={[12, 12]}>
          <Col>
            <Row gutter={[12, 12]}>
              <Col>
                <Space>
                  <Badge color="#292929" />
                  <Text>Completed trips</Text>
                </Space>
                <SamplesPerDayCount
                  location={location}
                  dateRangeFilter={dateRangeFilter}
                  service={service}
                  category={category}
                />
              </Col>
            </Row>
            <Row gutter={[12, 12]}>
              <Col>
                <Space>
                  <Badge color="#2db7f5" />
                  <Text>Samples in-transit</Text>
                </Space>
                <LostSamplesCount
                  location={location}
                  dateRangeFilter={dateRangeFilter}
                  service={service}
                  category={category}
                />
              </Col>
            </Row>
          </Col>
        </Row>
      </div>
    </div>
  );
};

export default () => {
  // Location filter init
  const [selectedLocation, setLocation] = useState('All locations');
  const [category, setCategory] = useState('All Categories');
  const [serviceProvider, setServiceProvider] = useState('All Services');

  const locations = ['All locations', ...Constants.REGION_NAMES];
  const categories = ['All Categories', ...Constants.CATEGORY];
  const services = ['All Services', ...Constants.SERVICE_PROVIDER];

  // Date filter init
  const defaultFilterSetting: DateFilterType = {
    granularity: 'day',
    dateRange: [
      moment().subtract(14, 'days').format(Constants.DATE_FORMAT),
      moment().subtract(1, 'days').format(Constants.DATE_FORMAT),
    ],
  };
  const [dateRangeFilter, setDateRangeFilter] = useState(defaultFilterSetting);

  const onDateChange = (filter) => {
    setDateRangeFilter({
      granularity: dateRangeFilter.granularity,
      dateRange: [
        filter ? filter[0].format(Constants.DATE_FORMAT) : moment().format(Constants.DATE_FORMAT),
        filter ? filter[1].format(Constants.DATE_FORMAT) : moment().format(Constants.DATE_FORMAT),
      ],
    });
  };

  const onGranularityChange = (filter) => {
    setDateRangeFilter({
      granularity: filter,
      dateRange: dateRangeFilter.dateRange,
    });
  };

  const [loading, setLoading] = useState<boolean>(false);
  useEffect(() => {
    setTimeout(() => {
      // setLoading(false);
      setLocation('All locations');
    }, 1000);
  }, []);

  return (
    <div className={styles.main}>
      {/* Action bar */}

      <Row className={styles.actionBar} align="middle" justify="space-between" gutter={[16, 16]}>
        <Col>
          <FileUploader />
        </Col>
        <Col>
          <Row gutter={[24, 24]} align="middle">
            <Col>
              <RegionFilter onChange={setServiceProvider} locations={services} />
            </Col>
            <Col>
              <RegionFilter onChange={setCategory} locations={categories} />
            </Col>
            <Col>
              <RegionFilter onChange={setLocation} locations={locations} />
            </Col>
            <Col>
              <DateFilter onDateChange={onDateChange} onGranularityChange={onGranularityChange} />
            </Col>
          </Row>
        </Col>
      </Row>

      {/* KPI cards */}

      <Row className={styles.kpiStatisticsCardRow} gutter={[16, 16]}>
        <Col span={4}>
          <KpiCard title={kpiStatisticsCardTitles.NETWORK_EFFICIENCY}>
            <NetworkEfficiency
              location={selectedLocation}
              dateRangeFilter={dateRangeFilter}
              category={category}
              service={serviceProvider}
            />
          </KpiCard>
        </Col>
        <Col span={4}>
          <KpiCard title={kpiStatisticsCardTitles.CAPACITY_AVAILABLE}>
            <CapacityAvailable
              location={selectedLocation}
              dateRangeFilter={dateRangeFilter}
              category={category}
              service={serviceProvider}
            />
          </KpiCard>
        </Col>
        <Col span={4}>
          <KpiStatisticsCard title={kpiStatisticsCardTitles.TAT}>
            <TATStatistics
              dateRangeFilter={dateRangeFilter}
              location={selectedLocation}
              category={category}
              service={serviceProvider}
            />
            <Text type="secondary">Average time</Text>
          </KpiStatisticsCard>
        </Col>

        <Col span={3}>
          <KpiStatisticsCard title={kpiStatisticsCardTitles.SAMPLE_COLLECTION_TIME}>
            <SampleCollectionTimeStatistics
              dateRangeFilter={dateRangeFilter}
              location={selectedLocation}
              category={category}
              service={serviceProvider}
            />
            <Text type="secondary">Average time</Text>
          </KpiStatisticsCard>
        </Col>
        <Col span={3}>
          <KpiStatisticsCard title={kpiStatisticsCardTitles.TESTING_TIME}>
            <TestingTimeStatistics
              dateRangeFilter={dateRangeFilter}
              location={selectedLocation}
              category={category}
              service={serviceProvider}
            />
            <Text type="secondary">Average time</Text>
          </KpiStatisticsCard>
        </Col>
        <Col span={3}>
          <KpiStatisticsCard title={kpiStatisticsCardTitles.POINT_OF_COLLECTION}>
            <PointOfCollectionStatistics
              dateRangeFilter={dateRangeFilter}
              location={selectedLocation}
              category={category}
              service={serviceProvider}
            />
            <Text type="secondary">Total Count</Text>
          </KpiStatisticsCard>
        </Col>
        <Col span={3}>
          <MissingSamplesStatisticsCard
            dateRangeFilter={dateRangeFilter}
            location={selectedLocation}
            category={category}
            service={serviceProvider}
          />
        </Col>
      </Row>

      {/* Charts */}

      <Row gutter={[16, 16]}>
        <Col span={10}>
          <LeadTimeHeatMapChart
            location={selectedLocation}
            dateRangeFilter={dateRangeFilter}
            category={category}
            service={serviceProvider}
          />
        </Col>
        <Col span={10}>
          <LeadTimeChart
            location={selectedLocation}
            dateRangeFilter={dateRangeFilter}
            category={category}
            service={serviceProvider}
          />
        </Col>
        <Col span={4}>
          <SamplesChart
            location={selectedLocation}
            dateRangeFilter={dateRangeFilter}
            category={category}
            service={serviceProvider}
          />
        </Col>
      </Row>

      <Row gutter={[16, 16]}>
        <Col span={24}>
          <TicketStatusChart
            location={selectedLocation}
            dateRangeFilter={dateRangeFilter}
            category={category}
            service={serviceProvider}
          />
        </Col>
      </Row>
    </div>
  );
};
