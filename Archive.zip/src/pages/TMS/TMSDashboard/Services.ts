import { Locations } from './Location.enum';
import tmsService from '../services/tms.service';

// import Apis from '@/api/apis';
// import { saveAs } from 'file-saver';
// import { message } from 'antd';

/* export const saveMissingSamplesReport = async (locationName, selectedDateRange) => {
  
  const params = {
    startDate: selectedDateRange.dateRange[0],
    endDate: selectedDateRange.dateRange[1],
  };

  if (locationName !== 'All locations') params['labId'] = Locations[locationName];

  const fileData = await Apis.getMissingSamplesReport(params);

  
  fileData && fileData.length
    ? saveToFileSystem(fileData, `Missing samples ${dateRange.startDate} - ${dateRange.endDate}`)
    : message.error('No data available!');
};

const saveToFileSystem = (response: any, filename: string) => {
  const blob = new Blob([response], {});
  saveAs(blob, filename);
}; */

export const sendMissingSamplesReport = async (locationName, selectedDateRange) => {
  const params = {
    startDate: selectedDateRange.dateRange[0],
    endDate: selectedDateRange.dateRange[1],
  };

  if (locationName !== 'All locations') params.labId = Locations[locationName];

  tmsService.sendMissingSamplesReportAsEmail(params);
};
