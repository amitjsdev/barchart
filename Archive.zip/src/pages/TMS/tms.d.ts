declare namespace Tms {
  type TicketPriority = 'low' | 'medium' | 'high' | 'critical';
  type TicketStatus = 'created' | 'completed';

  export interface Ticket {
    createdAt: string;
    dueDate: string;
    duration: number;
    externalTicketId: number;
    id: number;
    identifier: string;
    pointOfCollection: string;
    priority: TicketPriority;
    regionId: number;
    resolvedBy: string | null;
    sla: number;
    status: TicketStatus;
    subject: string;
    ticketStatus: string | null;
    tradeOff: number;
    turnAroundTime: string;
    type: string;
    updatedAt: string;
  }
}
