import { PageContainer } from '@ant-design/pro-layout';
import React, { useState, useEffect } from 'react';

import SettingsTable from './SettingsTable';
import SearchBar from './Searchbar';

const Settings: React.FC<any> = () => {
  const [data, setData] = useState(Array);
  const [filterData, setFilterdata] = useState(Array);

  const dummyData = [
    {
      labId: '1',
      company: 'SMAA',
      targetSLA: 12,
      location: 'AlMarkaz PHC',
    },
    {
      labId: '1',
      company: 'SMSA',
      targetSLA: 12,
      location: 'Taima General Hospital',
    },
    {
      labId: '1',
      company: 'SMSA',
      targetSLA: 12,
      location: 'Maternity and Children Hospital in Qassim',
    },
    {
      labId: '1',
      company: 'SMKA',
      targetSLA: 12,
      location: 'AlManhal PHC',
    },
    {
      labId: '1',
      company: 'SMSA',
      targetSLA: 12,
      location: 'Mogag General Hospital',
    },
    {
      labId: '1',
      company: 'SMSA',
      targetSLA: 12,
      location: 'AlOmran General Hospital',
    },
  ];

  useEffect(() => {
    setData(dummyData);
    setFilterdata(dummyData);
    // For API call ---------

    // Apis.getSettingsData().then((response) => {
    //
    //   if (response?.success) {
    //     setFilterdata(response.data);
    //     setData(response.data);
    //
    //   } else {
    //     return;
    //   }
    // });
  }, []);

  const getSearchItem = (searchCompany: any) => {
    setFilterdata(data);
    const x: any[] = [];
    if (searchCompany.length != 0) {
      for (let i = 0; i < data.length; i++) {
        if (data[i].company.toLowerCase().includes(searchCompany.toLowerCase())) {
          x.push(data[i]);
        }
      }
      setFilterdata(x);
    } else {
      setFilterdata(data);
    }
  };

  return (
    <PageContainer content="">
      <SearchBar onSearchItem={getSearchItem} />
      <SettingsTable data={filterData} />
      <div
        style={{
          paddingTop: 100,
          textAlign: 'center',
        }}
      >
        {/* <Spin spinning={loading} size="large" /> */}
      </div>
    </PageContainer>
  );
};

export default Settings;
