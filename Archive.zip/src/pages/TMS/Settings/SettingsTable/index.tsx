import React from 'react';
// import styles from './index.less';
import { Table } from 'antd';

const SettingsTable: React.FC<any> = (props) => {
  const columns = [
    {
      title: 'Lab Id',
      dataIndex: 'labId',
      width: 200,
    },
    {
      title: 'Company Name',
      dataIndex: 'company',
      width: 200,
    },
    {
      title: 'Target SLA',
      dataIndex: 'targetSLA',
      width: 200,
    },
    {
      title: 'Location',
      dataIndex: 'location',
      width: 200,
    },
  ];

  return <Table columns={columns} dataSource={props.data} pagination={{ pageSize: 10 }} />;
};

export default SettingsTable;
