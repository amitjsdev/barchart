import React from 'react';
import { Input } from 'antd';
import styles from './index.less';

const SearchBar: React.FC<any> = (props) => {
  const getSearchedItems = (e) => {
    props.onSearchItem(e.target.value);
  };

  return (
    <div style={{ width: 300, marginBottom: 20 }}>
      <Input placeholder="Search by ticket number.." onChange={getSearchedItems} />
    </div>
  );
};

export default SearchBar;
