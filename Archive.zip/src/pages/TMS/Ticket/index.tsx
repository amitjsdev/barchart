import { PageContainer } from '@ant-design/pro-layout';
import React, { useState, useEffect } from 'react';
import { Spin } from 'antd';
import Apis from '@/api/apis';
import styles from './index.less';
import TicketsTable from './TicketsTable';
import SearchBar from './Searchbar';

const Tickets: React.FC<any> = () => {
  // const [data, setData] = useState(Array);
  // const [filterData,setFilterdata] = useState(Array);

  // useEffect(() => {
  //   // For API call ----------
  //   Apis.getTokenData().then((response:any) => {
  //
  //     if (response ?.success) {
  //       setFilterdata(response.data);
  //       setData(response.data);
  //
  //     } else {
  //       return;
  //     }
  //   });
  // }, []);

  // const getSearchItem = (searchTicket: any) => {
  //   setFilterdata(data);
  //   let x: any[]=[];
  //   if (searchTicket.length != 0) {
  //     for(var i=0;i<data.length;i++){
  //       if(data[i]['ticketNumber'].toString().toLowerCase().includes(searchTicket)){
  //         x.push(data[i])
  //       }
  //     }
  //     setFilterdata(x);
  //   }else{
  //     setFilterdata(data);
  //   }
  // }

  return (
    <PageContainer content="">
      {/* <SearchBar onSearchItem={getSearchItem} /> */}
      <TicketsTable />
      <div
        style={{
          paddingTop: 100,
          textAlign: 'center',
        }}
      />
    </PageContainer>
  );
};

export default Tickets;
