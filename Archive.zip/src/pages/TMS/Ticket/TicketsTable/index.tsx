import React, { useState, useEffect } from 'react';
import { Table, Typography, Tag, Tooltip, Modal, Button } from 'antd';
import { FileDoneOutlined } from '@ant-design/icons';
import moment from 'moment';

import { PriorityColors, DATE_FORMAT } from '../../GlobalSearch/Constants';
import tmsService from '../../services/tms.service';

const { Text } = Typography;

const TicketsTable: React.FC<any> = (props) => {
  // const [data, setData] = useState(Array);
  const [filterData, setFilterdata] = useState(Array);
  const [pages, setPages] = useState([0, 2]);

  useEffect(() => {
    // For API call ----------
    getMoreTickets(0, 1, 20);
  }, []);

  const columns = [
    {
      title: 'Ticket number',
      dataIndex: 'externalTicketId',
      key: 'externalTicketId',
      width: '200px',
    },
    {
      title: 'Description',
      dataIndex: 'subject',
      key: 'subject',
      width: '300px',
    },
    {
      title: 'Target SLA',
      dataIndex: 'sla',
      key: 'sla',
      width: '200px',
      render: (text: any, record: any) => <Text>{text} hrs</Text>,
    },
    {
      title: 'TAT',
      dataIndex: 'turnAroundTime',
      key: 'turnAroundTime',
      width: '200px',
      render: (text: any, record: any) => {
        const hours = parseInt(text) / 60;
        return <Text>{hours.toFixed(2)} hrs</Text>;
      },
    },
    {
      title: 'Due date',
      dataIndex: 'dueDate',
      key: 'dueDate',
      width: '200px',
      render: (text: any, record: any) => {
        return moment(text).format(DATE_FORMAT);
      },
    },
    {
      title: 'Priority',
      dataIndex: 'priority',
      key: 'priority',
      width: '180px',
      render: (text: any) => (
        <Tag
          color={PriorityColors[text]}
          style={{
            textTransform: 'uppercase',
          }}
        >
          {text}
        </Tag>
      ),
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      width: '150px',
    },
    {
      title: 'Point of Collection',
      dataIndex: 'pointOfCollection',
      key: 'pointOfCollection',
      width: '300px',
    },
    {
      title: 'Actions',
      width: '100px',
      dataIndex: 'action',
      key: 'action',
      fixed: 'right',
      render: (text, record) => (
        <Tooltip title="Close ticket">
          <Button
            disabled={record.status === 'completed'}
            type="primary"
            shape="circle"
            icon={<FileDoneOutlined />}
            onClick={() => handleCloseTicket(record)}
          />
        </Tooltip>
      ),
    },
  ];

  const handleCloseTicket = (ticket: any) => {
    Modal.confirm({
      title: `Are you sure you want to close ticket no. ${ticket.externalTicketId}?`,
      onOk: () =>
        tmsService.closeTicket(ticket.id, ticket.externalTicketId).then(() => {
          window.location.reload();
        }),
      okText: 'Close ticket',
    });
  };

  const getMoreTickets = (skip: any, pageNum: any, size: any) => {
    if (!pages.includes(pageNum)) {
      const addPage = [...pages, pageNum];
      skip = filterData.length;
      tmsService.getTickets(skip, size).then((data: any) => {
        const newData = [...filterData, ...data];

        setFilterdata(newData);
      });

      setPages(addPage);
    }
  };

  return (
    <Table
      columns={columns}
      dataSource={filterData}
      pagination={{ pageSize: 10, showSizeChanger: false }}
      onChange={(e) => {
        getMoreTickets(0, +e.current + 1, e.pageSize);
      }}
    />
  );
};

export default TicketsTable;
