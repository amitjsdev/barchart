import React, { useState, useEffect, Component, useRef } from 'react';
import { connect, history, useModel, useAccess } from 'umi';
import { Col, Row, Tabs, Menu, Dropdown, Button, Badge, Result, Tooltip } from 'antd';

import { ModuleTypes } from '@/services/Constants';
import nonMohService from '../services/nonMoh.service';
import InventoryTable from './components/InventoryTable/InventoryTable';
import { InventoryType } from './Types';
import { StateType } from './model';

import styles from './index.less';

const { TabPane } = Tabs;

enum StatusNames {
  'outOfStock' = 'OOS',
  'nearOutOfStock' = 'NOOS',
  'safeStock' = 'SS',
  'overStock' = 'OS',
}

const InventoryContainer = (props) => {
  const {
    inventories,
    userLocation,
    userLocationId,
    onChangeTab,
    currentInventoryLocationId,
    onFilter,
    onUpdate,
    tableHeight,
    locationsKeys,
    access,
  } = props;

  const [height, setHeight] = useState(0);
  const ref = useRef(null);

  useEffect(() => {
    setHeight(ref.current.clientHeight);
  });

  const [filters, setFilters] = useState({
    status: 'clear',
    type: 'clear',
  });

  const Filters = (props) => {
    const onFilterChange = (value, key) => {
      const newFilters = { ...filters, [key]: value };
      setFilters(newFilters);
      onFilter(newFilters);
    };

    const menu = (
      <Menu onClick={(e) => onFilterChange(e.key, 'status')}>
        <Menu.Item key="outOfStock">
          <Badge color="red" /> OOS
        </Menu.Item>
        <Menu.Item key="nearOutOfStock">
          <Badge color="orange" /> NOOS
        </Menu.Item>
        <Menu.Item key="safeStock">
          <Badge color="green" />
          SS
        </Menu.Item>
        <Menu.Item key="overStock">
          <Badge color="purple" />
          OS
        </Menu.Item>
        <Menu.Item key="clear">Clear Status</Menu.Item>
      </Menu>
    );
    return (
      <Dropdown overlay={menu} placement="bottomRight">
        {/* <Button>Filters</Button> */}
        <Button type={filters.status !== 'clear' ? 'primary' : 'default'}>
          {filters.status !== 'clear' ? StatusNames[filters.status] : 'Status'}
        </Button>
      </Dropdown>
    );
  };

  return (
    <div className={styles.main}>
      <div className={styles.container}>
        <Row gutter={[24, 24]}>
          <Col>
            <div ref={ref} className={styles.tableContainer}>
              <Tabs
                activeKey={locationsKeys[currentInventoryLocationId]}
                onChange={onChangeTab}
                tabBarExtraContent={Filters(props.onFilter)}
              >
                {!access.canReadAllNonMohInventory()
                  ? Object.keys(inventories)
                      .map((locationKey) => {
                        return inventories[locationKey];
                      })
                      .filter((inventory) => inventory?.locationDetails?.code === userLocation)
                      .map((inventory: InventoryType) => {
                        const key = locationsKeys[inventory.locationDetails.id];
                        return (
                          <TabPane
                            key={key}
                            tab={
                              <Tooltip title={inventory.locationDetails.name}>
                                {inventory.locationDetails.code}
                              </Tooltip>
                            }
                          >
                            <InventoryTable
                              skus={inventory.skus}
                              locationDetails={inventory.locationDetails}
                              userLocationId={userLocationId}
                              inventoryLocationId={inventory.locationDetails.id}
                              onUpdate={props.onUpdate}
                              tableHeight={height}
                              access={access}
                            />
                          </TabPane>
                        );
                      })
                  : Object.keys(inventories)
                      .map((locationKey) => {
                        return inventories[locationKey];
                      })
                      .map((inventory: InventoryType) => {
                        const key = locationsKeys[inventory.locationDetails.id];
                        return (
                          <TabPane
                            key={key}
                            tab={
                              <Tooltip title={inventory.locationDetails.name}>
                                {inventory.locationDetails.code}
                              </Tooltip>
                            }
                          >
                            <InventoryTable
                              skus={inventory.skus}
                              locationDetails={inventory.locationDetails}
                              userLocationId={userLocationId}
                              inventoryLocationId={inventory.locationDetails.id}
                              onUpdate={props.onUpdate}
                              tableHeight={height}
                              access={access}
                            />
                          </TabPane>
                        );
                      })}
              </Tabs>
            </div>
          </Col>
        </Row>
      </div>
    </div>
  );
};

// const locationsKeys = ['nhl', 'mak', 'mad', 'asr', 'dam'];
const locationsKeys: {} = {};

const LabStatusWarning = () => {
  return (
    <div className={styles.labStatusWarning}>
      <Result
        className={styles.result}
        status="warning"
        title="The lab status isn't updated yet"
        subTitle="Please complete the lab status to access the inventory. If its updated try refreshing."
        extra={
          <Button type="primary" onClick={() => history.push('/non-moh/survey')}>
            Go to lab status
          </Button>
        }
      />
    </div>
  );
};

class InventoryNonMoh extends Component {
  nonMohProfile: App.Module | undefined;

  constructor(props) {
    super(props);

    const { currentUser } = props;
    this.nonMohProfile = currentUser.modules.find((module) => module.name === ModuleTypes.NON_MOH);
    const userLocationId = this.nonMohProfile?.locationId;

    this.state = {
      userLocationId,
      userLocation: '',
      currentInventoryLocationId: userLocationId,
      labStatus: false,
      // isInventoryStatusUpdated: false
    };

    this.onChangeTab = this.onChangeTab.bind(this);
  }

  async componentDidMount() {
    const { dispatch } = this.props;
    const labStatus = await nonMohService.getSurveyFormStatus(this.nonMohProfile?.locationId);
    const allLocationDetails = await nonMohService.getLocations();
    allLocationDetails.map((location: any) => {
      locationsKeys[location.id] = location.code;
    });

    this.setState({
      userLocation: locationsKeys[this.nonMohProfile?.locationId],
      labStatus,
    });

    dispatch({
      type: 'inventory_nonMoh/initInventories',
      payload: {
        allLocationDetails,
        userLocation: this.state.userLocation,
        locationId: this.state.userLocationId,
        page: 0,
      },
    });
  }

  onChangeTab(activeKey) {
    const { dispatch } = this.props;
    const locationId = Object.keys(locationsKeys).find((key) => locationsKeys[key] === activeKey);
    this.setState({
      currentInventoryLocationId: locationId,
    });
    dispatch({
      type: 'inventory_nonMoh/fetchInventory',
      payload: {
        locationKey: activeKey,
        locationId,
        page: 0,
      },
    });
  }

  refreshInventory = async (filter, key?) => {
    const { dispatch } = this.props;

    if (filter.status === 'clear' && filter.type === 'clear') {
      dispatch({
        type: 'inventory_nonMoh/fetchInventory',
        payload: {
          locationId: this.state.currentInventoryLocationId,
          page: 0,
          locationKey: locationsKeys[this.state.currentInventoryLocationId],
        },
      });
    } else {
      const payload = {
        filter,
        locationId: this.state.currentInventoryLocationId,
        page: 0,
        locationKey: locationsKeys[this.state.currentInventoryLocationId],
      };

      dispatch({
        type: 'inventory_nonMoh/fetchFilteredInventory',
        payload,
      });
    }
  };

  render() {
    const { inventories, access } = this.props;

    return this.state.labStatus || access.canReadAllNonMohInventory() ? (
      <InventoryContainer
        inventories={inventories}
        userLocation={this.state.userLocation}
        userLocationId={this.state.userLocationId}
        onChangeTab={this.onChangeTab}
        currentInventoryLocationId={this.state.currentInventoryLocationId}
        onFilter={(filter) => this.refreshInventory(filter)}
        onUpdate={(key) => this.refreshInventory({ status: 'clear', type: 'clear' })}
        locationsKeys={locationsKeys}
        access={access}
      />
    ) : (
      <LabStatusWarning />
    );
  }
}

const InventoryNonMohWrapper: React.FC<any> = (props: any) => {
  const { initialState } = useModel('@@initialState');
  return (
    <InventoryNonMoh {...props} access={useAccess()} currentUser={initialState?.currentUser} />
  );
};

export default connect(({ inventory_nonMoh }: { inventory_nonMoh: StateType }) => {
  return {
    inventories: inventory_nonMoh,
  };
})(InventoryNonMohWrapper);
