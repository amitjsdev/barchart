/* eslint-disable class-methods-use-this */
import React, { Component } from 'react';
import { Access } from 'umi';
import { Table, Button, Col, Row, Badge, Space, Popconfirm, Tooltip, Typography } from 'antd';

import OrderModal from '@/components/Modal/OrderModal';
import { DeleteOutlined, EditOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import moment from 'moment';
import { Modal } from 'antd/es';
import { ModuleTypes } from '@/services/Constants';
import styles from './index.less';
import EditModal from '../EditModal/EditModal';
import { ColumnType, SKUType } from '../../Types';
import nonMohService from '../../../services/nonMoh.service';

const { Text } = Typography;

// Excluding Checkbox column
const getTotalColumnWidth = (columns: ColumnType[]): number => {
  return columns.reduce((acc, cur) => acc + parseInt(cur.width, 10), 0);
};

const onViewBatches = async (skuId) => {
  const res = await nonMohService.getBatches(skuId);
};

const ViewBatchesButton = (props) => {
  const { skuId } = props;
  return <Button onClick={() => onViewBatches(skuId)}>View batches</Button>;
};

interface StateType {
  skuColumns: ColumnType[];
  skus: SKUType[];
  showEditModal: boolean;
  userLocationId: number;
  editModalContent: SKUType | null;
  editModalBatches: any | null;
  selectedRowKeys: any;
  selectedOrder: any;
  expandRowData: any[];
  nestedColumns: any[];
  loadEpandableRowdata: boolean;
  expandedRowKeys: any[];
  inventoryLocationId: number;
  isInventoryStatusUpdated: boolean;
}

interface PropsType {
  skus: SKUType[];
  userLocationId: number;
  inventoryLocationId: number;
  tableHeight: number;
  access: any;
}

class InventoryTable extends Component<PropsType, StateType> {
  constructor(props) {
    super(props);

    this.state = {
      skuColumns: [
        {
          title: 'S. No.',
          width: '100px',
          dataIndex: 'serialNum',
          key: 'serialNum',
          fixed: 'left',
          render: (text, record, index) => (
            <Space>
              <Badge status={this.isUpdatedToday(record) ? 'success' : 'error'} />
              <Text>{index + 1}</Text>
            </Space>
          ),
        },
        {
          title: 'Brand name',
          width: '150px',
          dataIndex: ['product', 'code'],
          key: 'code',
          fixed: 'left',
        },
        {
          title: 'Description',
          width: '300px',
          dataIndex: ['product', 'description'],
          key: 'description',
          fixed: 'left',
        },
        {
          title: 'Brand Code',
          width: '150px',
          dataIndex: ['nupcoInventory', 'brandCode'],
          key: 'classification',
        },
        {
          title: 'NUPCO Item Code',
          width: '150px',
          dataIndex: ['nupcoInventory', 'nupcoItemCode'],
          key: 'classification',
        },
        {
          title: 'Type',
          width: '150px',
          dataIndex: ['product', 'classification'],
          key: 'classification',
        },
        {
          title: 'Quantities in hand',
          width: '200px',
          dataIndex: 'quantity',
          key: 'quantity',
        },
        {
          title: 'Quantities in transit',
          width: '200px',
          dataIndex: 'quantitiesInTransit',
          key: 'quantitiesInTransit',
        },

        {
          title: 'Nupco Current Inventory',
          width: '200px',
          dataIndex: ['nupcoInventory', 'availableInventory'],
          key: 'availableInventory',
          render: (text, record) => this.formatColumn(text),
        },
        {
          title: 'Nupco Total Request Inventory',
          width: '200px',
          dataIndex: ['nupcoInventory', 'totalInventory'],
          key: 'totalInventory',
          render: (text, record) => this.formatColumn(text),
        },

        {
          title: 'UOM',
          width: '200px',
          dataIndex: ['product', 'unitOfMeasures'],
          key: 'unitOfMeasures',
        },
        {
          title: 'Actual Daily Consumption',
          width: '200px',
          dataIndex: 'dailyConsumption',
          key: 'dailyConsumption',
        },
        {
          title: 'Avg. Actual Consumption',
          width: '200px',
          dataIndex: 'consumption',
          key: 'consumption',
          render: (text, record) => Math.round(text),
        },
        {
          title: 'Reorder Level',
          width: '200px',
          dataIndex: 'reOrderLevel',
          key: 'reOrderLevel',
        },
        {
          title: 'Suggested Quantity',
          width: '200px',
          dataIndex: 'reOrderQuantity',
          key: 'reOrderQuantity',
        },
        /* {
          title: 'Monthly Consumption',
          width: '200px',
          dataIndex: 'monthlyConsumption',
          key: 'monthlyConsumption',
        }, */
        {
          title: 'Expected Covering days',
          width: '200px',
          dataIndex: 'consumableDays',
          key: 'consumableDays',
        },
        {
          title: 'Last updated at',
          width: '200px',
          dataIndex: 'updatedAt',
          key: 'updatedAt',
          render: (text) => <Text>{moment(text).format('YYYY-MM-DD, HH:mm')}</Text>,
        },
      ],
      skus: this.props.skus,
      showEditModal: false,
      loadEpandableRowdata: true,
      expandedRowKeys: [],
      expandRowData: [],
      userLocationId: this.props.userLocationId,
      inventoryLocationId: this.props.inventoryLocationId,
      editModalContent: null,
      selectedRowKeys: [],
      selectedOrder: null,
      nestedColumns: [
        {
          title: 'S. No.',
          width: '100px',
          dataIndex: 'serialNum',
          key: 'serialNum',
          fixed: 'left',
          render: (text, record, index) => <Text>{index + 1}</Text>,
        },
        {
          title: 'Batch number',
          // width: '200px',
          dataIndex: 'batchNumber',
          key: 'batchNumber',
        },
        {
          title: 'Batch quantity',
          // width: '200px',
          dataIndex: 'quantity',
          key: 'quantity',
        },
        {
          title: 'Manufactured date',
          // width: '200px',
          dataIndex: 'manufactureDate',
          key: 'manufactureDate',
        },
        {
          title: 'Expiry date',
          // width: '200px',
          dataIndex: 'expiryDate',
          key: 'expiryDate',
        },
      ],
      isInventoryStatusUpdated: false,
    };

    this.configureRowSelction = this.configureRowSelction.bind(this);
    this.editButton = this.editButton.bind(this);
    this.onEdit = this.onEdit.bind(this);
  }

  async componentDidMount() {
    const { locationDetails } = this.props;
    const inventoryConfirmationStatus = await nonMohService.getInventoryStatus(locationDetails.id);
    if (inventoryConfirmationStatus) {
      this.setState({
        isInventoryStatusUpdated: true,
      });
    }
  }

  static getDerivedStateFromProps(props, currentState) {
    return {
      skus: props.skus,
    };
  }

  private async onEdit(sku) {
    const skuBatchDetails = await nonMohService.getBatches(sku.id);

    this.setState({
      editModalContent: sku,
      editModalBatches: skuBatchDetails,
      showEditModal: true,
    });
  }

  private isUpdatedToday(sku: SKUType) {
    const lastUpdatedOn = sku.updatedAt;
    const today = moment();

    return moment(lastUpdatedOn).isSame(today, 'day');
  }

  formatColumn(text) {
    if (text === 0) return <Text type="danger"> Unavailable </Text>;
    if (text < 20001) return text;
    if (text > 20001) return <Text type="success"> Available </Text>;
  }

  // Excluding Checkbox column
  private getTotalColumnWidth(columns: ColumnType[]): number {
    return columns.reduce((acc, cur) => acc + parseInt(cur.width, 10), 0);
  }

  handleOk = async (updates) => {
    const dailyConsumptionPayload = {
      dailyConsumption: updates.dailyConsumption,
      productId: this.state.editModalContent?.productId,
      locationId: this.state.editModalContent?.locationId,
      inventoryId: this.state.editModalContent?.id,
    };

    const batchesPayload = updates?.batches?.map((batch) => {
      return {
        ...batch,
        productId: this.state.editModalContent?.productId,
        locationId: this.state.editModalContent?.locationId,
        inventoryId: this.state.editModalContent?.id,
        hasExpiry: !!batch.expiryDate,
      };
    });

    if (updates.callUpdateApi) {
      await nonMohService.updateBatches(batchesPayload);
      await nonMohService.updateDailyConsumption(dailyConsumptionPayload);
    }

    this.props.onUpdate();
    this.fetchBatches(this.state.editModalContent?.id);
    this.setState({
      showEditModal: false,
      editModalBatches: null,
      editModalContent: null,
    });
    // window.location.reload();
  };

  handleCancel = () => {
    this.setState({
      showEditModal: false,
      editModalBatches: null,
      editModalContent: null,
    });
    // this.props.onUpdate();
    // window.location.reload();
  };

  // Row checkbox config
  private configureRowSelction() {
    return {
      onChange: (selectedRowKeys, selectedRows) => {
        this.onSelectChange(selectedRowKeys);
      },
      getCheckboxProps: (record: SKUType) => {
        return {
          code: record.product.code,
          disabled:
            !this.props.access.canPlaceNonMohPurchaseOrder(this.props.locationDetails.id) ||
            !this.state.isInventoryStatusUpdated ||
            record.nupcoInventory.availableInventory === 0,
        };
      },
    };
  }

  editButton(sku) {
    const { locationDetails, access } = this.props;
    return (
      <Access accessible={access.canUpdateNonMohInventory(locationDetails.id)}>
        <Tooltip title="Edit">
          <Button
            type="primary"
            shape="circle"
            icon={<EditOutlined />}
            onClick={() => this.onEdit(sku)}
          />
        </Tooltip>
      </Access>
    );
  }

  keys: any[] = [];

  getExpandableData = (inventoryId, rowId) => {
    this.keys[0] === rowId ? (this.keys = []) : (this.keys[0] = rowId);
    this.setState({
      expandRowData: [],
      loadEpandableRowdata: true,
      expandedRowKeys: this.keys,
    });
    this.fetchBatches(inventoryId);
  };

  fetchBatches = (inventoryId) => {
    nonMohService.getBatches(inventoryId).then((sku) => {
      this.setState({
        expandRowData: sku.batches,
        loadEpandableRowdata: false,
      });
    });
  };

  expandedRowRender = () => {
    let extraColumns = [];

    // Hide/Show Action Button
    if (
      this.state.expandRowData.length &&
      this.props.access.canUpdateNonMohInventory(this.state.inventoryLocationId)
    ) {
      extraColumns = [
        {
          title: 'Action',
          dataIndex: 'delete',
          key: 'delete',
          render: (text, record) =>
            this.state.expandRowData.length >= 1 ? (
              <Popconfirm title="Sure to delete?" onConfirm={() => this.handleDelete(record.id)}>
                <Tooltip title="Delete">
                  <Button type="primary" shape="circle" icon={<DeleteOutlined />} />
                </Tooltip>
                {/* <DeleteOutlined style={{ fontSize: '18px' }} /> */}
              </Popconfirm>
            ) : null,
        },
      ];
    }

    return (
      <Table
        columns={[...this.state.nestedColumns, ...extraColumns]}
        dataSource={this.state.expandRowData}
        pagination={false}
        loading={this.state.loadEpandableRowdata}
      />
    );
  };

  handleDelete = (id) => {
    nonMohService.deleteBatch(id).then(() => {
      const dataSource = [...this.state.expandRowData];

      this.setState({ expandRowData: dataSource.filter((item) => item.id !== id) });
      this.props.onUpdate();
    });
  };

  onSelectChange = (selectedRowKeys) => {
    const { skus, selectedOrder } = this.state;

    this.setState({ selectedRowKeys });

    const selectedOrderData: any = [];
    selectedRowKeys.forEach((el, index) => {
      const selectedRow = skus.find((sku) => sku.product.id === el);

      if (selectedRow.reOrderQuantity === 0) {
        // message.warning("In-sufficient Reorder Quantity");
        // selectedRowKeys = [];
        // this.setState({ selectedRowKeys });

        selectedOrderData.push({
          inventoryId: selectedRow.id,
          productId: selectedRow.productId,
          locationId: selectedRow.locationId,
          quantity: selectedRow.reOrderQuantity,
          code: selectedRow.product.code,
          description: selectedRow.product.description,
          quantitiesInTransit: selectedRow.quantitiesInTransit,
          nupcoInventoryQuantity: selectedRow.nupcoInventory.availableInventory,
        });
      } else {
        selectedOrderData.push({
          inventoryId: selectedRow.id,
          productId: selectedRow.productId,
          locationId: selectedRow.locationId,
          quantity: selectedRow.reOrderQuantity,
          code: selectedRow.product.code,
          description: selectedRow.product.description,
          quantitiesInTransit: selectedRow.quantitiesInTransit,
          nupcoInventoryQuantity: selectedRow.nupcoInventory.availableInventory,
        });
      }
    });

    this.setState({ selectedOrder: selectedOrderData });
  };

  render() {
    let extraColumns = [];
    // Hide/Show Action Button
    if (
      this.state.skus.length &&
      this.props.access.canUpdateNonMohInventory(this.state.inventoryLocationId)
    ) {
      extraColumns = [
        {
          title: 'Actions',
          width: '100px',
          dataIndex: 'actions',
          key: 'actions',
          fixed: 'right',
          render: (text, record) => this.editButton(record),
        },
      ];
    }

    const updateInventoryConfirmationStatus = (status) => {
      this.setState({
        isInventoryStatusUpdated: status,
      });
      window.location.reload();
    };

    const handleConfirmInventory = () => {
      const { locationDetails } = this.props;

      Modal.confirm({
        icon: <ExclamationCircleOutlined />,
        title: 'Are you sure you want to confirm the current status of the inventory?',
        content: 'This action is irreversible.',
        okText: 'Confirm',
        onOk() {
          return nonMohService
            .confirmInventoryStatus({ status: true, locationId: locationDetails.id })
            .then((res) => {
              if (res.success === true) {
                updateInventoryConfirmationStatus(true);
                window.location.reload();
              }
            });
        },
      });
    };

    return (
      <>
        <Table
          id="table-element"
          columns={[...this.state.skuColumns, ...extraColumns]}
          dataSource={this.state.skus}
          rowKey={(record) => record.product.id}
          rowSelection={this.configureRowSelction()}
          pagination={false}
          onExpand={(expanded, record) => this.getExpandableData(record.id, record.product.id)}
          expandedRowRender={(record) => this.expandedRowRender()}
          expandIconColumnIndex={0}
          expandedRowKeys={this.state.expandedRowKeys}
          expandIconAsCell
          rowExpandable={(record: any) =>
            record.product.classification === 'EXTRACTION' ||
            record.product.classification === 'PCR'
          }
          scroll={{
            x:
              this.getTotalColumnWidth(this.state.skuColumns) + // All columns
              300, // Checkbox
            y: this.props.tableHeight - 100,
          }}
        />

        <EditModal
          isVisible={this.state.showEditModal}
          skuDetails={this.state.editModalContent}
          skuBatchDetails={this.state.editModalBatches}
          handleOk={(edits) => this.handleOk(edits)}
          handleCancel={this.handleCancel}
        />
        {this.state.selectedRowKeys.length > 0 ? (
          <Access
            accessible={this.props.access.canPlaceNonMohPurchaseOrder(
              this.props.locationDetails.id,
            )}
          >
            <Row className={styles.stickyFooter}>
              <Col>
                <OrderModal
                  // style={this.orderModalStyles}
                  inputList={this.state.selectedOrder}
                  locationId={this.state.inventoryLocationId}
                  count={this.state.selectedOrder.length}
                  btnName="Place Order"
                  module={ModuleTypes.NON_MOH}
                />
              </Col>
            </Row>
          </Access>
        ) : null}
        {/* Confirm inventory sticky footer */}

        {this.props.access.canPlaceNonMohPurchaseOrder(this.props.locationDetails.id) &&
        !this.state.isInventoryStatusUpdated ? (
          <Row className={styles.stickyFooter}>
            <Col>
              <Button type="primary" onClick={handleConfirmInventory}>
                Confirm current inventory
              </Button>
            </Col>
          </Row>
        ) : null}
      </>
    );
  }
}

export default InventoryTable;
