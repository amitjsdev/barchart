import React from 'react';
import { Form, Input, InputNumber, Button, Row, Col, Modal, Divider, DatePicker } from 'antd';
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import moment from 'moment';

import { SKUType, BatchType } from '../../Types';

import styles from './index.less';

const areValuesChanged = (currentObj, previousObj): boolean => {
  const changedValues = Object.keys(previousObj)
    .filter((key) => currentObj.hasOwnProperty(key) && currentObj[key] !== previousObj[key])
    .map((key) => {
      return {
        [key]: currentObj[key],
      };
    });

  return Object.values(changedValues).length > 0 ? true : false;
};

const BatchEditForm = (props) => {
  const dateFormat = 'YYYY-MM-DD';
  const onFinish = (values) => {
    const { batches, prevBatches, dailyConsumption } = values;

    if (batches) {
      const updatedBatches = batches.map((batch) => {
        return {
          ...batch,
          manufactureDate: moment(batch.manufactureDate).format(dateFormat),
          expiryDate: moment(batch.expiryDate).format(dateFormat),
        };
      });

      // let dailyConsumptionPayload = null;
      // if (dailyConsumption !== props.currentDailyConsumption)
      let dailyConsumptionPayload = dailyConsumption;

      let callUpdateApi = true;

      if (updatedBatches.length > 0 || dailyConsumptionPayload)
        props.handleOk({
          batches: updatedBatches,
          dailyConsumption: dailyConsumptionPayload,
          callUpdateApi: callUpdateApi,
        });
    }

    if (prevBatches) {
      const updatedBatches = prevBatches
        .map((batchItem) => {
          const oldBatch = props.batches.find((oldBatchItem) => oldBatchItem.id === batchItem.id);
          if (oldBatch) {
            return {
              ...batchItem,
              manufactureDate: moment(batchItem.manufactureDate).format(dateFormat),
              expiryDate: moment(batchItem.expiryDate).format(dateFormat),
              id: oldBatch.id,
            };
          }
        })
        .filter((updatedBatch) => {
          const oldBatch = props.batches.find((batch) => batch.id === updatedBatch.id);
          if (oldBatch) return areValuesChanged(updatedBatch, oldBatch);
          return updatedBatch;
        });

      // let dailyConsumptionPayload = null;
      // if (dailyConsumption !== props.currentDailyConsumption)
      let dailyConsumptionPayload = dailyConsumption;

      let callUpdateApi = true;

      if (updatedBatches.length > 0 || dailyConsumptionPayload)
        props.handleOk({
          batches: updatedBatches,
          dailyConsumption: dailyConsumptionPayload,
          callUpdateApi: callUpdateApi,
        });
    }

    if (
      !prevBatches &&
      !batches &&
      dailyConsumption &&
      dailyConsumption !== props.currentDailyConsumption
    ) {
      let callUpdateApi = true;

      props.handleOk({ batches: [], dailyConsumption, callUpdateApi: callUpdateApi });
    }

    // props.batches = null;
  };

  const onCancel = () => {
    props.handleCancel();
  };

  const disabledDate = (current: any) => {
    // Can not select days after today
    return current && current > moment().endOf('day');
  };

  const disabledPastDates = (current: any) => {
    // Can not select days after today
    return current && current < moment().add(1, 'days');
  };

  const getInitalValue = (initialValue) => {
    return initialValue || '';
  };

  const FormFields = (props) => {
    const { batch, index, add, remove } = props;

    return (
      <div key={index}>
        <Form.Item
          name={[index, 'id']}
          fieldKey={[index, 'id']}
          initialValue={batch?.id}
        ></Form.Item>
        <Row gutter={[24, 24]}>
          <Col span={11}>
            <Form.Item
              label="Batch number"
              name={[index, 'batchNumber']}
              fieldKey={[index, 'batchNumber']}
              rules={[{ required: true, message: 'Missing batch number' }]}
              initialValue={batch?.batchNumber}
            >
              <Input placeholder="Batch number" />
            </Form.Item>
          </Col>
          <Col span={11}>
            <Form.Item
              label="Batch quantity"
              name={[index, 'quantity']}
              fieldKey={[index, 'quantity']}
              rules={[
                { required: true, message: 'Missing quantity' },
                {
                  type: 'number',
                  min: 1,
                  message: 'Should be more than 0',
                },
              ]}
              initialValue={batch?.quantity}
            >
              <InputNumber placeholder="Batch quantity" style={{ width: '100%' }} />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={[24, 24]}>
          <Col span={11}>
            <Form.Item
              label="Manufactured date"
              name={[index, 'manufactureDate']}
              fieldKey={[index, 'manufactureDate']}
              initialValue={batch?.manufactureDate ? moment(batch?.manufactureDate) : ''}
              rules={[{ required: true, message: 'Missing manufactured date' }]}
            >
              <DatePicker
                defaultValue={moment(batch?.manufactureDate, dateFormat)}
                // defaultPickerValue={moment(batch?.manufactureDate, dateFormat)}
                disabledDate={disabledDate}
                format={dateFormat}
                style={{ width: '100%' }}
              />
            </Form.Item>
          </Col>
          <Col span={11}>
            <Form.Item
              label="Expiry date"
              name={[index, 'expiryDate']}
              fieldKey={[index, 'expiryDate']}
              initialValue={batch?.expiryDate ? moment(batch?.expiryDate) : ''}
              rules={[{ required: true, message: 'Missing expiry date' }]}
            >
              <DatePicker
                defaultValue={moment(batch?.expiryDate, dateFormat)}
                // defaultPickerValue={moment(batch?.expiryDate, dateFormat)}
                // value={moment(batch?.expiryDate, dateFormat)}
                format={dateFormat}
                disabledDate={disabledPastDates}
                style={{ width: '100%' }}
              />
            </Form.Item>
          </Col>
          {/* <Col span={4}>
            <MinusCircleOutlined
              onClick={() => {
                // remove(field.name);
              }}
            />
          </Col> */}
        </Row>
        <Divider />
      </div>
    );
  };

  return (
    <Form layout="vertical" name="batchEditForm" onFinish={onFinish} autoComplete="off">
      {props.batches.length ? (
        <>
          <Form.Item
            label="Actual daily consumption"
            name={'dailyConsumption'}
            fieldKey={'dailyConsumption'}
            rules={[
              { required: true, message: 'Missing Daily consumption' },
              {
                type: 'number',
                min: 0,
                message: 'Please enter a valid quantity',
              },
            ]}
            initialValue={props.currentDailyConsumption}
          >
            <InputNumber placeholder="Actual Daily Consumption" style={{ width: '100%' }} />
          </Form.Item>
          <Divider />
        </>
      ) : null}
      <Form.List name="prevBatches">
        {() => {
          return props.batches?.map((batch, index) => {
            return batch ? <FormFields index={index} batch={batch} initialValue={batch} /> : null;
          });
        }}
      </Form.List>
      <Form.List name="batches">
        {(fields, { add, remove }) => {
          return (
            <div>
              {fields.map((field, index) => (
                <div key={index}>
                  <Row gutter={[24, 24]}>
                    <Col span={11}>
                      <Form.Item
                        label="Batch number"
                        {...field}
                        name={[field.name, 'batchNumber']}
                        fieldKey={[field.fieldKey, 'batchNumber']}
                        rules={[{ required: true, message: 'Missing batch number' }]}
                        // initialValue={getInitalValue(batches[index]?.batchNumber)}
                      >
                        <Input placeholder="" />
                      </Form.Item>
                    </Col>
                    <Col span={11}>
                      <Form.Item
                        label="Batch quantity"
                        {...field}
                        name={[field.name, 'quantity']}
                        fieldKey={[field.fieldKey, 'quantity']}
                        rules={[
                          { required: true, message: 'Missing quantity' },
                          {
                            type: 'number',
                            min: 1,
                            message: 'Should be more than 0',
                          },
                        ]}
                        // initialValue={getInitalValue(batches[index]?.quantity)}
                      >
                        <InputNumber placeholder="" style={{ width: '100%' }} />
                      </Form.Item>
                    </Col>
                  </Row>
                  <Row gutter={[24, 24]} align="middle">
                    <Col span={11}>
                      <Form.Item
                        label="Manufactured date"
                        {...field}
                        name={[field.name, 'manufactureDate']}
                        fieldKey={[field.fieldKey, 'manufactureDate']}
                        rules={[{ required: true, message: 'Missing manufactured date' }]}
                      >
                        <DatePicker
                          // defaultValue={
                          //   getInitalValue(batches[index]?.manufactureDate).length > 1
                          //     ? moment(getInitalValue(batches[index]?.manufactureDate), dateFormat)
                          //     : moment()
                          // }
                          disabledDate={disabledDate}
                          style={{ width: '100%' }}
                        />
                      </Form.Item>
                    </Col>
                    <Col span={11}>
                      <Form.Item
                        label="Expiry date"
                        {...field}
                        name={[field.name, 'expiryDate']}
                        fieldKey={[field.fieldKey, 'expiryDate']}
                        rules={[{ required: true, message: 'Missing expiry date' }]}
                      >
                        <DatePicker
                          // defaultValue={
                          //   getInitalValue(batches[index]?.expiryDate).length > 1
                          //     ? moment(getInitalValue(batches[index]?.expiryDate), dateFormat)
                          //     : moment().add(1, 'days')
                          // }
                          disabledDate={disabledPastDates}
                          style={{ width: '100%' }}
                        />
                      </Form.Item>
                    </Col>
                    <Col span={2}>
                      <MinusCircleOutlined
                        onClick={() => {
                          remove(field.name);
                        }}
                      />
                    </Col>
                  </Row>
                  <Divider />
                </div>
              ))}

              <Form.Item>
                <Button
                  type="dashed"
                  onClick={() => {
                    add();
                  }}
                  block
                >
                  {() => {
                    if (batches) {
                      batches.forEach((batch) => {
                        add();
                      });
                    }
                  }}
                  <PlusOutlined /> Add batch
                </Button>
              </Form.Item>
            </div>
          );
        }}
      </Form.List>

      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item>
            <Button type="primary" htmlType="submit" block>
              Apply
            </Button>
          </Form.Item>
        </Col>
        <Col flex={1}>
          <Form.Item>
            <Button onClick={onCancel} block>
              Cancel
            </Button>
          </Form.Item>
        </Col>
      </Row>
    </Form>
  );
};

const BasicEditForm = (props) => {
  const [form] = Form.useForm();

  const batchDetail = props.batches[0];
  const { currentDailyConsumption } = props;
  const onFinish = (values) => {
    const { quantity, dailyConsumption } = values;
    const batches = [
      {
        quantity,
        id: batchDetail.id,
      },
    ];
    //
    // let dailyConsumptionPayload = null;
    // if (dailyConsumption !== currentDailyConsumption)
    let dailyConsumptionPayload = dailyConsumption;
    // let updatedBatches = null;
    // if (batches[0].quantity !== props.batches[0].quantity)
    let updatedBatches = batches;
    let callUpdateApi = true;
    if (
      dailyConsumption === currentDailyConsumption &&
      batches[0].quantity === props.batches[0].quantity
    ) {
      callUpdateApi = false;
    }

    if (updatedBatches || dailyConsumptionPayload)
      props.handleOk({
        batches: updatedBatches,
        dailyConsumption: dailyConsumptionPayload,
        callUpdateApi: callUpdateApi,
      });
  };

  const onCancel = () => {
    props.handleCancel();
  };

  return (
    <Form layout="vertical" form={form} name="basicEditForm" onFinish={onFinish}>
      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item
            name="quantity"
            label="Quantities in hand"
            rules={[
              { required: true },
              {
                type: 'number',
                min: 0,
                message: 'Please enter a valid quantity',
              },
            ]}
            initialValue={batchDetail.quantity}
          >
            <InputNumber style={{ width: '100%' }} />
          </Form.Item>
        </Col>
      </Row>
      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item
            name="dailyConsumption"
            label="Actual daily consumption"
            rules={[
              { required: true },
              {
                type: 'number',
                min: 0,
                message: 'Please enter a valid number',
              },
            ]}
            initialValue={currentDailyConsumption}
          >
            <InputNumber style={{ width: '100%' }} />
          </Form.Item>
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item>
            <Button type="primary" htmlType="submit" block>
              Apply
            </Button>
          </Form.Item>
        </Col>
        <Col flex={1}>
          <Form.Item>
            <Button onClick={onCancel} block>
              Cancel
            </Button>
          </Form.Item>
        </Col>
      </Row>
    </Form>
  );
};

const EditModal = (props) => {
  const { skuDetails, skuBatchDetails, handleOk, handleCancel, isVisible } = props;
  const title = skuDetails?.product?.description || 'Edit';
  let batchDetails = skuBatchDetails;

  batchDetails ||= null;

  //
  if (batchDetails) {
    return (
      <>
        {/* <Spin spinning={!isVisible} /> */}
        <Modal
          title={title}
          visible={isVisible}
          afterClose={() => handleCancel()}
          destroyOnClose
          closable={false}
          footer={false}
        >
          {skuDetails &&
          (skuDetails?.product.classification === 'EXTRACTION' ||
            skuDetails?.product.classification === 'PCR') ? (
            <BatchEditForm
              batches={batchDetails?.batches || null}
              currentDailyConsumption={skuDetails.dailyConsumption}
              handleOk={(updatedBatches) => handleOk(updatedBatches)}
              handleCancel={() => handleCancel()}
            />
          ) : (
            <BasicEditForm
              batches={batchDetails?.batches || null}
              currentDailyConsumption={skuDetails.dailyConsumption}
              handleOk={(updatedBatches) => handleOk(updatedBatches)}
              handleCancel={() => handleCancel()}
            />
          )}
        </Modal>
      </>
    );
  } else {
    return null;
  }
};

export default EditModal;
