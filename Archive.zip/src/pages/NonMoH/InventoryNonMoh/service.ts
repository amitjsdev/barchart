import Apis from '@/api/apis';

interface IInventoryParams {
  locationId: number;
  page: number;
}

export async function getInventory(payload: IInventoryParams) {
  return Apis.getNonMohInventory(payload.locationId, payload.page);
}

export async function getLocations() {
  return Apis.getLocations();
}

export async function getBatches(skuId) {
  return Apis.getBatches(skuId);
}

export async function updateBatches(data) {
  return Apis.updateBatches(data);
}

export async function updateDailyConsumption(data) {
  return Apis.updateDailyConsumption(data);
}

export async function getFilteredInventory(payload) {
  return Apis.nonMohfilterInventory(payload.locationId, payload.page, payload.filter);
}

export async function confirmInventory(status) {
  return Apis.confirmInventory(status);
}

export async function getNonMohInventoryStatus() {
  return Apis.getNonMohInventoryStatus();
}

export async function getSurveyFormStatus() {
  return Apis.getSurveyFormStatus().then((res) => res?.message);
}
