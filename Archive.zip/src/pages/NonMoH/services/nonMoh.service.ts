import { message } from 'antd';
import moment from 'moment';

import httpService from '@/services/http.service';
import errorHandler from '@/services/errorHandler';
import apiService from '@/shared/services/api.service';
import { LabTypes, ApiUrlFragments } from '@/services/Constants';

export default {
  getInventory: (payload: { locationId: number; page: number }) => {
    const limit = 150;
    const { locationId, page } = payload;

    return httpService
      .get<API.InventoryResponse>(`${ApiUrlFragments.INVENTORY}/nonmoh-inventories/${locationId}`, {
        params: { page, limit },
      })
      .then((res) => res.results)
      .catch((err) => errorHandler(err));
  },

  getFilteredInventory: (payload: {
    locationId: number;
    page: number;
    filter: { status: string; type: string };
  }) => {
    const limit = 150;
    const { locationId, page, filter } = payload;
    const params = {
      page,
      limit,
    };

    if (filter.status !== 'clear') params[filter.status] = true;

    return httpService
      .get<API.InventoryResponse>(`${ApiUrlFragments.INVENTORY}/nonmoh-inventories/${locationId}`, {
        params,
      })
      .then((res) => res.results)
      .catch((err) => errorHandler(err));
  },

  getInventoryStatus: (locationId: number) => {
    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/surveys/lab-status`, {
        params: {
          locationId,
          date: moment().format('YYYY-MM-DD'),
        },
      })
      .then((data: any) => data.message)
      .catch((err) => errorHandler(err));
  },

  confirmInventoryStatus: (payload: NonMoh.API.ConfirmInventoryRequest) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/surveys/lab-status`, payload)
      .then((data) => {
        message.success('Inventory status updated successfully');
        return data;
      })
      .catch((err) => errorHandler(err));
  },

  getSurveyFormStatus: (locationId: number) => {
    return apiService
      .getSurveyFormStatus(locationId)
      .then((data: any) => data.message)
      .catch((err) => errorHandler(err));
  },

  getLastUpdatedSurveyData: (locationId: number) => {
    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/surveys/draft/latest/${locationId}`)
      .catch((err) => errorHandler(err));
  },

  submitSurveyForm: (formData: any) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/surveys/nonmoh-create`, formData)
      .then((data: any) => {
        message.success('Survey form uploaded successfully');
        return data;
      })
      .catch((err) => errorHandler(err));
  },

  saveSurveyForm: (formData: any, date: string, locationId: number) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/surveys/draft/${date}/${locationId}`, formData)
      .catch((err) => errorHandler(err));
  },

  getNupcoInventory: () => {
    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/nupco-inventories`)
      .then((data: any) => data.data)
      .catch((err) => errorHandler(err));
  },

  updateNupcoInventory: (update: any, skuId: number) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/nupco-inventories/${skuId}`, update)
      .then(() => message.success('SKU updated successfully'))
      .catch((err) => errorHandler(err));
  },

  getLocations: () => {
    return apiService.getLocationsByLabType(LabTypes.NON_MOH);
  },

  getOrders: (
    locationId: number,
    status: App.PurchaseOrderStatus,
    isApproved = null,
    brandName?: string,
  ) => {
    const params = { labType: LabTypes.NON_MOH, status, productCode: brandName };
    if (isApproved !== null) params['isApproved'] = isApproved;
    if (locationId) params['location'] = locationId;

    return httpService
      .get(`${ApiUrlFragments.INVENTORY}/purchase-order`, { params })
      .then((data: any) => data.data)
      .catch((err) => errorHandler(err));
  },

  getTickets: ({ locationId }) => {
    return apiService.getImsTickets(LabTypes.NON_MOH, locationId);
  },

  getBatches: (skuId: number) => {
    return apiService.getBatches(skuId);
  },

  updateBatches: (update: API.UpdateBatchRequest) => {
    return apiService
      .updateBatches(update)
      .then(() => message.success('Batches updated successfully'));
  },

  updateDailyConsumption: (update: API.UpdateDailyConsumptionRequest) => {
    return apiService
      .updateDailyConsumption(update)
      .then(() => message.success('Daily consumption updated successfully'));
  },

  deleteBatch: (batchId: number) => {
    return apiService.deleteBatch(batchId).then(() => message.success('Batch deleted'));
  },

  updateOrder: (orderId: number, data: any) => {
    return apiService.updateOrder(orderId, data).then(() => message.success('Order updated'));
  },

  approveOrder: (orderId: number) => {
    return apiService.approveOrder(orderId).then(() => message.success('Order approved'));
  },

  deleteOrder: (orderId: number) => {
    return apiService.deleteOrder(orderId).then(() => message.success('Order deleted'));
  },

  closeTicket: (ticketId: number) => {
    return apiService
      .closeImsTicket(ticketId)
      .then(() => message.success(`Ticket no. ${ticketId} was closed successfully!`));
  },

  uploadInflowOutflowData: (data: any) => {
    return httpService
      .post(`${ApiUrlFragments.INVENTORY}/flows`, data)
      .then(() => message.success('File uploaded successfully'))
      .catch((err) => errorHandler(err));
  },

  getAllBrandNames: () => {
    return httpService
      .get<NonMoh.API.GetAllBrandNamesResponse>(`${ApiUrlFragments.INVENTORY}/products/codes`, {
        params: {
          labType: LabTypes.NON_MOH,
        },
      })
      .then((data) => data.results.data)
      .catch((err) => errorHandler(err));
  },

  downloadPurchaseOrder: (key: string) => {
    // return httpService.get(`${ApiUrlFragments.DOWNLOAD}/${key}`).catch((err) => errorHandler(err));
    window.location.replace(`${ApiUrlFragments.DOWNLOAD}/${key}`)
  },
};
