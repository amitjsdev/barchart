import React, { useState, useEffect } from 'react';
import { Spin } from 'antd';
import nonMohService from '../services/nonMoh.service';
import NupcoInventoryTable from './NupcoInventoryTable';

const NupcoInventory: React.FC<any> = (props) => {
  const [nupcoInventoryData, setNupcoInventoryData] = useState([]);
  const [loading, setLoading] = useState(true);

  const getNupcoInventoryData = () => {
    nonMohService.getNupcoInventory().then((response: any) => {
      setNupcoInventoryData(response);
      setLoading(false);
    });
  };

  useEffect(() => {
    getNupcoInventoryData();
  }, []);

  return (
    <>
      {nupcoInventoryData?.length ? (
        <NupcoInventoryTable
          nupcoInventoryData={nupcoInventoryData}
          getNupcoInventoryData={getNupcoInventoryData}
        />
      ) : (
        <Spin spinning={loading} size="large" />
      )}
    </>
  );
};

export default NupcoInventory;
