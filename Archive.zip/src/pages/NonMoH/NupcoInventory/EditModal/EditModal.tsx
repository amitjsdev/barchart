import React from 'react';
import { Form, InputNumber, Button, Row, Col, Modal, DatePicker } from 'antd';
import moment from 'moment';

const BasicEditForm = (props: any) => {
  const [form] = Form.useForm();

  const { currentInventory, totalInventory, expiryDate } = props;

  const dateFormat = 'YYYY-MM-DD';

  const onFinish = (values: any) => {
    props.handleOk(values);
  };

  const onCancel = () => {
    props.handleCancel();
  };

  const disabledPastDates = (current: any) => {
    // Can not select days after today
    return current && current < moment().add(1, 'days');
  };

  return (
    <Form layout="vertical" form={form} name="basicEditForm" onFinish={onFinish}>
      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item
            name="availableInventory"
            label="Current Inventory"
            rules={[
              { required: true },
              {
                type: 'number',
                min: 0,
                message: 'Please enter a valid quantity',
              },
            ]}
            initialValue={currentInventory}
          >
            <InputNumber style={{ width: '100%' }} />
          </Form.Item>
        </Col>
      </Row>
      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item
            name="totalInventory"
            label="Total Request Inventory"
            rules={[
              { required: true },
              {
                type: 'number',
                min: 0,
                message: 'Please enter a valid number',
              },
            ]}
            initialValue={totalInventory}
          >
            <InputNumber style={{ width: '100%' }} />
          </Form.Item>
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item
            label="Expiry date"
            name="expiryDate"
            fieldKey="expiryDate"
            initialValue={expiryDate ? moment(expiryDate) : ''}
            rules={[{ required: true, message: 'Missing expiry date' }]}
          >
            <DatePicker
              // defaultValue={moment(expiryDate, dateFormat)}
              // defaultPickerValue={expiryDate? moment(expiryDate, dateFormat): }
              // value={moment(expiryDate, dateFormat)}
              format={dateFormat}
              disabledDate={disabledPastDates}
              style={{ width: '100%' }}
            />
          </Form.Item>
        </Col>
      </Row>

      <Row gutter={[24, 24]}>
        <Col flex={1}>
          <Form.Item>
            <Button type="primary" htmlType="submit" block>
              Apply
            </Button>
          </Form.Item>
        </Col>
        <Col flex={1}>
          <Form.Item>
            <Button onClick={onCancel} block>
              Cancel
            </Button>
          </Form.Item>
        </Col>
      </Row>
    </Form>
  );
};

const EditModal = (props: any) => {
  const { skuDetails, handleOk, handleCancel, isVisible } = props;
  const title = skuDetails?.product?.description || 'Edit';

  if (skuDetails) {
    return (
      <>
        {/* <Spin spinning={!isVisible} /> */}
        <Modal
          title={title}
          visible={isVisible}
          afterClose={() => handleCancel()}
          destroyOnClose
          closable={false}
          footer={false}
        >
          <BasicEditForm
            currentInventory={skuDetails.availableInventory}
            totalInventory={skuDetails.totalInventory}
            expiryDate={skuDetails.expiryDate}
            handleOk={(updatedBatches: any) => handleOk(updatedBatches)}
            handleCancel={() => handleCancel()}
          />
        </Modal>
      </>
    );
  }
  return null;
};

export default EditModal;
