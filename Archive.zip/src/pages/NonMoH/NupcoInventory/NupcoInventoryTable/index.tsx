import React, { useState } from 'react';
// import styles from './index.less';
import { Button, Table, Tooltip, Typography } from 'antd';
import { EditOutlined } from '@ant-design/icons';
import moment from 'moment';
import EditModal from '../EditModal/EditModal';
import nonMohService from '../../services/nonMoh.service';

const NupcoInventoryTable: React.FC<any> = (props) => {
  const { Text } = Typography;

  const [showEditModal, setShowEditModal] = useState(false);
  const [editModalContent, setEditModalContent] = useState({});

  const columns = [
    {
      title: 'S. No.',
      width: '100px',
      dataIndex: 'serialNum',
      key: 'serialNum',
      fixed: 'left',
      render: (text: any, record: any, index: any) => <Text>{index + 1}</Text>,
    },
    {
      title: 'Brand name',
      width: '200px',
      dataIndex: 'code',
      key: 'code',
      fixed: 'left',
    },
    {
      title: 'Description',
      width: '300px',
      dataIndex: 'description',
      key: 'description',
      fixed: 'left',
    },

    {
      title: 'Current Inventory',
      width: '200px',
      dataIndex: 'availableInventory',
      key: 'availableInventory',
    },
    {
      title: 'Total Request Inventory',
      width: '200px',
      dataIndex: 'totalInventory',
      key: 'totalInventory',
    },
    {
      title: 'Remaining Inventory',
      width: '200px',
      dataIndex: 'remainingInventory',
      key: 'remainingInventory',
    },
    {
      title: 'Expiry Date',
      width: '200px',
      dataIndex: 'expiryDate',
      key: 'expiryDate',
      render: (text, record) => {
        return text ? moment(text).format('YYYY-MM-DD') : '-';
      },
    },

    {
      title: 'Actions',
      width: '100px',
      dataIndex: 'actions',
      key: 'actions',
      fixed: 'right',
      render: (text: any, record: any) => editButton(record),
    },
  ];

  const editButton = (sku: any) => {
    return (
      <Tooltip title="Edit">
        <Button type="primary" shape="circle" icon={<EditOutlined />} onClick={() => onEdit(sku)} />
      </Tooltip>
    );
  };

  const onEdit = (sku: any) => {
    setShowEditModal(true);
    setEditModalContent(sku);
  };

  const handleCancel = () => {
    setShowEditModal(false);
    setEditModalContent({});
  };

  const handleOk = async (updateData: any) => {
    await nonMohService.updateNupcoInventory(updateData, editModalContent.id);
    setShowEditModal(false);
    setEditModalContent({});
    props.getNupcoInventoryData();
  };

  return (
    <>
      <Table columns={columns} dataSource={props.nupcoInventoryData} pagination={false} />
      <EditModal
        isVisible={showEditModal}
        skuDetails={editModalContent}
        handleOk={(edits: any) => handleOk(edits)}
        handleCancel={handleCancel}
      />
    </>
  );
};

export default NupcoInventoryTable;
