/* eslint-disable react/no-unused-state */
import React, { Component } from 'react';
import { Table, Button, Tooltip, Typography, Tag, Modal } from 'antd';
import { useAccess } from 'umi';
import moment from 'moment';
import { FileDoneOutlined, InfoCircleFilled } from '@ant-design/icons';

import nonMohService from '../../../services/nonMoh.service';
import { TicketTypeNames, PriorityColors, ITicket } from '../../Types';
import styles from './index.less';

const { Text } = Typography;

const DATE_FORMAT = 'YYYY-MM-DD';

class NonMohTicketsTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      columns: [
        /* {
          title: 'Lab code',
          width: '100px',
          dataIndex: 'locationCode',
          key: 'locationCode',
          fixed: 'left',
        }, */
        {
          title: 'Ticket No.',
          width: '100px',
          dataIndex: 'id',
          key: 'id',
          fixed: 'left',
        },
        {
          title: 'Product Code',
          width: '100px',
          dataIndex: 'productCode',
          key: 'productCode',
        },
        {
          title: '',
          width: '20px',
          dataIndex: 'productDescription',
          key: 'productDescription',
          render: (text, record) => {
            return (
              <Tooltip placement="top" title={text}>
                <InfoCircleFilled />
              </Tooltip>
            );
          },
        },
        {
          title: 'Type',
          width: '100px',
          dataIndex: 'type',
          key: 'type',
          render: (text, record) => {
            return TicketTypeNames[text];
          },
        },
        {
          title: 'Status',
          width: '100px',
          dataIndex: 'status',
          key: 'status',
          render: (text) => <Text className={styles.status}>{text}</Text>,
        },
        {
          title: 'Due date',
          width: '100px',
          dataIndex: 'dueDate',
          key: 'dueDate',
          render: (text, record) => {
            return moment(text).format(DATE_FORMAT);
          },
        },
        {
          title: 'Priority',
          width: '100px',
          dataIndex: 'priority',
          key: 'priority',
          render: (text) => (
            <Tag color={PriorityColors[text]} className={styles.priorityTags}>
              {text}
            </Tag>
          ),
        },
        {
          title: 'Created on',
          width: '100px',
          dataIndex: 'createdAt',
          key: 'createdAt',
          render: (text, record) => {
            return moment(text).format(DATE_FORMAT);
          },
        },
      ],
    };
    this.handleCloseTicket = this.handleCloseTicket.bind(this);
  }

  private getTotalColumnWidth(columns: ColumnType[]): number {
    return columns.reduce((acc, cur) => acc + parseInt(cur.width, 10), 0);
  }

  // handleUpdate()

  handleCloseTicket(ticket: ITicket) {
    Modal.confirm({
      title: `Are you sure you want to close ticket no. ${ticket.id}?`,
      onOk: () =>
        nonMohService.closeTicket(ticket.id).then(() => {
          window.location.reload();
          // this.props.onUpdate();
        }),
      okText: 'Close ticket',
    });
  }

  render() {
    const { tickets, tableHeight } = this.props;

    const actionColumn = {
      title: 'Actions',
      width: '100px',
      dataIndex: 'action',
      key: 'action',
      fixed: 'right',
      render: (text, record) => (
        <Tooltip title="Close ticket">
          <Button
            disabled={record.status === 'completed'}
            type="primary"
            shape="circle"
            icon={<FileDoneOutlined />}
            onClick={() => this.handleCloseTicket(record)}
          />
        </Tooltip>
      ),
    };

    return (
      <Table
        columns={
          this.props.access.canCloseNonMohTickets()
            ? [...this.state.columns, actionColumn]
            : this.state.columns
        }
        dataSource={tickets}
        pagination={false}
        scroll={{
          x:
            this.getTotalColumnWidth(this.state.columns) + // All columns
            300, // Checkbox
          y: tableHeight - 100,
        }}
      />
    );
  }
}

const NonMohTicketsTableWrapper = (props) => <NonMohTicketsTable {...props} access={useAccess()} />;

export default NonMohTicketsTableWrapper;
