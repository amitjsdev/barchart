import React, { Component, useState, useEffect, useRef } from 'react';
import { connect, useModel } from 'umi';
import { Spin, Tabs, Row, Col, Tooltip } from 'antd';

import { ModuleTypes } from '@/services/Constants';
import nonMohServices from '../services/nonMoh.service';

import styles from './index.less';
import NonMohTicketsTable from './components/NonMohTicketsTable/NonMohTicketTable';

const { TabPane } = Tabs;

const TicketsListContianer = (props) => {
  const { tickets, locationKeys, onChangeTab, currentLocationId, onUpdate } = props;
  const [height, setHeight] = useState(0);
  const ref = useRef(null);

  useEffect(() => {
    setHeight(ref.current.clientHeight);
  });

  const onChange = (activeKey) => {
    onChangeTab(activeKey);
  };

  return (
    <div className={styles.main}>
      <div className={styles.container}>
        <Row gutter={[24, 24]}>
          <Col>
            <div ref={ref} className={styles.tableContainer}>
              <Tabs activeKey={locationKeys[currentLocationId]} onChange={onChange}>
                {Object.keys(tickets)
                  .map((locationKey) => tickets[locationKey])
                  .map((location) => {
                    const key = locationKeys[location.locationDetails.id];
                    return (
                      <TabPane
                        key={key}
                        tab={
                          <Tooltip title={location.locationDetails.name}>
                            {location.locationDetails.code}
                          </Tooltip>
                        }
                      >
                        <NonMohTicketsTable
                          tickets={location.tickets}
                          tableHeight={height}
                          onUpdate={onUpdate}
                        />
                      </TabPane>
                    );
                  })}
              </Tabs>
            </div>
          </Col>
        </Row>
      </div>
    </div>
  );
};

class NonMohTickets extends Component {
  constructor(props) {
    super(props);

    const { currentUser }: App.InitialStateType = props;
    const nonMohProfile = currentUser?.modules.find(
      (module) => module.name === ModuleTypes.NON_MOH,
    );
    const userLocationId = nonMohProfile?.locationId;

    this.state = {
      userLocationId,
      userLocation: '',
      currentLocationId: userLocationId,
      locationKeys: null,
      isLoading: true,
    };

    this.onChangeTab = this.onChangeTab.bind(this);
  }

  async componentDidMount() {
    const { dispatch } = this.props;
    const allLocations = await nonMohServices.getLocations();
    const locationKeys = {};
    allLocations.forEach((location: any) => {
      locationKeys[location.id] = location.code;
    });

    this.setState((prevState) => ({
      locationKeys,
      userLocation: locationKeys[prevState.userLocationId],
    }));

    dispatch({
      type: 'nonMohTickets/initTickets',
      payload: {
        allLocations,
        userLocation: this.state.userLocation,
        locationId: this.state.userLocationId,
      },
    });

    this.setState({ isLoading: false });
  }

  onChangeTab(activeKey) {
    this.fetchTicketsByLocation(activeKey);
  }

  getLocationId(locationKey: string) {
    const { locationKeys } = this.state;
    return Object.keys(locationKeys).find((key) => locationKeys[key] === locationKey);
  }

  fetchTicketsByLocation(locationKey) {
    const { dispatch } = this.props;
    const locationId = this.getLocationId(locationKey);

    this.setState({
      currentLocationId: locationId,
    });
    dispatch({
      type: 'nonMohTickets/fetchTicketsByLocation',
      payload: {
        locationKey,
        locationId,
      },
    });
  }

  handleUpdate() {
    const { currentLocationId: locationId, locationKeys } = this.state;
    const locationKey = locationKeys[locationId];
    this.fetchTicketsByLocation(locationKey);
  }

  render() {
    const { tickets } = this.props;
    const { isLoading, userLocation, userLocationId, locationKeys, currentLocationId } = this.state;

    return !isLoading ? (
      <TicketsListContianer
        tickets={tickets}
        userLocation={userLocation}
        userLocationId={userLocationId}
        locationKeys={locationKeys}
        currentLocationId={currentLocationId}
        onChangeTab={this.onChangeTab}
        onUpdate={this.handleUpdate}
      />
    ) : (
      <Spin />
    );
  }
}

const NonMohTicketsWrapper: React.FC<any> = (props) => {
  const { initialState } = useModel('@@initialState');

  return initialState?.currentUser ? (
    <NonMohTickets {...props} currentUser={initialState.currentUser} />
  ) : null;
};

export default connect(({ nonMohTickets }: { nonMohTickets: any }) => {
  return {
    tickets: nonMohTickets,
  };
})(NonMohTicketsWrapper);
