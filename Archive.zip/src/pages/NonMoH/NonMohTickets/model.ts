import { Effect, Reducer } from 'umi';

import nonMohService from '../services/nonMoh.service';

export interface ModelType {
  namespace: string;
  state: any;
  effects: {
    initTickets: Effect;
    fetchTicketsByLocation: Effect;
  };
  reducers: {
    updateLocations: Reducer<any>;
    addTickets: Reducer<any>;
    // updateTicket: Reducer<any>;
  };
}

const Model: ModelType = {
  namespace: 'nonMohTickets',
  state: {},
  effects: {
    *initTickets({ payload }, { call, put }) {
      const { userLocation, allLocations, ...getTicketsParams } = payload;
      const { data } = yield call(nonMohService.getTickets, getTicketsParams);

      const locations = {};

      allLocations.forEach((location) => {
        locations[location.code] = {
          locationDetails: location,
          tickets: [],
        };
      });

      locations[userLocation].tickets = data;

      yield put({
        type: 'updateLocations',
        payload: locations,
      });
    },
    *fetchTicketsByLocation({ payload }, { call, put }) {
      const { locationKey, ...params } = payload;
      const { data } = yield call(nonMohService.getTickets, params);

      yield put({
        type: 'addTickets',
        payload: {
          locationKey,
          tickets: data,
        },
      });
    },
  },
  reducers: {
    updateLocations(state, { payload }) {
      return { ...state, ...payload };
    },
    addTickets(state, { payload }) {
      const { locationKey, tickets } = payload;
      const location = {};

      location[locationKey] = {
        locationDetails: state[locationKey].locationDetails,
        tickets,
      };

      return {
        ...state,
        ...location,
      };
    },
  },
};

export default Model;
