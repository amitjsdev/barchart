declare namespace NonMoh {
  export namespace API {
    export interface ConfirmInventoryRequest {
      status: boolean;
      locationId: number;
    }

    export interface GetAllBrandNamesResponse {
      success: boolean;
      results: {
        data: ProductCode[]
      }
    };

    export interface ProductCode {
      id: number;
      code: string;
    }
  }
}
