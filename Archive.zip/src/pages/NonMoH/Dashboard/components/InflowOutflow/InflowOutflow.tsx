import React, { useState, useEffect } from 'react';
import cubejs, { ResultSet } from '@cubejs-client/core';
import { Spin, Empty } from 'antd';
import { Chart, Axis, Tooltip, Legend, LineAdvance } from 'bizcharts';
import moment from 'moment';

import { getCubejsApiParams } from '@/services/cubejs';

enum ProductClassifications {
  EXTRACTION = 'EXTRACTION',
  PCR = 'PCR',
}

enum DatumNames {
  'Flows.date' = 'Date',
  'DailyConsumptions.consumptiondate' = 'Date',
  'Flows.inflow' = 'Inflow',
  'Flows.outflow' = 'Outflow',
  'Flows.allInflow' = 'Inflow',
  'Flows.allOutflow' = 'Outflow',
  'Extraction daily consumption' = 'Extraction daily consumption',
  'PCR daily consumption' = 'PCR daily consumption',
}

const datumKeysForSpecificLocationData = {
  FLOW_DATE: 'Flows.date',
  DAILY_CONSUMPTION_DATE: 'DailyConsumptions.consumptiondate',
  INFLOW: 'Flows.inflow',
  OUTFLOW: 'Flows.outflow',
  DAILY_CONSUMPTION: 'DailyConsumptions.consumption',
  EXTRACTION_CONSUMPTION: 'Extraction daily consumption',
  PCR_CONSUMPTION: 'PCR daily consumption',
};

const datumKeysForAllLocationData = {
  FLOW_DATE: 'Flows.date',
  DAILY_CONSUMPTION_DATE: 'DailyConsumptions.consumptiondate',
  INFLOW: 'Flows.allInflow',
  OUTFLOW: 'Flows.allOutflow',
  DAILY_CONSUMPTION: 'DailyConsumptions.consumption',
  EXTRACTION_CONSUMPTION: 'Extraction daily consumption',
  PCR_CONSUMPTION: 'PCR daily consumption',
};

const DATE_FORMAT = 'DD-MM-YYYY';

const colors = ['color', ['#753BBD', '#27a29e', '#E1BE4C', '#E33C3C']];

const LineRender = ({ chartData }) => {
  if (chartData?.length) {
    return (
      <Chart scale={{ x: { tickCount: 8 } }} data={chartData} autoFit padding="auto">
        <Axis name="x" label={false} tickLine={false} />
        <Axis name="measure" />
        <Tooltip />
        {/* <Geom type="area" position={`x*measure`} size={2} color={colors} /> */}
        <LineAdvance shape="smooth" point area position="x*measure" color={colors} />
        <Legend visible />
      </Chart>
    );
  }
  return <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
};

const InflowOutflow = (props) => {
  const { dateRangeFilter, location } = props;
  const [chartData, setChartData] = useState([]);

  const cubejsParams = getCubejsApiParams();
  const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

  let basicFilters = [];
  let datumKeys = datumKeysForAllLocationData;

  if (location && location !== 'All locations') {
    basicFilters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
    datumKeys = datumKeysForSpecificLocationData;
  }

  basicFilters = [
    ...basicFilters,
    /*     {
      member: datumKeys.FLOW_DATE,
      operator: 'inDateRange',
      values: dateRangeFilter.dateRange,
    }, */
    {
      member: 'Locations.labType',
      operator: 'equals',
      values: ['nonmoh'],
    },
    /* {
      dimension: 'Products.labType',
      operator: 'equals',
      values: ['nonmoh'],
    }, */
  ];

  const getCombinedData = (
    inflowOutflowResultSet: ResultSet,
    pcrResultSet: ResultSet,
    extractionResultSet: ResultSet,
  ) => {
    const inflowOutflowData = inflowOutflowResultSet.tablePivot().map((datum) => {
      const { [datumKeys.FLOW_DATE]: date, ...rest } = datum;
      return { ...rest, [DatumNames[datumKeys.FLOW_DATE]]: date };
    });

    const pcrData = pcrResultSet.tablePivot().map((datum) => {
      const {
        [datumKeys.DAILY_CONSUMPTION]: pcr,
        [datumKeys.DAILY_CONSUMPTION_DATE]: date,
        ...rest
      } = datum;
      return {
        ...rest,
        [datumKeys.PCR_CONSUMPTION]: pcr,
        [DatumNames[datumKeys.DAILY_CONSUMPTION_DATE]]: date,
      };
    });

    const extractionData = extractionResultSet.tablePivot().map((datum) => {
      const {
        [datumKeys.DAILY_CONSUMPTION]: extraction,
        [datumKeys.DAILY_CONSUMPTION_DATE]: date,
        ...rest
      } = datum;
      return {
        ...rest,
        [datumKeys.EXTRACTION_CONSUMPTION]: extraction,
        [DatumNames[datumKeys.DAILY_CONSUMPTION_DATE]]: date,
      };
    });

    const dateSeries = new Set([
      ...inflowOutflowData.map((datum) => datum[DatumNames[datumKeys.FLOW_DATE]]),
      ...pcrData.map((datum) => datum[DatumNames[datumKeys.DAILY_CONSUMPTION_DATE]]),
      ...extractionData.map((datum) => datum[DatumNames[datumKeys.DAILY_CONSUMPTION_DATE]]),
    ]);

    const isSameDate = (date1: string, date2: string): boolean => {
      return moment(date1).isSame(date2, 'day');
    };

    const combinedData = [...dateSeries].map((date) => {
      const inflowOutflowDatum = inflowOutflowData.find((datum) =>
        isSameDate(datum[DatumNames[datumKeys.FLOW_DATE]], date),
      );
      const pcrDatum = pcrData.find((datum) =>
        isSameDate(datum[DatumNames[datumKeys.DAILY_CONSUMPTION_DATE]], date),
      );
      const extractionDatum = extractionData.find((datum) =>
        isSameDate(datum[DatumNames[datumKeys.DAILY_CONSUMPTION_DATE]], date),
      );

      const newDatum = {
        [DatumNames[datumKeys.FLOW_DATE]]: date,
        [datumKeys.EXTRACTION_CONSUMPTION]: 0,
        [datumKeys.PCR_CONSUMPTION]: 0,
        [datumKeys.INFLOW]: 0,
        [datumKeys.OUTFLOW]: 0,
      };

      return inflowOutflowDatum && pcrDatum && extractionDatum
        ? { ...inflowOutflowDatum, ...pcrDatum, ...extractionDatum }
        : { ...newDatum, ...inflowOutflowDatum, ...pcrDatum, ...extractionDatum };
    });

    return combinedData;
  };

  const getFormattedChartData = (combinedData: any[]) => {
    return combinedData
      .sort((a, b) => {
        const aDate = moment(a[DatumNames[datumKeys.FLOW_DATE]]);
        const bDate = moment(b[DatumNames[datumKeys.FLOW_DATE]]);

        if (aDate.isBefore(bDate)) return -1;

        if (aDate.isAfter(bDate)) return 1;

        return 0;
      })
      .map((datum) => {
        return [
          {
            x: moment(datum[DatumNames[datumKeys.DAILY_CONSUMPTION_DATE]]).format(DATE_FORMAT),
            color: DatumNames[datumKeys.EXTRACTION_CONSUMPTION],
            measure: datum[datumKeys.EXTRACTION_CONSUMPTION],
          },
          {
            x: moment(datum[DatumNames[datumKeys.DAILY_CONSUMPTION_DATE]]).format(DATE_FORMAT),
            color: DatumNames[datumKeys.PCR_CONSUMPTION],
            measure: datum[datumKeys.PCR_CONSUMPTION],
          },
          {
            x: moment(datum[DatumNames[datumKeys.FLOW_DATE]]).format(DATE_FORMAT),
            color: DatumNames[datumKeys.INFLOW],
            measure: datum[datumKeys.INFLOW],
          },
          {
            x: moment(datum[DatumNames[datumKeys.FLOW_DATE]]).format(DATE_FORMAT),
            color: DatumNames[datumKeys.OUTFLOW],
            measure: datum[datumKeys.OUTFLOW],
          },
        ];
      })
      .flat();
  };

  const mainQuery = {
    measures: [datumKeys.INFLOW, datumKeys.OUTFLOW],
    dimensions: [datumKeys.FLOW_DATE],
    filters: [...basicFilters],
    order: {
      [datumKeys.FLOW_DATE]: 'desc',
    },
    timeDimensions: [
      {
        dimension: datumKeys.FLOW_DATE,
        granularity: 'day',
        dateRange: dateRangeFilter.dateRange,
      },
    ],
  };

  const pcrConsumptionQuery = {
    measures: [datumKeys.DAILY_CONSUMPTION],
    dimensions: [datumKeys.DAILY_CONSUMPTION_DATE],
    filters: [
      ...basicFilters,
      {
        dimension: 'Products.classification',
        operator: 'contains',
        values: [ProductClassifications.PCR],
      },
      {
        dimension: 'Products.labType',
        operator: 'equals',
        values: ['nonmoh'],
      },
    ],
    /*     order: {
      [datumKeys.DAILY_CONSUMPTION_DATE]: 'desc',
    }, */
    timeDimensions: [
      {
        dimension: datumKeys.DAILY_CONSUMPTION_DATE,
        granularity: 'day',
        dateRange: dateRangeFilter.dateRange,
      },
    ],
  };

  const extractionConsumptionQuery = {
    measures: [datumKeys.DAILY_CONSUMPTION],
    dimensions: [datumKeys.DAILY_CONSUMPTION_DATE],
    filters: [
      ...basicFilters,
      {
        dimension: 'Products.classification',
        operator: 'contains',
        values: [ProductClassifications.EXTRACTION],
      },
      {
        dimension: 'Products.labType',
        operator: 'equals',
        values: ['nonmoh'],
      },
    ],
    /*     order: {
      [datumKeys.DAILY_CONSUMPTION_DATE]: 'desc',
    }, */
    timeDimensions: [
      {
        dimension: datumKeys.DAILY_CONSUMPTION_DATE,
        granularity: 'day',
        dateRange: dateRangeFilter.dateRange,
      },
    ],
  };

  useEffect(() => {
    const getCubeDate = async () => {
      const inflowOutflowResultSet = await cubejsApi.load(mainQuery);
      const pcrResultSet = await cubejsApi.load(pcrConsumptionQuery);
      const extractionResultSet = await cubejsApi.load(extractionConsumptionQuery);

      const combinedData = getCombinedData(
        inflowOutflowResultSet,
        pcrResultSet,
        extractionResultSet,
      );

      const formattedChartData = getFormattedChartData(combinedData);

      setChartData(formattedChartData);
    };

    getCubeDate();
  }, [dateRangeFilter, location]);

  return chartData ? <LineRender chartData={chartData} /> : <Spin />;
};

export default InflowOutflow;
