import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Row, Col, Statistic, Spin, Space, Typography } from 'antd';
import { InboxOutlined } from '@ant-design/icons';

import { getCubejsApiParams } from '@/services/cubejs';

const { Text } = Typography;

enum DatumNames {
  'NonMohSurveys.extractionTotalCapacity' = 'Extraction',
  'NonMohSurveys.allExtractionTotalCapacity' = 'Extraction',
  'NonMohSurveys.pcrTotalCapacity' = 'PCR',
  'NonMohSurveys.allPcrTotalCapacity' = 'PCR',
}

const datumKeysForSpecificLocationData = {
  EXTRACTION_CAPACITY: 'NonMohSurveys.extractionTotalCapacity',
  PCR_CAPACITY: 'NonMohSurveys.pcrTotalCapacity',
  DATE: 'NonMohSurveys.date',
  LOCATIONS: 'Locations.name',
} as const;

const datumKeysForAllLocationData = {
  EXTRACTION_CAPACITY: 'NonMohSurveys.allExtractionTotalCapacity',
  PCR_CAPACITY: 'NonMohSurveys.allPcrTotalCapacity',
  DATE: 'NonMohSurveys.date',
  LOCATIONS: 'Locations.name',
} as const;

const numberRender = ({ resultSet, pivotConfig }) => (
  <Row type="flex" justify="center" align="middle" style={{ height: '100%', width: '100%' }}>
    <Col style={{ width: '100%' }}>
      {resultSet.seriesNames().map((s) => {
        const label = DatumNames[s.key];
        return [
          DatumNames['NonMohSurveys.allExtractionTotalCapacity'],
          DatumNames['NonMohSurveys.extractionTotalCapacity'],
        ].includes(label) ? (
          <>
            <div style={{ float: 'left', width: '50%', borderRight: 'solid 1px' }}>
              <div style={{ textAlign: 'center' }}>
                <Statistic value={resultSet.totalRow()[s.key]} />
                <span style={{ fontSize: '12px' }}>{label} </span>
              </div>
            </div>
          </>
        ) : (
          <>
            <div style={{ float: 'right', width: '50%' }}>
              <div style={{ textAlign: 'center' }}>
                <Statistic value={resultSet.totalRow()[s.key]} />
                <span style={{ fontSize: '12px' }}>{label} </span>
              </div>
            </div>
          </>
        );
      })}
    </Col>
  </Row>
);

const cubejsParams = getCubejsApiParams();

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) => {
  const data = resultSet?.loadResponses[0]?.data || [];
  const result = (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
    (error && error.toString()) || <Spin />;

  const hasData = data[0] && Object.values(data[0]).some((value) => !!value);

  return hasData ? (
    result
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

const ChartRenderer = (props) => {
  const { location } = props;
  const filters = [];
  let datumKeys = datumKeysForAllLocationData;

  if (location && location !== 'All locations') {
    filters.push({ dimension: datumKeys.LOCATIONS, operator: 'equals', values: [location] });
    datumKeys = datumKeysForSpecificLocationData;
  }

  return (
    <QueryRenderer
      query={{
        measures: [datumKeys.EXTRACTION_CAPACITY, datumKeys.PCR_CAPACITY],
        dimensions: [datumKeys.DATE],
        filters,
        limit: 1,
        order: {
          [datumKeys.DATE]: 'desc',
        },
      }}
      cubejsApi={cubejsApi}
      render={renderChart(numberRender, {
        x: ['PurchaseOrders.orderdate'],
        y: ['measures'],
        fillMissingDates: true,
        joinDateRange: false,
      })}
    />
  );
};

export default ChartRenderer;
