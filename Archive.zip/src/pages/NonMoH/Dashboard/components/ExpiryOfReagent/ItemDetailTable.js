import React from 'react';
import { Table, Spin } from 'antd';

const getFormattedColumns = () => {
  return [
    {
      dataIndex: 'NonMohProducts.description',
      shortTitle: 'Non Moh Products Description',
      title: 'Non Moh Products Description',
      type: 'number',
    },
    {
      dataIndex: 'Locations.name',
      shortTitle: 'Locations Name',
      title: 'Locations Name',
      type: 'number',
    },
    // {
    //   dataIndex: 'Batches.expirydate',
    //   shortTitle: 'Batches Expirydate',
    //   title: 'Batches Expirydate',
    //   type: 'number',
    // },
    {
      dataIndex: 'NonMohBatches.quantity',
      shortTitle: 'Non Moh Batches Quantity',
      title: 'Non Moh Batches Quantity',
      type: 'number',
    },
  ];
};

const getFormattedData = (dataSource) => {
  return dataSource;
};

const ItemDetailTable = ({ resultSet, pivotConfig }) => {
  return resultSet ? (
    // <div className={styles.tableContainer}>
    <Table
      pagination={false}
      columns={getFormattedColumns()}
      dataSource={getFormattedData(resultSet.tablePivot(pivotConfig))}
    />
  ) : (
    // </div>
    <Spin />
  );
};

export default ItemDetailTable;
