import React, { useState } from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer, useCubeQuery } from '@cubejs-client/react';
import { Spin, Empty, Modal, Row, Col, Typography } from 'antd';
import { Chart, Axis, Tooltip, Interval, Geom, Coord, Legend } from 'bizcharts';
import hostname from '@/hostname';
import { getCubejsApiParams } from '@/services/cubejs';
import moment from 'moment';
import ItemDetailTable from './ItemDetailTable';

const colors = ['color', ['#753BBD']];

const MachineTestCount = (props) => {
  const { Title, Paragraph, Text } = Typography;
  const { dateRangeFilter, location, expiryfilter } = props;

  const DATE_FORMAT = 'YYYY-MM-DD';

  const expiryDateFilter = {
    dimension: 'NonMohBatches.expirydate',
    operator: 'inDateRange',
    values: [],
  };

  if (expiryfilter === '< 1 month') {
    expiryDateFilter.values = [
      moment().format(DATE_FORMAT),
      moment().add(1, 'month').format(DATE_FORMAT),
    ];
  } else if (expiryfilter === '1 - 3 months') {
    expiryDateFilter.values = [
      moment().add(1, 'month').format(DATE_FORMAT),
      moment().add(3, 'month').format(DATE_FORMAT),
    ];
  } else if (expiryfilter === '3+ months') {
    expiryDateFilter.values = [
      moment().add(3, 'month').format(DATE_FORMAT),
      moment().add(24, 'month').format(DATE_FORMAT),
    ];
  }

  const [drillDownQuery, setDrillDownQuery] = useState();
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [tableDescription, setTableDescription] = useState();

  const formatData = (data) => {
    return data.map((item) => {
      const formattedItem = { ...item };

      if (formattedItem.color.endsWith('NonMohBatches.quantity')) {
        formattedItem.color = 'Quantity';
        return formattedItem;
      }
    });
  };

  const stackedChartData = (resultSet) => {
    const data = resultSet
      .pivot()
      .map(({ xValues, yValuesArray }) =>
        yValuesArray.map(([yValues, m]) => ({
          x: resultSet.axisValuesString(xValues, ', '),
          color: resultSet.axisValuesString(yValues, ', '),
          measure: m && Number.parseFloat(m),
        })),
      )
      .reduce((a, b) => a.concat(b), []);

    return formatData(data);
    // return data;
  };

  const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

  const cubejsParams = getCubejsApiParams(API_URL);

  const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

  const filters = [
    expiryDateFilter,
    // {
    //   member: 'NonMohProducts.createdat',
    //   operator: 'inDateRange',
    //   values: dateRangeFilter.dateRange,
    // },
  ];

  const baseItemDetailsQuery = {
    measures: ['NonMohBatches.quantity'],
    timeDimensions: [],
    dimensions: ['NonMohProducts.description', 'Locations.name', 'NonMohBatches.expirydate'],
    filters: [],
    segments: [],
    order: {},
  };

  const getItemDetailQuery = (machineName) => {
    const filters = [
      {
        dimension: 'NonMohProducts.description',
        operator: 'equals',
        values: [machineName],
      },
    ];

    if (machineName.length && location && location !== 'All locations') {
      filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
    }
    filters.push(
      // {
      //   member: 'NonMohProducts.createdat',
      //   operator: 'inDateRange',
      //   values: dateRangeFilter.dateRange,
      // },
      expiryDateFilter,
      // {
      //   dimension: "SurveyOptions.key",
      //   operator: "contains",
      //   values: [
      //     "machine_pcr_working",
      //     "serology_working_machines",
      //     "machine_extraction_working"
      //   ]
      // },
    );
    const order = {};
    // order[stockType] = 'desc';

    return { ...baseItemDetailsQuery, filters };
  };

  if (location && location !== 'All locations') {
    filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
    // setTableDescription({
    //   location: location
    // })
  }

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['NonMohBatches.quantity'],
      timeDimensions: [],
      dimensions: ['NonMohProducts.description'],
      filters,
      segments: [],
      order: {},
    },
    {
      cubejsApi,
    },
  );

  const drillDownResponse = useCubeQuery(drillDownQuery, {
    skip: !drillDownQuery,
    cubejsApi,
  });

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const handleClickOnChart = (data) => {
    // const query = getXAndYValues(geomId);

    const query = {
      machineFullName: data.x,
      machineName: data.x,
    };

    setDrillDownQuery(getItemDetailQuery(query.machineName));

    if (drillDownResponse) {
      setTableDescription({
        machineFullName: query.machineFullName,
        machineName: query.machineName,
      });
      setIsModalVisible(true);
    }
  };

  const handleModalOk = () => setIsModalVisible(false);
  const handleModalCancel = () => setIsModalVisible(false);

  const BarRender = ({ resultSet }) => {
    if (resultSet?.loadResponses[0]?.data.length > 0) {
      return (
        <Chart
          scale={{ x: { tickCount: 8 } }}
          data={stackedChartData(resultSet)}
          autoFit
          padding="auto"
          onIntervalClick={(e, chart) => {
            handleClickOnChart(e.data.data);
          }}
        >
          <Axis name="x" label={false} tickLine={false} />
          <Axis name="measure" />
          <Tooltip />
          <Geom type="interval" position="x*measure" color={colors} />
        </Chart>
      );
    }
    return <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
  };

  const ModalHeader = () => (
    <Row>
      <Col>
        <Title level={4}>{tableDescription.machineFullName}</Title>
        {/* <Text type="secondary" level={5}>
          {tableDescription.location}
        </Text> */}
      </Col>
    </Row>
  );

  // const renderChart = (Component, pivotConfig) => ({ resultSet, error }) => {
  //
  //   const data = resultSet?.loadResponses[0]?.data;
  //   const result = (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
  //     (error && error.toString()) || <Spin />;

  //   return data && data.length ? result : <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
  // };

  // const timeDimensions = [
  //   {
  //     dimension: 'NonMohProducts.createdat',
  //     granularity: dateRangeFilter.granularity,
  //     dateRange: dateRangeFilter.dateRange,
  //   },
  // ];

  return (
    <>
      <BarRender resultSet={resultSet} />
      <Modal
        title={<ModalHeader />}
        centered
        visible={isModalVisible}
        width={720}
        onOk={handleModalOk}
        onCancel={handleModalCancel}
        destroyOnClose
        footer={false}
      >
        <ItemDetailTable
          resultSet={drillDownResponse.resultSet}
          pivotConfig={drillDownResponse.pivotConfig || null}
        />
      </Modal>
    </>
  );
};

export default MachineTestCount;
