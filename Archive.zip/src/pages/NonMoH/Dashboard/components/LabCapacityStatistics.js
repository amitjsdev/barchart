import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer, useCubeQuery } from '@cubejs-client/react';
import { Row, Col, Statistic, Table, Spin, Empty, Space, Typography } from 'antd';
import { InboxOutlined } from '@ant-design/icons';

import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '../../../../hostname';

const { Text } = Typography;

// CubeJS
const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint
const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

/**
 * @deprecated LabCapacityStatistics shouldn't be used anymore.
 * Use ExtractionPcrLabCapacityStatics instead.
 */
const cubeQueryRender = (props) => {
  const { dateRangeFilter, location } = props;
  const filters = [
    // {
    //   member: 'NonMohSurveys.date',
    //   operator: 'inDateRange',
    //   values: dateRangeFilter.dateRange,
    // },
  ];

  if (location && location !== 'All locations') {
    filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
  }

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['NonMohSurveys.extractionTotalCapacity', 'NonMohSurveys.pcrTotalCapacity'],
      dimensions: ['NonMohSurveys.date'],
      limit: 1,
      filters,
      timeDimensions: [],
      order: {
        'NonMohSurveys.date': 'desc',
      },
    },
    {
      cubejsApi,
    },
  );

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const dataSource = resultSet.tablePivot();

  return dataSource.length ? (
    <Statistic
      value={
        dataSource[0]['NonMohSurveys.extractionTotalCapacity'] <
        dataSource[0]['NonMohSurveys.pcrTotalCapacity']
          ? dataSource[0]['NonMohSurveys.extractionTotalCapacity']
          : dataSource[0]['NonMohSurveys.pcrTotalCapacity']
      }
    />
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

export default cubeQueryRender;
