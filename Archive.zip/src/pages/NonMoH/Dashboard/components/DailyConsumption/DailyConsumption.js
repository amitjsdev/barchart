import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer, useCubeQuery } from '@cubejs-client/react';
import { Spin, Empty } from 'antd';
import { Chart, Axis, Tooltip, Geom, Coord, Legend, LineAdvance } from 'bizcharts';
import hostname from '@/hostname';
import { getCubejsApiParams } from '@/services/cubejs';

const DailyConsumption = (props) => {
  const { dateRangeFilter, location } = props;
  let setDimention = '';

  const formatData = (data) => {
    return data.map((item) => {
      const formattedItem = { ...item };

      if (formattedItem.color.endsWith('DailyConsumptions.consumption')) {
        formattedItem.color = 'Daily Consumption';
        return formattedItem;
      }
      if (formattedItem.color.endsWith('Flows.inflow')) {
        formattedItem.color = 'Inflow';
        return formattedItem;
      }
      formattedItem.color = 'Outflow';
      return formattedItem;
    });
  };

  const stackedChartData = (resultSet) => {
    const data = resultSet
      .pivot()
      .map(({ xValues, yValuesArray }) =>
        yValuesArray.map(([yValues, m]) => ({
          x: resultSet.axisValuesString(xValues, ', '),
          color: resultSet.axisValuesString(yValues, ', '),
          measure: m && Number.parseFloat(m),
        })),
      )
      .reduce((a, b) => a.concat(b), []);

    return formatData(data);
  };

  const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

  const cubejsParams = getCubejsApiParams(API_URL);

  const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

  const colors = ['color', ['#753BBD', '#27a29e', '#E1BE4C']];

  const LineRender = ({ resultSet }) => {
    if (resultSet?.loadResponses[0]?.data.length > 0) {
      return (
        <Chart
          scale={{ x: { tickCount: 8 } }}
          data={stackedChartData(resultSet)}
          autoFit
          padding="auto"
        >
          <Axis name="x" label={false} tickLine={false} />
          <Axis name="measure" />
          <Tooltip />
          {/* <Geom type="area" position={`x*measure`} size={2} color={colors} /> */}
          <LineAdvance shape="smooth" point area position="x*measure" color={colors} />
          <Legend visible />
        </Chart>
      );
    }
    return <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
  };

  const filters = [
    {
      member: 'DailyConsumptions.consumptiondate',
      operator: 'inDateRange',
      values: dateRangeFilter.dateRange,
    },
    {
      member: 'Locations.labType',
      operator: 'equals',
      values: ['nonmoh'],
    },
  ];

  if (location && location !== 'All locations') {
    setDimention = 'DailyConsumptions.consumptiondate';
    filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
  } else {
    setDimention = 'Locations.name';
  }

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['DailyConsumptions.consumption', 'Flows.inflow', 'Flows.outflow'],
      dimensions: [setDimention],
      filters,
    },
    {
      cubejsApi,
    },
  );

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  return (
    <>
      <LineRender resultSet={resultSet} />
    </>
  );
};
export default DailyConsumption;
