import React from 'react';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { Spin, Empty } from 'antd';
import { Chart, Axis, Tooltip, Interval } from 'bizcharts';
import hostname from '@/hostname';
import { getCubejsApiParams } from '@/services/cubejs';

const TotalInventory = (props) => {
  const { location } = props;

  const formatData = (data) => {
    return data.map((item) => {
      const formattedItem = { ...item };

      if (formattedItem.color.endsWith('NonMohSurveys.extractionTotalCapacity')) {
        formattedItem.color = 'Extraction Capacity';
        return formattedItem;
      }
      formattedItem.color = 'PCR Capacity';
      return formattedItem;
    });
  };

  const stackedChartData = (resultSet) => {
    const data = resultSet
      .pivot()
      .map(({ xValues, yValuesArray }) =>
        yValuesArray.map(([yValues, m]) => ({
          x: resultSet.axisValuesString(xValues, ', '),
          color: resultSet.axisValuesString(yValues, ', '),
          measure: m && Number.parseFloat(m),
        })),
      )
      .reduce((a, b) => a.concat(b), []);

    return formatData(data);
  };

  const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

  const cubejsParams = getCubejsApiParams(API_URL);

  const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

  const colors = ['color', ['#753BBD', '#27a29e']];

  const BarRender = ({ resultSet }) => {
    return (
      <Chart
        scale={{ x: { tickCount: 8 } }}
        // height={280}
        data={stackedChartData(resultSet)}
        autoFit
        padding="auto"
      >
        <Axis name="x" label={false} tickLine={false} />
        <Axis name="measure" />
        <Tooltip />

        <Interval
          adjust={[
            {
              type: 'dodge',
              marginRatio: 0,
            },
          ]}
          position="x*measure"
          color={colors}
        />
      </Chart>
    );
  };

  const filters = [];

  if (location && location !== 'All locations') {
    filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
  }

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['NonMohSurveys.extractionTotalCapacity', 'NonMohSurveys.pcrTotalCapacity'],
      timeDimensions: [],
      dimensions: ['Locations.name', 'NonMohSurveys.date'],
      filters,
      limit: 1,
      order: {
        'NonMohSurveys.date': 'desc',
      },
    },
    {
      cubejsApi,
    },
  );

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const data = resultSet?.loadResponses[0].data || null;
  return data && data.length ? (
    <>
      <BarRender resultSet={resultSet} />
    </>
  ) : (
    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
  );
};
export default TotalInventory;
