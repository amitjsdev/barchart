import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer, useCubeQuery } from '@cubejs-client/react';
import { Row, Col, Statistic, Table, Spin, Empty, Space, Typography } from 'antd';
import { InboxOutlined } from '@ant-design/icons';

import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '../../../../hostname';

const { Text } = Typography;

// CubeJS
const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint
const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const cubeQueryRender = (props) => {
  const { dateRangeFilter, location } = props;
  const DATE_FORMAT = 'YYYY-MM-DD';
  const filters = [
    // {
    //   member: 'NonMohSurveys.date',
    //   operator: 'inDateRange',
    //   values: dateRangeFilter.dateRange,
    // },
  ];

  if (location && location !== 'All locations') {
    filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
  }

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['NonMohSurveys.manpower'],
      dimensions: ['NonMohSurveys.date'],
      filters,
      timeDimensions: [],
      order: {
        'NonMohSurveys.date': 'desc',
      },
      limit: 1,
    },
    {
      cubejsApi,
    },
  );

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const dataSource = resultSet.tablePivot();

  return dataSource && dataSource.length ? (
    <Statistic value={dataSource[0]['NonMohSurveys.manpower']} />
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

export default cubeQueryRender;
