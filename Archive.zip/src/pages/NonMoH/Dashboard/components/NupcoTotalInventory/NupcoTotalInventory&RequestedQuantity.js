import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Spin, Empty } from 'antd';
import { Chart, Axis, Tooltip, Geom, Coord, Legend, Interval, Annotation } from 'bizcharts';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';

const formatResultSet = (resultSet) => {
  const lastUptime = 0;
  resultSet.loadResponses[0].data = resultSet.loadResponses[0].data.map((item) => {
    const formattedItem = { ...item };
    if (formattedItem['NupcoInventories.totalInventory'] == 0) {
      formattedItem['NupcoInventories.totalInventory'] = formattedItem['OrderItems.quantity'] + 1;
    }

    const OrderItemPercentage =
      (formattedItem['OrderItems.quantity'] * 100) /
      formattedItem['NupcoInventories.totalInventory'];
    const NupcoTotalInventoryPercentage = 100 - OrderItemPercentage;
    formattedItem['OrderItems.quantity'] = +OrderItemPercentage.toFixed(2);
    formattedItem['NupcoInventories.totalInventory'] = +NupcoTotalInventoryPercentage.toFixed(2);
    return formattedItem;
  });

  return resultSet;
};

const formatData = (data) => {
  return data.map((item) => {
    const formattedItem = { ...item };
    if (formattedItem.color === 'NupcoInventories.totalInventory') {
      formattedItem.color = 'Total Nupco Inventory';
      return formattedItem;
    }

    formattedItem.color = 'Requested Quantity';
    return formattedItem;
  });
};

const stackedChartData = (resultSet) => {
  const data = resultSet
    .pivot()
    .map(({ xValues, yValuesArray }) =>
      yValuesArray.map(([yValues, m]) => ({
        x: resultSet.axisValuesString(xValues, ', '),
        color: resultSet.axisValuesString(yValues, ', '),
        measure: m && Number.parseFloat(m),
      })),
    )
    .reduce((a, b) => a.concat(b), []);

  return formatData(data);
};
// const colors = ['color', ['#292E29', '#1DAD28']];
const chartcolors = ['color', ['#291940', '#753BBD']];
const colors = ['red'];
const itemVal =
  '<li data-index={index}>' +
  '<span style="background-color:{color};width:8px;height:8px;border-radius:50%;display:inline-block;margin-right:8px;"></span>' +
  '{name}: {value}%' +
  '</li>';

const axisLabel = {
  formatter(text, item, index) {
    return `${text}%`;
  },
};

const dataMarkerConfig = {
  start: [3, '40%'],
  end: [2, '40%'],
  text: {
    content: '',
    style: {
      textAlign: 'center',
      fill: 'red',
    },
  },
  lineLength: 50,
};
const barRender = ({ resultSet }) => {
  return (
    <Chart
      // renderer="svg"
      scale={{ x: { tickCount: 8 } }}
      // height={300}
      data={stackedChartData(formatResultSet(resultSet))}
      autoFit
      padding="auto"
    >
      <Axis name="x" label={false} tickLine={false} />
      <Axis name="measure" label={axisLabel} />
      <Tooltip itemTpl={itemVal} />
      <Tooltip>
        {(title, items) => {
          return (
            <div style={{ padding: '10px' }}>
              <div>{title}</div>
              <br />
              <div>
                <span
                  style={{
                    backgroundColor: items[0].color,
                    width: '8px',
                    height: '8px',
                    borderRadius: '50%',
                    display: 'inline-block',
                    marginRight: '8px',
                  }}
                />
                {items[0]?.name}: {items[0]?.value}%
              </div>
            </div>
          );
        }}
      </Tooltip>
      {/* <Geom type="interval" position={`x*measure`} color={colors} /> */}
      {/* <Geom type="interval" position={`x*measure`} color={chartcolors}/> */}
      <Interval
        adjust={[
          {
            type: 'stack',
          },
        ]}
        color={chartcolors}
        position="x*measure"
      />
      <Annotation.Line
        start={['min', 40]}
        end={['max', 40]}
        text={{
          content: ``,
          style: {
            fill: colors[0],
          },
        }}
        style={{
          lineWidth: 2,
          lineDash: [2, 4],
          stroke: colors[0],
        }}
      />
    </Chart>
  );
};

const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) => {
  const data = resultSet?.loadResponses[0]?.data;
  const result = (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
    (error && error.toString()) || <Spin />;

  return data && data.length ? result : <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
};

const ChartRenderer = (props) => {
  const { dateRangeFilter } = props;

  /* const timeDimensions = [
    {
      dimension: 'Answers.date',
      granularity: dateRangeFilter.granularity,
      dateRange: dateRangeFilter.dateRange,
    },
  ]; */

  const filters = [
    //     { member: 'Answers.date', operator: 'inDateRange', values: dateRangeFilter.dateRange },
  ];

  return (
    <QueryRenderer
      query={{
        measures: ['NupcoInventories.totalInventory', 'OrderItems.quantity'],
        timeDimensions: [],
        filters,
        dimensions: ['NonMohProducts.description'],
        order: {},
      }}
      cubejsApi={cubejsApi}
      render={renderChart(barRender, {
        x: ['NonMohProducts.description'],
        y: ['measures'],
        fillMissingDates: true,
        joinDateRange: false,
      })}
    />
  );
};

export default ChartRenderer;
