/* eslint-disable @typescript-eslint/no-unused-expressions */
import React from 'react';
import { Modal, Button, message } from 'antd';
import * as Papa from 'papaparse';
import moment from 'moment';
import { reject } from 'lodash';
import nonMohService from '../../../services/nonMoh.service';
import UploadDrag from './UploadDrag';
import {
  InflowOutflowPropertyNames,
  InflowOutflowMandatoryPropertyNames,
  INFLOW_OUTFLOW_FILE_COLUMNS,
  INFLOW_OUTFLOW_MANDATORY_COLUMNS,
} from '../../Types';

import styles from './index.less';

class App extends React.Component {
  state = {
    visible: false,
    isValidDataAvailable: false,
    inflowOutflowData: null,
  };

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleOk = (e) => {
    const { inflowOutflowData, isValidDataAvailable } = this.state;

    if (isValidDataAvailable) {
      nonMohService.uploadInflowOutflowData(inflowOutflowData);
      this.setState({
        inflowOutflowData: null,
        isValidDataAvailable: false,
        visible: false,
      });
    } else {
      message.error('Upload a valid file');
    }
  };

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  };

  papaParseConfig = {
    header: true,
    dynamicTyping: true,
    worker: true,
    skipEmptyLines: true,
  };

  isValidFile = (file) => {
    return new Promise((resolve, reject) => {
      Papa.parse(file, {
        header: true,
        step: (row, parser) => {
          const headers: string[] = row.meta.fields;
          let isValid: boolean = false;
          const missingMandatoryColumns: string[] = [];

          if (headers.length >= INFLOW_OUTFLOW_MANDATORY_COLUMNS.length) {
            const containsMandatoryColumns: boolean = INFLOW_OUTFLOW_MANDATORY_COLUMNS.map(
              (mandatoryColumn) => {
                const isPresent: boolean = headers.includes(mandatoryColumn);
                if (!isPresent) missingMandatoryColumns.push(mandatoryColumn);
                return isPresent;
              },
            ).every((value) => value);

            if (containsMandatoryColumns) isValid = true;
          }
          parser.abort();
          resolve(isValid);
        },
        error: (err) => reject(err),
      });
    });
  };

  getFormattedData = (result) => {
    return result.data.map((row) => {
      const payload = {};
      INFLOW_OUTFLOW_MANDATORY_COLUMNS.forEach((mandtoryColumn) => {
        mandtoryColumn === 'Date'
          ? (payload[InflowOutflowMandatoryPropertyNames[mandtoryColumn]] = moment(
              row[mandtoryColumn],
            ).format('YYYY-MM-DD'))
          : (payload[InflowOutflowMandatoryPropertyNames[mandtoryColumn]] = row[mandtoryColumn]);
      });

      return payload;
    });
  };

  getParsedData = (file: File) => {
    return new Promise((resolve, reject) => {
      Papa.parse(file, {
        ...this.papaParseConfig,
        complete: (parsedData) => {
          resolve(parsedData);
        },
      });
    });
  };

  processFile = async (file: File) => {
    const isValid = await this.isValidFile(file);

    if (isValid) {
      const inflowOutFlowData = await this.getParsedData(file);
      this.setState({
        inflowOutflowData: this.getFormattedData(inflowOutFlowData),
        isValidDataAvailable: true,
      });
    }
  };

  render() {
    return (
      <div style={{ textAlign: 'right' }}>
        <Button type="primary" onClick={this.showModal}>
          Upload file
        </Button>
        <Modal
          title="Upload File"
          visible={this.state.visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          bodyStyle={{ background: 'black' }}
        >
          <UploadDrag onGetFileData={this.processFile} />
        </Modal>
      </div>
    );
  }
}

export default () => (
  <div>
    <div id="components-modal-demo-basic">
      <App />
    </div>
  </div>
);
