import React from 'react';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { Spin, Empty } from 'antd';
import { Chart, Axis, Tooltip, Interval } from 'bizcharts';
import hostname from '@/hostname';
import { getCubejsApiParams } from '@/services/cubejs';

const TotalInventory = (props) => {
  const { dateRangeFilter, location } = props;
  let finalObj = [];

  const formatData = (data) => {
    return data.map((item) => {
      const formattedItem = { ...item };

      if (formattedItem.color.endsWith('NonMohBatches.quantity')) {
        formattedItem.color = 'Quantities in hand';
        return formattedItem;
      }
      formattedItem.color = 'Requested quantities';
      return formattedItem;
    });
  };

  const stackedChartData = (resultSet, responsedata) => {
    const data = resultSet
      .pivot()
      .map(({ xValues, yValuesArray }) =>
        yValuesArray.map(([yValues, m]) => ({
          x: resultSet.axisValuesString(xValues, ', '),
          color: resultSet.axisValuesString(yValues, ', '),
          measure: m && Number.parseFloat(m),
        })),
      )
      .reduce((a, b) => a.concat(b), []);

    if (responsedata.resultSet?.loadResponses[0].data.length > 0) {
      const data2 = responsedata.resultSet
        .pivot()
        .map(({ xValues, yValuesArray }) =>
          yValuesArray.map(([yValues, m]) => ({
            x: responsedata.resultSet.axisValuesString(xValues, ', '),
            color: responsedata.resultSet.axisValuesString(yValues, ', '),
            measure: m && Number.parseFloat(m),
          })),
        )
        .reduce((a, b) => a.concat(b), []);
      const k = formatData(data2);
      finalObj = k.concat(formatData(data));

      return finalObj;
    }
    return formatData(data);
  };

  const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

  const cubejsParams = getCubejsApiParams(API_URL);

  const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

  const colors = ['color', ['#753BBD', '#27a29e']];

  const BarRender = ({ resultSet, responsedata }) => {
    // if(responsedata.resultSet?.loadResponses[0].data.length>0){

    // }
    return (
      <Chart
        scale={{ x: { tickCount: 8 } }}
        // height={280}
        data={stackedChartData(resultSet, responsedata)}
        autoFit
        padding="auto"
      >
        <Axis name="x" label={false} tickLine={false} />
        <Axis name="measure" />
        <Tooltip />
        {/* <Geom type="interval" position={`x*measure`} color={colors} adjust={[
						{
							type: 'dodge',
							// dodgeBy: 'type', // 按照 type 字段进行分组
							// marginRatio: 0, // 分组中各个柱子之间不留空隙
						},
						// {
						// 	type: 'stack',
						// },
					]} /> */}
        {/* <Interaction type="brush"/> */}
        <Interval adjust="stack" position="x*measure" color={colors} />
      </Chart>
    );
  };

  const filters = [
    // {
    //   member: 'OrderItems.createdat',
    //   operator: 'inDateRange',
    //   values: dateRangeFilter.dateRange,
    // },
  ];

  if (location && location !== 'All locations') {
    filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
  }

  // const drillDownResponse = useCubeQuery(drillDownQuery, {
  //   skip: !drillDownQuery,
  //   cubejsApi,
  // });

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['NonMohBatches.quantity'],
      dimensions: ['NonMohProducts.description'],
      filters,
    },
    {
      cubejsApi,
    },
  );

  const orderQuery = {
    measures: ['OrderItems.quantity'],
    dimensions: ['NonMohProducts.description'],
    filters: [
      {
        member: 'OrderItems.createdat',
        operator: 'inDateRange',
        values: dateRangeFilter.dateRange,
      },
    ],
  };

  const responsedata = useCubeQuery(orderQuery, {
    skip: !orderQuery,
    cubejsApi,
  });

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  if (responsedata) {
  }

  const data = resultSet?.loadResponses[0].data || null;
  return data && data.length ? (
    <>
      <BarRender resultSet={resultSet} responsedata={responsedata} />
    </>
  ) : (
    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
  );
};
export default TotalInventory;
