import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Row, Col, Statistic, Table, Spin, Empty, Space, Typography } from 'antd';
import { InboxOutlined } from '@ant-design/icons';

import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '../../../../hostname';

const { Text } = Typography;
const numberRender = ({ resultSet, pivotConfig }) => (
  <Row type="flex" justify="center" align="middle" style={{ height: '100%', width: '100%' }}>
    <Col style={{ width: '100%' }}>
      {resultSet.seriesNames().map((s) => {
        const label =
          s.key == 'PurchaseOrders.requestedPurchaseOrders' ? 'Requested' : 'Pending Approval';
        return label == 'Requested' ? (
          <>
            <div style={{ float: 'right', width: '50%' }}>
              <div style={{ textAlign: 'center' }}>
                <Statistic value={resultSet.totalRow()[s.key]} />
                <span style={{ fontSize: '12px' }}>{label} </span>
              </div>
            </div>
          </>
        ) : (
          <>
            <div style={{ float: 'right', width: '50%', borderRight: 'solid 1px' }}>
              <div style={{ textAlign: 'center' }}>
                <Statistic value={resultSet.totalRow()[s.key]} />
                <span style={{ fontSize: '12px' }}>{label} </span>
              </div>
            </div>
          </>
        );
      })}
    </Col>
  </Row>
);

const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) => {
  const data = resultSet?.loadResponses[0]?.data;
  const result = (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
    (error && error.toString()) || <Spin />;

  return data &&
    data.length &&
    data[0]['PurchaseOrders.requestedPurchaseOrders'] !== null &&
    data[0]['PurchaseOrders.pendingApproval'] !== null ? (
    result
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

const ChartRenderer = (props) => {
  const { dateRangeFilter, location } = props;
  const filters = [
    {
      member: 'PurchaseOrders.orderdate',
      operator: 'inDateRange',
      values: dateRangeFilter.dateRange,
    },
    {
      member: 'Locations.labType',
      operator: 'equals',
      values: ['nonmoh'],
    },
  ];

  if (location && location !== 'All locations') {
    filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
  }

  return (
    <QueryRenderer
      query={{
        measures: ['PurchaseOrders.requestedPurchaseOrders', 'PurchaseOrders.pendingApproval'],
        dimensions: [],
        filters,
      }}
      cubejsApi={cubejsApi}
      render={renderChart(numberRender, {
        x: ['PurchaseOrders.orderdate'],
        y: ['measures'],
        fillMissingDates: true,
        joinDateRange: false,
      })}
    />
  );
};

export default ChartRenderer;
