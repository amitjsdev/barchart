import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer, useCubeQuery } from '@cubejs-client/react';
import { Spin, Empty } from 'antd';
import { Chart, Axis, Tooltip, Geom, Coord, Legend } from 'bizcharts';
import hostname from '@/hostname';
import { getCubejsApiParams } from '@/services/cubejs';

const NupcoInventory = (props) => {
  const { dateRangeFilter, location } = props;

  const formatData = (data) => {
    return data.map((item) => {
      const formattedItem = { ...item };

      if (formattedItem.color.endsWith('NupcoInventories.availableInventory')) {
        formattedItem.color = 'Available Inventory';
        return formattedItem;
      }
    });
  };

  const stackedChartData = (resultSet) => {
    const data = resultSet
      .pivot()
      .map(({ xValues, yValuesArray }) =>
        yValuesArray.map(([yValues, m]) => ({
          x: resultSet.axisValuesString(xValues, ', '),
          color: resultSet.axisValuesString(yValues, ', '),
          measure: m && Number.parseFloat(m),
        })),
      )
      .reduce((a, b) => a.concat(b), []);

    return formatData(data);
  };

  const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

  const cubejsParams = getCubejsApiParams(API_URL);

  const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

  const colors = ['color', ['#27a29e', '#753BBD']];

  const BarRender = ({ resultSet }) => {
    if (resultSet?.loadResponses[0]?.data.length > 0) {
      return (
        <Chart
          scale={{ x: { tickCount: 8 } }}
          data={stackedChartData(resultSet)}
          autoFit
          padding="auto"
        >
          <Axis name="x" label={false} tickLine={false} />
          <Axis name="measure" />
          <Tooltip />
          <Geom type="interval" position="x*measure" color={colors} />
        </Chart>
      );
    }
    return <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
  };

  const filters = [
    /* {
      "dimension": "SurveyOptions.type",
      "operator": "equals",
      "values": [
        "tests"
      ]
    } */
  ];

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['NupcoInventories.availableInventory'],
      timeDimensions: [],
      dimensions: ['Products.code'],
      filters,
      segments: [],
      order: {},
    },
    {
      cubejsApi,
    },
  );

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  return (
    <>
      <BarRender resultSet={resultSet} />
    </>
  );
};
export default NupcoInventory;
