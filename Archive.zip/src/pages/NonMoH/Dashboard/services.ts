import Apis from '@/api/apis';

const uploadInflowOutflowData = (data) => {
  return Apis.uploadInflowOutflowData(data);
};

export { uploadInflowOutflowData };
