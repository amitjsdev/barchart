import React, { useState } from 'react';
import { useAccess, useModel, Access } from 'umi';
import { Row, Col, Typography, Popover, Select } from 'antd';
import { InfoCircleOutlined } from '@ant-design/icons';
import moment from 'moment';
import { ModuleTypes } from '@/services/Constants';
import { DateFilterType, LabNames } from './Types';
import DateFilter from './components/DateFilter/DateFilter';
import LabCapacityStatistics from './components/LabCapacityStatistics';
import POStatusStatistics from './components/POStatusStatistics';
import LabStatusStatistics from './components/LabStatusStatistics';
import ManPowerStatistics from './components/ManPowerStatistics';
import LabTatStatistics from './components/LabTatStatistics';
import AvgDeliveryTimeStatistics from './components/AvgDeliveryTimeStatistics';
import LocationSelector from '../../../components/LocationSelector';
import NupcoInventory from './components/NUPCOInventory/NupcoInventory';
import TotalInventory from './components/TotalInventory/TotalInventory';
import ExpiryOfReagent from './components/ExpiryOfReagent/ExpiryOfReagent';
import ClusteredLabCapacity from './components/ClusteredLabCapacity/ClusteredLabCapacity';
import TotalNupcoInventoryAndRequestedQuantity from './components/NupcoTotalInventory/NupcoTotalInventory&RequestedQuantity';
import InflowOutflow from './components/InflowOutflow/InflowOutflow';
import ExtractionPcrLabCapcityStatistics from './components/ExtractionPcrLabCapcityStatistics';

import FileUploader from './components/FileUploader';

import styles from './index.less';

const { Text, Title } = Typography;
const DATE_FORMAT = 'YYYY-MM-DD';

const itemExpiryFilters = [
  {
    name: 'Range filter',
    onChange: (option: string) => {
      itemExpiryFilters[0] = {
        ...itemExpiryFilters,
        selectedOption: [option],
      };
    },
    options: [
      { label: '< 1 month', value: '< 1 month' },
      { label: '1 - 3 months', value: '1 - 3 months' },
      { label: '3+ months', value: '3+ months' },
    ],
    selectedOption: '< 1 month',
  },
];

const FilterSelect: React.FC<{}> = (props: any) => (
  <Select
    style={{ width: '120px' }}
    defaultValue={props.filter.options[0].value}
    onChange={props.onChange}
  >
    {props.filter.options.map((option: any) => (
      <Select.Option key={option.value} value={option.value}>
        {option.label}
      </Select.Option>
    ))}
  </Select>
);

// KPI statistics card
const kpiStatisticsCardTitles = {
  LAB_CAPACITY: 'Lab Capacity',
  LAB_TAT: 'Lab TAT (hrs)',
  MAN_POWER: 'Man Power',
  LAB_STATUS_UPDATED: 'Lab Status Updated',
  PO_STATUS: 'PO Status',
  AVG_DELIVERY_TIME: 'Avg. Delivery Time (In days)',
};

const chartTitles = {
  DAILY_CONSUMPTION: 'Daily Consumption',
  EXPIRY_OF_REAGENT: 'Expiry Of Reagent',
  NUPCO_INVENTORY: 'NUPCO Inventory',
  TOTAL_INVENTORY: 'Total Inventory',
  CLUSTERED_LAB_CAPACITY: 'Lab Capacity',
  NUPCO_INVENTORY_REQUESTED_QUANTITY: 'Total Nupco Inventory and Requested Quantity',
};
const KpiStatisticsCard: React.FC<any> = (props) => (
  <div className={styles.kpiStatisticsCard}>
    <div className={styles.kpiCardTitleBar}>
      <div>
        <Text className={styles.chartTitle}>{props.title}</Text>
        {props.info ? (
          <Popover content={props.info} title="Info">
            <InfoCircleOutlined style={{ padding: '8px' }} />
          </Popover>
        ) : null}
      </div>
    </div>
    <div className={styles.kpiStatisticsCardContent}>
      {/* <div>
          <Title level={3}>{props.value}</Title>
        </div> */}
      {props.children}
    </div>
  </div>
);

const Dashboard: React.FC<any> = (props) => {
  const access = useAccess();
  const { initialState } = useModel('@@initialState');

  const { currentUser }: App.InitialStateType = initialState;
  const nonMohProfile = currentUser?.modules.find((module) => module.name === ModuleTypes.NON_MOH);
  const userLocation = nonMohProfile?.locationName;

  const defaultLocation = !access.canReadAllNonMohDashboard() ? userLocation : '';

  const defaultFilterSetting: DateFilterType = {
    granularity: 'day',
    dateRange: [moment().format(DATE_FORMAT), moment().format(DATE_FORMAT)],
  };

  const labNames = Object.keys(LabNames).filter((key) => key.length > 3); // Filtering out double map keys
  const locations = ['All locations', ...labNames];
  const [dateRangeFilter, setDateRangeFilter] = useState(defaultFilterSetting);
  const [selectedLocation, setLocation] = useState(defaultLocation);

  const onDateChange = (filter: any) => {
    setDateRangeFilter({
      granularity: dateRangeFilter.granularity,
      dateRange: [
        filter ? filter[0].format(DATE_FORMAT) : moment().format(DATE_FORMAT),
        filter ? filter[1].format(DATE_FORMAT) : moment().format(DATE_FORMAT),
      ],
    });
  };

  const onGranularityChange = (filter: any) => {
    setDateRangeFilter({
      granularity: filter,
      dateRange: dateRangeFilter.dateRange,
    });
  };

  const NupcoInventoryChart: React.FC<any> = (props) => {
    const { dateRangeFilter } = props;
    const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;
    return (
      <div className={`${styles.kpiCard} ${styles.large}`}>
        <div className={styles.kpiCardTitleBar}>
          <Row style={{ flex: '1 1 auto' }}>
            <Col flex={1}>
              <Text className={styles.chartTitle}>{chartTitles.NUPCO_INVENTORY}</Text>
            </Col>
            <Col flex={2} className={styles.filters}>
              <div />
            </Col>
          </Row>
        </div>
        <div className={contentCss}>
          <NupcoInventory dateRangeFilter={dateRangeFilter} location={selectedLocation} />
        </div>
      </div>
    );
  };
  // TotalNupcoInventoryAndRequestedQuantity

  const TotalNupcoInventoryAndRequestedQuantityChart: React.FC<any> = (props) => {
    const { dateRangeFilter } = props;
    const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;
    return (
      <div className={`${styles.kpiCard} ${styles.large}`}>
        <div className={styles.kpiCardTitleBar}>
          <Row style={{ flex: '1 1 auto' }}>
            <Col flex={1}>
              <Text className={styles.chartTitle}>
                {chartTitles.NUPCO_INVENTORY_REQUESTED_QUANTITY}
              </Text>
            </Col>
            <Col flex={2} className={styles.filters}>
              <div />
            </Col>
          </Row>
        </div>
        <div className={contentCss}>
          <TotalNupcoInventoryAndRequestedQuantity
            dateRangeFilter={dateRangeFilter}
            location={selectedLocation}
          />
        </div>
      </div>
    );
  };

  const TotalInventoryChart: React.FC<any> = (props) => {
    const { dateRangeFilter } = props;
    const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;
    return (
      <div className={`${styles.kpiCard} ${styles.large}`}>
        <div className={styles.kpiCardTitleBar}>
          <Row style={{ flex: '1 1 auto' }}>
            <Col flex={1}>
              <Text className={styles.chartTitle}>{chartTitles.TOTAL_INVENTORY}</Text>
            </Col>
            <Col flex={2} className={styles.filters}>
              <div />
            </Col>
          </Row>
        </div>
        <div className={contentCss}>
          <TotalInventory dateRangeFilter={dateRangeFilter} location={selectedLocation} />
        </div>
      </div>
    );
  };

  const ClusteredLabCapacityChart: React.FC<any> = (props) => {
    const { dateRangeFilter } = props;
    const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;
    return (
      <div className={`${styles.kpiCard} ${styles.large}`}>
        <div className={styles.kpiCardTitleBar}>
          <Row style={{ flex: '1 1 auto' }}>
            <Col flex={1}>
              <Text className={styles.chartTitle}>{chartTitles.CLUSTERED_LAB_CAPACITY}</Text>
            </Col>
            <Col flex={2} className={styles.filters}>
              <div />
            </Col>
          </Row>
        </div>
        <div className={contentCss}>
          <ClusteredLabCapacity dateRangeFilter={dateRangeFilter} location={selectedLocation} />
        </div>
      </div>
    );
  };

  const ExpiryOfReagentChart: React.FC<any> = (props) => {
    const [expiryDateRange, setExpiryDateRange] = useState(itemExpiryFilters[0].selectedOption);
    const { dateRangeFilter } = props;
    const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;
    return (
      <div className={`${styles.kpiCard} ${styles.large}`}>
        <div className={styles.kpiCardTitleBar}>
          <Row style={{ flex: '1 1 auto' }} align="middle" justify="space-between">
            <Col>
              <Text className={styles.chartTitle}>{chartTitles.EXPIRY_OF_REAGENT}</Text>
            </Col>
            <Col className={styles.filters}>
              <div>
                {props.filters?.map((filter) => (
                  <FilterSelect
                    filter={filter}
                    onChange={(val) => {
                      setExpiryDateRange(val);
                    }}
                  />
                ))}
              </div>
            </Col>
          </Row>
        </div>
        <div className={contentCss}>
          <ExpiryOfReagent
            dateRangeFilter={dateRangeFilter}
            location={selectedLocation}
            expiryfilter={expiryDateRange}
          />
        </div>
      </div>
    );
  };

  const DailyConsumptionChart: React.FC<any> = (props) => {
    const { dateRangeFilter } = props;
    const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;
    return (
      <div className={`${styles.kpiCard} ${styles.large}`}>
        <div className={styles.kpiCardTitleBar}>
          <Row style={{ flex: '1 1 auto' }}>
            <Col flex={1}>
              <Text className={styles.chartTitle}>{chartTitles.DAILY_CONSUMPTION}</Text>
            </Col>
            <Access accessible={!!access.canUploadInflowOutflowData()}>
              <Col flex={2} className={styles.filters}>
                <div>
                  <FileUploader />
                </div>
              </Col>
            </Access>
          </Row>
        </div>
        <div className={contentCss}>
          <InflowOutflow dateRangeFilter={dateRangeFilter} location={selectedLocation} />
        </div>
      </div>
    );
  };
  return (
    <div className={styles.main}>
      {/* <Spin spinning={loading} size="large" /> */}
      <Row className={styles.actionBar} align="middle" justify="space-between">
        <Col>
          <Title level={4}> Dashboard </Title>
        </Col>
        <Col>
          <Row gutter={[24, 24]} align="middle" style={{ margin: '0px' }}>
            <Access accessible={!!access.canReadAllNonMohDashboard()}>
              <Col>
                <LocationSelector onChange={setLocation} locations={locations} />
              </Col>
            </Access>
            <Col style={{ padding: '0px' }}>
              <DateFilter onDateChange={onDateChange} onGranularityChange={onGranularityChange} />
            </Col>
          </Row>
        </Col>
      </Row>

      {/* KPI Statistics Cards */}
      <Row className={styles.kpiStatisticsCardRow} gutter={[24, 24]}>
        <Col flex={1}>
          <KpiStatisticsCard title={kpiStatisticsCardTitles.LAB_CAPACITY}>
            <ExtractionPcrLabCapcityStatistics location={selectedLocation} />
          </KpiStatisticsCard>
        </Col>
        <Col flex={1}>
          <KpiStatisticsCard title={kpiStatisticsCardTitles.AVG_DELIVERY_TIME}>
            <AvgDeliveryTimeStatistics
              dateRangeFilter={dateRangeFilter}
              location={selectedLocation}
            />
          </KpiStatisticsCard>
        </Col>

        <Col flex={1}>
          <KpiStatisticsCard title={kpiStatisticsCardTitles.LAB_TAT}>
            <LabTatStatistics dateRangeFilter={dateRangeFilter} location={selectedLocation} />
          </KpiStatisticsCard>
        </Col>
        <Col flex={1}>
          <KpiStatisticsCard title={kpiStatisticsCardTitles.MAN_POWER}>
            <ManPowerStatistics dateRangeFilter={dateRangeFilter} location={selectedLocation} />
          </KpiStatisticsCard>
        </Col>
        <Col flex={1}>
          <KpiStatisticsCard title={kpiStatisticsCardTitles.LAB_STATUS_UPDATED}>
            <LabStatusStatistics dateRangeFilter={dateRangeFilter} location={selectedLocation} />
          </KpiStatisticsCard>
        </Col>
        <Col flex={1}>
          <KpiStatisticsCard title={kpiStatisticsCardTitles.PO_STATUS}>
            <POStatusStatistics dateRangeFilter={dateRangeFilter} location={selectedLocation} />
          </KpiStatisticsCard>
        </Col>
      </Row>

      {/* Row 2 */}

      <Row gutter={[24, 24]}>
        <Col span={12}>
          <DailyConsumptionChart dateRangeFilter={dateRangeFilter} location={selectedLocation} />
        </Col>

        <Col span={12}>
          <ExpiryOfReagentChart
            dateRangeFilter={dateRangeFilter}
            location={selectedLocation}
            filters={itemExpiryFilters}
          />
        </Col>
      </Row>

      {/* Row 3 */}

      <Row gutter={[24, 24]}>
        <Col span={12}>
          <ClusteredLabCapacityChart
            dateRangeFilter={dateRangeFilter}
            location={selectedLocation}
          />
        </Col>

        <Col span={12}>
          <TotalInventoryChart dateRangeFilter={dateRangeFilter} location={selectedLocation} />
        </Col>
      </Row>

      {/* Row 4 */}
      <Access accessible={!!access.canReadNupcoInventoryChart()}>
        <Row gutter={[24, 24]}>
          <Col span={12}>
            <NupcoInventoryChart dateRangeFilter={dateRangeFilter} location={selectedLocation} />
          </Col>
          <Col span={12}>
            <TotalNupcoInventoryAndRequestedQuantityChart
              dateRangeFilter={dateRangeFilter}
              location={selectedLocation}
            />
          </Col>
        </Row>
      </Access>
    </div>
  );
};

export default Dashboard;
