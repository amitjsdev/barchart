import React, { useState, useEffect } from 'react';
import { PageContainer } from '@ant-design/pro-layout';
import { Result, Row, Card, Form, Button, message, InputNumber, Col, Select } from 'antd';
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import { connect, useModel } from 'umi';

import { ModuleTypes } from '@/services/Constants';
import { StateType } from './model';
import nonMohService from '../services/nonMoh.service';

import styles from './index.less';

// const { Link } = Anchor;
// const { Text, Paragraph } = Typography;
let tableData = {};
let surveyData = {};

const SurveyNonMoh: React.FC<any> = (props) => {
  const [fieldsOpen, setFieldsOpen] = useState<boolean>(false);
  const [inputDynamicFieldValues, setDynamicInputFieldValues] = useState({});
  const [inputFieldValues, setInputFieldValues] = useState({});
  const [showSubmitted, setShowSubmitted] = useState<boolean>(true);
  const [loading, setLoading] = useState<boolean>(false);

  const { initialState } = useModel('@@initialState');

  const { currentUser } = initialState as App.InitialStateType;
  const nonMohProfile = currentUser?.modules.find((module) => module.name === ModuleTypes.NON_MOH);

  useEffect(() => {
    nonMohService.getSurveyFormStatus(nonMohProfile?.locationId).then((status) => {
      if (status === false) {
        nonMohService.getLastUpdatedSurveyData(nonMohProfile?.locationId).then((res: any) => {
          if (!res.data) {
            setShowSubmitted(status);
          } else {
            tableData = res.data.options; // for nested Fields
            surveyData = res.data.survey;
            setInputFieldValues({ ...surveyData });
            setShowSubmitted(status);
          }
        });
      } else {
        setShowSubmitted(status);
      }
    });
  }, []);

  const addNewRow = (questionKey: any, rowSchema: any) => {
    // {machine: {}}
    inputDynamicFieldValues[questionKey] = inputDynamicFieldValues[questionKey] || [];
    // {machine:{mx0: []}}
    inputDynamicFieldValues[questionKey].push(rowSchema);
    // {machine:{mx0: [{}]}}
    setDynamicInputFieldValues({ ...inputDynamicFieldValues });
  };

  const removeRow = (questionKey: any, index: number) => {
    inputDynamicFieldValues[questionKey]?.splice(index, 1);
    setDynamicInputFieldValues({ ...inputDynamicFieldValues });
  };

  const setItemName = (value: any) => {
    inputDynamicFieldValues[value.key][value.index][value.name] = isNaN(parseInt(value.value))
      ? value.value
      : parseInt(value.value);
    setDynamicInputFieldValues({ ...inputDynamicFieldValues });
  };

  const surveyValues = (value: any) => {
    if (value.type === 'date') {
      inputFieldValues[value.key] = value.value;
    } else {
      inputFieldValues[value.key] = isNaN(parseInt(value.value))
        ? value.value
        : parseInt(value.value);
    }
    setInputFieldValues({ ...inputFieldValues });
  };

  const onFinish = () => {
    setLoading(true);

    const keysOfOptionsarrays: any = Object.keys(inputDynamicFieldValues);
    const arrayOfOptionsarrays: any = Object.values(inputDynamicFieldValues);
    const optionsArray = [];

    for (var i = 0; i < arrayOfOptionsarrays.length; i++) {
      for (let j = 0; j < arrayOfOptionsarrays[i].length; j++) {
        optionsArray.push({
          ...arrayOfOptionsarrays[i][j],
          type: keysOfOptionsarrays[i],
        });
      }
    }

    if (Object.keys(inputFieldValues).length !== 4) {
      message.error('Please fill all the fields');
      return;
    }
    for (var i = 0; i < optionsArray.length; i++) {
      if (
        Object.values(optionsArray[i]).some((val) => {
          return val === null;
        })
      ) {
        message.error('Please fill all the fields!');
        return;
      }
    }

    nonMohService.getSurveyFormStatus(nonMohProfile?.locationId).then((status) => {
      if (status) {
        message.error('Form is already filled');
        setShowSubmitted(status);
      } else {
        props.dispatch({
          type: 'nonMohSurveyStore/submitForm',
          payload: {
            locationId: nonMohProfile?.locationId,
            submitData: {
              ...inputFieldValues,
              options: optionsArray,
            },
            draft: {
              survey: inputFieldValues,
              options: inputDynamicFieldValues,
            },
          },
        });
      }
    });
  };

  // const saveAsDraft = () => {
  //
  //

  //   props.dispatch({
  //     type: 'nonMohSurveyStore/saveSurveyForm',
  //     payload: {
  //       survey: inputFieldValues,
  //       options: inputDynamicFieldValues,
  //     },
  //   });
  // };

  const Success: React.FC<any> = (props) => {
    return (
      <div style={{ padding: '10%' }}>
        <Result
          status="success"
          title="Lab status is up-to-date!"
          subTitle="Please come tomorrow to update the lab status."
          extra={[]}
        />
      </div>
    );
  };

  return showSubmitted ? (
    <Success />
  ) : (
    <PageContainer title="LAB STATUS" className={styles.main}>
      <div className={styles.main}>
        <Row gutter={[24, 24]}>
          <Col span={24}>
            <Card>
              {props.formContent[0].contents.map((content: any) => {
                return (
                  <Card type="inner" style={{ marginTop: '2%' }}>
                    <Form
                      layout="vertical"
                      autoComplete="off"
                      name={content.key}
                      initialValues={{}}
                    >
                      {content.enableDropdown ? (
                        <Form.List
                          name="ok"
                          // name={props.formContent.section.sectionName}
                        >
                          {(fields, { add, remove }) => {
                            if (!fieldsOpen) {
                              setFieldsOpen(true);

                              if (Object.keys(tableData).length > 0) {
                                for (let i = 0; i < tableData[content.key].length; i++) {
                                  add();
                                  addNewRow(content.key, tableData[content.key][i]);
                                }
                              } else {
                                add();
                                addNewRow(
                                  content.key,
                                  content.formFields.reduce((acc, field) => {
                                    return { ...acc, [field.name]: null };
                                  }, {}),
                                );
                              }
                            }

                            return (
                              <div className={styles.formFieldContainer}>
                                {fields.map((field: any, fieldIndex) => (
                                  <div>
                                    {content.formFields.map((inputField: any, index: number) => {
                                      return inputField.valueType === 'select' ? (
                                        <Form.Item
                                          className={styles.formField}
                                          label={inputField.label}
                                          key={inputField.name + index}
                                          // style={{ width: '200px' }}
                                          name={[field.name, inputField.name]}
                                          initialValue={
                                            inputDynamicFieldValues[content.key][field.name][
                                              inputField.name
                                            ]
                                          }
                                          rules={[
                                            {
                                              required: content.required,
                                              message: 'Required',
                                            },
                                          ]}
                                        >
                                          <Select
                                            style={{ width: '350px' }}
                                            onChange={(e) =>
                                              setItemName({
                                                value: e,
                                                name: inputField.name,
                                                index: fieldIndex,
                                                key: content.key,
                                              })
                                            }
                                          >
                                            {inputField.selectOptions.map((option: any) => (
                                              <Select.Option
                                                key={option.key}
                                                value={option.key}
                                                disabled={inputDynamicFieldValues[
                                                  content.key
                                                ]?.find((val: any) => {
                                                  return val.name === option.key;
                                                })}
                                              >
                                                {option.value}
                                              </Select.Option>
                                            ))}
                                          </Select>
                                        </Form.Item>
                                      ) : (
                                        <Form.Item
                                          className={styles.formField}
                                          label={inputField.label}
                                          {...field}
                                          name={[field.name, inputField.name]}
                                          key={inputField.name + index}
                                          initialValue={
                                            inputDynamicFieldValues[content.key][field.name][
                                              inputField.name
                                            ]
                                          }
                                          rules={[
                                            {
                                              required: content.required,
                                              message: 'Required',
                                            },
                                            {
                                              type: 'number',
                                              min: 0,
                                              message: 'Should be more than 0',
                                            },
                                          ]}
                                        >
                                          <InputNumber
                                            style={{ width: '200px' }}
                                            min={0}
                                            placeholder=""
                                            // type={inputField.inputType}
                                            disabled={(() => {
                                              const selectfield = content.formFields.find(
                                                (field: any) => field.valueType === 'select',
                                              );
                                              if (!selectfield) {
                                                return false;
                                              }
                                              return !inputDynamicFieldValues[content.key][
                                                fieldIndex
                                              ][selectfield.name];
                                            })()}
                                            onChange={(value) =>
                                              setItemName({
                                                value,
                                                name: inputField.name,
                                                index: fieldIndex,
                                                key: content.key,
                                              })
                                            }
                                          />
                                        </Form.Item>
                                      );
                                    })}

                                    <MinusCircleOutlined
                                      style={{ marginLeft: '3%' }}
                                      onClick={() => {
                                        if (fields.length > 1) {
                                          remove(field.name);
                                          removeRow(content.key, fieldIndex);
                                        }
                                      }}
                                    />
                                  </div>
                                ))}

                                <Form.Item>
                                  <Button
                                    type="dashed"
                                    onClick={() => {
                                      add();
                                      addNewRow(
                                        content.key,
                                        content.formFields.reduce((acc, field) => {
                                          return { ...acc, [field.name]: null };
                                        }, {}),
                                      );
                                    }}
                                  >
                                    <PlusOutlined /> Add field
                                  </Button>
                                </Form.Item>
                              </div>
                            );
                          }}
                        </Form.List>
                      ) : (
                        <Form.Item
                          name={content.key}
                          label={content.question}
                          // inputFieldValues
                          initialValue={inputFieldValues[content.key]}
                          rules={[
                            { required: content.required, message: 'Required' },
                            {
                              type: 'number',
                              min: 0,
                              message: 'Should be more than 0',
                            },
                          ]}
                        >
                          <InputNumber
                            style={{ width: '200px' }}
                            min={0}
                            placeholder=""
                            onChange={(value) =>
                              surveyValues({
                                value,
                                key: content.key,
                                type: 'input',
                              })
                            }
                          />
                        </Form.Item>
                      )}
                    </Form>
                  </Card>
                );
              })}
              <br />
              <div style={{ textAlign: 'right' }}>
                <Button type="primary" onClick={onFinish} loading={loading}>
                  Submit
                </Button>
              </div>
            </Card>
          </Col>
        </Row>
      </div>
    </PageContainer>
  );
};

export default connect(({ nonMohSurveyStore }: { nonMohSurveyStore: StateType }) => ({
  formContent: nonMohSurveyStore.nonMohFormContent,
}))(SurveyNonMoh);
