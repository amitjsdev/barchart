import Apis from '@/api/apis';

export async function getSurveyFormStatus() {
  return Apis.getSurveyFormStatus().then((res) => res?.message);
}
