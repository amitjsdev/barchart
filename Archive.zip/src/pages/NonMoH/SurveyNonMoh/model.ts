import { Effect } from 'umi';
import moment from 'moment';

import nonMohService from '../services/nonMoh.service';

export interface StateType {
  survey: any[];
  nonMohFormContent: any[];
}

export interface ModelType {
  namespace: string;
  state: StateType;
  effects: {
    submitForm: Effect;
  };
  reducers: {};
}

const nonMohFormContent = [
  {
    sectionName: 'Form',
    contents: [
      {
        question: 'Lab Capacity',
        // questionInArabic: 'مجموع عدد العينات المعاد فحصها ',
        key: 'labCapacity',
        enableDropdown: false,
        required: true,
        surveyFields: {
          type: 'input',
          optionfields: [],
          inputType: 'number',
        },
        formFields: [],
      },
      {
        question: 'Lab Turn Around Time',
        // questionInArabic: 'مجموع عدد العينات المعاد فحصها ',
        key: 'labTurnAroundTime',
        enableDropdown: false,
        required: true,
        surveyFields: {
          type: 'input',
          optionfields: [],
          inputType: 'number',
        },
        formFields: [],
      },
      {
        question: 'Manpower',
        // questionInArabic: 'مجموع عدد العينات المعاد فحصها ',
        key: 'manPower',
        enableDropdown: false,
        required: true,
        surveyFields: {
          type: 'input',
          optionfields: [],
          inputType: 'number',
        },
        formFields: [],
      },

      {
        question: 'Lab Operational Hours',
        // questionInArabic: 'مجموع عدد العينات المعاد فحصها ',
        key: 'operationalHours',
        enableDropdown: false,
        required: true,
        surveyFields: {
          type: 'input',
          optionfields: [],
          inputType: 'number',
        },
        formFields: [],
      },

      {
        question: 'Capacity of each Machine',
        // questionInArabic: 'مجموع عدد العينات المعاد فحصها ',
        key: 'extraction',
        enableDropdown: true,
        required: true,
        surveyFields: {},
        formFields: [
          {
            valueType: 'select',
            type: '',
            name: 'name',
            label: 'Extraction',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              {
                key: 'nm_me4',
                value: 'VERSANT kPCR',
              },
              {
                key: 'nm_me1',
                value: 'Bioneer',
              },
              {
                key: 'nm_me2',
                value: 'Thermo Fisher',
              },
              {
                key: 'nm_me3',
                value: 'Perkin Elmer',
              },
              {
                key: 'nm_me5',
                value: 'Roche magna pure 96',
              },
              {
                key: 'nm_me6',
                value: 'Roche magna pure 24',
              },
              {
                key: 'nm_me7',
                value: 'Promega',
              },
              {
                key: 'nm_me8',
                value: 'Abbott m24sp EXT',
              },
              {
                key: 'nm_me9',
                value: 'Abbott m2000sp',
              },
              {
                key: 'nm_me10',
                value: 'Qiagen EZ1 Advanced XL',
              },
              {
                key: 'nm_me11',
                value: 'Qiagen QIAsymphony',
              },
              {
                key: 'nm_me12',
                value: 'Cepheid GeneXpert',
              },
              {
                key: 'nm_me13',
                value: 'Abbott Alinity',
              },
            ],
          },
          {
            valueType: 'input',
            name: 'capacity',
            label: 'Capacity',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
          {
            valueType: 'input',
            name: 'noOfMachines',
            label: 'Number Of Machines',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
        ],
      },

      {
        question: 'PCR of each Machine',
        // questionInArabic: 'مجموع عدد العينات المعاد فحصها ',
        key: 'pcr',
        enableDropdown: true,
        required: true,
        surveyFields: {},
        formFields: [
          {
            valueType: 'select',
            name: 'name',
            label: 'PCR',
            defaultValue: '',
            inputType: 'text',
            selectOptions: [
              {
                key: 'nm_mpcr1',
                value: 'Qiagen Rotor Gene Q',
              },
              {
                key: 'nm_mpcr2',
                value: 'ABI 7500',
              },
              {
                key: 'nm_mpcr3',
                value: 'Roche lightcycler 480',
              },
              {
                key: 'nm_mpcr4',
                value: 'Abbott m2000rt',
              },
              {
                key: 'nm_mpcr5',
                value: 'Bio-Rad',
              },
              {
                key: 'nm_mpcr6',
                value: 'QuantStudio RT PCR',
              },
              {
                key: 'nm_mpcr7',
                value: 'Cepheid GeneXpert',
              },
              {
                key: 'nm_mpcr8',
                value: 'Abbott Alinity',
              },
            ],
          },
          {
            valueType: 'input',
            name: 'capacity',
            label: 'Capacity',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
          },
          {
            valueType: 'input',
            name: 'noOfMachines',
            label: 'Number Of Machines',
            defaultValue: '',
            inputType: 'number',
            selectOptions: [],
            onChange: () => {},
          },
        ],
      },
    ],
  },
];

const Model: ModelType = {
  namespace: 'nonMohSurveyStore',
  state: {
    survey: [],
    nonMohFormContent,
  },

  effects: {
    async *submitForm({ payload }) {
      const payloadToSend = {
        locationId: payload.locationId,
        ...payload.submitData,
      };

      const response = await nonMohService.submitSurveyForm(payloadToSend);

      if (response?.success) {
        const today = new Date();
        const dd = String(today.getDate()).padStart(2, '0');
        const mm = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
        const yyyy = today.getFullYear();

        const _date = `${yyyy}-${mm}-${dd}`;
        const { locationId } = payload;

        const res = await nonMohService.saveSurveyForm(payload.draft, _date, locationId);

        if (res?.success) {
          window.location.reload();
        } else {
          window.location.reload();
        }
      } else {
        window.location.reload();
      }
    },
  },

  reducers: {},
};

export default Model;
