import { PageContainer } from '@ant-design/pro-layout';
import React from 'react';
import { useModel, useAccess, Redirect } from 'umi';
import { Tabs, Radio, Tooltip, Select } from 'antd';
import moment from 'moment';

import { ModuleTypes, POStatues } from '@/services/Constants';
import nonMohService from '../services/nonMoh.service';
import PurchaseTable from './PurchaseTable';

import styles from './index.less';

const { TabPane } = Tabs;
const { Option } = Select;

interface PropsType {
  nonMohProfile: App.Module;
  access: any;
}

class EditableTable extends React.Component<PropsType, any> {
  filterValueMap = {
    created: { status: POStatues.CREATED, isApproved: false },
    approved: { status: 'approved', isApproved: true },
    pending: { status: POStatues.PENDING, isApproved: true },
    cancelled: { status: POStatues.CANCELLED, isApproved: null },
    completed: { status: POStatues.COMPLETED, isApproved: null },
  };

  filters;

  constructor(props: PropsType) {
    super(props);

    this.state = {
      status: 'created',
      isApproved: false,
      labs: [{ name: 'NHL', id: '1' }],
      locationId: '',
      dataSource: [],
      showAllLocations: false,
      brandNames: [],
      currentBrandName: null,
    };

    this.filters = (
      <>
        <Radio.Group
          defaultValue="created"
          buttonStyle="solid"
          onChange={(e) => this.changeStatus(this.filterValueMap[e.target.value])}
        >
          <Radio.Button value="created">Created</Radio.Button>
          <Radio.Button value="approved">Approved</Radio.Button>
          <Radio.Button value="cancelled">Rejected</Radio.Button>
          <Radio.Button value="pending">Pending</Radio.Button>
          <Radio.Button value="completed">Completed</Radio.Button>
        </Radio.Group>
      </>
    );
  }

  async componentDidMount() {
    const { nonMohProfile, access } = this.props;
    const labs = await nonMohService.getLocations();
    const brandNames = await nonMohService.getAllBrandNames();

    if (access.canReadAllNonMohPurchaseOrder()) this.setState({ showAllLocations: true });
    this.setState({
      brandNames,
      labs: !access.canReadAllNonMohPurchaseOrder()
        ? labs.filter((lab) => lab.id === nonMohProfile.locationId)
        : [{ id: 0, code: 'All' }, ...labs],
    });

    this.changeLocation(this.state.labs[0].id);
  }

  async getOrder() {
    this.setState({ dataSource: [] });
    const { status, isApproved, locationId, currentBrandName } = this.state;

    const locId = parseInt(locationId, 10) === 0 ? '' : locationId; // Check if its All locations (All tab key === 0)
    let filterStatus = status;
    if (filterStatus === 'approved') filterStatus = POStatues.CREATED;

    const orderData = await nonMohService.getOrders(
      locId,
      filterStatus,
      isApproved,
      currentBrandName,
    );
    const orderStateData = [];

    if (orderData === undefined || orderData === null) return;

    orderData.forEach((el, index) => {
      orderStateData.push({
        name: el.userName || 'NA',
        quantity: el.quantity,
        createdOn: moment(el.createdAt).format('YYYY-MM-DD'),
        createdBy: el.userName,
        id: el.id,
        orderItems: el.orderItems,
        deliveredOn: el.expectedDeliveryDate,
        expectedOn: el.expectedDeliveryDate,
        locationId: el.locationId,
        notes: el.notes,
        content: el.content,
      });
    });

    this.setState({ dataSource: orderStateData });
  }

  handleBrandFilter = async (brandName: string) => {
    this.setState({ currentBrandName: brandName }, () => this.getOrder());
  };

  changeLocation = async (key) => {
    this.setState({ locationId: key }, () => this.getOrder());
  };

  refreshOrder() {
    this.getOrder();
  }

  async changeStatus(filter: { status: string; isApproved: boolean | null }) {
    this.setState({ ...filter, currentBrandName: null}, () => this.getOrder());
  }

  render() {
    const { labs, dataSource, status } = this.state;

    return (
      <PageContainer content="" className={styles.main}>
        <div className={styles.divContain}>
          <Tabs
            defaultActiveKey={labs[0].id}
            onChange={this.changeLocation}
            tabBarExtraContent={
              <>
                {this.filters}
                {/* Brand name filter */}
                <Select
                  placeholder="Select Brand"
                  className={styles.brandFilter}
                  defaultValue={this.state.currentBrandName}
                  value={this.state.currentBrandName}
                  onChange={(value) => this.handleBrandFilter(value)}
                  allowClear
                >
                  {this.state.brandNames.map((brand: NonMoh.API.ProductCode) => (
                    <Option key={brand.id} value={brand.code}>
                      {brand.code}
                    </Option>
                  ))}
                </Select>
              </>
            }
          >
            {labs.map((item, i) => (
              <TabPane tab={<Tooltip title={item.name}>{item.code}</Tooltip>} key={item.id} />
            ))}
          </Tabs>

          {/* <Button type="primary" className={styles.addItem} >Add Item</Button> */}

          <PurchaseTable
            data={dataSource}
            status={status}
            getOrder={this.getOrder.bind(this)}
            locationId={this.state.locationId}
            labs={this.state.labs}
            showAllLocations={this.state.showAllLocations}
          />
        </div>
        <div
          style={{
            paddingTop: 100,
            textAlign: 'center',
          }}
        >
          {/* <Spin spinning={loading} size="large" /> */}
        </div>
      </PageContainer>
    );
  }
}

const Purchase = (props: any) => (
  <div className={styles.container}>
    <div id="components-table-demo-edit-cell">
      <EditableTable nonMohProfile={props.nonMohProfile} access={props.access} />
    </div>
  </div>
);

const PurchaseWrapper = (props) => {
  const { initialState } = useModel('@@initialState');
  const access = useAccess();

  const currentUser: App.CurrentUser = initialState?.currentUser;
  const nonMohProfile = currentUser?.modules.find((module) => module.name === ModuleTypes.NON_MOH);

  return nonMohProfile ? (
    <Purchase {...props} nonMohProfile={nonMohProfile} access={access} />
  ) : (
    <Redirect to="/user/login" />
  );
};

export default PurchaseWrapper;
