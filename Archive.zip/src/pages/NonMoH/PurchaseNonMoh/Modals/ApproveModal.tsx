import React from 'react';
import { Modal, Button, Tooltip } from 'antd';
import { CheckOutlined } from '@ant-design/icons';

import nonMohService from '../../services/nonMoh.service';

class ApproveModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      loading: false,
      switchComplete: false,
      orderName: 'DefaultOrder',
      orderNotes: '',
      inputList: [{ product: '', quantity: '', note: '', id: '' }],
      outputList: [{ product: '', quantity: '', note: '', id: '' }],
      orderOptions: [],
    };
  }

  componentDidMount() {
    const { inputList } = this.props;
    this.setState({ inputList });
  }

  componentDidUpdate(prevProps) {
    const { inputList, index } = this.props;

    if (inputList !== prevProps.inputList) {
      const _data = [];
      inputList[index].orderItems?.forEach((el) => {
        _data.push({ product: el.productCode, quantity: el.quantity, id: el.id });
      });

      this.setState({ inputList: _data });
    }
  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleOk = async (e) => {
    const { inputList, index } = this.props;

    this.setState({
      // visible: false,
      loading: true,
    });

    const _data = JSON.parse(JSON.stringify(inputList));
    await nonMohService.approveOrder(_data[index].id);
    this.setState({
      visible: false,
      loading: false,
    });
    this.props.getOrder();
  };

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  };

  render() {
    const { visible, orderName, orderOptions, loading } = this.state;
    const { inputList, outputList, switchComplete } = this.state;

    return (
      <>
        <Tooltip title="Approve">
          <Button
            type="primary"
            style={this.props.style}
            shape="circle"
            icon={<CheckOutlined />}
            onClick={this.showModal}
          />
        </Tooltip>

        <Modal
          title="Order"
          visible={visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
          maskClosable={false}
          footer={[
            <Button key="back" onClick={this.handleCancel} disabled={loading}>
              Cancel
            </Button>,
            <Button key="submit" type="primary" loading={loading} onClick={this.handleOk}>
              Submit
            </Button>,
          ]}
        >
          {/* <br /> */}
          <span>Do you approve the purchase order?</span>

          {/* <Input style={styles.orderNotes} placeholder="Note" onChange={(event) => this.setState({ orderNotes: event.target.value}) } />
           */}
        </Modal>
      </>
    );
  }
}

export default ApproveModal;
