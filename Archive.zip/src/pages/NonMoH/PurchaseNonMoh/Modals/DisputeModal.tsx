import { Modal, Button, Input, AutoComplete, Switch, Tooltip } from 'antd';
import {
  ProfileTwoTone,
  PlusSquareTwoTone,
  MinusSquareTwoTone,
  CheckOutlined,
} from '@ant-design/icons';
import { history } from 'umi';
import { storageService } from '@/services/storage';
import Apis from '../../../api/apis';
import styles from './styles';

class DisputeModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      switchComplete: false,
      orderName: 'DefaultOrder',
      orderNotes: '',
      inputList: [{ product: '', quantity: '', note: '', id: '' }],
      outputList: [{ product: '', quantity: '', note: '', id: '' }],
      orderOptions: [],
      role: storageService.getItem('role'),
      allowedLocation: storageService.getItem('locationId'),
    };
  }

  componentDidMount() {
    const { inputList } = this.props;
    this.setState({ inputList });
  }

  componentDidUpdate(prevProps) {
    const { inputList, index } = this.props;

    if (inputList !== prevProps.inputList) {
      const _data = [];
      inputList[index].orderItems.forEach((el) => {
        _data.push({ product: el.productCode, quantity: el.quantity, id: el.id });
      });

      this.setState({ inputList: _data });
    }
  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleOk = async (e) => {
    const { locationId, inputList, index } = this.props;
    const { orderName, orderNotes } = this.state;

    this.setState({
      visible: false,
    });

    const _data = JSON.parse(JSON.stringify(inputList));

    const payload = { status: 'completed', dispute: this.state.outputList };
    await Apis.updateOrder(_data[index].id, payload);
    this.props.getOrder();
    // await Apis.updateOrder({"name": orderName, "location": locationId, "orderItems": inputList, "notes": orderNotes});
  };

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  };

  handleInputChange = (e, index) => {
    const { name, value } = e.target;
    const list = this.state.outputList;
    list[index][name] = value;
    this.setState({ outputList: list });
  };

  handleAInputChange = (e, index) => {
    const { outputList, inputList } = this.state;
    const _ind = inputList
      .map(function (ev) {
        return ev.product;
      })
      .indexOf(e);
    const list = outputList;
    list[index].product = e;

    if (_ind !== -1) {
      list[index].quantity = inputList[_ind].quantity;
      list[index].id = inputList[_ind].id;
    }

    this.setState({ outputList: list });
  };

  // handle click event of the Remove button
  handleRemoveClick = (index) => {
    const list = this.state.outputList;
    list.splice(index, 1);
    this.setState({ outputList: list });
  };

  // handle click event of the Add button
  handleAddClick = () => {
    const list = this.state.outputList;
    list.push({ product: '', quantity: '', note: '', id: '' });
    this.setState({ outputList: list });
  };

  onSwitch = (checked) => this.setState({ switchComplete: checked });

  checkPermission = () => {
    return !(
      ['planner', 'manager'].includes(this.state.role) &&
      this.state.allowedLocation == this.props.locationId
    );
  };

  render() {
    const { visible, orderName, orderOptions } = this.state;
    const { inputList, outputList, switchComplete } = this.state;

    return (
      <div>
        <Tooltip title="Complete PO / Raise Dispute">
          <Button
            // disabled={this.checkPermission()}
            type="primary"
            style={this.props.style}
            shape="circle"
            icon={<CheckOutlined />}
            onClick={this.showModal}
          />
        </Tooltip>
        <Modal
          title="Complete PO / Raise Dispute"
          visible={visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
          <br />
          <span>Did you receive all the items listed in the purchase order?</span>
          <Switch style={styles.switch} onChange={this.onSwitch} />

          {switchComplete === false ? (
            <div style={styles.productFormDiv}>
              <span>Products</span>
              <span style={styles.quantityLabel}>Quantity</span>
              <span style={styles.noteLabel}>Note</span>
              {outputList.map((x, i) => {
                return (
                  <div className="box" style={styles.productFormDiv}>
                    <AutoComplete
                      style={styles.productInput}
                      name="product"
                      dataSource={inputList.map(({ product }) => product)}
                      placeholder="Search for Order"
                      filterOption={(inputValue, option) =>
                        option.props.children.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                      }
                      onChange={(e) => this.handleAInputChange(e, i)}
                    />
                    <Input
                      style={styles.quantityInput}
                      className="ml10"
                      name="quantity"
                      value={x.quantity}
                      onChange={(e) => this.handleInputChange(e, i)}
                    />
                    <Input
                      style={styles.noteInput}
                      className="ml10"
                      name="note"
                      value={x.note}
                      onChange={(e) => this.handleInputChange(e, i)}
                    />
                    <div className="btn-box" style={styles.buttonBox}>
                      {outputList.length - 1 === i && (
                        <PlusSquareTwoTone style={styles.icon} onClick={this.handleAddClick} />
                      )}
                      {outputList.length !== 1 && (
                        <MinusSquareTwoTone
                          style={styles.icon}
                          twoToneColor="#ff0000"
                          onClick={this.handleRemoveClick}
                        />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : null}

          <br />
          <Input
            style={styles.orderNotes}
            placeholder="Note"
            onChange={(event) => this.setState({ orderNotes: event.target.value })}
          />
        </Modal>
      </div>
    );
  }
}

export default DisputeModal;
