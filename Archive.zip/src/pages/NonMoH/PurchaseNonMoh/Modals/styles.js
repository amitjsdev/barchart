const styles = {
  purchaseInput: { width: '90%' },

  productFormDiv: { marginTop: '20px' },

  quantityLabel: { marginLeft: '23%' },

  noteLabel: { marginLeft: '5%' },

  formBox: { overflow: 'auto', marginTop: '10px' },

  oformBox: { overflow: 'auto', marginTop: '10px' },

  productInput: { width: '30%' },

  oproductInput: { width: '50%' },

  quantityInput: { marginLeft: '10px', width: '15%' },

  oquantityInput: { marginLeft: '10px', width: '30%' },

  noteInput: { marginLeft: '10px', width: '25%' },

  buttonBox: { position: 'relative', float: 'right' },
  icon: { fontSize: '175%' },

  orderNotes: { marginTop: '20px', width: '80%' },
  switch: { left: '80px' },
};

export default styles;
