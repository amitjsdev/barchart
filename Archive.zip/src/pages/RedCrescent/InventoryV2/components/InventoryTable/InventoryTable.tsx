/* eslint-disable class-methods-use-this */
import React, { Component } from 'react';
import { Access, useAccess } from 'umi';
import { Table, Button, Col, Row, Badge, Space, Popconfirm, Tooltip, Typography } from 'antd';
import moment from 'moment';

import OrderModal from '@/components/Modal/OrderModal';
import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import ReplenishmentModal from '@/components/Modal/ReplenishmentModal';
import { ModuleTypes } from '@/services/Constants';
import bgiService from '../../../services/bgi.service';
import { ColumnType, SKUType } from '../../Types';
import EditModal from '../EditModal/EditModal';
import styles from './index.less';

import { getAuthToken } from '@/utils/userProfile';
const { Text } = Typography;

const locationsKeys = ['nhl', 'mak', 'mad', 'asr', 'dam'];

// Excluding Checkbox column
const getTotalColumnWidth = (columns: ColumnType[]): number => {
  return columns.reduce((acc, cur) => acc + parseInt(cur.width, 10), 0);
};

const onViewBatches = async (skuId) => {
  const res = await bgiService.getBatches(skuId);
};

const ViewBatchesButton = (props) => {
  const { skuId } = props;
  return <Button onClick={() => onViewBatches(skuId)}>View batches</Button>;
};

interface StateType {
  skuColumns: ColumnType[];
  skus: SKUType[];
  showEditModal: boolean;
  userLocationId: number;
  editModalContent: SKUType | null;
  editModalBatches: any | null;
  selectedRowKeys: any;
  selectedOrder: any;
  userAccess: any;
  expandRowData: any[];
  nestedColumns: any[];
  loadEpandableRowdata: boolean;
  expandedRowKeys: any[];
  inventoryLocationId: number;
  autoReplenishment: any[];
}

interface PropsType {
  skus: SKUType[];
  userLocationId: number;
  inventoryLocationId: number;
  tableHeight: number;
  access: any;
}

class InventoryTable extends Component<PropsType, StateType> {
  constructor(props) {
    super(props);

    this.state = {
      skuColumns: [
        {
          title: 'S. No.',
          width: '100px',
          dataIndex: 'serialNum',
          key: 'serialNum',
          fixed: 'left',
          render: (text, record, index) => (
            <Space>
              <Badge status={record.hasUpdated ? 'success' : 'error'} />
              <Text>{index + 1}</Text>
            </Space>
          ),
        },
        {
          title: 'Code',
          width: '200px',
          dataIndex: ['product', 'code'],
          key: 'code',
          fixed: 'left',
        },
        {
          title: 'Description',
          width: '300px',
          dataIndex: ['product', 'description'],
          key: 'description',
          fixed: 'left',
        },
        {
          title: 'Quantities in hand',
          width: '200px',
          dataIndex: 'quantity',
          key: 'quantity',
        },
        {
          title: 'Quantities in transit',
          width: '200px',
          dataIndex: 'quantitiesInTransit',
          key: 'quantitiesInTransit',
        },
        {
          title: 'UOM',
          width: '200px',
          dataIndex: ['product', 'unitOfMeasures'],
          key: 'unitOfMeasures',
        },
        {
          title: 'Actual Daily Consumption',
          width: '200px',
          dataIndex: 'dailyConsumption',
          key: 'dailyConsumption',
          render: (text, record) => text.toFixed(3),
        },
        {
          title: 'Avg. Actual Consumption',
          width: '200px',
          dataIndex: 'consumption',
          key: 'consumption',
          render: (text, record) => Math.round(text),
        },
        {
          title: 'Reorder Level',
          width: '200px',
          dataIndex: 'reOrderLevel',
          key: 'reOrderLevel',
        },
        {
          title: 'Suggested Quantity',
          width: '200px',
          dataIndex: 'reOrderQuantity',
          key: 'reOrderQuantity',
        },
        /* {
          title: 'Monthly Consumption',
          width: '200px',
          dataIndex: 'monthlyConsumption',
          key: 'monthlyConsumption',
        }, */
        {
          title: 'Expected Covering days',
          width: '200px',
          dataIndex: 'consumableDays',
          key: 'consumableDays',
        },
        {
          title: 'Last updated at',
          width: '200px',
          dataIndex: 'updatedAt',
          key: 'updatedAt',
          render: (text) => <Text>{moment(text).format('YYYY-MM-DD, HH:mm')}</Text>,
        },
      ],
      skus: this.props.skus,
      autoReplenishment: this.props.skus.filter(function (item: any) {
        return item.reOrderQuantity > 0 && item.quantitiesInTransit == 0;
      }),
      showEditModal: false,
      loadEpandableRowdata: true,
      expandedRowKeys: [],
      expandRowData: [],
      userLocationId: this.props.userLocationId,
      inventoryLocationId: this.props.inventoryLocationId,
      editModalContent: null,
      selectedRowKeys: [],
      selectedOrder: null,
      userAccess: this.props.access,
      nestedColumns: [
        {
          title: 'S. No.',
          width: '100px',
          dataIndex: 'serialNum',
          key: 'serialNum',
          fixed: 'left',
          render: (text, record, index) => <Text>{index + 1}</Text>,
        },
        {
          title: 'Batch number',
          // width: '200px',
          dataIndex: 'batchNumber',
          key: 'batchNumber',
        },
        {
          title: 'Batch quantity',
          // width: '200px',
          dataIndex: 'quantity',
          key: 'quantity',
        },
        {
          title: 'Manufactured date',
          // width: '200px',
          dataIndex: 'manufactureDate',
          key: 'manufactureDate',
        },
        {
          title: 'Expiry date',
          // width: '200px',
          dataIndex: 'expiryDate',
          key: 'expiryDate',
        },
      ],
    };

    this.configureRowSelction = this.configureRowSelction.bind(this);
    this.editButton = this.editButton.bind(this);
    this.onEdit = this.onEdit.bind(this);

    //
    //   this.state.skus.filter(function (item: any) {
    //     return item.reOrderQuantity > 0;
    //   }),
    // );
    // this.setState({
    //   autoReplenishment: this.state.skus.filter(function (item: any) {
    //     return item.reOrderQuantity > 0;
    //   })
    // })
    // this.haveAutoReplenishment(this.props.skus);
    //
  }

  // componentDidMount() {
  //   this.haveAutoReplenishment(this.state.skus);
  // }

  // haveAutoReplenishment(data: any) {
  //   this.setState({
  //     autoReplenishment: data.filter(function (item: any) {
  //       return item.reOrderQuantity > 0;
  //     }),
  //   });
  // }

  // componentDidUpdate(prevProps) {
  //
  //
  // }

  shouldComponentUpdate(nextProps, nextState) {
    const repl = nextProps.skus.filter(function (item: any) {
      return item.reOrderQuantity > 0 && item.quantitiesInTransit == 0;
    });

    if (nextState.autoReplenishment.length == 0 && repl.length > 0) {
      this.setState({
        autoReplenishment: repl,
      });
    }

    return true;
    // return this.state.autoReplenishme   s nt != nextState.value;
  }

  static getDerivedStateFromProps(props, currentState) {
    return {
      skus: props.skus,
    };
  }

  private async onEdit(sku) {
    const skuBatchDetails = await bgiService.getBatches(sku.id);

    this.setState({
      editModalContent: sku,
      editModalBatches: skuBatchDetails,
      showEditModal: true,
    });
  }

  private isUpdatedToday(sku: SKUType) {
    const lastUpdatedOn = sku.updatedAt;
    const today = moment();

    return moment(lastUpdatedOn).isSame(today, 'day');
  }

  // Excluding Checkbox column
  private getTotalColumnWidth(columns: ColumnType[]): number {
    return columns.reduce((acc, cur) => acc + parseInt(cur.width, 10), 0);
  }

  handleOk = async (updates) => {
    const dailyConsumptionPayload = {
      dailyConsumption: updates.dailyConsumption,
      productId: this.state.editModalContent?.productId,
      locationId: this.state.editModalContent?.locationId,
      inventoryId: this.state.editModalContent?.id,
    };

    const batchesPayload = updates?.batches?.map((batch) => {
      return {
        ...batch,
        productId: this.state.editModalContent?.productId,
        locationId: this.state.editModalContent?.locationId,
        inventoryId: this.state.editModalContent?.id,
        hasExpiry: !!batch.expiryDate,
      };
    });
    //
    if (updates.callUpdateApi) {
      await bgiService.updateBatches(batchesPayload);
      await bgiService.updateDailyConsumption(dailyConsumptionPayload);
    }

    this.props.onUpdate();
    this.fetchBatches(this.state.editModalContent?.id);
    this.setState({
      showEditModal: false,
      editModalBatches: null,
      editModalContent: null,
    });
    // window.location.reload();
  };

  handleCancel = () => {
    this.setState({
      showEditModal: false,
      editModalBatches: null,
      editModalContent: null,
    });
    // this.props.onUpdate();
    // window.location.reload();
  };

  // Row checkbox config
  private configureRowSelction() {
    return {
      onChange: (selectedRowKeys, selectedRows) => {
        this.onSelectChange(selectedRowKeys);
      },
      getCheckboxProps: (record: SKUType) => {
        return {
          code: record.product.code,
          disabled: !this.state.userAccess.canPlaceBgiPurchaseOrder(this.props.locationDetails.id),
        };
      },
    };
  }

  editButton(sku) {
    const { userAccess } = this.state;
    const { locationDetails } = this.props;

    return (
      <Access accessible={userAccess.canUpdateBgiInventory(locationDetails.id)}>
        <Tooltip title="Edit">
          <Button
            type="primary"
            shape="circle"
            icon={<EditOutlined />}
            onClick={() => this.onEdit(sku)}
          />
        </Tooltip>
      </Access>
    );
  }

  keys: any[] = [];

  getExpandableData = (inventoryId, rowId) => {
    this.keys[0] === rowId ? (this.keys = []) : (this.keys[0] = rowId);
    this.setState({
      expandRowData: [],
      loadEpandableRowdata: true,
      expandedRowKeys: this.keys,
    });
    this.fetchBatches(inventoryId);
  };

  fetchBatches = async (inventoryId: number) => {
    const data = await bgiService.getBatches(inventoryId);

    if (data) {
      this.setState({
        expandRowData: data.batches,
        loadEpandableRowdata: false,
      });
    }
  };

  expandedRowRender = () => {
    let extraColumns = [];

    if (
      this.state.expandRowData.length &&
      this.state.userAccess.canUpdateBgiInventory(this.state.inventoryLocationId)
    ) {
      extraColumns = [
        {
          title: 'Action',
          dataIndex: 'delete',
          key: 'delete',
          render: (text, record) =>
            this.state.expandRowData.length >= 1 ? (
              <Popconfirm title="Sure to delete?" onConfirm={() => this.handleDelete(record.id)}>
                <Tooltip title="Delete">
                  <Button type="primary" shape="circle" icon={<DeleteOutlined />} />
                </Tooltip>
                {/* <DeleteOutlined style={{ fontSize: '18px' }} /> */}
              </Popconfirm>
            ) : null,
        },
      ];
    }

    return (
      <Table
        columns={[...this.state.nestedColumns, ...extraColumns]}
        dataSource={this.state.expandRowData}
        pagination={false}
        loading={this.state.loadEpandableRowdata}
      />
    );
  };

  handleDelete = (id) => {
    bgiService.deleteBatch(id).then((response) => {
      const dataSource = [...this.state.expandRowData];

      this.setState({ expandRowData: dataSource.filter((item) => item.id !== id) });
      this.props.onUpdate();
    });
  };

  onSelectChange = (selectedRowKeys) => {
    const { skus, selectedOrder } = this.state;

    this.setState({ selectedRowKeys });

    const selectedOrderData = [];
    selectedRowKeys.forEach((el, index) => {
      const selectedRow = skus.find((sku) => sku.product.code === el);
      if (selectedRow.reOrderQuantity === 0) {
        // message.warning("In-sufficient Reorder Quantity");
        // selectedRowKeys = [];
        // this.setState({ selectedRowKeys });

        selectedOrderData.push({
          inventoryId: selectedRow.id,
          productId: selectedRow.productId,
          locationId: selectedRow.locationId,
          quantity: selectedRow.reOrderQuantity,
          code: selectedRow.product.code,
          description: selectedRow.product.description,
          quantitiesInTransit: selectedRow.quantitiesInTransit,
        });
      } else {
        selectedOrderData.push({
          inventoryId: selectedRow.id,
          productId: selectedRow.productId,
          locationId: selectedRow.locationId,
          quantity: selectedRow.reOrderQuantity,
          code: selectedRow.product.code,
          description: selectedRow.product.description,
          quantitiesInTransit: selectedRow.quantitiesInTransit,
        });
      }
    });
    this.setState({ selectedOrder: selectedOrderData });
  };

  downloadInventory = async () => {
    await bgiService.downloadInventory(
      this.state.inventoryLocationId,
      locationsKeys[this.state.inventoryLocationId - 1],
    );
  };

  render() {
    let extraColumns = [];
    if (
      this.state.skus.length &&
      this.state.userAccess.canUpdateBgiInventory(this.state.inventoryLocationId)
    ) {
      extraColumns = [
        {
          title: 'Actions',
          width: '100px',
          dataIndex: 'actions',
          key: 'actions',
          fixed: 'right',
          render: (text, record) => this.editButton(record),
        },
      ];
    }

    return (
      <>
        <Table
          id="table-element"
          columns={[...this.state.skuColumns, ...extraColumns]}
          dataSource={this.state.skus}
          rowKey={(record) => record.product.code}
          rowSelection={this.configureRowSelction()}
          pagination={false}
          onExpand={(expanded, record) => this.getExpandableData(record.id, record.product.code)}
          expandedRowRender={(record) => this.expandedRowRender()}
          expandIconColumnIndex={0}
          expandedRowKeys={this.state.expandedRowKeys}
          expandIconAsCell
          rowExpandable={(record: any) => record.product.classification === 'Reagent'}
          scroll={{
            x:
              this.getTotalColumnWidth(this.state.skuColumns) + // All columns
              300, // Checkbox
            y: this.props.tableHeight - 100,
          }}
        />
        <EditModal
          isVisible={this.state.showEditModal}
          skuDetails={this.state.editModalContent}
          skuBatchDetails={this.state.editModalBatches}
          handleOk={(edits) => this.handleOk(edits)}
          handleCancel={this.handleCancel}
        />

        <Row className={styles.stickyFooter} gutter={[12, 0]}>
          <Col>
            <Button type="primary" onClick={this.downloadInventory}>Download</Button>
          </Col>

          <Access
            accessible={this.state.userAccess.canPlaceBgiPurchaseOrder(
              this.props.locationDetails.id,
            )}
          >
            <Col>
              {this.state.autoReplenishment?.length > 0 && this.state.selectedRowKeys.length === 0 && (
                <OrderModal
                  // style={this.orderModalStyles}
                  inputList={this.state.autoReplenishment.map((item) => {
                    return {
                      inventoryId: item.id,
                      productId: item.productId,
                      locationId: item.locationId,
                      quantity: item.reOrderQuantity,
                      code: item.product.code,
                      description: item.product.description,
                      quantitiesInTransit: item.quantitiesInTransit,
                    };
                  })}
                  locationId={this.state.inventoryLocationId}
                  count={this.state.autoReplenishment?.length}
                  btnName="Auto Replenishment"
                />
              )}

              {this.state.selectedRowKeys.length > 0 && (
                <OrderModal
                  // style={this.orderModalStyles}
                  inputList={this.state.selectedOrder}
                  locationId={this.state.inventoryLocationId}
                  count={this.state.selectedOrder.length}
                  btnName="Place Order"
                  module={ModuleTypes.BGI}
                />
              )}
            </Col>
          </Access>
        </Row>
      </>
    );
  }
}

const InventoryTableWrapper = (props: any) => <InventoryTable {...props} access={useAccess()} />;
export default InventoryTableWrapper;
