import Apis from '@/api/apis';

interface IInventoryParams {
  locationId: number;
  page: number;
}

export async function getInventory(payload: IInventoryParams) {
  return Apis.getInventory(payload.locationId, payload.page);
}

export async function getLocations() {
  return Apis.getLocations();
}

export async function getBatches(skuId) {
  return Apis.getBatches(skuId);
}

export async function updateBatches(data) {
  return Apis.updateBatches(data);
}

export async function updateDailyConsumption(data) {
  return Apis.updateDailyConsumption(data);
}

export async function getFilteredInventory(payload) {
  return Apis.filterInventory(payload.locationId, payload.page, payload.filter);
}
