import React, { useState, useEffect, Component, useRef } from 'react';
import { connect, useModel } from 'umi';
import { Col, Row, Tabs, Menu, Dropdown, Button, Badge } from 'antd';
import { ModuleTypes } from '@/services/Constants';
import InventoryTable from './components/InventoryTable/InventoryTable';
import bgiService from '../services/bgi.service';
import { InventoryType } from './Types';
import { StateType } from './model';
import styles from './index.less';

const { TabPane } = Tabs;

enum StatusNames {
  'outOfStock' = 'OOS',
  'nearOutOfStock' = 'NOOS',
  'safeStock' = 'SS',
  'overStock' = 'OS',
}

enum ExpiryFrequeny {
  'perWeek' = 'Every Week',
  'perMonth' = 'Every Month',
  'perDay' = 'Every Day',
  'once' = 'Once',
}
const InventoryContainer = (props) => {
  const {
    inventories,
    userLocationId,
    onChangeTab,
    currentInventoryLocationId,
    onFilter,
    locationsKeys,
  } = props;

  const [height, setHeight] = useState(0);
  const ref = useRef(null);

  useEffect(() => {
    setHeight(ref.current.clientHeight);
  });

  const [filters, setFilters] = useState({
    status: 'clear',
    type: 'clear',
    expiry: 'clear'
  });

  const Filters = (props) => {
    const onFilterChange = (value, key) => {
      const newFilters = { ...filters, [key]: value };
      setFilters(newFilters);
      onFilter(newFilters);
    };

    const menu = (
      <Menu onClick={(e) => onFilterChange(e.key, 'status')}>
        <Menu.Item key="outOfStock">
          <Badge color="red" /> OOS
        </Menu.Item>
        <Menu.Item key="nearOutOfStock">
          <Badge color="orange" /> NOOS
        </Menu.Item>
        <Menu.Item key="safeStock">
          <Badge color="green" />
          SS
        </Menu.Item>
        <Menu.Item key="overStock">
          <Badge color="purple" />
          OS
        </Menu.Item>
        <Menu.Item key="clear">Clear Status</Menu.Item>
      </Menu>
    );

    const productClassificationMenu = (
      <Menu onClick={(e) => onFilterChange(e.key, 'type')}>
        <Menu.Item key="Consumables">Consumables</Menu.Item>
        <Menu.Item key="PPE">PPE</Menu.Item>
        <Menu.Item key="Reagent">Reagent</Menu.Item>
        <Menu.Item key="Equipment">Equipment</Menu.Item> 
        <Menu.Item key="clear">Clear Type</Menu.Item>
      </Menu>
    );

    const expiryTime = (
      <Menu onClick={(e) => onFilterChange(e.key, 'expiry')}>
        <Menu.Item key="once">Once</Menu.Item>
        <Menu.Item key="perDay">Every Day</Menu.Item>
        <Menu.Item key="perMonth">Every Month</Menu.Item>
        <Menu.Item key="perWeek">Every Week</Menu.Item>
        <Menu.Item key="clear">Clear Frequecy</Menu.Item>
      </Menu>
    );

    return (
      <>
        <Dropdown
          className={styles.filterDropdown}
          overlay={productClassificationMenu}
          placement="bottomRight"
        >
          <Button type={filters.type !== 'clear' ? 'primary' : 'default'}>
            {filters.type !== 'clear' ? filters.type : 'Type'}
          </Button>
        </Dropdown>
        <Dropdown className={styles.filterDropdown} overlay={menu} placement="bottomRight">
          <Button type={filters.status !== 'clear' ? 'primary' : 'default'}>
            {filters.status !== 'clear' ? StatusNames[filters.status] : 'Status'}
          </Button>
        </Dropdown>
        <Dropdown className={styles.filterDropdown} overlay={expiryTime} placement="bottomRight">
          <Button type={filters.expiry !== 'clear' ? 'primary' : 'default'}>
            {filters.expiry !== 'clear' ? ExpiryFrequeny[filters.expiry] : 'Update Frequency'}
          </Button>
        </Dropdown>
      </>
    );
  };

  const onChange = (activeKey?) => {
    setFilters({
      status: 'clear',
      type: 'clear',
      expiry: 'clear'
    });
    onChangeTab(activeKey);
    // setCurrentTab(activeKey);
  };

  return (
    <div className={styles.main}>
      <div className={styles.container}>
        <Row gutter={[24, 24]}>
          <Col>
            <div ref={ref} className={styles.tableContainer}>
              <Tabs
                activeKey={locationsKeys[currentInventoryLocationId]}
                onChange={onChange}
                tabBarExtraContent={Filters(props.onFilter)}
              >
                {Object.keys(inventories)
                  .map((locationKey) => {
                    return inventories[locationKey];
                  })
                  .filter((inventory) => inventory?.locationDetails?.code)
                  .map((inventory: InventoryType) => {
                    const key = locationsKeys[inventory.locationDetails.id];
                    return (
                      <TabPane key={key} tab={inventory.locationDetails.code}>
                        <InventoryTable
                          skus={inventory.skus}
                          locationDetails={inventory.locationDetails}
                          userLocationId={userLocationId}
                          inventoryLocationId={inventory.locationDetails.id}
                          onUpdate={props.onUpdate}
                          tableHeight={height}
                        />
                      </TabPane>
                    );
                  })}
              </Tabs>
            </div>
          </Col>
        </Row>
      </div>
    </div>
  );
};

// const locationsKeys = ['nhl', 'mak', 'mad', 'asr', 'dam'];
const locationsKeys: {} = {};

class Inventory extends Component {
  constructor(props) {
    super(props);

    const { currentUser }: App.InitialStateType = props;
    const bgiProfile = currentUser?.modules.find((module) => module.name === ModuleTypes.BGI);
    const userLocationId = bgiProfile?.locationId;

    this.state = {
      userLocationId,
      userLocation: '',
      currentInventoryLocationId: userLocationId,
    };
    this.onChangeTab = this.onChangeTab.bind(this);
  }

  async componentDidMount() {
    const { dispatch } = this.props;
    const allLocationDetails = (await bgiService.getLocations()) || [];
    allLocationDetails.forEach((location: any) => {
      locationsKeys[location.id] = location.code;
    });

    this.setState((prevState) => ({
      userLocation: locationsKeys[prevState.userLocationId],
    }));

    dispatch({
      type: 'inventory/initInventories',
      payload: {
        allLocationDetails,
        userLocation: this.state.userLocation,
        locationId: this.state.userLocationId,
        page: 0,
      },
    });
  }

  onChangeTab(activeKey) {
    const { dispatch } = this.props;
    const locationId = Object.keys(locationsKeys).find((key) => locationsKeys[key] === activeKey);
    this.setState({
      currentInventoryLocationId: locationId,
    });
    dispatch({
      type: 'inventory/fetchInventory',
      payload: {
        locationKey: activeKey,
        locationId,
        page: 0,
      },
    });
  }

  refreshInventory = async (filter) => {
    const { dispatch } = this.props;

    if (filter.status === 'clear' && filter.type === 'clear' && filter.expiry === 'clear') {
      dispatch({
        type: 'inventory/fetchInventory',
        payload: {
          locationId: this.state.currentInventoryLocationId,
          page: 0,
          locationKey: locationsKeys[this.state.currentInventoryLocationId],
        },
      });
    } else {
      const payload = {
        filter,
        locationId: this.state.currentInventoryLocationId,
        page: 0,
        locationKey: locationsKeys[this.state.currentInventoryLocationId],
      };

      dispatch({
        type: 'inventory/fetchFilteredInventory',
        payload,
      });
    }
  };

  render() {
    const { inventories } = this.props;

    return (
      <InventoryContainer
        inventories={inventories}
        userLocation={this.state.userLocation}
        userLocationId={this.state.userLocationId}
        onChangeTab={this.onChangeTab}
        currentInventoryLocationId={this.state.currentInventoryLocationId}
        onFilter={(filter) => this.refreshInventory(filter)}
        onUpdate={(key) => this.refreshInventory({ status: 'clear', type: 'clear',expiry : 'clear' })}
        locationsKeys={locationsKeys}
      />
    );
  }
}

const InventoryWrapper: React.FC<any> = (props) => {
  const { initialState } = useModel('@@initialState');

  return <Inventory {...props} currentUser={initialState?.currentUser} />;
};

export default connect(({ inventory }: { inventory: StateType }) => {
  return {
    inventories: inventory,
  };
})(InventoryWrapper);
