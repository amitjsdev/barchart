import React, { useState, useEffect } from 'react';
import { Gauge } from '@ant-design/charts';

const AvgDayStockGauge: React.FC = () => {
  const config = {
    autoFit: true,
    // height: 200,
    min: 0.15,
    max: 0.8,
    percent: 0.75,
    range: {
      color: ['#5d7cef'],
    },
    /* axis: {
      label: {
        formatter(v: string) {
          return Number(v) * 100;
        },
      },
    },
    statistic: {
      content: {
        formatter: ({ percent }) => `${percent * 100}`,
      },
    }, */
  };
  return <Gauge {...config} />;
  /*   const config = {
    height: 160,
    percent: 0.75,
    range: {
      ticks: [0, 0.2, 0.4, 0.75, 1],
      color: ['red', 'yellow', 'green'],
    },
    indicator: {
      pointer: {
        style: {
          stroke: 'pink',
        },
      },
      pin: {
        style: {
          stroke: 'blue',
        },
      },
    },
    axis: {
      label: {
        formatter(v: string) {
          return Number(v) * 100;
        },
      },
      subTickLine: {
        count: 3,
      },
    },
    statistic: {
      content: {
        formatter: ({ percent }) => `分数：${percent * 100}`,
      },
    },
  };
  return <Gauge {...config} />; */
};

export default AvgDayStockGauge;
