import React from 'react';
import { Spin, Statistic, Space, Typography } from 'antd';
import { InboxOutlined } from '@ant-design/icons';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import moment from 'moment';

import { getCubejsApiParams } from '@/services/cubejs';

const { Text } = Typography;

// CubeJS
const cubejsParams = getCubejsApiParams();

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const CubeQueryRender = (props) => {
  const DATE_FORMAT = 'YYYY-MM-DD';
  const filters = [
    {
      member: 'BgiSurveys.date',
      operator: 'equals',
      values: [moment().format(DATE_FORMAT)],
    },
  ];
  if (props.location && props.location !== 'All locations') {
    filters.push({ dimension: 'Locations.name', operator: 'equals', values: [props.location] });
  }

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['BgiSurveys.numberOfAttendees'],
      dimensions: ['BgiSurveys.date'],
      filters,
      order: {},
    },
    {
      cubejsApi,
    },
  );

  if (isLoading) {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const dataSource = resultSet.tablePivot();

  let avgAttendees = null;

  if (dataSource && dataSource.length)
    avgAttendees =
      dataSource.reduce((acc, cur) => acc + cur['BgiSurveys.numberOfAttendees'], 0) /
      dataSource.length;

  return avgAttendees ? (
    <Statistic value={Math.round(avgAttendees)} />
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

export default CubeQueryRender;
