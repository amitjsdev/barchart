import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Spin, Empty } from 'antd';
import { Chart, Axis, Tooltip, Geom, Coord, Legend } from 'bizcharts';
import { getCubejsApiParams } from '@/services/cubejs';
import moment from 'moment';
import hostname from '@/hostname';

const formatData = (data) => {
  return data.map((item) => {
    const formattedItem = { ...item };

    if (formattedItem.color.endsWith('Batches.quantity')) {
      formattedItem.color = 'Quantity';
      return formattedItem;
    }
  });
};

const stackedChartData = (resultSet) => {
  const data = resultSet
    .pivot()
    .map(({ xValues, yValuesArray }) =>
      yValuesArray.map(([yValues, m]) => ({
        x: resultSet.axisValuesString(xValues, ', '),
        color: resultSet.axisValuesString(yValues, ', '),
        measure: m && Number.parseFloat(m),
      })),
    )
    .reduce((a, b) => a.concat(b), []);

  return formatData(data);
};

const color = ['color', ['#753BBD']];

const barRender = ({ resultSet }) => (
  <Chart
    scale={{ x: { tickCount: 8 } }}
    // height={240}
    data={stackedChartData(resultSet)}
    autoFit
    padding="auto"
    // renderer={'svg'}
  >
    <Axis name="x" label={false} tickLine={false} />
    <Axis name="measure" />
    <Tooltip />
    <Geom type="interval" position="x*measure" color={color} />
  </Chart>
);

const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) => {
  const data = resultSet?.loadResponses[0]?.data;
  const result = (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
    (error && error.toString()) || <Spin />;

  return data && data.length ? result : <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
};

const ChartRenderer = (props) => {
  const DATE_FORMAT = 'YYYY-MM-DD';

  const dateRangeFilter = {
    dimension: 'Batches.expirydate',
    operator: 'inDateRange',
    values: [],
  };

  if (props.filter === '< 1 month') {
    dateRangeFilter.values = [
      moment().format(DATE_FORMAT),
      moment().add(1, 'month').format(DATE_FORMAT),
    ];
  } else if (props.filter === '1 - 3 months') {
    dateRangeFilter.values = [
      moment().add(1, 'month').format(DATE_FORMAT),
      moment().add(3, 'month').format(DATE_FORMAT),
    ];
  } else if (props.filter === '3+ months') {
    dateRangeFilter.values = [
      moment().add(3, 'month').format(DATE_FORMAT),
      moment().add(24, 'month').format(DATE_FORMAT),
    ];
  }

  const filters = [
    dateRangeFilter,
    {
      dimension: 'Products.classification',
      operator: 'equals',
      values: ['Reagent'],
    },
  ];

  if (props.location !== 'All locations') {
    filters.push({ dimension: 'Locations.name', operator: 'equals', values: [props.location] });
  }

  return (
    <QueryRenderer
      query={{
        measures: ['Batches.quantity'],
        timeDimensions: [],
        dimensions: ['Products.description'],
        filters,
        order: {},
      }}
      cubejsApi={cubejsApi}
      render={renderChart(barRender, {
        x: ['Products.description'],
        y: ['measures'],
        fillMissingDates: true,
        joinDateRange: false,
      })}
    />
  );
};

export default ChartRenderer;
