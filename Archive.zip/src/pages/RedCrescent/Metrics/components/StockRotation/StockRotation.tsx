import React, { useState, useEffect } from 'react';
import { Gauge } from '@ant-design/charts';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';

import { Spin } from 'antd';
import styles from './index.less';

const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint
const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

// CubeJS
const cubeQueryRender = (props) => {
  let filters: any[] = [];

  if (props.location && props.location !== 'All locations') {
    filters = [{ dimension: 'Locations.name', operator: 'equals', values: [props.location] }];
  }

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['Inventories.consumableDays'],
      timeDimensions: [],
      filters,
      order: {},
    },
    {
      cubejsApi,
    },
  );

  if (isLoading || props.location === '') {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet) {
    return null;
  }

  const dataSource = resultSet.tablePivot();

  const cssClasses = `${styles.fixValue} ${styles.fixAxisLine} ${styles.fixGridLines}`;
  const stockData = dataSource[0]['Inventories.consumableDays'];
  let value: number = 0;
  let roundedValue: number = 0;

  if (stockData) {
    value = 365 / Math.round(stockData);
    roundedValue = Math.round(value);
  }

  return <StockRotationGauge className={cssClasses} value={roundedValue} />;
};

const StockRotationGauge: React.FC = (props) => {
  const cssClasses = `${styles.fixValue} ${styles.fixAxisLine} ${styles.fixGridLines}`;
  const gaugeData = {
    min: 0,
    max: 30,
    value: 12,
  };
  const gaugeColors = {
    normalValue: '#753BBD',
    idealValue: '#27a29e',
  };

  const percentageFactor = 100 / gaugeData.max;
  const config = {
    // renderer: 'svg',
    autoFit: true,
    // height: 200,
    min: gaugeData.min / 100,
    max: gaugeData.max / 100,
    percent: (props.value / 100) * percentageFactor,
    range: {
      ticks: [0, 0.38, 0.42, 1],
      color: [gaugeColors.normalValue, gaugeColors.idealValue, gaugeColors.normalValue],
    },
    axis: {
      label: {
        formatter(v: string) {
          return (Number(v) * 100) / percentageFactor;
        },
      },
    },
    statistic: {
      content: {
        formatter: ({ percent }) => `${Math.round((percent * 100) / percentageFactor)}`,
        style: {
          fill: '#ffffff',
          textAlign: 'center',
          fontWeight: 500,
          fontSize: 24,
        },
      },
    },
  };
  return <Gauge className={cssClasses} {...config} />;
};

/* const StockRotation = () => {
  const cssClasses = `${styles.fixValue} ${styles.fixAxisLine} ${styles.fixGridLines}`;
  const stockData = cubeQueryRender();
  let value: number = 0;
  let roundedValue: number = 0;

  if (stockData) {
    value = 365 / Math.round(stockData);
    roundedValue = Math.round(value);
  }

  

  return <StockRotationGauge className={cssClasses} value={roundedValue} />
  // return <h1>{'Test'}</h1>;
}; */

export default cubeQueryRender;
