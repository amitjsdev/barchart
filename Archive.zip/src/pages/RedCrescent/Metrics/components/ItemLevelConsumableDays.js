import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Spin } from 'antd';
import { Chart, Axis, Tooltip, Geom, Coord, Legend } from 'bizcharts';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';

const stackedChartData = (resultSet) => {
  const data = resultSet
    .pivot()
    .map(({ xValues, yValuesArray }) =>
      yValuesArray.map(([yValues, m]) => ({
        x: resultSet.axisValuesString(xValues, ', '),
        color: resultSet.axisValuesString(yValues, ', '),
        measure: m && Number.parseFloat(m),
      })),
    )
    .reduce((a, b) => a.concat(b), []);

  return data;
};

const scale = { x: { tickCount: 20 } };
const label = {
  // rotate: Math.PI / 3,
  autoHide: false,
  style: {
    fill: '#ffffff',
    color: '#ffffff',
  },

  formatter(text, item, index) {
    const arr = text.split(' ');
    return `${arr[0]}...`;
  },
};

const color = ['color', ['#753BBD']];
const barRender = ({ resultSet }) => (
  <Chart scale={scale} data={stackedChartData(resultSet)} autoFit>
    <Axis name="x" label={label} />
    <Axis name="measure" />
    <Tooltip />
    <Geom type="interval" position="x*measure" color={color} />
    <Legend visible={false} />
  </Chart>
);

const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) =>
  (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
  (error && error.toString()) || <Spin />;

// [{"dimension":"Products.classification","operator":"equals","values":["PPE"]},{"dimension":"Locations.name","operator":"equals","values":["NHL"]}]
// [{"dimension":"Products.classification","operator":"equals","values":["MAD"]}]}
const ChartRenderer = (props) => {
  const filters = [{ dimension: 'Inventories.consumableDays', operator: 'lte', values: ['80'] }];
  if (props.categoryFilter !== 'All') {
    filters.push({
      dimension: 'Products.classification',
      operator: 'equals',
      values: [props.categoryFilter],
    });
  }

  if (props.location !== 'All locations') {
    filters.push({ dimension: 'Locations.name', operator: 'equals', values: [props.location] });
  }

  return (
    <QueryRenderer
      query={{
        measures: ['Inventories.consumableDays'],
        dimensions: props.dimensions, // ["Products.description"],
        timeDimensions: [],
        order: { 'Inventories.consumableDays': 'asc' },
        filters,
      }}
      cubejsApi={cubejsApi}
      render={renderChart(barRender, {
        x: ['Products.description'],
        y: ['measures'],
        joinDateRange: false,
        fillMissingDates: true,
      })}
    />
  );
};

export default ChartRenderer;
