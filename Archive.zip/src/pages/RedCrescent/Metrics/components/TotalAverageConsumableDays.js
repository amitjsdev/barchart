import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Spin, Row, Col, Statistic, Table } from 'antd';
import { getCubejsApiParams } from '@/services/cubejs';

const numberRender = ({ resultSet, pivotConfig }) => (
  <Row type="flex" justify="center" align="middle" style={{ height: '100%' }}>
    <Col>
      {resultSet.seriesNames().map((s) => (
        <Statistic value={resultSet.totalRow()[s.key]} />
      ))}
    </Col>
  </Row>
);

const API_URL = '';

const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) =>
  (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
  (error && error.toString()) || <Spin />;

const ChartRenderer = () => (
  <QueryRenderer
    query={{
      dimensions: [],
      measures: ['Inventories.consumableDays'],
      timeDimensions: [
        {
          dimension: 'Inventories.createdat',
        },
      ],
      order: {},
      filters: [],
    }}
    cubejsApi={cubejsApi}
    render={renderChart(numberRender, {
      x: [],
      y: ['measures'],
      fillMissingDates: true,
      joinDateRange: false,
    })}
  />
);

export default ChartRenderer;
