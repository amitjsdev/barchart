import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Spin, Empty } from 'antd';
import { Chart, Axis, Tooltip, Slider, LineAdvance, Legend } from 'bizcharts';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';
import moment from 'moment';

const formatData = (data) => {
  return data.map((item) => {
    const formattedItem = { ...item };

    if (formattedItem.color.endsWith('BgiSurveys.samplesPerDay')) {
      formattedItem.color = 'Samples per day';
      return formattedItem;
    }
    formattedItem.color = 'Attendees';

    formattedItem.measure1 = formattedItem.measure;
    delete formattedItem.measure;

    return formattedItem;
  });
};

const stackedChartData = (resultSet) => {
  const data = resultSet
    .pivot()
    .map(({ xValues, yValuesArray }) => {
      return yValuesArray.map(([yValues, m]) => ({
        x: resultSet.axisValuesString(xValues, ', '),
        color: resultSet.axisValuesString(yValues, ', '),
        measure: m && Number.parseFloat(m),
      }));
    })
    .reduce((a, b) => a.concat(b), []);

  return formatData(data);
  // return data;
};

const attendeesColors = ['color', ['#27a29e', '#A72566']];
const samplePerDayColors = ['color', ['#27a29e', '#27a29e']]; // blue

const lineRender = ({ resultSet }) => (
  <Chart padding="auto" scale={{ x: { tickCount: 8 } }} data={stackedChartData(resultSet)} autoFit>
    <Axis name="x" label={false} tickLine={false} />
    <Axis name="measure" />

    {/* Attendees */}
    <Axis name="measure1" />

    <LineAdvance shape="smooth" point area position="x*measure1" color={attendeesColors} />
    <LineAdvance shape="smooth" point area position="x*measure" color={samplePerDayColors} />
    <Slider
      start={0.5}
      textStyle={{ fill: '#fff' }}
      formatter={(val, datum) => {
        return moment(val).format('YYYY-MM-DD');
      }}
    />
    <Legend layout="horizontal" position="top-right" />
    <Tooltip />
  </Chart>
);

const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) => {
  const data = resultSet?.loadResponses[0]?.data;
  const result = (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
    (error && error.toString()) || <Spin />;

  return data && data.length ? result : <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />;
};

const ChartRenderer = (props) => {
  const { dateRangeFilter, location } = props;

  /* const timeDimensions = [
    {
      dimension: 'PodData.appointmentDate',
      granularity: dateRangeFilter.granularity,
      dateRange: dateRangeFilter.dateRange,
    },
  ]; */

  const filters = [];
  if (location && location !== 'All locations') {
    filters.push({ dimension: 'Locations.name', operator: 'equals', values: [location] });
  }

  return (
    <QueryRenderer
      query={{
        measures: ['BgiSurveys.samplesPerDay', 'BgiSurveys.numberOfAttendees'],
        // dimensions: [
        //   "BgiSurveys.createdat"
        // ],
        timeDimensions: [
          {
            dimension: 'BgiSurveys.createdat',
            granularity: 'day',
            dateRange: 'Last 30 days',
          },
        ],
        order: {},
        filters,
      }}
      cubejsApi={cubejsApi}
      render={renderChart(lineRender, {
        x: ['BgiSurveys.createdat.day'],
        y: ['measures'],
        fillMissingDates: true,
        joinDateRange: false,
      })}
    />
  );
};

export default ChartRenderer;
