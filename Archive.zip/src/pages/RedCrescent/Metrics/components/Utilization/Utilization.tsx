import React from 'react';
import { RingProgress } from '@ant-design/charts';
import { Spin, Space, Typography } from 'antd';
import { InboxOutlined } from '@ant-design/icons';
import cubejs from '@cubejs-client/core';
import { useCubeQuery } from '@cubejs-client/react';
import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '@/hostname';

import styles from './index.less';

const { Text } = Typography;

const UtilizationRing: React.FC = (props) => {
  const config = {
    // renderer: 'svg',
    height: 56,
    width: 56,
    autoFit: false,
    percent: props.samplePerDay / props.totalCapacity,
    color: ['#753BBD', '#27a29e'],
    statistic: {
      content: {
        formatter: ({ percent }) => `${Math.round(percent * 100)}%`,
        style: {
          fill: '#ffffff',
          textAlign: 'center',
          fontWeight: 500,
        },
      },
    },
  };
  return <RingProgress className={styles.fixValue} {...config} />;
};

// CubeJS
const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint
const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const cubeQueryRender = (props) => {
  let filters: any[] = [];

  if (props.location && props.location !== 'All locations') {
    filters = [{ dimension: 'Locations.name', operator: 'equals', values: [props.location] }];
  }

  const { resultSet, isLoading, error, progress } = useCubeQuery(
    {
      measures: ['Locations.totalCapacity', 'BgiSurveys.samplesPerDay'],
      timeDimensions: [],
      filters,
      order: {},
    },
    {
      cubejsApi,
    },
  );

  if (isLoading || props.location === '') {
    return <div>{(progress && progress.stage && progress.stage.stage) || <Spin />}</div>;
  }

  if (error) {
    return null;
  }

  if (!resultSet && resultSet?.tablePivot()) {
    return null;
  }

  const dataSource = resultSet.tablePivot();

  let totalCapacity = null;
  let samplePerDay = null;

  if (dataSource.length) {
    totalCapacity = dataSource[0]['Locations.totalCapacity'];
    samplePerDay = dataSource[0]['BgiSurveys.samplesPerDay'];
  }

  return totalCapacity && samplePerDay ? (
    <UtilizationRing samplePerDay={samplePerDay} totalCapacity={totalCapacity} />
  ) : (
    <Space size={12}>
      <InboxOutlined />
      <Text type="secondary">No data</Text>
    </Space>
  );
};

export default cubeQueryRender;
