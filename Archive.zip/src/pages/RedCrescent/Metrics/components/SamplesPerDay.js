import React from 'react';
import cubejs from '@cubejs-client/core';
import { QueryRenderer } from '@cubejs-client/react';
import { Spin, Row, Col, Statistic, Table } from 'antd';

import { getCubejsApiParams } from '@/services/cubejs';
import hostname from '../../../hostname';
import Utilization from './Utilization/Utilization';

let value = null;

const numberRender = ({ resultSet, pivotConfig }) => (
  <Row type="flex" justify="center" align="middle" style={{ height: '100%' }}>
    <Col>
      {resultSet.seriesNames().map((s) => (
        <Statistic value={Math.round(resultSet.totalRow()[s.key])} />
      ))}
    </Col>
  </Row>
);

const API_URL = hostname.CUBEJS_URL; // change to your actual endpoint

const cubejsParams = getCubejsApiParams(API_URL);

const cubejsApi = cubejs(cubejsParams.token, cubejsParams.options);

const renderChart = (Component, pivotConfig) => ({ resultSet, error }) => {
  if (resultSet) value = resultSet.loadResponse.results[0].data[0]['BgiSurveys.samplesPerDay'];
  return (
    (resultSet && <Component resultSet={resultSet} pivotConfig={pivotConfig} />) ||
    (error && error.toString()) || <Spin />
  );
};

const ChartRenderer = (props) => {
  let filters = [];

  if (props.location && props.location !== 'All locations') {
    filters = [{ dimension: 'Locations.name', operator: 'equals', values: [props.location] }];
  }

  return (
    <QueryRenderer
      query={{
        measures: ['BgiSurveys.samplesPerDay'],
        timeDimensions: [],
        filters,
        order: {},
      }}
      cubejsApi={cubejsApi}
      render={renderChart(numberRender, {
        x: [],
        y: ['measures'],
        fillMissingDates: true,
        joinDateRange: false,
      })}
    />
  );
};

const SamplesPerDay = (props) => {
  return (
    <div
      style={{
        width: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}
    >
      <ChartRenderer location={props.location} />
      <Utilization location={props.location} />
      {/* <Row justify="space-between" style={{ width: '100%' }}>
        <Col span={12}>
          <ChartRenderer />
        </Col>
        <Col span={8}>
          <Utilization />
        </Col>
      </Row> */}
    </div>
  );
};

export default SamplesPerDay;
