import { PageContainer } from '@ant-design/pro-layout';
import React, { useState, useEffect } from 'react';
import { Typography, List, Divider, Row, Col, Spin, Card, Select, Popover } from 'antd';
import LocationSelector from '@/components/LocationSelector';
import { InfoCircleOutlined } from '@ant-design/icons';
import styles from './index.less';
import AvailableQuantity from './components/AvailableQuantity';
import AverageConsumableDays from './components/AverageConsumableDays';
import ItemLevelConsumableDays from './components/ItemLevelConsumableDays';
import ProductLevelAverageConsumableDays from './components/ProductLevelAverageConsumableDays';
import AvgDayStock from './components/AvgDayStock/AvgDayStock';
import ItemExpiry from './components/ItemExpiry';
import StockRotation from './components/StockRotation/StockRotation';
import InventoryComposition from './components/InventoryComposition/InventoryComposition';

import TotalCapacity from './components/TotalCapacity';
import LabCapacity from './components/LabCapacity';
import Attendees from './components/Attendees';
import SamplesPerDay from './components/SamplesPerDay';
import SamplesPerDayTrend from './components/SamplesPerDayTrend/SamplesPerDayTrend';
import SamplesPerDayStatistics from './components/SamplesPerDayStatistics';
import AttendeesStatistics from './components/AttendeesStatistics';

const { Title, Text } = Typography;

interface IKpiCardProps {
  title: string;
  info?: string;
  filters?: any;
  children?: React.ReactNode;
  location?: string;
}

interface IKpiStatisticsCardProps {
  title: string;
  info?: string;
  value: string;
  children?: React.ReactNode;
}

// [{"dimension":"Products.classification","operator":"equals","values":["PPE"]}]

const itemLevelConsumableDaysFilters = [
  {
    name: 'Category filter',
    options: [
      { label: 'All categories', value: 'All' },
      { label: 'Consumables', value: 'Consumables' },
      { label: 'PPE', value: 'PPE' },
      { label: 'Reagent', value: 'Reagent' },
    ],
    selectedOption: ['Products.description'],
  },
];

const avgConsumableDaysFilters = [
  {
    name: 'Category filter',
    onChange: (option: string) => {
      avgConsumableDaysFilters[0] = {
        ...avgConsumableDaysFilters,
        selectedOption: [option],
      };
    },
    options: [
      { label: 'By location', value: 'Locations.name' },
      { label: 'By Category', value: 'Products.classification' },
    ],
    selectedOption: ['Locations.name'],
  },
];

const itemExpiryFilters = [
  {
    name: 'Range filter',
    onChange: (option: string) => {
      itemExpiryFilters[0] = {
        ...itemExpiryFilters,
        selectedOption: [option],
      };
    },
    options: [
      { label: '< 1 month', value: '< 1 month' },
      { label: '1 - 3 months', value: '1 - 3 months' },
      { label: '3+ months', value: '3+ months' },
    ],
    selectedOption: '< 1 month',
  },
];

const FilterSelect: React.FC<{}> = (props: any) => (
  <Select
    style={{ width: '120px' }}
    defaultValue={props.filter.options[0].value}
    onChange={props.onChange}
  >
    {props.filter.options.map((option: any) => (
      <Select.Option key={option.value} value={option.value}>
        {option.label}
      </Select.Option>
    ))}
  </Select>
);

// KPI card
const KpiCard: React.FC<IKpiCardProps> = (props) => {
  return (
    <div className={styles.kpiCard}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <div>
              <Text className={styles.chartTitle}>{props.title}</Text>
              {props.info ? (
                <Popover content={props.info} title="Info">
                  <InfoCircleOutlined style={{ padding: '8px' }} />
                </Popover>
              ) : null}
            </div>
          </Col>
          <Col flex={2} className={styles.filters}>
            <div>
              {props.filters?.map((filter) => (
                <FilterSelect filter={filter} />
              ))}
            </div>
          </Col>
        </Row>
      </div>
      <div className={styles.kpiCardContent}>{props.children}</div>
    </div>
  );
};

// KPI card
const AverageConsumableDaysChart: React.FC<IKpiCardProps> = (props) => {
  // const chartDimension = avgConsumableDaysFilters[0].selectedOption;
  const [chartDimension, setChartDimension] = useState(avgConsumableDaysFilters[0].selectedOption);
  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;

  return (
    <div className={styles.kpiCard}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{props.title}</Text>
          </Col>
          <Col flex={2} className={styles.filters}>
            <div>
              {props.filters?.map((filter) => (
                <FilterSelect
                  filter={filter}
                  onChange={(val) => {
                    setChartDimension([val]);
                  }}
                />
              ))}
            </div>
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <AverageConsumableDays dimensions={chartDimension} />
      </div>
    </div>
  );
};

const ItemExpiryChart: React.FC<IKpiCardProps> = (props) => {
  const [expiryDateRange, setExpiryDateRange] = useState(itemExpiryFilters[0].selectedOption);
  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;
  return (
    <div className={styles.kpiCard}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{props.title}</Text>
          </Col>
          <Col flex={2} className={styles.filters}>
            <div>
              {props.filters?.map((filter) => (
                <FilterSelect
                  filter={filter}
                  onChange={(val) => {
                    setExpiryDateRange(val);
                  }}
                />
              ))}
            </div>
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <ItemExpiry filter={expiryDateRange} location={props.location} />
      </div>
    </div>
  );
};

const ItemLevelConsumableDaysChart: React.FC<IKpiCardProps> = (props) => {
  const [categoryFilter, setCategoryFilter] = useState('All');
  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;

  return (
    <div className={styles.kpiCardLarge}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{props.title}</Text>
          </Col>
          <Col flex={2} className={styles.filters}>
            <div>
              {props.filters?.map((filter) => (
                <FilterSelect filter={filter} onChange={setCategoryFilter} />
              ))}
            </div>
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <ItemLevelConsumableDays
          dimensions={['Products.description']}
          categoryFilter={categoryFilter}
          location={props.location}
        />
      </div>
    </div>
  );
};

const SamplesPerDayAndAttendeesTrendChart: React.FC<IKpiCardProps> = (props) => {
  // const [categoryFilter, setCategoryFilter] = useState('All');
  const contentCss = `${styles.kpiCardContent} ${styles.fixXAxisLabels} ${styles.fixYAxisLabels}`;

  return (
    <div className={styles.kpiCardLarge}>
      <div className={styles.kpiCardTitleBar}>
        <Row style={{ flex: '1 1 auto' }}>
          <Col flex={1}>
            <Text className={styles.chartTitle}>{props.title}</Text>
          </Col>
          <Col flex={2} className={styles.filters}>
            {/* <div>
              {props.filters?.map((filter) => (
                <FilterSelect filter={filter} onChange={setCategoryFilter} />
              ))}
            </div> */}
          </Col>
        </Row>
      </div>
      <div className={contentCss}>
        <SamplesPerDayTrend location={props.location} />
      </div>
    </div>
  );
};

// KPI statistics card
const KpiStatisticsCard: React.FC<IKpiStatisticsCardProps> = (props) => (
  <div className={styles.kpiStatisticsCard}>
    <div className={styles.kpiCardTitleBar}>
      <div>
        <Text className={styles.chartTitle}>{props.title}</Text>
        {props.info ? (
          <Popover content={props.info} title="Info">
            <InfoCircleOutlined style={{ padding: '8px' }} />
          </Popover>
        ) : null}
      </div>
    </div>
    <div className={styles.kpiStatisticsCardContent}>
      {/* <div>
        <Title level={3}>{props.value}</Title>
      </div> */}
      {props.children}
    </div>
  </div>
);

export default () => {
  const [selectedLocation, setLocation] = useState('');
  const locations = ['All locations', 'NHL', 'MAK', 'MAD', 'ASR', 'DAM'];

  const [loading, setLoading] = useState<boolean>(true);
  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
      setLocation('All locations');
    }, 1000);
  }, []);

  return (
    // <PageContainer className={styles.main} header={{ title: '' }}>
    <div className={styles.main}>
      <Spin spinning={loading} size="large" />
      <Row className={styles.locationPanel} align="middle" justify="space-between">
        <Col>
          <Title level={4}>Metrics</Title>
        </Col>
        <Col>
          <LocationSelector onChange={setLocation} locations={locations} />
        </Col>
      </Row>
      {/* KPI cards */}

      <Row gutter={[24, 24]}>
        <Col span={5}>
          <KpiCard
            title="Average day stock"
            info={() => (
              <div>
                <p>
                  <b>&lt; 15:</b> OOS
                </p>
                <p>
                  <b>15-30:</b> NOOS,
                </p>
                <p>
                  <b>30-80:</b> SS,
                </p>
                <p>
                  <b>&gt; 80:</b> OS
                </p>
              </div>
            )}
          >
            <AvgDayStock location={selectedLocation} />
          </KpiCard>
        </Col>
        <Col span={5}>
          <KpiCard
            title="Stock rotation per year"
            info={() => (
              <div>
                <p>
                  <b>Target value:</b> 12
                </p>
              </div>
            )}
          >
            {/* <AvgDayStock /> */}
            <StockRotation location={selectedLocation} />
          </KpiCard>
        </Col>
        <Col span={5}>
          <KpiCard title="Inventory composition">
            <InventoryComposition location={selectedLocation} />
          </KpiCard>
        </Col>
        <Col span={9}>
          <Row gutter={[12, 12]}>
            <Col flex={1}>
              <KpiStatisticsCard title="Sample per day" value="9,000">
                <SamplesPerDayStatistics location={selectedLocation} />
              </KpiStatisticsCard>
            </Col>
            <Col flex={1}>
              <KpiStatisticsCard title="Total capacity" value="50,000">
                <TotalCapacity location={selectedLocation} />
              </KpiStatisticsCard>
            </Col>
          </Row>
          <Row gutter={[12, 12]}>
            <Col flex={1}>
              <KpiStatisticsCard title="Lab capacity" value="10,000">
                <LabCapacity location={selectedLocation} />
              </KpiStatisticsCard>
            </Col>
            <Col flex={1}>
              <KpiStatisticsCard title="Attendees" value="92">
                <AttendeesStatistics location={selectedLocation} />
              </KpiStatisticsCard>
            </Col>
          </Row>
        </Col>
      </Row>

      {/* Row 2 */}

      <Row gutter={[24, 24]}>
        <Col span={12}>
          <AverageConsumableDaysChart
            title="Average stock days"
            filters={avgConsumableDaysFilters}
          />
        </Col>
        <Col span={12}>
          <ItemExpiryChart
            title="Expiry of reagents"
            filters={itemExpiryFilters}
            location={selectedLocation}
          />
        </Col>
      </Row>

      {/* Row 3 */}

      <Row gutter={[24, 24]}>
        <Col span={12}>
          <ItemLevelConsumableDaysChart
            title="Avg. No. Of days of stocks"
            filters={itemLevelConsumableDaysFilters}
            location={selectedLocation}
          />
        </Col>
        <Col span={12}>
          <SamplesPerDayAndAttendeesTrendChart
            title="Samples per day & attendees trend"
            location={selectedLocation}
          />
        </Col>
      </Row>

      {/* Row 4 */}

      {/* <Row gutter={[24, 24]}>
            <Col flex={1}>
              <ItemLevelConsumableDaysChart
                title="Avg. No. Of days of stocks"
                filters={itemLevelConsumableDaysFilters}
                location={selectedLocation}
              />
            </Col>
          </Row> */}
    </div>
    // {/* </PageContainer> */}
  );
};
