import Apis from '@/api/apis';

export async function getLocations() {
  return Apis.getLocations();
}

export async function getTickets({ locationId }) {
  return Apis.getImsTickets(locationId);
}

export async function closeImsTicket(ticketId) {
  return Apis.closeImsTicket(ticketId);
}
