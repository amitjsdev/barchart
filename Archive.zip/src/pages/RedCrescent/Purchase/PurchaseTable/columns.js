import React from 'react';
import { Spin, Tag, Input, Button, Popconfirm, Form, Tabs } from 'antd';
import styles from './styles';

import DisputeModal from '../Modals/DisputeModal';

const createdColumns = [
  {
    title: 'Name',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'Quantity',
    dataIndex: 'quantity',
    key: 'quantity',
  },
  {
    title: 'Created By',
    dataIndex: 'createdBy',
    key: 'createdBy',
  },
  {
    title: 'Created On',
    key: 'createdOn',
    dataIndex: 'createdOn',
    // render: (record, text)=> (this.dateDiff(record.createdOn) > 7 ? record.color="red" : record.color="green")
  },
  {
    title: 'Expected Delivery Date',
    dataIndex: 'expectedOn',
    key: 'expectedOn',
  },
  {
    title: 'Action',
    key: 'action',
    render: (text, record, index) => (
      <span>
        <Button style={styles.actionButton}>Edit</Button>
        <Button style={styles.actionButton}>Delete</Button>
        <DisputeModal style={styles.disputeModal} inputList={this.state.inputList} index={index} />
      </span>
    ),
  },
];

const completedColumns = [
  {
    title: 'Name',
    dataIndex: 'name',
    key: 'name',
  },
  {
    title: 'Quantity',
    dataIndex: 'quantity',
    key: 'quantity',
  },
  {
    title: 'Created By',
    dataIndex: 'createdBy',
    key: 'createdBy',
  },
  {
    title: 'Created On',
    key: 'createdOn',
    dataIndex: 'createdOn',
    // render: (record, text)=> (this.dateDiff(record.createdOn) > 7 ? record.color="red" : record.color="green")
  },
  {
    title: 'Delivered Date',
    dataIndex: 'deliveredOn',
    key: 'deliveredOn',
  },
  {
    title: 'Action',
    key: 'action',
  },
];

export { createdColumns, completedColumns };
