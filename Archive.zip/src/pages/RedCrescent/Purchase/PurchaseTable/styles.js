const styles = {
  actions: {
    // display: 'inline-block',
    // marginLeft: '-50px',
  },

  actionButton: {
    border: 'none',
    // color: 'blue',
    // background: 'transparent',
  },

  disputeModal: {
    // float: 'left',
    // marginTop: '-32px',
    // marginLeft: '10px',
    // left: '90px',
    // border: 'none',
    // color: 'blue',
    // background: 'transparent',
  },

  disputeModal2: {
    float: 'left',
    // marginTop: '-32px',
    // marginLeft: '10px',
    left: '40%',
    border: 'none',
    // color: 'blue',
    // background: 'transparent',
  },

  deleteModal: {
    // float: 'left',
    // marginTop: '-32px',
    // marginLeft: '10px',
    // left: '40px',
    // border: 'none',
    // color: 'blue',
    // background: 'transparent',
  },

  topMargin: { marginTop: '-40px' },
};

export default styles;
