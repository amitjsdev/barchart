import { PageContainer } from '@ant-design/pro-layout';
import React from 'react';
import { Button, Tabs } from 'antd';
import moment from 'moment';

import { POStatues } from '@/services/Constants';
import PurchaseTable from './PurchaseTable';
import bgiService from '../services/bgi.service';

import styles from './index.less';

const { TabPane } = Tabs;

class EditableTable extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      status: 'created',
      isApproved: false,
      labs: [{ name: 'NHL', id: '1' }], // ["NHL", "MAK", "MAD", "ASR", "DAM"];
      locationId: '',
      dataSource: [],
    };
  }

  async componentDidMount() {
    // Make a request for a user with a given ID
    const labs = await bgiService.getLocations();
    this.setState({ labs });

    this.changeLocation(labs[0].id);
  }

  changeLocation = async (key) => {
    this.setState({ locationId: key }, () => this.getOrder());
  };

  refreshOrder() {
    this.getOrder();
  }

  async getOrder() {
    this.setState({ dataSource: [] });
    const { status, isApproved, locationId } = this.state;
    let currentStatus = status;
    let isApprovedStatus = isApproved;

    if (status === 'approved') {
      currentStatus = POStatues.CREATED;
      isApprovedStatus = true;
    }

    const _orderData = await bgiService.getOrders(locationId, currentStatus, isApprovedStatus);
    const _orderStateData = [];

    if (_orderData === undefined || _orderData === null) return;

    _orderData.forEach((el, index) => {
      _orderStateData.push({
        name: el.userName || 'NA',
        quantity: el.quantity,
        createdOn: moment(el.createdAt).format('YYYY-MM-DD'),
        createdBy: el.userName,
        id: el.id,
        orderItems: el.orderItems,
        deliveredOn: el.expectedDeliveryDate,
        expectedOn: el.expectedDeliveryDate,
      });
    });

    this.setState({ dataSource: _orderStateData });
  }

  async changeStatus(status: string, isApproved: boolean | null) {
    this.setState({ status, isApproved }, () => this.getOrder());
  }

  togglePurchase(mode) {}

  // const [loading, setLoading] = useState<bogolean>(true);
  // useEffect(() => {
  //   setTimeout(() => {
  //     setLoading(false);
  //   }, 3000);
  // }, []);

  render() {
    const { labs, dataSource, status } = this.state;

    return (
      <PageContainer content="" className={styles.main}>
        <div className={styles.divContain}>
          <Tabs defaultActiveKey={labs[0].id} onChange={this.changeLocation}>
            {labs.map((item, i) => (
              <TabPane tab={item.code} key={item.id} />
            ))}
          </Tabs>

          <div className={styles.toggleContainer}>
            <Button
              type={status === 'created' ? 'primary' : 'default'}
              className={styles.toggleButtonContainer}
              onClick={() => this.changeStatus('created', false)}
            >
              Created
            </Button>
            <Button
              type={status === 'approved' ? 'primary' : 'default'}
              className={styles.toggleButtonContainer}
              onClick={() => this.changeStatus('approved', true)}
            >
              Approved
            </Button>

            <Button
              type={status === 'pending' ? 'primary' : 'default'}
              className={styles.toggleButtonContainer}
              onClick={() => this.changeStatus('pending', true)}
            >
              Pending
            </Button>

            <Button
              type={status === 'completed' ? 'primary' : 'default'}
              className={styles.toggleButtonContainer}
              onClick={() => this.changeStatus('completed', null)}
            >
              Completed
            </Button>
          </div>

          {/* <Button type="primary" className={styles.addItem} >Add Item</Button> */}

          <PurchaseTable
            data={dataSource}
            status={status}
            getOrder={this.getOrder.bind(this)}
            locationId={this.state.locationId}
          />
        </div>
        <div
          style={{
            paddingTop: 100,
            textAlign: 'center',
          }}
        >
          {/* <Spin spinning={loading} size="large" /> */}
        </div>
      </PageContainer>
    );
  }
}

export default () => (
  <div className={styles.container}>
    <div id="components-table-demo-edit-cell">
      <EditableTable />
    </div>
  </div>
);
