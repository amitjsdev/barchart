import React from 'react';
import { Switch } from 'antd';

enum Theme {
  LIGHT = 'light',
  DARK = 'dark',
}

function changeTheme(nextTheme: Theme) {
  let styleLink = document.getElementById('theme-style') as HTMLLinkElement;
  const body = document.getElementsByTagName('body')[0];

  if (styleLink) {
    styleLink.href = `/theme/${nextTheme}.css`;
    body.className = `body-wrap-${nextTheme}`;
    return;
  }
  styleLink = document.createElement('link');
  styleLink.type = 'text/css';
  styleLink.rel = 'stylesheet';
  styleLink.id = 'theme-style';
  styleLink.href = `/theme/${nextTheme}.css`;
  body.className = `body-wrap-${nextTheme}`;
  document.body.append(styleLink);
}

export default () => {
  const onChange = (checked: boolean) => {
    if (checked) {
      changeTheme(Theme.DARK);
    } else {
      changeTheme(Theme.LIGHT);
    }
  };

  return <Switch onChange={onChange} />;
};
