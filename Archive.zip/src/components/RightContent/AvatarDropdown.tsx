import React, { useCallback, useState } from 'react';
import {
  EnvironmentOutlined,
  SafetyOutlined,
  LogoutOutlined,
  MailOutlined,
  UserOutlined,
} from '@ant-design/icons';
import { Avatar, Menu, Spin, Modal } from 'antd';
import { history, useModel } from 'umi';
import Apis from '@/api/apis';
import _ from 'lodash';
import HeaderDropdown from '../HeaderDropdown';

import styles from './index.less';

export interface GlobalHeaderRightProps {
  menu?: boolean;
}

const AvatarDropdown: React.FC<GlobalHeaderRightProps> = ({ menu }) => {
  const { initialState, setInitialState } = useModel('@@initialState');
  const [isVisible, setIsVisible] = useState(false);

  const logOut = async () => {
    Modal.confirm({
      title: 'Are you sure you want to log out?',
      okText: 'Yes',
      okType: 'primary',
      onOk: () => {
        return Apis.logout().then(() => {
          // storageService.clear();

          setInitialState({});
          history.push('/user/login');
        });
      },
      onCancel: () => {},
    });
  };

  const onMenuClick = useCallback(
    (event: {
      key: React.Key;
      keyPath: React.Key[];
      item: React.ReactInstance;
      domEvent: React.MouseEvent<HTMLElement>;
    }) => {
      const { key } = event;
      if (key === 'logout' && initialState) {
        setIsVisible(false);
        logOut();
        return;
      }

      if (key === 'profile') {
        // Modal.
      }
      // history.push(`/user/login`);
    },
    [],
  );

  const loading = (
    <span className={`${styles.action} ${styles.account}`}>
      <Spin
        size="small"
        style={{
          marginLeft: 8,
          marginRight: 8,
        }}
      />
    </span>
  );

  if (!initialState) {
    return loading;
  }

  const { currentUser } = initialState;

  if (!currentUser || !currentUser.name) {
    return loading;
  }

  const handleVisibleChange = (flag) => {
    setIsVisible(flag);
  };

  const menuHeaderDropdown = (
    <Menu className={styles.menu} selectedKeys={[]} onClick={onMenuClick}>
      <Menu.Item className={styles.info}>
        <MailOutlined />
        {currentUser.email}
      </Menu.Item>

      <Menu.Item className={styles.info}>
        <SafetyOutlined />
        {_.startCase(currentUser.role)}
      </Menu.Item>

      <Menu.Item className={styles.info}>
        <EnvironmentOutlined />
        {currentUser.locationName || currentUser.region}
      </Menu.Item>
      <Menu.Divider />

      <Menu.Item key="logout" className={styles.logout}>
        <LogoutOutlined />
        Log out
      </Menu.Item>
    </Menu>
  );
  return (
    // <></>
    <HeaderDropdown
      overlay={menuHeaderDropdown}
      onVisibleChange={handleVisibleChange}
      visible={isVisible}
    >
      <span className={`${styles.action} ${styles.account}`}>
        <Avatar size="small" className={styles.avatar} icon={<UserOutlined />} alt="avatar" />
        <span className={`${styles.name} anticon`}>{currentUser.name}</span>
      </span>
    </HeaderDropdown>
  );
};

export default AvatarDropdown;
