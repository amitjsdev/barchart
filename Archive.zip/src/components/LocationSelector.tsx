import React, { useEffect } from 'react';
import { Select, Cascader } from 'antd';
import { connect } from 'react-redux';

const LocationSelector = (props) => {
  useEffect(() => {}, []);
  return (
    <Select defaultValue={props.locations[0]} style={{ width: '215px' }} onChange={props.onChange}>
      {props.locations.map((location) => {
        return (
          <Select.Option key={location} value={location}>
            {location}
          </Select.Option>
        );
      })}
    </Select>
  );
};

export default LocationSelector;

/* const mapStateToProps = (state) =>  {
    return {
        location: state.location
    }
  }
  
  const mapDispatchToProps = dispatch => {
    return {
      onChange: location => dispatch({
          type: 'SELECT_LOCATION',
          location
      })
    }
  }
  
  export default connect(mapStateToProps, mapDispatchToProps)(LocationSelector); */
