import React from 'react';
import { history, useModel } from 'umi';
import { Modal, Button, Input, Alert, Row, Col, Tooltip, InputNumber, message } from 'antd';
import { ExclamationCircleFilled } from '@ant-design/icons';
import apiService from '@/shared/services/api.service';

import { storageService } from '@/services/storage';

enum PurchaseRoutes {
  'bgi' = '/bgi/purchase',
  'nonmoh' = '/non-moh/purchase',
  'centralbloodbank' = '/blood-bank/purchase',
  'branchbloodbank' = '/blood-bank/purchase',
  'peripheralbloodbank' = '/blood-bank/purchase',
}

class OrderModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      orderName: 'DefaultOrder',
      orderNotes: '',
      inputList: [{ product: '', quantity: '' }],
      maxValue: 0,
    };
  }

  componentDidMount() {
    const { inputList } = this.props;
    this.setState({ inputList });
  }

  componentDidUpdate(prevProps) {
    if (prevProps.inputList !== this.props.inputList) {
      this.setState({ inputList: this.props.inputList });
    }
  }

  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleOk = async (e) => {
    const { locationId } = this.props;
    const { orderName, orderNotes, inputList } = this.state;

    // array.forEach(function(v){ delete v.bad });

    if (!inputList.some((sku) => sku.quantity <= 0)) {
      this.setState({
        visible: false,
      });

      await apiService
        .createPurchaseOrder({
          name: orderName,
          // location: locationId,
          userName: this.props.user.name,
          email: this.props.user.email,
          orderItems: inputList,
          notes: orderNotes,
        })
        .then(() => message.success('Order Creation Success'));

      const urlFragment = PurchaseRoutes[this.props.module];
      history.push(urlFragment);
    } else {
      message.error('SKU quantity should be more than 0');
    }
  };

  handleCancel = (e) => {
    this.setState({
      visible: false,
    });
  };

  handleInputChange = (e, index) => {
    const { name, value } = e.target;
    const list = this.state.inputList;
    list[index][name] = value;

    this.setState({ inputList: list });
  };

  // handle click event of the Remove button
  handleRemoveClick = (index) => {
    const list = this.state.inputList;
    list.splice(index, 1);
    this.setState({ inputList: list });
  };

  // handle click event of the Add button
  handleAddClick = () => {
    const list = this.state.inputList;
    list.push({ product: '', quantity: '' });
    this.setState({ inputList: list });
  };

  render() {
    const { visible, orderName, inputList } = this.state;
    const { count, style, btnName } = this.props;

    return (
      <div>
        <Button
          // disabled={this.checkPermission()}
          // style={style}
          type="primary"
          onClick={this.showModal}
        >
          {btnName}
        </Button>
        <Modal
          title="Create Purchase Order"
          visible={visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
          {inputList.some((item) => item.quantitiesInTransit > 0) ? (
            <Row gutter={[12, 12]}>
              <Col>
                <Alert
                  message="Warning!"
                  description="Some of the items in this order are already in transit!"
                  type="warning"
                  showIcon
                  closable
                />
              </Col>
            </Row>
          ) : null}

          <div style={{ marginTop: '5px' }}>
            <span>Product</span>
            <span style={{ marginLeft: '36%' }}>Quantity</span>
            {inputList.map((x, i) => {
              if (typeof x.quantity !== 'number') {
                x.quantity = 0;
              }

              return (
                <Row gutter={[12, 12]} align="middle">
                  <Col span={11}>
                    <Input
                      name="product"
                      value={x.description}
                      onChange={(e) => this.handleInputChange(e, i)}
                    />
                    {this.state.inputList[i].quantity > x.nupcoInventoryQuantity &&
                    this.state.inputList[i].quantity !== x.nupcoInventoryQuantity ? (
                      <p style={{ color: 'red', height: '20px' }}> </p>
                    ) : (
                      <p> </p>
                    )}
                  </Col>
                  <Col span={11}>
                    <InputNumber
                      className="ml10"
                      name="quantity"
                      value={x.quantity}
                      min={0}
                      max={x.nupcoInventoryQuantity}
                      defaultValue={0}
                      onChange={(value) =>
                        this.handleInputChange({ target: { value, name: 'quantity' } }, i)
                      }
                      style={{ width: '100%' }}
                    />
                    {this.state.inputList[i].quantity > x.nupcoInventoryQuantity &&
                    this.state.inputList[i].quantity !== x.nupcoInventoryQuantity ? (
                      <p style={{ color: 'red', height: '20px' }}>
                        Cannot be more than {x.nupcoInventoryQuantity}
                      </p>
                    ) : (
                      <p> </p>
                    )}
                  </Col>
                  <Col span={2}>
                    {x.quantitiesInTransit > 0 ? (
                      <Tooltip
                        placement="top"
                        title={`Quantities in transit: ${x.quantitiesInTransit}`}
                      >
                        <ExclamationCircleFilled style={{ color: '#ad8b00' }} />
                      </Tooltip>
                    ) : null}
                  </Col>

                  {/* <div className="btn-box" style={{position: 'relative', float: 'right'}}>
                        {inputList.length - 1 === i && <Button onClick={this.handleAddClick}>A</Button>}
                        {inputList.length !== 1 && <Button onClick={this.handleRemoveClick}>R</Button>}
                    </div> */}
                </Row>
              );
            })}
          </div>
          <Row gutter={[12, 12]}>
            <Col span={22}>
              <Input
                placeholder="Note"
                onChange={(event) => this.setState({ orderNotes: event.target.value })}
                style={{ width: '100%' }}
              />
            </Col>
          </Row>
        </Modal>
      </div>
    );
  }
}

const OrderModalWrapper = (props: any) => {
  const { initialState } = useModel('@@initialState');
  const userDetails = {
    name: initialState?.currentUser?.name || '',
    email: initialState?.currentUser?.email || '',
  };

  return <OrderModal {...props} user={userDetails} />;
};

export default OrderModalWrapper;
