import React, { Component } from 'react';
import { Redirect, history } from 'umi';
import { Spin, Modal } from 'antd';

import Apis from '@/api/apis';
import { storageService } from '@/services/storage';
import { getAuthToken, getCubeJSToken, setUserProfileInLocal } from '@/utils/userProfile';

export default class AuthWrapper extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userProfile: null,
      isLoaded: false,
    };
  }

  componentDidMount() {
    if (getAuthToken() && getCubeJSToken()) {
      Apis.getProfile().then((data) => {
        if (data) {
          // setUserProfileInLocal(data);
          this.setState({ userProfile: data, isLoaded: true });
        } else {
          this.setState({ userProfile: data, isLoaded: false });
        }
      });
    } else {
      Modal.error({
        title: 'Something went wrong!',
        content: 'Authorization token is unavailable or corrupt. Login again.',
        onOk: () => {
          Modal.destroyAll();
          storageService.clear();
          history.push('/user/login');
        },
      });
    }
  }

  render() {
    if (!this.state.isLoaded) return <Spin />;

    if (this.state.userProfile?.role) return <>{this.props.children}</>;

    Modal.error({
      title: 'Something went wrong!',
      content: 'Authorization token is unavailable or corrupt. Login again.',
      onOk: () => {
        Modal.destroyAll();
        storageService.clear();
        history.push('/user/login');
      },
    });
    return <Redirect to="/user/login" />;
  }
}
