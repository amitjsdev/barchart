enum DefaultRoutes {
  'bgi' = '/bgi/inventory',
  'moh' = '/moh/survey-dashboard',
  'nonmoh' = '/non-moh/inventory',
  'tms' = '/tms/dashboard',
  'centralbloodbank' = '/cbb/inventory',
  'peripheralbloodbank' = '/pbb/inventory',
  'branchbloodbank' = '/bbb/inventory',
  'userManagement' = '/user-management',
}

/* export default (userRole: string) => {
  switch (userRole) {
    case 'superAdmin':
      return '/user-management';

    case 'planner':
      return '/bgi-moh/metrics';

    case 'surveyor':
      return '/bgi-moh/survey';

    case 'readSurveyor':
      return '/bgi-moh/survey';

    case 'tms':
      return '/tms/dashboard';

    default:
      return DefaultRoutes[storageService.getItem('type')];
  }
}; */

export default (module: string) => DefaultRoutes[module];
