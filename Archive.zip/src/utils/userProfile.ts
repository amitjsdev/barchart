import { history } from 'umi';
import { Modal } from 'antd';
import { storageService } from '@/services/storage';

/**
 * @deprecated User profile is not stored in localStorage anymore.
 * Use plugin-initial-state instead.
 */
export const setUserProfileInLocal = (userProfile: API.CurrentUser) => {
  storageService.setItem('locationId', userProfile.locationId);
  storageService.setItem('role', userProfile.role);
  storageService.setItem('email', userProfile.email);
  storageService.setItem('name', userProfile.name);
  storageService.setItem('organisationId', userProfile.organisationId);
  storageService.setItem('locationName', userProfile.locationName);
  storageService.setItem('type', userProfile.type);
  storageService.setItem('regionId', userProfile.regionId);
  storageService.setItem('region', userProfile.region);
};

/**
 * @deprecated User profile is not stored in localStorage anymore.
 * Use plugin-initial-state instead.
 */
export const getUserProfileFromLocal = () => {
  try {
    const userProfile = {
      authToken: storageService.getItem('auth-token'),
      locationId: storageService.getItem('locationId'),
      role: storageService.getItem('role'),
      email: storageService.getItem('email'),
      name: storageService.getItem('name'),
      organisationId: storageService.getItem('organisationId'),
      locationName: storageService.getItem('locationName'),
      type: storageService.getItem('type'),
      regionId: storageService.getItem('regionId'),
      region: storageService.getItem('region'),
    };
    return userProfile;
  } catch (err) {
    // return null;
    Modal.error({
      title: 'Something went wrong!',
      content: 'User details is unavailable or corrupt in local storage. Login again.',
      onOk: () => {
        Modal.destroyAll();
        storageService.clear();
        history.push('/user/login');
      },
    });
    return null;
  }
};

/**
 * @deprecated This method shouldn't be used anymore.
 * Use AuthService instead.
 */
export const getAuthToken = () => {
  try {
    return storageService.getItem('auth-token');
  } catch (error) {
    // throw Error('Unable to get Auth token!');
    return null;
  }
};

/**
 * @deprecated This method shouldn't be used anymore.
 * Use AuthService instead.
 */
export const getCubeJSToken = () => {
  try {
    return storageService.getItem('cubejs-token');
  } catch (error) {
    // throw Error('Unable to get Auth token!');
    return null;
  }
};

/**
 * @deprecated User profile is not stored in localStorage anymore.
 * Use plugin-initial-state instead.
 */
export const checkLocalProfileIntegrity = () => {
  try {
    const userProfile = {
      authToken: storageService.getItem('auth-token'),
      locationId: storageService.getItem('locationId'),
      role: storageService.getItem('role'),
      email: storageService.getItem('email'),
      name: storageService.getItem('name'),
      organisationId: storageService.getItem('organisationId'),
      // cubejsToken: storageService.getItem('cubejs-token'),
    };

    return Object.values(userProfile).every((item) => item && item.length);
  } catch (err) {
    /* Modal.error({
      title: 'Something went wrong!',
      content: 'User details is unavailable or corrupt in local storage. Login again.',
      onOk: () => {
        Modal.destroyAll();
        storageService.clear();
        history.push('/user/login');
      },
    }); */
    return false;
  }
};
